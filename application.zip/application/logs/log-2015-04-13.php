<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-13 14:12:22 --> Config Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:12:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:12:22 --> URI Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Router Class Initialized
DEBUG - 2015-04-13 14:12:22 --> No URI present. Default controller set.
DEBUG - 2015-04-13 14:12:22 --> Output Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Security Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Input Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:12:22 --> Language Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Loader Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:12:22 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Session Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:12:22 --> A session cookie was not found.
DEBUG - 2015-04-13 14:12:22 --> Session routines successfully run
DEBUG - 2015-04-13 14:12:22 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Controller Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:22 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:12:22 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:12:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 14:12:22 --> Final output sent to browser
DEBUG - 2015-04-13 14:12:22 --> Total execution time: 0.1104
DEBUG - 2015-04-13 14:12:29 --> Config Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:12:29 --> URI Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Router Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Output Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Security Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Input Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:12:29 --> Language Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Loader Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:12:29 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Session Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:12:29 --> Session routines successfully run
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Controller Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:12:29 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 14:12:29 --> Config Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:12:29 --> URI Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Router Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Output Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Security Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Input Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:12:29 --> Language Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Loader Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:12:29 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Session Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:12:29 --> Session routines successfully run
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Controller Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:12:29 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:12:29 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:12:29 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:12:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:12:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 14:12:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:12:29 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:12:29 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-13 14:12:29 --> Final output sent to browser
DEBUG - 2015-04-13 14:12:29 --> Total execution time: 0.0523
DEBUG - 2015-04-13 14:12:31 --> Config Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:12:31 --> URI Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Router Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Output Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Security Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Input Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:12:31 --> Language Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Loader Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:12:31 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Session Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:12:31 --> Session routines successfully run
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Controller Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:12:31 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:12:31 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:12:31 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:12:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:12:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 14:12:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:12:31 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:12:31 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-13 14:12:31 --> Final output sent to browser
DEBUG - 2015-04-13 14:12:31 --> Total execution time: 0.0750
DEBUG - 2015-04-13 14:12:54 --> Config Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:12:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:12:54 --> URI Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Router Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Output Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Security Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Input Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:12:54 --> Language Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Loader Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:12:54 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Session Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:12:54 --> Session routines successfully run
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Controller Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:12:54 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:12:54 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:12:54 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:12:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:12:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 14:12:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:12:54 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:12:54 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-13 14:12:54 --> Final output sent to browser
DEBUG - 2015-04-13 14:12:54 --> Total execution time: 0.0877
DEBUG - 2015-04-13 14:12:57 --> Config Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:12:57 --> URI Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Router Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Output Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Security Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Input Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:12:57 --> Language Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Loader Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:12:57 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Session Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:12:57 --> Session routines successfully run
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Controller Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Model Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:12:57 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:12:57 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:12:57 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:12:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:12:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 14:12:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:12:57 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:12:57 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-13 14:12:57 --> Final output sent to browser
DEBUG - 2015-04-13 14:12:57 --> Total execution time: 0.0651
DEBUG - 2015-04-13 14:14:21 --> Config Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:14:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:14:21 --> URI Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Router Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Output Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Security Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Input Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:14:21 --> Language Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Loader Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:14:21 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Session Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:14:21 --> Session routines successfully run
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Controller Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:14:21 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:14:21 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:14:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:14:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:14:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 14:14:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:14:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:14:21 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-13 14:14:21 --> Final output sent to browser
DEBUG - 2015-04-13 14:14:21 --> Total execution time: 0.0979
DEBUG - 2015-04-13 14:14:46 --> Config Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:14:46 --> URI Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Router Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Output Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Security Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Input Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:14:46 --> Language Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Loader Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:14:46 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Session Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:14:46 --> Session routines successfully run
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Controller Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:14:46 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Config Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:14:46 --> URI Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Router Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Output Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Security Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Input Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:14:46 --> Language Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Loader Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:14:46 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Session Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:14:46 --> Session routines successfully run
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Controller Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:46 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:14:46 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:14:46 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 14:14:46 --> Final output sent to browser
DEBUG - 2015-04-13 14:14:46 --> Total execution time: 0.0363
DEBUG - 2015-04-13 14:14:53 --> Config Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:14:53 --> URI Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Router Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Output Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Security Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Input Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:14:53 --> Language Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Loader Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:14:53 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Session Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:14:53 --> Session routines successfully run
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Controller Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:14:53 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 14:14:53 --> Config Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:14:53 --> URI Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Router Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Output Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Security Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Input Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:14:53 --> Language Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Loader Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:14:53 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Session Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:14:53 --> Session routines successfully run
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Controller Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Model Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:14:53 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:14:53 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:14:53 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:14:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:14:53 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 14:14:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:14:53 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:14:53 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-13 14:14:53 --> Final output sent to browser
DEBUG - 2015-04-13 14:14:53 --> Total execution time: 0.0417
DEBUG - 2015-04-13 14:16:18 --> Config Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:16:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:16:18 --> URI Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Router Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Output Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Security Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Input Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:16:18 --> Language Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Loader Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:16:18 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Session Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:16:18 --> Session routines successfully run
DEBUG - 2015-04-13 14:16:18 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Controller Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:16:18 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:16:18 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:16:19 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:16:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:16:19 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 14:16:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:16:19 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:16:19 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-13 14:16:19 --> Final output sent to browser
DEBUG - 2015-04-13 14:16:19 --> Total execution time: 0.0528
DEBUG - 2015-04-13 14:16:28 --> Config Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:16:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:16:28 --> URI Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Router Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Output Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Security Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Input Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:16:28 --> Language Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Loader Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:16:28 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Session Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:16:28 --> Session routines successfully run
DEBUG - 2015-04-13 14:16:28 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Controller Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:28 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:16:28 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:16:28 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:16:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:16:28 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 14:16:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:16:28 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:16:28 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-13 14:16:28 --> Final output sent to browser
DEBUG - 2015-04-13 14:16:28 --> Total execution time: 0.0528
DEBUG - 2015-04-13 14:16:29 --> Config Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:16:29 --> URI Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Router Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Output Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Security Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Input Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:16:29 --> Language Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Loader Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:16:29 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Session Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:16:29 --> Session routines successfully run
DEBUG - 2015-04-13 14:16:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Controller Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:29 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:16:29 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:16:29 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:16:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:16:29 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 14:16:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:16:29 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:16:29 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-04-13 14:16:29 --> Final output sent to browser
DEBUG - 2015-04-13 14:16:29 --> Total execution time: 0.0469
DEBUG - 2015-04-13 14:16:30 --> Config Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:16:30 --> URI Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Router Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Output Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Security Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Input Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:16:30 --> Language Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Loader Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:16:30 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Session Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:16:30 --> Session routines successfully run
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Controller Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:16:30 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:16:30 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:16:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:16:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:16:30 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 14:16:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:16:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:16:30 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-13 14:16:30 --> Final output sent to browser
DEBUG - 2015-04-13 14:16:30 --> Total execution time: 0.0589
DEBUG - 2015-04-13 14:16:33 --> Config Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Hooks Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Utf8 Class Initialized
DEBUG - 2015-04-13 14:16:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 14:16:33 --> URI Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Router Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Output Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Security Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Input Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 14:16:33 --> Language Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Loader Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Helper loaded: url_helper
DEBUG - 2015-04-13 14:16:33 --> Database Driver Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Session Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Helper loaded: string_helper
DEBUG - 2015-04-13 14:16:33 --> Session routines successfully run
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Controller Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Model Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Helper loaded: form_helper
DEBUG - 2015-04-13 14:16:33 --> Form Validation Class Initialized
DEBUG - 2015-04-13 14:16:33 --> Pagination Class Initialized
DEBUG - 2015-04-13 14:16:33 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 14:16:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 14:16:33 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 14:16:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 14:16:33 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 14:16:33 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-13 14:16:33 --> Final output sent to browser
DEBUG - 2015-04-13 14:16:33 --> Total execution time: 0.0552
DEBUG - 2015-04-13 16:38:08 --> Config Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:38:08 --> URI Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Router Class Initialized
DEBUG - 2015-04-13 16:38:08 --> No URI present. Default controller set.
DEBUG - 2015-04-13 16:38:08 --> Output Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Security Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Input Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:38:08 --> Language Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Loader Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:38:08 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Session Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:38:08 --> A session cookie was not found.
DEBUG - 2015-04-13 16:38:08 --> Session routines successfully run
DEBUG - 2015-04-13 16:38:08 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Controller Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:08 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:38:08 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:38:08 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:38:08 --> Final output sent to browser
DEBUG - 2015-04-13 16:38:08 --> Total execution time: 0.0586
DEBUG - 2015-04-13 16:38:44 --> Config Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:38:44 --> URI Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Router Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Output Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Security Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Input Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:38:44 --> Language Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Loader Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:38:44 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Session Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:38:44 --> Session routines successfully run
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Controller Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:38:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:38:44 --> Config Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:38:44 --> URI Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Router Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Output Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Security Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Input Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:38:44 --> Language Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Loader Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:38:44 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Session Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:38:44 --> Session routines successfully run
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Controller Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:38:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:38:44 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:38:44 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:38:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:38:44 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 16:38:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:38:44 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:38:44 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-13 16:38:44 --> Final output sent to browser
DEBUG - 2015-04-13 16:38:44 --> Total execution time: 0.0444
DEBUG - 2015-04-13 16:38:53 --> Config Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:38:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:38:53 --> URI Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Router Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Output Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Security Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Input Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:38:53 --> Language Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Loader Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:38:53 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Session Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:38:53 --> Session routines successfully run
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Controller Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:38:53 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Config Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:38:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:38:53 --> URI Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Router Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Output Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Security Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Input Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:38:53 --> Language Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Loader Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:38:53 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Session Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:38:53 --> Session routines successfully run
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Controller Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Model Class Initialized
DEBUG - 2015-04-13 16:38:53 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:38:53 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:38:53 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:38:53 --> Final output sent to browser
DEBUG - 2015-04-13 16:38:53 --> Total execution time: 0.0421
DEBUG - 2015-04-13 16:39:04 --> Config Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:39:04 --> URI Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Router Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Output Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Security Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Input Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:39:04 --> Language Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Loader Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:39:04 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Session Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:39:04 --> Session routines successfully run
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Controller Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:39:04 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:39:04 --> Config Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:39:04 --> URI Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Router Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Output Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Security Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Input Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:39:04 --> Language Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Loader Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:39:04 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Session Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:39:04 --> Session routines successfully run
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Controller Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:39:04 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:39:04 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:39:04 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:39:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:39:04 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 16:39:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:39:04 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:39:05 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-13 16:39:05 --> Final output sent to browser
DEBUG - 2015-04-13 16:39:05 --> Total execution time: 0.0417
DEBUG - 2015-04-13 16:39:51 --> Config Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:39:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:39:51 --> URI Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Router Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Output Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Security Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Input Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:39:51 --> Language Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Loader Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:39:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Session Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:39:51 --> Session routines successfully run
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Controller Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:39:51 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Config Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:39:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:39:51 --> URI Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Router Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Output Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Security Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Input Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:39:51 --> Language Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Loader Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:39:51 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Session Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:39:51 --> Session routines successfully run
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Controller Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Model Class Initialized
DEBUG - 2015-04-13 16:39:51 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:39:51 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:39:51 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:39:51 --> Final output sent to browser
DEBUG - 2015-04-13 16:39:51 --> Total execution time: 0.0376
DEBUG - 2015-04-13 16:40:04 --> Config Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:40:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:40:04 --> URI Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Router Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Output Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Security Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Input Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:40:04 --> Language Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Loader Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:40:04 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Session Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:40:04 --> Session routines successfully run
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Controller Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:40:04 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:40:04 --> Config Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:40:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:40:04 --> URI Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Router Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Output Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Security Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Input Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:40:04 --> Language Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Loader Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:40:04 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Session Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:40:04 --> Session routines successfully run
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Controller Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Model Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:40:04 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:40:04 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:40:04 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:40:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:40:04 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-13 16:40:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:40:04 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:40:04 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-13 16:40:04 --> Final output sent to browser
DEBUG - 2015-04-13 16:40:04 --> Total execution time: 0.0397
DEBUG - 2015-04-13 16:41:10 --> Config Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:41:10 --> URI Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Router Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Output Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Security Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Input Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:41:10 --> Language Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Loader Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:41:10 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Session Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:41:10 --> Session routines successfully run
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Controller Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:41:10 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Config Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:41:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:41:10 --> URI Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Router Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Output Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Security Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Input Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:41:10 --> Language Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Loader Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:41:10 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Session Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:41:10 --> Session routines successfully run
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:10 --> Controller Class Initialized
DEBUG - 2015-04-13 16:41:11 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:11 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:11 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:11 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:11 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:41:11 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:41:11 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:41:11 --> Final output sent to browser
DEBUG - 2015-04-13 16:41:11 --> Total execution time: 0.0403
DEBUG - 2015-04-13 16:41:18 --> Config Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:41:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:41:18 --> URI Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Router Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Output Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Security Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Input Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:41:18 --> Language Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Loader Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:41:18 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Session Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:41:18 --> Session routines successfully run
DEBUG - 2015-04-13 16:41:18 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Controller Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:41:18 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:41:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:41:18 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:41:18 --> Final output sent to browser
DEBUG - 2015-04-13 16:41:18 --> Total execution time: 0.0304
DEBUG - 2015-04-13 16:41:29 --> Config Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:41:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:41:29 --> URI Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Router Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Output Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Security Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Input Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:41:29 --> Language Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Loader Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:41:29 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Session Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:41:29 --> Session routines successfully run
DEBUG - 2015-04-13 16:41:29 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Controller Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Model Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:41:29 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:41:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:41:29 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:41:29 --> Final output sent to browser
DEBUG - 2015-04-13 16:41:29 --> Total execution time: 0.0314
DEBUG - 2015-04-13 16:52:47 --> Config Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:52:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:52:47 --> URI Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Router Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Output Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Security Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Input Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:52:47 --> Language Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Loader Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:52:47 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Session Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:52:47 --> Session routines successfully run
DEBUG - 2015-04-13 16:52:47 --> Model Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Model Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Controller Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Model Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Model Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Model Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Model Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:52:47 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:52:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:52:47 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:52:47 --> Final output sent to browser
DEBUG - 2015-04-13 16:52:47 --> Total execution time: 0.0476
DEBUG - 2015-04-13 16:53:07 --> Config Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:53:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:53:07 --> URI Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Router Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Output Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Security Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Input Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:53:07 --> Language Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Loader Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:53:07 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Session Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:53:07 --> Session routines successfully run
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Controller Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:53:07 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:53:07 --> Config Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:53:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:53:07 --> URI Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Router Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Output Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Security Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Input Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:53:07 --> Language Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Loader Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:53:07 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Session Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:53:07 --> Session routines successfully run
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Controller Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:53:07 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:53:07 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:53:07 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:53:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:53:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:53:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:53:07 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:53:07 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-13 16:53:07 --> Final output sent to browser
DEBUG - 2015-04-13 16:53:07 --> Total execution time: 0.0442
DEBUG - 2015-04-13 16:53:12 --> Config Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:53:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:53:12 --> URI Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Router Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Output Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Security Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Input Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:53:12 --> Language Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Loader Class Initialized
DEBUG - 2015-04-13 16:53:12 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:53:12 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Session Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:53:13 --> Session routines successfully run
DEBUG - 2015-04-13 16:53:13 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Controller Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:53:13 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:53:13 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:53:13 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:53:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:53:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:53:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:53:13 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:53:13 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-13 16:53:13 --> Final output sent to browser
DEBUG - 2015-04-13 16:53:13 --> Total execution time: 0.0523
DEBUG - 2015-04-13 16:53:16 --> Config Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:53:16 --> URI Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Router Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Output Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Security Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Input Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:53:16 --> Language Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Loader Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:53:16 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Session Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:53:16 --> Session routines successfully run
DEBUG - 2015-04-13 16:53:16 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Controller Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:53:16 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:53:16 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:53:16 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:53:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:53:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:53:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:53:16 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:53:16 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-13 16:53:16 --> Final output sent to browser
DEBUG - 2015-04-13 16:53:16 --> Total execution time: 0.0431
DEBUG - 2015-04-13 16:53:23 --> Config Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:53:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:53:23 --> URI Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Router Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Output Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Security Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Input Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:53:23 --> Language Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Loader Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:53:23 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Session Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:53:23 --> Session routines successfully run
DEBUG - 2015-04-13 16:53:23 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Controller Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Model Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:53:23 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:53:23 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-04-13 16:53:23 --> Severity: Notice  --> Undefined index: customer_project /Applications/MAMP/htdocs/asmc/crm/application/controllers/customer.php 194
ERROR - 2015-04-13 16:53:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-13 16:53:23 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:53:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:53:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:53:23 --> File loaded: application/views/sidebar.php
ERROR - 2015-04-13 16:53:23 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-13 16:53:23 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:53:23 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-13 16:53:23 --> Final output sent to browser
DEBUG - 2015-04-13 16:53:23 --> Total execution time: 0.0521
DEBUG - 2015-04-13 16:55:30 --> Config Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:55:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:55:30 --> URI Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Router Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Output Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Security Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Input Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:55:30 --> Language Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Loader Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:55:30 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Session Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:55:30 --> Session routines successfully run
DEBUG - 2015-04-13 16:55:30 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Controller Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:55:30 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:55:30 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-04-13 16:55:30 --> Severity: Notice  --> Undefined index: customer_project /Applications/MAMP/htdocs/asmc/crm/application/controllers/customer.php 194
ERROR - 2015-04-13 16:55:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-13 16:55:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:55:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:55:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:55:30 --> File loaded: application/views/sidebar.php
ERROR - 2015-04-13 16:55:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-13 16:55:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:55:30 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-13 16:55:30 --> Final output sent to browser
DEBUG - 2015-04-13 16:55:30 --> Total execution time: 0.0573
DEBUG - 2015-04-13 16:55:41 --> Config Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:55:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:55:41 --> URI Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Router Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Output Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Security Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Input Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:55:41 --> Language Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Loader Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:55:41 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Session Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:55:41 --> Session routines successfully run
DEBUG - 2015-04-13 16:55:41 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Controller Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:55:41 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:55:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-13 16:55:41 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:55:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:55:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:55:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:55:41 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:55:41 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-13 16:55:41 --> Final output sent to browser
DEBUG - 2015-04-13 16:55:41 --> Total execution time: 0.0398
DEBUG - 2015-04-13 16:55:48 --> Config Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:55:48 --> URI Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Router Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Output Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Security Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Input Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:55:48 --> Language Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Loader Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:55:48 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Session Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:55:48 --> Session routines successfully run
DEBUG - 2015-04-13 16:55:48 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Controller Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Model Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:55:48 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:55:48 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:55:48 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:55:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:55:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:55:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:55:48 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:55:48 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-13 16:55:48 --> Final output sent to browser
DEBUG - 2015-04-13 16:55:48 --> Total execution time: 0.0431
DEBUG - 2015-04-13 16:56:38 --> Config Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:56:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:56:38 --> URI Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Router Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Output Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Security Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Input Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:56:38 --> Language Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Loader Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:56:38 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Session Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:56:38 --> Session routines successfully run
DEBUG - 2015-04-13 16:56:38 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Controller Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:56:38 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:56:38 --> Pagination Class Initialized
DEBUG - 2015-04-13 16:56:38 --> File loaded: application/views/header.php
DEBUG - 2015-04-13 16:56:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-13 16:56:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-13 16:56:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-13 16:56:38 --> File loaded: application/views/footer.php
DEBUG - 2015-04-13 16:56:38 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-13 16:56:38 --> Final output sent to browser
DEBUG - 2015-04-13 16:56:38 --> Total execution time: 0.0439
DEBUG - 2015-04-13 16:56:44 --> Config Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:56:44 --> URI Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Router Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Output Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Security Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Input Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:56:44 --> Language Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Loader Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:56:44 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Session Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:56:44 --> Session routines successfully run
DEBUG - 2015-04-13 16:56:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Controller Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:44 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:56:44 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Config Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Hooks Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Utf8 Class Initialized
DEBUG - 2015-04-13 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-13 16:56:45 --> URI Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Router Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Output Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Security Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Input Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-13 16:56:45 --> Language Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Loader Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Helper loaded: url_helper
DEBUG - 2015-04-13 16:56:45 --> Database Driver Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Session Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Helper loaded: string_helper
DEBUG - 2015-04-13 16:56:45 --> Session routines successfully run
DEBUG - 2015-04-13 16:56:45 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Controller Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Model Class Initialized
DEBUG - 2015-04-13 16:56:45 --> Helper loaded: form_helper
DEBUG - 2015-04-13 16:56:45 --> Form Validation Class Initialized
DEBUG - 2015-04-13 16:56:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-13 16:56:45 --> Final output sent to browser
DEBUG - 2015-04-13 16:56:45 --> Total execution time: 0.0350
