<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-09-29 22:47:53 --> Config Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:47:53 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:47:53 --> URI Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Router Class Initialized
DEBUG - 2015-09-29 22:47:53 --> No URI present. Default controller set.
DEBUG - 2015-09-29 22:47:53 --> Output Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Security Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Input Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:47:53 --> Language Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Loader Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:47:53 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Session Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:47:53 --> A session cookie was not found.
DEBUG - 2015-09-29 22:47:53 --> Session routines successfully run
DEBUG - 2015-09-29 22:47:53 --> Model Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Model Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Controller Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Model Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Model Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Model Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Model Class Initialized
DEBUG - 2015-09-29 22:47:53 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:47:53 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:47:53 --> File loaded: application/views/loginView.php
DEBUG - 2015-09-29 22:47:53 --> Final output sent to browser
DEBUG - 2015-09-29 22:47:53 --> Total execution time: 0.2112
DEBUG - 2015-09-29 22:47:54 --> Config Class Initialized
DEBUG - 2015-09-29 22:47:54 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:47:54 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:47:54 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:47:54 --> URI Class Initialized
DEBUG - 2015-09-29 22:47:54 --> Router Class Initialized
ERROR - 2015-09-29 22:47:54 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:50:16 --> Config Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:50:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:50:16 --> URI Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Router Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Output Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Security Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Input Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:50:16 --> Language Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Loader Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:50:16 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Session Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:50:16 --> Session routines successfully run
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Controller Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:50:16 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 22:50:16 --> Config Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:50:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:50:16 --> URI Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Router Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Output Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Security Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Input Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:50:16 --> Language Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Loader Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:50:16 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Session Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:50:16 --> Session routines successfully run
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Controller Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:16 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:50:16 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:50:16 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:50:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:50:16 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-09-29 22:50:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:50:16 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:50:16 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-09-29 22:50:16 --> Final output sent to browser
DEBUG - 2015-09-29 22:50:16 --> Total execution time: 0.0435
DEBUG - 2015-09-29 22:50:17 --> Config Class Initialized
DEBUG - 2015-09-29 22:50:17 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:50:17 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:50:17 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:50:17 --> URI Class Initialized
DEBUG - 2015-09-29 22:50:17 --> Router Class Initialized
ERROR - 2015-09-29 22:50:17 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:50:32 --> Config Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:50:32 --> URI Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Router Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Output Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Security Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Input Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:50:32 --> Language Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Loader Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:50:32 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Session Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:50:32 --> Session routines successfully run
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Controller Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Model Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:50:32 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:50:32 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:50:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:50:32 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-09-29 22:50:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:50:32 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:50:32 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-09-29 22:50:32 --> Final output sent to browser
DEBUG - 2015-09-29 22:50:32 --> Total execution time: 0.0863
DEBUG - 2015-09-29 22:50:32 --> Config Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:50:32 --> URI Class Initialized
DEBUG - 2015-09-29 22:50:32 --> Router Class Initialized
ERROR - 2015-09-29 22:50:32 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:51:41 --> Config Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:51:41 --> URI Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Router Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Output Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Security Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Input Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:51:41 --> Language Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Loader Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:51:41 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Session Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:51:41 --> Session routines successfully run
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Controller Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Model Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:51:41 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:51:41 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:51:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:51:41 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-09-29 22:51:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:51:41 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:51:41 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-09-29 22:51:41 --> Final output sent to browser
DEBUG - 2015-09-29 22:51:41 --> Total execution time: 0.0643
DEBUG - 2015-09-29 22:51:41 --> Config Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:51:41 --> URI Class Initialized
DEBUG - 2015-09-29 22:51:41 --> Router Class Initialized
ERROR - 2015-09-29 22:51:41 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:52:08 --> Config Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:52:08 --> URI Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Router Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Output Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Security Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Input Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:52:08 --> Language Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Loader Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:52:08 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Session Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:52:08 --> Session routines successfully run
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Controller Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Model Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:52:08 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:52:08 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:52:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:52:08 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-09-29 22:52:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:52:08 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:52:08 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-09-29 22:52:08 --> Final output sent to browser
DEBUG - 2015-09-29 22:52:08 --> Total execution time: 0.0572
DEBUG - 2015-09-29 22:52:08 --> Config Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:52:08 --> URI Class Initialized
DEBUG - 2015-09-29 22:52:08 --> Router Class Initialized
ERROR - 2015-09-29 22:52:08 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:55:22 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:22 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Router Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Output Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Security Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Input Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:55:22 --> Language Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Loader Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:55:22 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Session Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:55:22 --> Session routines successfully run
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Controller Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:55:22 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:22 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Router Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Output Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Security Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Input Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:55:22 --> Language Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Loader Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:55:22 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Session Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:55:22 --> Session routines successfully run
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Controller Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:55:22 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:55:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-09-29 22:55:22 --> Final output sent to browser
DEBUG - 2015-09-29 22:55:22 --> Total execution time: 0.0318
DEBUG - 2015-09-29 22:55:22 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:22 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:22 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:22 --> Router Class Initialized
ERROR - 2015-09-29 22:55:22 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:55:27 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:27 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Router Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Output Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Security Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Input Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:55:27 --> Language Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Loader Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:55:27 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Session Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:55:27 --> Session routines successfully run
DEBUG - 2015-09-29 22:55:27 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Controller Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:55:27 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 22:55:27 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:27 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:27 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Router Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Output Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Security Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Input Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:55:27 --> Language Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Loader Class Initialized
DEBUG - 2015-09-29 22:55:27 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:55:28 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Session Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:55:28 --> Session routines successfully run
DEBUG - 2015-09-29 22:55:28 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Controller Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:55:28 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:55:28 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:55:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:55:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-09-29 22:55:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:55:28 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:55:28 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-09-29 22:55:28 --> Final output sent to browser
DEBUG - 2015-09-29 22:55:28 --> Total execution time: 0.0409
DEBUG - 2015-09-29 22:55:28 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:28 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:28 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:28 --> Router Class Initialized
ERROR - 2015-09-29 22:55:28 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:55:31 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:31 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Router Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Output Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Security Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Input Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:55:31 --> Language Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Loader Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:55:31 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Session Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:55:31 --> Session routines successfully run
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Controller Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:55:31 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:55:31 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:55:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:55:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-09-29 22:55:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:55:31 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:55:31 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-09-29 22:55:31 --> Final output sent to browser
DEBUG - 2015-09-29 22:55:31 --> Total execution time: 0.1874
DEBUG - 2015-09-29 22:55:31 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:31 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:31 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:32 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:32 --> Router Class Initialized
ERROR - 2015-09-29 22:55:32 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:55:34 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:34 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Router Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Output Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Security Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Input Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:55:34 --> Language Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Loader Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:55:34 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Session Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:55:34 --> Session routines successfully run
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Controller Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Model Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:55:34 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:55:34 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:55:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:55:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-09-29 22:55:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:55:34 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:55:34 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-09-29 22:55:34 --> Final output sent to browser
DEBUG - 2015-09-29 22:55:34 --> Total execution time: 0.0844
DEBUG - 2015-09-29 22:55:34 --> Config Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:55:34 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:55:34 --> URI Class Initialized
DEBUG - 2015-09-29 22:55:34 --> Router Class Initialized
ERROR - 2015-09-29 22:55:34 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:58:58 --> Config Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:58:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:58:58 --> URI Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Router Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Output Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Security Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Input Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:58:58 --> Language Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Loader Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:58:58 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Session Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:58:58 --> Session routines successfully run
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Controller Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Model Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:58:58 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:58:58 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:58:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:58:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-09-29 22:58:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:58:58 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:58:58 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-09-29 22:58:58 --> Final output sent to browser
DEBUG - 2015-09-29 22:58:58 --> Total execution time: 0.0976
DEBUG - 2015-09-29 22:58:58 --> Config Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:58:58 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:58:58 --> URI Class Initialized
DEBUG - 2015-09-29 22:58:58 --> Router Class Initialized
ERROR - 2015-09-29 22:58:58 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:59:01 --> Config Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:59:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:59:01 --> URI Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Router Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Output Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Security Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Input Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:59:01 --> Language Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Loader Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:59:01 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Session Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:59:01 --> Session routines successfully run
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Controller Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:59:01 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:59:01 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:59:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:59:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-09-29 22:59:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:59:01 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:59:01 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-09-29 22:59:01 --> Final output sent to browser
DEBUG - 2015-09-29 22:59:01 --> Total execution time: 0.0681
DEBUG - 2015-09-29 22:59:01 --> Config Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:59:01 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:59:01 --> URI Class Initialized
DEBUG - 2015-09-29 22:59:01 --> Router Class Initialized
ERROR - 2015-09-29 22:59:01 --> 404 Page Not Found --> js
DEBUG - 2015-09-29 22:59:15 --> Config Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:59:15 --> URI Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Router Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Output Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Security Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Input Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:59:15 --> Language Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Loader Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:59:15 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Session Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:59:15 --> Session routines successfully run
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Controller Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:59:15 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-09-29 22:59:15 --> Config Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:59:15 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:59:15 --> URI Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Router Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Output Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Security Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Input Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-09-29 22:59:15 --> Language Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Loader Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Helper loaded: url_helper
DEBUG - 2015-09-29 22:59:15 --> Database Driver Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Session Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Helper loaded: string_helper
DEBUG - 2015-09-29 22:59:15 --> Session routines successfully run
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Controller Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Model Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Helper loaded: form_helper
DEBUG - 2015-09-29 22:59:15 --> Form Validation Class Initialized
DEBUG - 2015-09-29 22:59:15 --> Pagination Class Initialized
DEBUG - 2015-09-29 22:59:15 --> File loaded: application/views/header.php
DEBUG - 2015-09-29 22:59:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-09-29 22:59:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-09-29 22:59:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-09-29 22:59:15 --> File loaded: application/views/footer.php
DEBUG - 2015-09-29 22:59:15 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-09-29 22:59:15 --> Final output sent to browser
DEBUG - 2015-09-29 22:59:15 --> Total execution time: 0.0681
DEBUG - 2015-09-29 22:59:16 --> Config Class Initialized
DEBUG - 2015-09-29 22:59:16 --> Hooks Class Initialized
DEBUG - 2015-09-29 22:59:16 --> Utf8 Class Initialized
DEBUG - 2015-09-29 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2015-09-29 22:59:16 --> URI Class Initialized
DEBUG - 2015-09-29 22:59:16 --> Router Class Initialized
ERROR - 2015-09-29 22:59:16 --> 404 Page Not Found --> js
