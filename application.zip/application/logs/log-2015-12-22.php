<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-22 12:08:15 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:15 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:15 --> No URI present. Default controller set.
DEBUG - 2015-12-22 12:08:15 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:15 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:15 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:15 --> A session cookie was not found.
DEBUG - 2015-12-22 12:08:15 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:15 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:15 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:15 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-22 12:08:15 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:15 --> Total execution time: 0.1224
DEBUG - 2015-12-22 12:08:16 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:16 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:16 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:16 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:16 --> Router Class Initialized
ERROR - 2015-12-22 12:08:16 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:23 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:23 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:23 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:23 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:23 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:23 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:08:23 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-22 12:08:23 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:23 --> Total execution time: 0.1131
DEBUG - 2015-12-22 12:08:23 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:23 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:23 --> Router Class Initialized
ERROR - 2015-12-22 12:08:23 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:30 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:30 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:30 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:30 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:30 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:08:30 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:30 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:30 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:30 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:30 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:08:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:08:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:08:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:08:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:08:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:08:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-22 12:08:30 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:30 --> Total execution time: 0.0494
DEBUG - 2015-12-22 12:08:30 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:30 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:30 --> Router Class Initialized
ERROR - 2015-12-22 12:08:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:33 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:33 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:33 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:33 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:33 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:33 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:08:33 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:08:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:08:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:08:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:08:33 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:08:33 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:08:33 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:33 --> Total execution time: 0.1884
DEBUG - 2015-12-22 12:08:33 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:33 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:33 --> Router Class Initialized
ERROR - 2015-12-22 12:08:33 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:39 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:39 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:39 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:39 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:39 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:39 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:08:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:08:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:08:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:08:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:08:39 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:08:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:08:39 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:39 --> Total execution time: 0.0964
DEBUG - 2015-12-22 12:08:39 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:39 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:39 --> Router Class Initialized
ERROR - 2015-12-22 12:08:39 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:50 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:50 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:50 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:50 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:50 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:50 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:08:50 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:08:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:08:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:08:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:08:50 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:08:50 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:08:50 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:50 --> Total execution time: 0.0953
DEBUG - 2015-12-22 12:08:50 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:50 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:50 --> Router Class Initialized
ERROR - 2015-12-22 12:08:50 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:53 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:53 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:53 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:53 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:53 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:53 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:08:53 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:08:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:08:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:08:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:08:53 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:08:53 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:08:53 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:53 --> Total execution time: 0.0789
DEBUG - 2015-12-22 12:08:53 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:53 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:53 --> Router Class Initialized
ERROR - 2015-12-22 12:08:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:08:58 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:58 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Router Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Output Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Security Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Input Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:08:58 --> Language Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Loader Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:08:58 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Session Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:08:58 --> Session routines successfully run
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Controller Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Model Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:08:58 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:08:58 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:08:58 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:08:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:08:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:08:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:08:58 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:08:58 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:08:58 --> Final output sent to browser
DEBUG - 2015-12-22 12:08:58 --> Total execution time: 0.0737
DEBUG - 2015-12-22 12:08:59 --> Config Class Initialized
DEBUG - 2015-12-22 12:08:59 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:08:59 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:08:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:08:59 --> URI Class Initialized
DEBUG - 2015-12-22 12:08:59 --> Router Class Initialized
ERROR - 2015-12-22 12:08:59 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:09:03 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:03 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Router Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Output Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Security Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Input Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:09:03 --> Language Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Loader Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:09:03 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Session Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:09:03 --> Session routines successfully run
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Controller Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:09:03 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:09:03 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:09:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:09:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:09:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:09:03 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:09:03 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:09:03 --> Final output sent to browser
DEBUG - 2015-12-22 12:09:03 --> Total execution time: 0.0727
DEBUG - 2015-12-22 12:09:03 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:03 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:03 --> Router Class Initialized
ERROR - 2015-12-22 12:09:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:09:07 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:07 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Router Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Output Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Security Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Input Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:09:07 --> Language Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Loader Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:09:07 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Session Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:09:07 --> Session routines successfully run
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Controller Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:09:07 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:09:07 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:09:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:09:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:09:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:09:07 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:09:07 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:09:07 --> Final output sent to browser
DEBUG - 2015-12-22 12:09:07 --> Total execution time: 0.0739
DEBUG - 2015-12-22 12:09:07 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:07 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:07 --> Router Class Initialized
ERROR - 2015-12-22 12:09:07 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:09:10 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:10 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Router Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Output Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Security Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Input Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:09:10 --> Language Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Loader Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:09:10 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Session Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:09:10 --> Session routines successfully run
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Controller Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:09:10 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:09:10 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:09:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:09:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:09:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:09:10 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:09:10 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-22 12:09:10 --> Final output sent to browser
DEBUG - 2015-12-22 12:09:10 --> Total execution time: 0.0696
DEBUG - 2015-12-22 12:09:10 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:10 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:10 --> Router Class Initialized
ERROR - 2015-12-22 12:09:10 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:09:18 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:18 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Router Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Output Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Security Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Input Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:09:18 --> Language Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Loader Class Initialized
DEBUG - 2015-12-22 12:09:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:09:19 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Session Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:09:19 --> Session routines successfully run
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Controller Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Model Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:09:19 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:09:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:09:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:09:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:09:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:09:19 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:09:19 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:09:19 --> Final output sent to browser
DEBUG - 2015-12-22 12:09:19 --> Total execution time: 0.1207
DEBUG - 2015-12-22 12:09:19 --> Config Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:09:19 --> URI Class Initialized
DEBUG - 2015-12-22 12:09:19 --> Router Class Initialized
ERROR - 2015-12-22 12:09:19 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:11:04 --> Config Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:11:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:11:04 --> URI Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Router Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Output Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Security Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Input Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:11:04 --> Language Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Loader Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:11:04 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Session Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:11:04 --> Session routines successfully run
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Controller Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:11:04 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:11:04 --> Pagination Class Initialized
ERROR - 2015-12-22 12:11:04 --> Severity: Notice  --> Undefined index: id /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 142
DEBUG - 2015-12-22 12:11:04 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:11:04 --> DB Transaction Failure
ERROR - 2015-12-22 12:11:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4
DEBUG - 2015-12-22 12:11:04 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-22 12:11:04 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 442
DEBUG - 2015-12-22 12:11:08 --> Config Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:11:08 --> URI Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Router Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Output Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Security Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Input Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:11:08 --> Language Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Loader Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:11:08 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Session Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:11:08 --> Session routines successfully run
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Controller Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Model Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:11:08 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:11:08 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:11:09 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2015-12-22 12:11:09 --> Final output sent to browser
DEBUG - 2015-12-22 12:11:09 --> Total execution time: 1.3922
DEBUG - 2015-12-22 12:13:16 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:16 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Router Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Output Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Security Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Input Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:13:16 --> Language Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Loader Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:13:16 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Session Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:13:16 --> Session routines successfully run
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Controller Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:13:16 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:13:16 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:13:17 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2015-12-22 12:13:17 --> Final output sent to browser
DEBUG - 2015-12-22 12:13:17 --> Total execution time: 1.3367
DEBUG - 2015-12-22 12:13:26 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:26 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:26 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:26 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:26 --> Router Class Initialized
ERROR - 2015-12-22 12:13:26 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:13:29 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:29 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Router Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Output Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Security Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Input Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:13:29 --> Language Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Loader Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:13:29 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Session Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:13:29 --> Session routines successfully run
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Controller Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:13:29 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:13:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:13:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:13:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:13:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:13:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:13:29 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:13:29 --> Final output sent to browser
DEBUG - 2015-12-22 12:13:29 --> Total execution time: 0.0750
DEBUG - 2015-12-22 12:13:29 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:29 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:29 --> Router Class Initialized
ERROR - 2015-12-22 12:13:29 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:13:34 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:34 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Router Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Output Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Security Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Input Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:13:34 --> Language Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Loader Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:13:34 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Session Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:13:34 --> Session routines successfully run
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Controller Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:13:34 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:13:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:13:34 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:13:34 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:13:36 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-22 12:13:37 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2015-12-22 12:13:38 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:38 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Router Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Output Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Security Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Input Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:13:38 --> Language Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Loader Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:13:38 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Session Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:13:38 --> Session routines successfully run
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Controller Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Model Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:13:38 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:13:38 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:13:38 --> Final output sent to browser
DEBUG - 2015-12-22 12:13:38 --> Total execution time: 0.0583
DEBUG - 2015-12-22 12:13:38 --> Config Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:13:38 --> URI Class Initialized
DEBUG - 2015-12-22 12:13:38 --> Router Class Initialized
ERROR - 2015-12-22 12:13:38 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:18:47 --> Config Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:18:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:18:47 --> URI Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Router Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Output Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Security Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Input Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:18:47 --> Language Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Loader Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:18:47 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Session Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:18:47 --> Session routines successfully run
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Controller Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:18:47 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:18:47 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:18:47 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:18:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:18:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:18:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:18:47 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:18:47 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:18:47 --> Final output sent to browser
DEBUG - 2015-12-22 12:18:47 --> Total execution time: 0.0959
DEBUG - 2015-12-22 12:18:48 --> Config Class Initialized
DEBUG - 2015-12-22 12:18:48 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:18:48 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:18:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:18:48 --> URI Class Initialized
DEBUG - 2015-12-22 12:18:48 --> Router Class Initialized
ERROR - 2015-12-22 12:18:48 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:18:51 --> Config Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:18:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:18:51 --> URI Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Router Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Output Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Security Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Input Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:18:51 --> Language Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Loader Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:18:51 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Session Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:18:51 --> Session routines successfully run
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Controller Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:18:51 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:18:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:18:51 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:18:51 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:18:53 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-22 12:18:54 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2015-12-22 12:18:55 --> Config Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:18:55 --> URI Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Router Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Output Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Security Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Input Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:18:55 --> Language Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Loader Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:18:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Session Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:18:55 --> Session routines successfully run
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Controller Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Model Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:18:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:18:55 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:18:55 --> Final output sent to browser
DEBUG - 2015-12-22 12:18:55 --> Total execution time: 0.0531
DEBUG - 2015-12-22 12:18:55 --> Config Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:18:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:18:55 --> URI Class Initialized
DEBUG - 2015-12-22 12:18:55 --> Router Class Initialized
ERROR - 2015-12-22 12:18:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:19:07 --> Config Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:19:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:19:07 --> URI Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Router Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Output Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Security Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Input Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:19:07 --> Language Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Loader Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:19:07 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Session Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:19:07 --> Session routines successfully run
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Controller Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:19:07 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:19:07 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:19:07 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:19:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:19:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:19:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:19:07 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:19:07 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:19:07 --> Final output sent to browser
DEBUG - 2015-12-22 12:19:07 --> Total execution time: 0.0770
DEBUG - 2015-12-22 12:19:08 --> Config Class Initialized
DEBUG - 2015-12-22 12:19:08 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:19:08 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:19:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:19:08 --> URI Class Initialized
DEBUG - 2015-12-22 12:19:08 --> Router Class Initialized
ERROR - 2015-12-22 12:19:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:19:16 --> Config Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:19:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:19:16 --> URI Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Router Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Output Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Security Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Input Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:19:16 --> Language Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Loader Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:19:16 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Session Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:19:16 --> Session routines successfully run
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Controller Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:19:16 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:19:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:19:16 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:19:17 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:19:18 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-22 12:19:19 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2015-12-22 12:19:21 --> Config Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:19:21 --> URI Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Router Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Output Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Security Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Input Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:19:21 --> Language Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Loader Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:19:21 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Session Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:19:21 --> Session routines successfully run
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Controller Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Model Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:19:21 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:19:21 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:19:21 --> Final output sent to browser
DEBUG - 2015-12-22 12:19:21 --> Total execution time: 0.0610
DEBUG - 2015-12-22 12:19:21 --> Config Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:19:21 --> URI Class Initialized
DEBUG - 2015-12-22 12:19:21 --> Router Class Initialized
ERROR - 2015-12-22 12:19:21 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:20:02 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:02 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Router Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Output Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Security Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Input Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:20:02 --> Language Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Loader Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:20:02 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Session Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:20:02 --> Session routines successfully run
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Controller Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:20:02 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:20:02 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:20:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:20:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:20:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:20:02 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:20:02 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:20:02 --> Final output sent to browser
DEBUG - 2015-12-22 12:20:02 --> Total execution time: 0.0758
DEBUG - 2015-12-22 12:20:02 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:02 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:02 --> Router Class Initialized
ERROR - 2015-12-22 12:20:02 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:20:05 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:05 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Router Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Output Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Security Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Input Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:20:05 --> Language Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Loader Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:20:05 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Session Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:20:05 --> Session routines successfully run
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Controller Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:20:05 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:20:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:20:05 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:20:06 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:20:07 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-22 12:20:08 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2015-12-22 12:20:09 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:09 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Router Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Output Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Security Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Input Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:20:09 --> Language Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Loader Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:20:09 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Session Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:20:09 --> Session routines successfully run
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Controller Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:20:09 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:20:09 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:20:09 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:20:09 --> Final output sent to browser
DEBUG - 2015-12-22 12:20:09 --> Total execution time: 0.0553
DEBUG - 2015-12-22 12:20:10 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:10 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:10 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:10 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:10 --> Router Class Initialized
ERROR - 2015-12-22 12:20:10 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:20:18 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:18 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Router Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Output Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Security Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Input Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:20:18 --> Language Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Loader Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:20:18 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Session Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:20:18 --> Session routines successfully run
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Controller Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:20:18 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:20:18 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:20:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:20:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:20:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:20:18 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:20:18 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:20:18 --> Final output sent to browser
DEBUG - 2015-12-22 12:20:18 --> Total execution time: 0.0573
DEBUG - 2015-12-22 12:20:18 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:18 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:18 --> Router Class Initialized
ERROR - 2015-12-22 12:20:18 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:20:24 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:24 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Router Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Output Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Security Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Input Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:20:24 --> Language Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Loader Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:20:24 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Session Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:20:24 --> Session routines successfully run
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Controller Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:20:24 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:20:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:20:24 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:20:25 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:20:26 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 12:20:27 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-22 12:20:28 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:28 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Router Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Output Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Security Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Input Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:20:28 --> Language Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Loader Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:20:28 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Session Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:20:28 --> Session routines successfully run
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Controller Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Model Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:20:28 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:20:28 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:20:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:20:28 --> Final output sent to browser
DEBUG - 2015-12-22 12:20:28 --> Total execution time: 0.0604
DEBUG - 2015-12-22 12:20:29 --> Config Class Initialized
DEBUG - 2015-12-22 12:20:29 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:20:29 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:20:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:20:29 --> URI Class Initialized
DEBUG - 2015-12-22 12:20:29 --> Router Class Initialized
ERROR - 2015-12-22 12:20:29 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:26:15 --> Config Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:26:15 --> URI Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Router Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Output Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Security Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Input Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:26:15 --> Language Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Loader Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:26:15 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Session Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:26:15 --> Session routines successfully run
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Controller Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Model Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:26:15 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:26:15 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:26:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:26:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:26:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:26:15 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:26:15 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-22 12:26:15 --> Final output sent to browser
DEBUG - 2015-12-22 12:26:15 --> Total execution time: 0.0683
DEBUG - 2015-12-22 12:26:15 --> Config Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:26:15 --> URI Class Initialized
DEBUG - 2015-12-22 12:26:15 --> Router Class Initialized
ERROR - 2015-12-22 12:26:15 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:38:55 --> Config Class Initialized
DEBUG - 2015-12-22 12:38:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:38:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:38:55 --> URI Class Initialized
DEBUG - 2015-12-22 12:38:55 --> Router Class Initialized
ERROR - 2015-12-22 12:38:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:39:00 --> Config Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:39:00 --> URI Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Router Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Output Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Security Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Input Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:39:00 --> Language Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Loader Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:39:00 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Session Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:39:00 --> Session routines successfully run
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Controller Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:39:00 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:39:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:39:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:39:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:39:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:39:00 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:39:00 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:39:00 --> Final output sent to browser
DEBUG - 2015-12-22 12:39:00 --> Total execution time: 0.0794
DEBUG - 2015-12-22 12:39:00 --> Config Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:39:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:39:00 --> URI Class Initialized
DEBUG - 2015-12-22 12:39:00 --> Router Class Initialized
ERROR - 2015-12-22 12:39:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:39:49 --> Config Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:39:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:39:49 --> URI Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Router Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Output Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Security Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Input Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:39:49 --> Language Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Loader Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:39:49 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Session Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:39:49 --> Session routines successfully run
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Controller Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Model Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:39:49 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:39:49 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:39:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:39:50 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:39:50 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:40:32 --> Config Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:40:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:40:32 --> URI Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Router Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Output Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Security Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Input Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:40:32 --> Language Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Loader Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:40:32 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Session Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:40:32 --> Session routines successfully run
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Controller Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:40:32 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:40:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:40:32 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:40:32 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:40:34 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 12:40:35 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-22 12:40:36 --> Config Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:40:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:40:36 --> URI Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Router Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Output Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Security Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Input Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:40:36 --> Language Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Loader Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:40:36 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Session Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:40:36 --> Session routines successfully run
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Controller Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Model Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:40:36 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:40:36 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:40:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:40:36 --> Final output sent to browser
DEBUG - 2015-12-22 12:40:36 --> Total execution time: 0.0558
DEBUG - 2015-12-22 12:40:37 --> Config Class Initialized
DEBUG - 2015-12-22 12:40:37 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:40:37 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:40:37 --> URI Class Initialized
DEBUG - 2015-12-22 12:40:37 --> Router Class Initialized
ERROR - 2015-12-22 12:40:37 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:47:05 --> Config Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:47:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:47:05 --> URI Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Router Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Output Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Security Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Input Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:47:05 --> Language Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Loader Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:47:05 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Session Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:47:05 --> Session routines successfully run
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Controller Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:47:05 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:47:05 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:47:05 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:47:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:47:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:47:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:47:05 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:47:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-22 12:47:05 --> Final output sent to browser
DEBUG - 2015-12-22 12:47:05 --> Total execution time: 0.0814
DEBUG - 2015-12-22 12:47:06 --> Config Class Initialized
DEBUG - 2015-12-22 12:47:06 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:47:06 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:47:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:47:06 --> URI Class Initialized
DEBUG - 2015-12-22 12:47:06 --> Router Class Initialized
ERROR - 2015-12-22 12:47:06 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:47:09 --> Config Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:47:09 --> URI Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Router Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Output Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Security Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Input Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:47:09 --> Language Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Loader Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:47:09 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Session Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:47:09 --> Session routines successfully run
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Controller Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:47:09 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:47:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-22 12:47:09 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:47:10 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-22 12:47:11 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 12:47:12 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-22 12:47:13 --> Config Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:47:13 --> URI Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Router Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Output Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Security Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Input Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:47:13 --> Language Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Loader Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:47:13 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Session Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:47:13 --> Session routines successfully run
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Controller Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Model Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:47:13 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:47:13 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/header.php
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/footer.php
DEBUG - 2015-12-22 12:47:13 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-22 12:47:13 --> Final output sent to browser
DEBUG - 2015-12-22 12:47:13 --> Total execution time: 0.0563
DEBUG - 2015-12-22 12:47:14 --> Config Class Initialized
DEBUG - 2015-12-22 12:47:14 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:47:14 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:47:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:47:14 --> URI Class Initialized
DEBUG - 2015-12-22 12:47:14 --> Router Class Initialized
ERROR - 2015-12-22 12:47:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-22 12:54:25 --> Config Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Hooks Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Utf8 Class Initialized
DEBUG - 2015-12-22 12:54:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 12:54:25 --> URI Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Router Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Output Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Security Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Input Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 12:54:25 --> Language Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Loader Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Helper loaded: url_helper
DEBUG - 2015-12-22 12:54:25 --> Database Driver Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Session Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Helper loaded: string_helper
DEBUG - 2015-12-22 12:54:25 --> Session routines successfully run
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Controller Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Model Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Helper loaded: form_helper
DEBUG - 2015-12-22 12:54:25 --> Form Validation Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Pagination Class Initialized
DEBUG - 2015-12-22 12:54:25 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 12:54:26 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-22 12:54:26 --> Final output sent to browser
DEBUG - 2015-12-22 12:54:26 --> Total execution time: 1.2066
DEBUG - 2015-12-22 13:08:06 --> Config Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Hooks Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Utf8 Class Initialized
DEBUG - 2015-12-22 13:08:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 13:08:06 --> URI Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Router Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Output Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Security Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Input Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 13:08:06 --> Language Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Loader Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Helper loaded: url_helper
DEBUG - 2015-12-22 13:08:06 --> Database Driver Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Session Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Helper loaded: string_helper
DEBUG - 2015-12-22 13:08:06 --> Session routines successfully run
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Controller Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Helper loaded: form_helper
DEBUG - 2015-12-22 13:08:06 --> Form Validation Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Pagination Class Initialized
DEBUG - 2015-12-22 13:08:06 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 13:08:24 --> Config Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Hooks Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Utf8 Class Initialized
DEBUG - 2015-12-22 13:08:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 13:08:24 --> URI Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Router Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Output Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Security Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Input Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 13:08:24 --> Language Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Loader Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Helper loaded: url_helper
DEBUG - 2015-12-22 13:08:24 --> Database Driver Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Session Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Helper loaded: string_helper
DEBUG - 2015-12-22 13:08:24 --> Session routines successfully run
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Controller Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Helper loaded: form_helper
DEBUG - 2015-12-22 13:08:24 --> Form Validation Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Pagination Class Initialized
DEBUG - 2015-12-22 13:08:24 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 13:08:40 --> Config Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Hooks Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Utf8 Class Initialized
DEBUG - 2015-12-22 13:08:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 13:08:40 --> URI Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Router Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Output Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Security Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Input Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 13:08:40 --> Language Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Loader Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Helper loaded: url_helper
DEBUG - 2015-12-22 13:08:40 --> Database Driver Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Session Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Helper loaded: string_helper
DEBUG - 2015-12-22 13:08:40 --> Session routines successfully run
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Controller Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Model Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Helper loaded: form_helper
DEBUG - 2015-12-22 13:08:40 --> Form Validation Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Pagination Class Initialized
DEBUG - 2015-12-22 13:08:40 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 13:08:41 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 13:08:41 --> Final output sent to browser
DEBUG - 2015-12-22 13:08:41 --> Total execution time: 1.6207
DEBUG - 2015-12-22 13:09:55 --> Config Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Hooks Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Utf8 Class Initialized
DEBUG - 2015-12-22 13:09:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 13:09:55 --> URI Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Router Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Output Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Security Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Input Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 13:09:55 --> Language Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Loader Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Helper loaded: url_helper
DEBUG - 2015-12-22 13:09:55 --> Database Driver Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Session Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Helper loaded: string_helper
DEBUG - 2015-12-22 13:09:55 --> Session routines successfully run
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Controller Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Model Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Helper loaded: form_helper
DEBUG - 2015-12-22 13:09:55 --> Form Validation Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Pagination Class Initialized
DEBUG - 2015-12-22 13:09:55 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 13:09:57 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 13:09:57 --> Final output sent to browser
DEBUG - 2015-12-22 13:09:57 --> Total execution time: 1.6120
DEBUG - 2015-12-22 13:11:30 --> Config Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Hooks Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Utf8 Class Initialized
DEBUG - 2015-12-22 13:11:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 13:11:30 --> URI Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Router Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Output Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Security Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Input Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 13:11:30 --> Language Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Loader Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Helper loaded: url_helper
DEBUG - 2015-12-22 13:11:30 --> Database Driver Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Session Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Helper loaded: string_helper
DEBUG - 2015-12-22 13:11:30 --> Session routines successfully run
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Controller Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Model Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Helper loaded: form_helper
DEBUG - 2015-12-22 13:11:30 --> Form Validation Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Pagination Class Initialized
DEBUG - 2015-12-22 13:11:30 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 13:11:31 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 13:11:31 --> Final output sent to browser
DEBUG - 2015-12-22 13:11:31 --> Total execution time: 1.5792
DEBUG - 2015-12-22 13:12:11 --> Config Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Hooks Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Utf8 Class Initialized
DEBUG - 2015-12-22 13:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-22 13:12:11 --> URI Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Router Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Output Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Security Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Input Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-22 13:12:11 --> Language Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Loader Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Helper loaded: url_helper
DEBUG - 2015-12-22 13:12:11 --> Database Driver Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Session Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Helper loaded: string_helper
DEBUG - 2015-12-22 13:12:11 --> Session routines successfully run
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Controller Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Model Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Helper loaded: form_helper
DEBUG - 2015-12-22 13:12:11 --> Form Validation Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Pagination Class Initialized
DEBUG - 2015-12-22 13:12:11 --> Helper loaded: pdf_helper
DEBUG - 2015-12-22 13:12:13 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-22 13:12:13 --> Final output sent to browser
DEBUG - 2015-12-22 13:12:13 --> Total execution time: 1.5919
