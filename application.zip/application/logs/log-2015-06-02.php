<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-06-02 11:56:57 --> Config Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Hooks Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Utf8 Class Initialized
DEBUG - 2015-06-02 11:56:57 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 11:56:57 --> URI Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Router Class Initialized
DEBUG - 2015-06-02 11:56:57 --> No URI present. Default controller set.
DEBUG - 2015-06-02 11:56:57 --> Output Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Security Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Input Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 11:56:57 --> Language Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Loader Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Helper loaded: url_helper
DEBUG - 2015-06-02 11:56:57 --> Database Driver Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Session Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Helper loaded: string_helper
DEBUG - 2015-06-02 11:56:57 --> A session cookie was not found.
DEBUG - 2015-06-02 11:56:57 --> Session routines successfully run
DEBUG - 2015-06-02 11:56:57 --> Model Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Model Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Controller Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Model Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Model Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Model Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Model Class Initialized
DEBUG - 2015-06-02 11:56:57 --> Helper loaded: form_helper
DEBUG - 2015-06-02 11:56:57 --> Form Validation Class Initialized
DEBUG - 2015-06-02 11:56:57 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 11:56:57 --> Final output sent to browser
DEBUG - 2015-06-02 11:56:57 --> Total execution time: 0.1178
DEBUG - 2015-06-02 11:57:46 --> Config Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Hooks Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Utf8 Class Initialized
DEBUG - 2015-06-02 11:57:46 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 11:57:46 --> URI Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Router Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Output Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Security Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Input Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 11:57:46 --> Language Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Loader Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Helper loaded: url_helper
DEBUG - 2015-06-02 11:57:46 --> Database Driver Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Session Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Helper loaded: string_helper
DEBUG - 2015-06-02 11:57:46 --> Session routines successfully run
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Controller Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Helper loaded: form_helper
DEBUG - 2015-06-02 11:57:46 --> Form Validation Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 11:57:46 --> Config Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Hooks Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Utf8 Class Initialized
DEBUG - 2015-06-02 11:57:46 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 11:57:46 --> URI Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Router Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Output Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Security Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Input Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 11:57:46 --> Language Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Loader Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Helper loaded: url_helper
DEBUG - 2015-06-02 11:57:46 --> Database Driver Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Session Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Helper loaded: string_helper
DEBUG - 2015-06-02 11:57:46 --> Session routines successfully run
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Controller Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Helper loaded: form_helper
DEBUG - 2015-06-02 11:57:46 --> Form Validation Class Initialized
DEBUG - 2015-06-02 11:57:46 --> Pagination Class Initialized
DEBUG - 2015-06-02 11:57:46 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 11:57:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 11:57:46 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 11:57:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 11:57:46 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 11:57:46 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-02 11:57:46 --> Final output sent to browser
DEBUG - 2015-06-02 11:57:46 --> Total execution time: 0.0406
DEBUG - 2015-06-02 11:57:49 --> Config Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Hooks Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Utf8 Class Initialized
DEBUG - 2015-06-02 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 11:57:49 --> URI Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Router Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Output Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Security Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Input Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 11:57:49 --> Language Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Loader Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Helper loaded: url_helper
DEBUG - 2015-06-02 11:57:49 --> Database Driver Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Session Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Helper loaded: string_helper
DEBUG - 2015-06-02 11:57:49 --> Session routines successfully run
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Controller Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Model Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Helper loaded: form_helper
DEBUG - 2015-06-02 11:57:49 --> Form Validation Class Initialized
DEBUG - 2015-06-02 11:57:49 --> Pagination Class Initialized
DEBUG - 2015-06-02 11:57:50 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 11:57:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 11:57:50 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 11:57:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 11:57:50 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 11:57:50 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 11:57:50 --> Final output sent to browser
DEBUG - 2015-06-02 11:57:50 --> Total execution time: 0.0607
DEBUG - 2015-06-02 11:58:03 --> Config Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Hooks Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Utf8 Class Initialized
DEBUG - 2015-06-02 11:58:03 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 11:58:03 --> URI Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Router Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Output Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Security Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Input Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 11:58:03 --> Language Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Loader Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Helper loaded: url_helper
DEBUG - 2015-06-02 11:58:03 --> Database Driver Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Session Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Helper loaded: string_helper
DEBUG - 2015-06-02 11:58:03 --> Session routines successfully run
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Controller Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Helper loaded: form_helper
DEBUG - 2015-06-02 11:58:03 --> Form Validation Class Initialized
DEBUG - 2015-06-02 11:58:03 --> Pagination Class Initialized
DEBUG - 2015-06-02 11:58:03 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 11:58:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 11:58:03 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 11:58:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 11:58:03 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 11:58:03 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-02 11:58:03 --> Final output sent to browser
DEBUG - 2015-06-02 11:58:03 --> Total execution time: 0.0564
DEBUG - 2015-06-02 11:58:14 --> Config Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Hooks Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Utf8 Class Initialized
DEBUG - 2015-06-02 11:58:14 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 11:58:14 --> URI Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Router Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Output Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Security Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Input Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 11:58:14 --> Language Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Loader Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Helper loaded: url_helper
DEBUG - 2015-06-02 11:58:14 --> Database Driver Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Session Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Helper loaded: string_helper
DEBUG - 2015-06-02 11:58:14 --> Session routines successfully run
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Controller Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Model Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Helper loaded: form_helper
DEBUG - 2015-06-02 11:58:14 --> Form Validation Class Initialized
DEBUG - 2015-06-02 11:58:14 --> Pagination Class Initialized
DEBUG - 2015-06-02 11:58:14 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 11:58:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 11:58:14 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 11:58:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 11:58:14 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 11:58:14 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-02 11:58:14 --> Final output sent to browser
DEBUG - 2015-06-02 11:58:14 --> Total execution time: 0.0628
DEBUG - 2015-06-02 12:04:24 --> Config Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:04:24 --> URI Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Router Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Output Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Security Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Input Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:04:24 --> Language Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Loader Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:04:24 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Session Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:04:24 --> Session routines successfully run
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Controller Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:04:24 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Config Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:04:24 --> URI Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Router Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Output Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Security Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Input Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:04:24 --> Language Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Loader Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:04:24 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Session Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:04:24 --> Session routines successfully run
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Controller Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:24 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:04:24 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:04:24 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 12:04:24 --> Final output sent to browser
DEBUG - 2015-06-02 12:04:24 --> Total execution time: 0.0342
DEBUG - 2015-06-02 12:04:37 --> Config Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:04:37 --> URI Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Router Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Output Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Security Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Input Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:04:37 --> Language Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Loader Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:04:37 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Session Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:04:37 --> Session routines successfully run
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Controller Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:04:37 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 12:04:37 --> Config Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:04:37 --> URI Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Router Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Output Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Security Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Input Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:04:37 --> Language Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Loader Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:04:37 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Session Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:04:37 --> Session routines successfully run
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Controller Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:04:37 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:04:37 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:04:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:04:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:04:37 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:04:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:04:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:04:37 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-02 12:04:37 --> Final output sent to browser
DEBUG - 2015-06-02 12:04:37 --> Total execution time: 0.0437
DEBUG - 2015-06-02 12:04:39 --> Config Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:04:39 --> URI Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Router Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Output Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Security Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Input Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:04:39 --> Language Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Loader Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:04:39 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Session Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:04:39 --> Session routines successfully run
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Controller Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Model Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:04:39 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:04:39 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:04:39 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:04:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:04:39 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:04:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:04:39 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:04:39 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:04:39 --> Final output sent to browser
DEBUG - 2015-06-02 12:04:39 --> Total execution time: 0.0574
DEBUG - 2015-06-02 12:08:13 --> Config Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:08:13 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:08:13 --> URI Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Router Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Output Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Security Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Input Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:08:13 --> Language Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Loader Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:08:13 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Session Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:08:13 --> Session routines successfully run
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Controller Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:08:13 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:08:13 --> Final output sent to browser
DEBUG - 2015-06-02 12:08:13 --> Total execution time: 0.0965
DEBUG - 2015-06-02 12:08:28 --> Config Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:08:28 --> URI Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Router Class Initialized
DEBUG - 2015-06-02 12:08:28 --> No URI present. Default controller set.
DEBUG - 2015-06-02 12:08:28 --> Output Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Security Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Input Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:08:28 --> Language Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Loader Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:08:28 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Session Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:08:28 --> Session routines successfully run
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Controller Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:08:28 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Config Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:08:28 --> URI Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Router Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Output Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Security Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Input Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:08:28 --> Language Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Loader Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:08:28 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Session Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:08:28 --> Session routines successfully run
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Controller Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:08:28 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:08:28 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:08:28 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:08:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:08:28 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:08:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:08:28 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:08:28 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-02 12:08:28 --> Final output sent to browser
DEBUG - 2015-06-02 12:08:28 --> Total execution time: 0.0450
DEBUG - 2015-06-02 12:08:30 --> Config Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:08:30 --> URI Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Router Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Output Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Security Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Input Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:08:30 --> Language Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Loader Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:08:30 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Session Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:08:30 --> Session routines successfully run
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Controller Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:08:30 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:08:30 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:08:30 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:08:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:08:30 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:08:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:08:30 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:08:30 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:08:30 --> Final output sent to browser
DEBUG - 2015-06-02 12:08:30 --> Total execution time: 0.0488
DEBUG - 2015-06-02 12:09:19 --> Config Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:09:19 --> URI Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Router Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Output Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Security Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Input Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:09:19 --> Language Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Loader Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:09:19 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Session Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:09:19 --> Session routines successfully run
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Controller Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:09:19 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:09:19 --> Final output sent to browser
DEBUG - 2015-06-02 12:09:19 --> Total execution time: 0.0633
DEBUG - 2015-06-02 12:09:22 --> Config Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:09:22 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:09:22 --> URI Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Router Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Output Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Security Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Input Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:09:22 --> Language Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Loader Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:09:22 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Session Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:09:22 --> Session routines successfully run
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Controller Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:09:22 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:09:22 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:09:22 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:09:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:09:22 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:09:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:09:22 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:09:22 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:09:22 --> Final output sent to browser
DEBUG - 2015-06-02 12:09:22 --> Total execution time: 0.0438
DEBUG - 2015-06-02 12:13:19 --> Config Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:13:19 --> URI Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Router Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Output Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Security Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Input Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:13:19 --> Language Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Loader Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:13:19 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Session Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:13:19 --> Session routines successfully run
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Controller Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:13:19 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:13:19 --> Final output sent to browser
DEBUG - 2015-06-02 12:13:19 --> Total execution time: 0.0645
DEBUG - 2015-06-02 12:13:22 --> Config Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:13:22 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:13:22 --> URI Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Router Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Output Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Security Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Input Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:13:22 --> Language Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Loader Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:13:22 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Session Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:13:22 --> Session routines successfully run
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Controller Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Model Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:13:22 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:13:22 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:13:22 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:13:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:13:22 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:13:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:13:22 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:13:22 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:13:22 --> Final output sent to browser
DEBUG - 2015-06-02 12:13:22 --> Total execution time: 0.0473
DEBUG - 2015-06-02 12:14:36 --> Config Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:14:36 --> URI Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Router Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Output Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Security Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Input Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:14:36 --> Language Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Loader Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:14:36 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Session Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:14:36 --> Session routines successfully run
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Controller Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Model Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:14:36 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:14:36 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Config Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:15:43 --> URI Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Router Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Output Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Security Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Input Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:15:43 --> Language Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Loader Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:15:43 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Session Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:15:43 --> Session routines successfully run
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Controller Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:15:43 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:15:43 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Config Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:15:51 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:15:51 --> URI Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Router Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Output Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Security Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Input Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:15:51 --> Language Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Loader Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:15:51 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Session Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:15:51 --> Session routines successfully run
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Controller Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:15:51 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:15:51 --> Final output sent to browser
DEBUG - 2015-06-02 12:15:51 --> Total execution time: 0.0701
DEBUG - 2015-06-02 12:15:53 --> Config Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:15:53 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:15:53 --> URI Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Router Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Output Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Security Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Input Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:15:53 --> Language Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Loader Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:15:53 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Session Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:15:53 --> Session routines successfully run
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Controller Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Model Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:15:53 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:15:53 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:15:53 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:15:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:15:53 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:15:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:15:53 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:15:53 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:15:53 --> Final output sent to browser
DEBUG - 2015-06-02 12:15:53 --> Total execution time: 0.0450
DEBUG - 2015-06-02 12:19:26 --> Config Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:19:26 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:19:26 --> URI Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Router Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Output Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Security Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Input Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:19:26 --> Language Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Loader Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:19:26 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Session Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:19:26 --> Session routines successfully run
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Controller Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:19:26 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:19:26 --> Final output sent to browser
DEBUG - 2015-06-02 12:19:26 --> Total execution time: 0.0795
DEBUG - 2015-06-02 12:19:51 --> Config Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:19:51 --> URI Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Router Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Output Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Security Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Input Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:19:51 --> Language Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Loader Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:19:51 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Session Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:19:51 --> Session routines successfully run
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Controller Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Model Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:19:51 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:19:51 --> Final output sent to browser
DEBUG - 2015-06-02 12:19:51 --> Total execution time: 0.0690
DEBUG - 2015-06-02 12:20:23 --> Config Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:20:23 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:20:23 --> URI Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Router Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Output Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Security Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Input Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:20:23 --> Language Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Loader Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:20:23 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Session Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:20:23 --> Session routines successfully run
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Controller Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:20:23 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:20:23 --> Final output sent to browser
DEBUG - 2015-06-02 12:20:23 --> Total execution time: 0.0731
DEBUG - 2015-06-02 12:20:30 --> Config Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:20:30 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:20:30 --> URI Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Router Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Output Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Security Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Input Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:20:30 --> Language Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Loader Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:20:30 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Session Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:20:30 --> Session routines successfully run
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Controller Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Model Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:20:30 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:20:30 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:20:30 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:20:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:20:30 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:20:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:20:30 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:20:30 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:20:30 --> Final output sent to browser
DEBUG - 2015-06-02 12:20:30 --> Total execution time: 0.0486
DEBUG - 2015-06-02 12:22:35 --> Config Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:22:35 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:22:35 --> URI Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Router Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Output Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Security Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Input Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:22:35 --> Language Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Loader Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:22:35 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Session Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:22:35 --> Session routines successfully run
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Controller Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:22:35 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:22:35 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Config Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:22:57 --> URI Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Router Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Output Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Security Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Input Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:22:57 --> Language Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Loader Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:22:57 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Session Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:22:57 --> Session routines successfully run
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Controller Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Model Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:22:57 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:22:57 --> Final output sent to browser
DEBUG - 2015-06-02 12:22:57 --> Total execution time: 0.0703
DEBUG - 2015-06-02 12:24:09 --> Config Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:24:09 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:24:09 --> URI Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Router Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Output Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Security Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Input Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:24:09 --> Language Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Loader Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:24:09 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Session Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:24:09 --> Session routines successfully run
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Controller Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Model Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:24:09 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:24:09 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:24:09 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:24:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:24:09 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:24:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:24:09 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:24:09 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:24:09 --> Final output sent to browser
DEBUG - 2015-06-02 12:24:09 --> Total execution time: 0.0511
DEBUG - 2015-06-02 12:26:37 --> Config Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:26:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:26:37 --> URI Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Router Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Output Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Security Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Input Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:26:37 --> Language Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Loader Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:26:37 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Session Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:26:37 --> Session routines successfully run
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Controller Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Model Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:26:37 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:26:37 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Config Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:27:15 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:27:15 --> URI Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Router Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Output Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Security Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Input Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:27:15 --> Language Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Loader Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:27:15 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Session Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:27:15 --> Session routines successfully run
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Controller Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Model Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:27:15 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:27:15 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:27:15 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:27:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:27:15 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:27:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:27:15 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:27:15 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:27:15 --> Final output sent to browser
DEBUG - 2015-06-02 12:27:15 --> Total execution time: 0.0467
DEBUG - 2015-06-02 12:34:29 --> Config Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:34:29 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:34:29 --> URI Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Router Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Output Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Security Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Input Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:34:29 --> Language Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Loader Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:34:29 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Session Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:34:29 --> Session routines successfully run
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Controller Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Model Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:34:29 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:34:29 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:34:29 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:34:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:34:29 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:34:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:34:29 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:34:29 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:34:29 --> Final output sent to browser
DEBUG - 2015-06-02 12:34:29 --> Total execution time: 0.0681
DEBUG - 2015-06-02 12:40:55 --> Config Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Hooks Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Utf8 Class Initialized
DEBUG - 2015-06-02 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 12:40:55 --> URI Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Router Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Output Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Security Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Input Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 12:40:55 --> Language Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Loader Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Helper loaded: url_helper
DEBUG - 2015-06-02 12:40:55 --> Database Driver Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Session Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Helper loaded: string_helper
DEBUG - 2015-06-02 12:40:55 --> Session routines successfully run
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Controller Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Model Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Helper loaded: form_helper
DEBUG - 2015-06-02 12:40:55 --> Form Validation Class Initialized
DEBUG - 2015-06-02 12:40:55 --> Pagination Class Initialized
DEBUG - 2015-06-02 12:40:55 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 12:40:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 12:40:55 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 12:40:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 12:40:55 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 12:40:55 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-02 12:40:55 --> Final output sent to browser
DEBUG - 2015-06-02 12:40:55 --> Total execution time: 0.0637
DEBUG - 2015-06-02 15:15:35 --> Config Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:15:35 --> URI Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Router Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Output Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Security Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Input Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:15:35 --> Language Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Loader Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:15:35 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Session Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:15:35 --> A session cookie was not found.
DEBUG - 2015-06-02 15:15:35 --> Session routines successfully run
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Controller Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Config Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:15:35 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:15:35 --> URI Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Router Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Output Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Security Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Input Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:15:35 --> Language Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Loader Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:15:35 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Session Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:15:35 --> Session routines successfully run
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Controller Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:35 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:15:35 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:15:35 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:15:35 --> Final output sent to browser
DEBUG - 2015-06-02 15:15:35 --> Total execution time: 0.0412
DEBUG - 2015-06-02 15:15:45 --> Config Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:15:45 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:15:45 --> URI Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Router Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Output Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Security Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Input Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:15:45 --> Language Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Loader Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:15:45 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Session Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:15:45 --> Session routines successfully run
DEBUG - 2015-06-02 15:15:45 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Controller Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Model Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:15:45 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:15:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:15:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:15:45 --> Final output sent to browser
DEBUG - 2015-06-02 15:15:45 --> Total execution time: 0.0481
DEBUG - 2015-06-02 15:16:10 --> Config Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:16:10 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:16:10 --> URI Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Router Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Output Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Security Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Input Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:16:10 --> Language Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Loader Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:16:10 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Session Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:16:10 --> Session routines successfully run
DEBUG - 2015-06-02 15:16:10 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Controller Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:16:10 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:16:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:16:10 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:16:10 --> Final output sent to browser
DEBUG - 2015-06-02 15:16:10 --> Total execution time: 0.0497
DEBUG - 2015-06-02 15:16:17 --> Config Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:16:17 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:16:17 --> URI Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Router Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Output Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Security Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Input Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:16:17 --> Language Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Loader Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:16:17 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Session Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:16:17 --> Session routines successfully run
DEBUG - 2015-06-02 15:16:17 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Controller Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:16:17 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:16:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:16:17 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:16:17 --> Final output sent to browser
DEBUG - 2015-06-02 15:16:17 --> Total execution time: 0.0611
DEBUG - 2015-06-02 15:16:27 --> Config Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:16:27 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:16:27 --> URI Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Router Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Output Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Security Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Input Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:16:27 --> Language Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Loader Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:16:27 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Session Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:16:27 --> Session routines successfully run
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Controller Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:16:27 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:16:27 --> Config Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:16:27 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:16:27 --> URI Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Router Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Output Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Security Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Input Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:16:27 --> Language Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Loader Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:16:27 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Session Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:16:27 --> Session routines successfully run
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Controller Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:16:27 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:16:27 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:16:27 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:16:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:16:27 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:16:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:16:27 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:16:27 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-02 15:16:27 --> Final output sent to browser
DEBUG - 2015-06-02 15:16:27 --> Total execution time: 0.0432
DEBUG - 2015-06-02 15:16:40 --> Config Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:16:40 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:16:40 --> URI Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Router Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Output Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Security Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Input Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:16:40 --> Language Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Loader Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:16:40 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Session Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:16:40 --> Session routines successfully run
DEBUG - 2015-06-02 15:16:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Controller Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:16:40 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:16:40 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:16:40 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:16:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:16:40 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:16:40 --> File loaded: application/views/sidebar.php
ERROR - 2015-06-02 15:16:40 --> Severity: Notice  --> Undefined variable: profile /Applications/MAMP/htdocs/asmc/crm/application/views/changePass.php 44
ERROR - 2015-06-02 15:16:40 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/changePass.php 44
ERROR - 2015-06-02 15:16:40 --> Severity: Notice  --> Undefined variable: profile /Applications/MAMP/htdocs/asmc/crm/application/views/changePass.php 51
ERROR - 2015-06-02 15:16:40 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/changePass.php 51
DEBUG - 2015-06-02 15:16:40 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:16:40 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:16:40 --> Final output sent to browser
DEBUG - 2015-06-02 15:16:40 --> Total execution time: 0.0476
DEBUG - 2015-06-02 15:17:24 --> Config Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:17:24 --> URI Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Router Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Output Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Security Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Input Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:17:24 --> Language Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Loader Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:17:24 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Session Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:17:24 --> Session routines successfully run
DEBUG - 2015-06-02 15:17:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Controller Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:17:24 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:17:24 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:17:24 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:17:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:17:24 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:17:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:17:24 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:17:24 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:17:24 --> Final output sent to browser
DEBUG - 2015-06-02 15:17:24 --> Total execution time: 0.0360
DEBUG - 2015-06-02 15:17:56 --> Config Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:17:56 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:17:56 --> URI Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Router Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Output Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Security Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Input Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:17:56 --> Language Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Loader Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:17:56 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Session Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:17:56 --> Session routines successfully run
DEBUG - 2015-06-02 15:17:56 --> Model Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Model Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Controller Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Model Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:17:56 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:17:56 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:17:56 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:17:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:17:56 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:17:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:17:56 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:17:56 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:17:56 --> Final output sent to browser
DEBUG - 2015-06-02 15:17:56 --> Total execution time: 0.0335
DEBUG - 2015-06-02 15:18:04 --> Config Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:18:04 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:18:04 --> URI Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Router Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Output Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Security Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Input Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:18:04 --> Language Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Loader Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:18:04 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Session Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:18:04 --> Session routines successfully run
DEBUG - 2015-06-02 15:18:04 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Controller Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:18:04 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:18:04 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:18:04 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:18:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:18:04 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:18:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:18:04 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:18:04 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:18:04 --> Final output sent to browser
DEBUG - 2015-06-02 15:18:04 --> Total execution time: 0.0488
DEBUG - 2015-06-02 15:18:11 --> Config Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:18:11 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:18:11 --> URI Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Router Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Output Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Security Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Input Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:18:11 --> Language Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Loader Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:18:11 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Session Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:18:11 --> Session routines successfully run
DEBUG - 2015-06-02 15:18:11 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Controller Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:18:11 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:18:11 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:18:11 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:18:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:18:11 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:18:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:18:11 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:18:11 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:18:11 --> Final output sent to browser
DEBUG - 2015-06-02 15:18:11 --> Total execution time: 0.0384
DEBUG - 2015-06-02 15:18:36 --> Config Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:18:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:18:36 --> URI Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Router Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Output Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Security Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Input Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:18:36 --> Language Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Loader Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:18:36 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Session Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:18:36 --> Session routines successfully run
DEBUG - 2015-06-02 15:18:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Controller Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:18:36 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:18:36 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:18:36 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:18:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:18:36 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:18:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:18:36 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:18:36 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:18:36 --> Final output sent to browser
DEBUG - 2015-06-02 15:18:36 --> Total execution time: 0.0343
DEBUG - 2015-06-02 15:18:37 --> Config Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:18:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:18:37 --> URI Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Router Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Output Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Security Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Input Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:18:37 --> Language Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Loader Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:18:37 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Session Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:18:37 --> Session routines successfully run
DEBUG - 2015-06-02 15:18:37 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Controller Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Model Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:18:37 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:18:37 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:18:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:18:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:18:37 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:18:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:18:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:18:37 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:18:37 --> Final output sent to browser
DEBUG - 2015-06-02 15:18:37 --> Total execution time: 0.0449
DEBUG - 2015-06-02 15:19:57 --> Config Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:19:57 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:19:57 --> URI Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Router Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Output Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Security Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Input Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:19:57 --> Language Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Loader Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:19:57 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Session Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:19:57 --> Session routines successfully run
DEBUG - 2015-06-02 15:19:57 --> Model Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Model Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Controller Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Model Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:19:57 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:19:57 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:19:57 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:19:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:19:57 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:19:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:19:57 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:19:57 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:19:57 --> Final output sent to browser
DEBUG - 2015-06-02 15:19:57 --> Total execution time: 0.0407
DEBUG - 2015-06-02 15:19:58 --> Config Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:19:58 --> URI Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Router Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Output Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Security Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Input Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:19:58 --> Language Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Loader Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:19:58 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Session Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:19:58 --> Session routines successfully run
DEBUG - 2015-06-02 15:19:58 --> Model Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Model Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Controller Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Model Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:19:58 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:19:58 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:19:58 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:19:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:19:58 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:19:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:19:58 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:19:58 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:19:58 --> Final output sent to browser
DEBUG - 2015-06-02 15:19:58 --> Total execution time: 0.0378
DEBUG - 2015-06-02 15:20:35 --> Config Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:20:35 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:20:35 --> URI Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Router Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Output Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Security Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Input Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:20:35 --> Language Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Loader Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:20:35 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Session Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:20:35 --> Session routines successfully run
DEBUG - 2015-06-02 15:20:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Controller Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:20:35 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:20:35 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:20:35 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:20:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:20:35 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:20:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:20:35 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:20:35 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:20:35 --> Final output sent to browser
DEBUG - 2015-06-02 15:20:35 --> Total execution time: 0.0457
DEBUG - 2015-06-02 15:20:40 --> Config Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:20:40 --> URI Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Router Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Output Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Security Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Input Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:20:40 --> Language Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Loader Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:20:40 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Session Class Initialized
DEBUG - 2015-06-02 15:20:40 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:20:40 --> Session routines successfully run
DEBUG - 2015-06-02 15:20:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:41 --> Controller Class Initialized
DEBUG - 2015-06-02 15:20:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:41 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:20:41 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:20:41 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:20:41 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:20:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:20:41 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:20:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:20:41 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:20:41 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:20:41 --> Final output sent to browser
DEBUG - 2015-06-02 15:20:41 --> Total execution time: 0.0375
DEBUG - 2015-06-02 15:20:42 --> Config Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:20:42 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:20:42 --> URI Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Router Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Output Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Security Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Input Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:20:42 --> Language Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Loader Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:20:42 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Session Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:20:42 --> Session routines successfully run
DEBUG - 2015-06-02 15:20:42 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Controller Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:20:42 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:20:42 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:20:42 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:20:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:20:42 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:20:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:20:42 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:20:42 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:20:42 --> Final output sent to browser
DEBUG - 2015-06-02 15:20:42 --> Total execution time: 0.0475
DEBUG - 2015-06-02 15:20:52 --> Config Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:20:52 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:20:52 --> URI Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Router Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Output Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Security Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Input Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:20:52 --> Language Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Loader Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:20:52 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Session Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:20:52 --> Session routines successfully run
DEBUG - 2015-06-02 15:20:52 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Controller Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Model Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:20:52 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:20:52 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:20:52 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:20:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:20:52 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:20:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:20:52 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:20:52 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:20:52 --> Final output sent to browser
DEBUG - 2015-06-02 15:20:52 --> Total execution time: 0.0328
DEBUG - 2015-06-02 15:26:20 --> Config Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:26:20 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:26:20 --> URI Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Router Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Output Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Security Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Input Class Initialized
DEBUG - 2015-06-02 15:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:26:20 --> Language Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Config Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:26:31 --> URI Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Router Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Output Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Security Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Input Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:26:31 --> Language Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Loader Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:26:31 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Session Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:26:31 --> Session routines successfully run
DEBUG - 2015-06-02 15:26:31 --> Model Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Model Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Controller Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Model Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:26:31 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:26:31 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:26:31 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:26:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:26:31 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:26:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:26:31 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:26:31 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:26:31 --> Final output sent to browser
DEBUG - 2015-06-02 15:26:31 --> Total execution time: 0.0469
DEBUG - 2015-06-02 15:26:58 --> Config Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:26:58 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:26:58 --> URI Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Router Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Output Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Security Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Input Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:26:58 --> Language Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Loader Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:26:58 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Session Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:26:58 --> Session routines successfully run
DEBUG - 2015-06-02 15:26:58 --> Model Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Model Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Controller Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Model Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:26:58 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:26:58 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:26:58 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:26:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:26:58 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:26:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:26:58 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:26:58 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:26:58 --> Final output sent to browser
DEBUG - 2015-06-02 15:26:58 --> Total execution time: 0.0528
DEBUG - 2015-06-02 15:27:05 --> Config Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:27:05 --> URI Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Router Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Output Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Security Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Input Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:27:05 --> Language Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Loader Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:27:05 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Session Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:27:05 --> Session routines successfully run
DEBUG - 2015-06-02 15:27:05 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Controller Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:27:05 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:27:05 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:27:05 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:27:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:27:05 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:27:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:27:05 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:27:05 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:27:05 --> Final output sent to browser
DEBUG - 2015-06-02 15:27:05 --> Total execution time: 0.0414
DEBUG - 2015-06-02 15:27:07 --> Config Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:27:07 --> URI Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Router Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Output Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Security Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Input Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:27:07 --> Language Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Loader Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:27:07 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Session Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:27:07 --> Session routines successfully run
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Controller Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:27:07 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Config Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:27:07 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:27:07 --> URI Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Router Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Output Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Security Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Input Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:27:07 --> Language Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Loader Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:27:07 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Session Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:27:07 --> Session routines successfully run
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Controller Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:07 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:27:07 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:27:07 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:27:07 --> Final output sent to browser
DEBUG - 2015-06-02 15:27:07 --> Total execution time: 0.0297
DEBUG - 2015-06-02 15:27:21 --> Config Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:27:21 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:27:21 --> URI Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Router Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Output Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Security Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Input Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:27:21 --> Language Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Loader Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:27:21 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Session Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:27:21 --> Session routines successfully run
DEBUG - 2015-06-02 15:27:21 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Controller Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:27:21 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:27:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:27:21 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:27:21 --> Final output sent to browser
DEBUG - 2015-06-02 15:27:21 --> Total execution time: 0.0392
DEBUG - 2015-06-02 15:27:24 --> Config Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:27:24 --> URI Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Router Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Output Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Security Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Input Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:27:24 --> Language Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Loader Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:27:24 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Session Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:27:24 --> Session routines successfully run
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Controller Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:27:24 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:27:24 --> Config Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:27:24 --> URI Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Router Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Output Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Security Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Input Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:27:24 --> Language Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Loader Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:27:24 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Session Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:27:24 --> Session routines successfully run
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Controller Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:27:24 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:27:24 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:27:24 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:27:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:27:24 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:27:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:27:24 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:27:24 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-02 15:27:24 --> Final output sent to browser
DEBUG - 2015-06-02 15:27:24 --> Total execution time: 0.0355
DEBUG - 2015-06-02 15:28:14 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:14 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:14 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:14 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:14 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:14 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:14 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:14 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:14 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:28:14 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:28:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:28:14 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:28:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:28:14 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:28:14 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-02 15:28:14 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:14 --> Total execution time: 0.0356
DEBUG - 2015-06-02 15:28:24 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:24 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:24 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:24 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:24 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:24 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:24 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:28:24 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:28:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:28:24 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-02 15:28:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:28:24 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:28:24 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:28:24 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:24 --> Total execution time: 0.0419
DEBUG - 2015-06-02 15:28:27 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:27 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:27 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:27 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:27 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:27 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:27 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:27 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:27 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:27 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:27 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:27 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:27 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:28:27 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:27 --> Total execution time: 0.0292
DEBUG - 2015-06-02 15:28:36 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:36 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:36 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:36 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:36 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:36 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:28:36 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:36 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:36 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:36 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:36 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:36 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:36 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:28:36 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:28:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:28:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-02 15:28:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:28:36 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:28:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-06-02 15:28:36 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:36 --> Total execution time: 0.0361
DEBUG - 2015-06-02 15:28:37 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:37 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:37 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:37 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:37 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:37 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:37 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:37 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:28:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:28:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:28:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-02 15:28:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:28:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:28:37 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:28:37 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:37 --> Total execution time: 0.0354
DEBUG - 2015-06-02 15:28:40 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:40 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:40 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:40 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:40 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:40 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:40 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:28:40 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:28:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:28:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-02 15:28:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:28:40 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:28:40 --> File loaded: application/views/changePass.php
DEBUG - 2015-06-02 15:28:40 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:40 --> Total execution time: 0.0411
DEBUG - 2015-06-02 15:28:41 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:41 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:41 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:41 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:41 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:41 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:41 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:41 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:41 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:41 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:41 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:41 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-02 15:28:41 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:41 --> Total execution time: 0.0305
DEBUG - 2015-06-02 15:28:50 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:50 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:50 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:50 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:50 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:50 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:50 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-02 15:28:50 --> Config Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Hooks Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Utf8 Class Initialized
DEBUG - 2015-06-02 15:28:50 --> UTF-8 Support Enabled
DEBUG - 2015-06-02 15:28:50 --> URI Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Router Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Output Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Security Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Input Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-02 15:28:50 --> Language Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Loader Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Helper loaded: url_helper
DEBUG - 2015-06-02 15:28:50 --> Database Driver Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Session Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Helper loaded: string_helper
DEBUG - 2015-06-02 15:28:50 --> Session routines successfully run
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Controller Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Model Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Helper loaded: form_helper
DEBUG - 2015-06-02 15:28:50 --> Form Validation Class Initialized
DEBUG - 2015-06-02 15:28:50 --> Pagination Class Initialized
DEBUG - 2015-06-02 15:28:50 --> File loaded: application/views/header.php
DEBUG - 2015-06-02 15:28:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-02 15:28:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-02 15:28:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-02 15:28:50 --> File loaded: application/views/footer.php
DEBUG - 2015-06-02 15:28:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-06-02 15:28:50 --> Final output sent to browser
DEBUG - 2015-06-02 15:28:50 --> Total execution time: 0.0330
