<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-05-07 11:49:22 --> Config Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:49:22 --> URI Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Router Class Initialized
DEBUG - 2015-05-07 11:49:22 --> No URI present. Default controller set.
DEBUG - 2015-05-07 11:49:22 --> Output Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Security Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Input Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:49:22 --> Language Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Loader Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:49:22 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Session Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:49:22 --> A session cookie was not found.
DEBUG - 2015-05-07 11:49:22 --> Session routines successfully run
DEBUG - 2015-05-07 11:49:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Controller Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:49:22 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:49:22 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:49:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-07 11:49:22 --> Final output sent to browser
DEBUG - 2015-05-07 11:49:22 --> Total execution time: 0.0740
DEBUG - 2015-05-07 11:50:58 --> Config Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:50:58 --> URI Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Router Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Output Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Security Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Input Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:50:58 --> Language Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Loader Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:50:58 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Session Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:50:58 --> Session routines successfully run
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Controller Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:50:58 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 11:50:58 --> Config Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:50:58 --> URI Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Router Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Output Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Security Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Input Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:50:58 --> Language Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Loader Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:50:58 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Session Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:50:58 --> Session routines successfully run
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Controller Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Model Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:50:58 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:50:58 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:50:58 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:50:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:50:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:50:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:50:58 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:50:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-07 11:50:58 --> Final output sent to browser
DEBUG - 2015-05-07 11:50:58 --> Total execution time: 0.0543
DEBUG - 2015-05-07 11:51:00 --> Config Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:51:00 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:51:00 --> URI Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Router Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Output Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Security Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Input Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:51:00 --> Language Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Loader Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:51:00 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Session Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:51:00 --> Session routines successfully run
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Controller Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:51:00 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:51:00 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:51:00 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:51:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:51:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:51:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:51:00 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:51:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-07 11:51:00 --> Final output sent to browser
DEBUG - 2015-05-07 11:51:00 --> Total execution time: 0.0802
DEBUG - 2015-05-07 11:51:01 --> Config Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:51:01 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:51:01 --> URI Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Router Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Output Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Security Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Input Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:51:01 --> Language Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Loader Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:51:01 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Session Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:51:01 --> Session routines successfully run
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Controller Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:51:01 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:51:01 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:51:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:51:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:51:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:51:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:51:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:51:01 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 11:51:01 --> Final output sent to browser
DEBUG - 2015-05-07 11:51:01 --> Total execution time: 0.0713
DEBUG - 2015-05-07 11:53:41 --> Config Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:53:41 --> URI Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Router Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Output Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Security Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Input Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:53:41 --> Language Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Loader Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:53:41 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Session Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:53:41 --> Session routines successfully run
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Controller Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:53:41 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:53:41 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:53:42 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:53:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:53:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:53:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:53:42 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:53:42 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 11:53:42 --> Final output sent to browser
DEBUG - 2015-05-07 11:53:42 --> Total execution time: 0.0780
DEBUG - 2015-05-07 11:53:43 --> Config Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:53:43 --> URI Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Router Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Output Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Security Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Input Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:53:43 --> Language Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Loader Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:53:43 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Session Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:53:43 --> Session routines successfully run
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Controller Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Model Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:53:43 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:53:43 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:53:43 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:53:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:53:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:53:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:53:43 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:53:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 11:53:43 --> Final output sent to browser
DEBUG - 2015-05-07 11:53:43 --> Total execution time: 0.0648
DEBUG - 2015-05-07 11:54:22 --> Config Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:54:22 --> URI Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Router Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Output Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Security Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Input Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:54:22 --> Language Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Loader Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:54:22 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Session Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:54:22 --> Session routines successfully run
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Controller Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:54:22 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:54:22 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:54:22 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:54:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:54:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:54:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:54:22 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:54:22 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 11:54:22 --> Final output sent to browser
DEBUG - 2015-05-07 11:54:22 --> Total execution time: 0.0686
DEBUG - 2015-05-07 11:54:34 --> Config Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:54:34 --> URI Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Router Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Output Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Security Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Input Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:54:34 --> Language Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Loader Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:54:34 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Session Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:54:34 --> Session routines successfully run
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Controller Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:54:34 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: pdf_helper
DEBUG - 2015-05-07 11:54:34 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-05-07 11:54:34 --> Config Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:54:34 --> URI Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Router Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Output Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Security Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Input Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:54:34 --> Language Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Loader Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:54:34 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Session Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:54:34 --> Session routines successfully run
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Controller Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Model Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:54:34 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:54:34 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:54:35 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:54:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:54:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:54:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:54:35 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:54:35 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 11:54:35 --> Final output sent to browser
DEBUG - 2015-05-07 11:54:35 --> Total execution time: 0.0572
DEBUG - 2015-05-07 11:55:53 --> Config Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:55:53 --> URI Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Router Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Output Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Security Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Input Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:55:53 --> Language Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Loader Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:55:53 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Session Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:55:53 --> Session routines successfully run
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Controller Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Model Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:55:53 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:55:53 --> Helper loaded: pdf_helper
DEBUG - 2015-05-07 11:55:55 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-05-07 11:55:55 --> Final output sent to browser
DEBUG - 2015-05-07 11:55:55 --> Total execution time: 1.6701
DEBUG - 2015-05-07 11:57:01 --> Config Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:57:01 --> URI Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Router Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Output Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Security Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Input Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:57:01 --> Language Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Loader Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:57:01 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Session Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:57:01 --> Session routines successfully run
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Controller Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:57:01 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:57:01 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:57:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:57:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:57:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:57:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:57:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:57:01 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 11:57:01 --> Final output sent to browser
DEBUG - 2015-05-07 11:57:01 --> Total execution time: 0.0635
DEBUG - 2015-05-07 11:57:16 --> Config Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Hooks Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Utf8 Class Initialized
DEBUG - 2015-05-07 11:57:16 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 11:57:16 --> URI Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Router Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Output Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Security Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Input Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 11:57:16 --> Language Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Loader Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Helper loaded: url_helper
DEBUG - 2015-05-07 11:57:16 --> Database Driver Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Session Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Helper loaded: string_helper
DEBUG - 2015-05-07 11:57:16 --> Session routines successfully run
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Controller Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Model Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Helper loaded: form_helper
DEBUG - 2015-05-07 11:57:16 --> Form Validation Class Initialized
DEBUG - 2015-05-07 11:57:16 --> Pagination Class Initialized
DEBUG - 2015-05-07 11:57:16 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 11:57:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 11:57:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 11:57:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 11:57:16 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 11:57:16 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 11:57:16 --> Final output sent to browser
DEBUG - 2015-05-07 11:57:16 --> Total execution time: 0.0588
DEBUG - 2015-05-07 12:03:50 --> Config Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:03:50 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:03:50 --> URI Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Router Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Output Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Security Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Input Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:03:50 --> Language Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Loader Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:03:50 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Session Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:03:50 --> Session routines successfully run
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Controller Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:03:50 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:03:50 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:03:50 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:03:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:03:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:03:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:03:50 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:03:50 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-07 12:03:50 --> Final output sent to browser
DEBUG - 2015-05-07 12:03:50 --> Total execution time: 0.0746
DEBUG - 2015-05-07 12:03:51 --> Config Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:03:51 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:03:51 --> URI Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Router Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Output Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Security Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Input Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:03:51 --> Language Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Loader Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:03:51 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Session Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:03:51 --> Session routines successfully run
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Controller Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:51 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:52 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:03:52 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:03:52 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:03:52 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:03:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:03:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:03:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:03:52 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:03:52 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 12:03:52 --> Final output sent to browser
DEBUG - 2015-05-07 12:03:52 --> Total execution time: 0.0629
DEBUG - 2015-05-07 12:03:57 --> Config Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:03:57 --> URI Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Router Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Output Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Security Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Input Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:03:57 --> Language Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Loader Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:03:57 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Session Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:03:57 --> Session routines successfully run
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Controller Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Model Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:03:57 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:03:57 --> Helper loaded: pdf_helper
ERROR - 2015-05-07 12:03:58 --> Severity: Warning  --> fopen(file:///Applications/MAMP/htdocs/asmc/crm/pdf/receipts/customer/9.pdf): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/include/tcpdf_static.php 2440
DEBUG - 2015-05-07 12:04:15 --> Config Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:04:15 --> URI Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Router Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Output Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Security Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Input Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:04:15 --> Language Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Loader Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:04:15 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Session Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:04:15 --> Session routines successfully run
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Controller Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:04:15 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: pdf_helper
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2015-05-07 12:04:15 --> Config Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:04:15 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:04:15 --> URI Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Router Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Output Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Security Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Input Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:04:15 --> Language Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Loader Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:04:15 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Session Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:04:15 --> Session routines successfully run
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Controller Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:04:15 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:04:15 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:04:15 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 12:04:15 --> Final output sent to browser
DEBUG - 2015-05-07 12:04:15 --> Total execution time: 0.0551
DEBUG - 2015-05-07 12:04:20 --> Config Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:04:20 --> URI Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Router Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Output Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Security Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Input Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:04:20 --> Language Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Loader Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:04:20 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Session Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:04:20 --> Session routines successfully run
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Controller Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Model Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:04:20 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:04:20 --> Helper loaded: pdf_helper
DEBUG - 2015-05-07 12:04:20 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2015-05-07 12:04:20 --> Final output sent to browser
DEBUG - 2015-05-07 12:04:20 --> Total execution time: 0.4619
DEBUG - 2015-05-07 12:05:07 --> Config Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:05:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:05:07 --> URI Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Router Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Output Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Security Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Input Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:05:07 --> Language Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Loader Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:05:07 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Session Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:05:07 --> Session routines successfully run
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Controller Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Model Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:05:07 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:05:07 --> Helper loaded: pdf_helper
DEBUG - 2015-05-07 12:05:07 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-05-07 12:05:07 --> Final output sent to browser
DEBUG - 2015-05-07 12:05:07 --> Total execution time: 0.5027
DEBUG - 2015-05-07 12:08:00 --> Config Class Initialized
DEBUG - 2015-05-07 12:08:00 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:08:00 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:08:00 --> URI Class Initialized
DEBUG - 2015-05-07 12:08:00 --> Router Class Initialized
DEBUG - 2015-05-07 12:08:00 --> Output Class Initialized
DEBUG - 2015-05-07 12:08:00 --> Security Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Input Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:08:01 --> Language Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Loader Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:08:01 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Session Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:08:01 --> Session routines successfully run
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Controller Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:08:01 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:08:01 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:08:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:08:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:08:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:08:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:08:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:08:01 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 12:08:01 --> Final output sent to browser
DEBUG - 2015-05-07 12:08:01 --> Total execution time: 0.0774
DEBUG - 2015-05-07 12:08:17 --> Config Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:08:17 --> URI Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Router Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Output Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Security Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Input Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:08:17 --> Language Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Loader Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:08:17 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Session Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:08:17 --> Session routines successfully run
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Controller Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:08:17 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:08:17 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:08:17 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:08:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:08:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:08:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:08:17 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:08:17 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 12:08:17 --> Final output sent to browser
DEBUG - 2015-05-07 12:08:17 --> Total execution time: 0.0724
DEBUG - 2015-05-07 12:08:22 --> Config Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:08:22 --> URI Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Router Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Output Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Security Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Input Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:08:22 --> Language Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Loader Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:08:22 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Session Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:08:22 --> Session routines successfully run
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Controller Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Model Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:08:22 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:08:22 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:08:22 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:08:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:08:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:08:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:08:22 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:08:22 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 12:08:22 --> Final output sent to browser
DEBUG - 2015-05-07 12:08:22 --> Total execution time: 0.0600
DEBUG - 2015-05-07 12:09:10 --> Config Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:09:10 --> URI Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Router Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Output Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Security Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Input Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:09:10 --> Language Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Loader Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:09:10 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Session Class Initialized
DEBUG - 2015-05-07 12:09:10 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:09:10 --> Session routines successfully run
DEBUG - 2015-05-07 12:09:10 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Controller Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:09:11 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Config Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:09:11 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:09:11 --> URI Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Router Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Output Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Security Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Input Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:09:11 --> Language Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Loader Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:09:11 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Session Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:09:11 --> Session routines successfully run
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Controller Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:09:11 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:09:11 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:09:11 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:09:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:09:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:09:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:09:11 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:09:11 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 12:09:11 --> Final output sent to browser
DEBUG - 2015-05-07 12:09:11 --> Total execution time: 0.0618
DEBUG - 2015-05-07 12:09:18 --> Config Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:09:18 --> URI Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Router Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Output Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Security Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Input Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:09:18 --> Language Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Loader Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:09:18 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Session Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:09:18 --> Session routines successfully run
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Controller Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:09:18 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Config Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:09:18 --> URI Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Router Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Output Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Security Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Input Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:09:18 --> Language Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Loader Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:09:18 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Session Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:09:18 --> Session routines successfully run
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Controller Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:09:18 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:09:18 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:09:18 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:09:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:09:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:09:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:09:18 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:09:18 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 12:09:18 --> Final output sent to browser
DEBUG - 2015-05-07 12:09:18 --> Total execution time: 0.0575
DEBUG - 2015-05-07 12:09:54 --> Config Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:09:54 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:09:54 --> URI Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Router Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Output Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Security Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Input Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:09:54 --> Language Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Loader Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:09:54 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Session Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:09:54 --> Session routines successfully run
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Controller Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:09:54 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Config Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Hooks Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Utf8 Class Initialized
DEBUG - 2015-05-07 12:09:54 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 12:09:54 --> URI Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Router Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Output Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Security Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Input Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 12:09:54 --> Language Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Loader Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Helper loaded: url_helper
DEBUG - 2015-05-07 12:09:54 --> Database Driver Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Session Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Helper loaded: string_helper
DEBUG - 2015-05-07 12:09:54 --> Session routines successfully run
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Controller Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Model Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Helper loaded: form_helper
DEBUG - 2015-05-07 12:09:54 --> Form Validation Class Initialized
DEBUG - 2015-05-07 12:09:54 --> Pagination Class Initialized
DEBUG - 2015-05-07 12:09:54 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 12:09:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 12:09:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 12:09:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 12:09:54 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 12:09:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 12:09:54 --> Final output sent to browser
DEBUG - 2015-05-07 12:09:54 --> Total execution time: 0.0624
DEBUG - 2015-05-07 13:19:44 --> Config Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:19:44 --> URI Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Router Class Initialized
DEBUG - 2015-05-07 13:19:44 --> No URI present. Default controller set.
DEBUG - 2015-05-07 13:19:44 --> Output Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Security Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Input Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:19:44 --> Language Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Loader Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:19:44 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Session Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:19:44 --> Session routines successfully run
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Controller Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:19:44 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Config Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:19:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:19:44 --> URI Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Router Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Output Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Security Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Input Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:19:44 --> Language Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Loader Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:19:44 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Session Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:19:44 --> Session routines successfully run
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Controller Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:19:44 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:19:44 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:19:44 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:19:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:19:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:19:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:19:44 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:19:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-07 13:19:44 --> Final output sent to browser
DEBUG - 2015-05-07 13:19:44 --> Total execution time: 0.0414
DEBUG - 2015-05-07 13:19:46 --> Config Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:19:46 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:19:46 --> URI Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Router Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Output Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Security Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Input Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:19:46 --> Language Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Loader Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:19:46 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Session Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:19:46 --> Session routines successfully run
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Controller Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:19:46 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:19:46 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:19:46 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:19:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:19:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:19:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:19:46 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:19:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-07 13:19:46 --> Final output sent to browser
DEBUG - 2015-05-07 13:19:46 --> Total execution time: 0.0612
DEBUG - 2015-05-07 13:19:48 --> Config Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:19:48 --> URI Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Router Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Output Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Security Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Input Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:19:48 --> Language Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Loader Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:19:48 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Session Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:19:48 --> Session routines successfully run
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Controller Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:19:48 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:19:48 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:19:48 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:19:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:19:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:19:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:19:48 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:19:48 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 13:19:48 --> Final output sent to browser
DEBUG - 2015-05-07 13:19:48 --> Total execution time: 0.0551
DEBUG - 2015-05-07 13:19:55 --> Config Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:19:55 --> URI Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Router Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Output Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Security Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Input Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:19:55 --> Language Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Loader Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:19:55 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Session Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:19:55 --> Session routines successfully run
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Controller Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:19:55 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 13:19:55 --> Config Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:19:55 --> URI Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Router Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Output Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Security Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Input Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:19:55 --> Language Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Loader Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:19:55 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Session Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:19:55 --> Session routines successfully run
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Controller Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:19:55 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:19:55 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:19:55 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:19:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:19:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:19:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:19:55 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:19:55 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:19:55 --> Final output sent to browser
DEBUG - 2015-05-07 13:19:55 --> Total execution time: 0.0555
DEBUG - 2015-05-07 13:20:49 --> Config Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:20:49 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:20:49 --> URI Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Router Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Output Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Security Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Input Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:20:49 --> Language Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Loader Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:20:49 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Session Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:20:49 --> Session routines successfully run
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Controller Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:20:49 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:20:49 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:20:49 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:20:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:20:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:20:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:20:49 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:20:49 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 13:20:49 --> Final output sent to browser
DEBUG - 2015-05-07 13:20:49 --> Total execution time: 0.0660
DEBUG - 2015-05-07 13:20:55 --> Config Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:20:55 --> URI Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Router Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Output Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Security Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Input Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:20:55 --> Language Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Loader Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:20:55 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Session Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:20:55 --> Session routines successfully run
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Controller Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:20:55 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 13:20:55 --> Config Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:20:55 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:20:55 --> URI Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Router Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Output Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Security Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Input Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:20:55 --> Language Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Loader Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:20:55 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Session Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:20:55 --> Session routines successfully run
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Controller Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Model Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:20:55 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:20:55 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:20:55 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:20:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:20:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:20:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:20:55 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:20:55 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:20:55 --> Final output sent to browser
DEBUG - 2015-05-07 13:20:55 --> Total execution time: 0.0532
DEBUG - 2015-05-07 13:35:22 --> Config Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:35:22 --> URI Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Router Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Output Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Security Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Input Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:35:22 --> Language Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Loader Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:35:22 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Session Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:35:22 --> Session routines successfully run
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Controller Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:35:22 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:35:22 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:35:22 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:35:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:35:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:35:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:35:22 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:35:22 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 13:35:22 --> Final output sent to browser
DEBUG - 2015-05-07 13:35:22 --> Total execution time: 0.0788
DEBUG - 2015-05-07 13:35:32 --> Config Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:35:32 --> URI Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Router Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Output Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Security Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Input Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:35:32 --> Language Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Loader Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:35:32 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Session Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:35:32 --> Session routines successfully run
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Controller Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:35:32 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 13:35:32 --> Config Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:35:32 --> URI Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Router Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Output Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Security Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Input Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:35:32 --> Language Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Loader Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:35:32 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Session Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:35:32 --> Session routines successfully run
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Controller Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Model Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:35:32 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:35:32 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:35:32 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:35:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:35:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:35:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:35:32 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:35:32 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:35:32 --> Final output sent to browser
DEBUG - 2015-05-07 13:35:32 --> Total execution time: 0.0568
DEBUG - 2015-05-07 13:36:27 --> Config Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:36:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:36:27 --> URI Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Router Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Output Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Security Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Input Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:36:27 --> Language Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Loader Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:36:27 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Session Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:36:27 --> Session routines successfully run
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Controller Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:36:27 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:36:27 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:36:27 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:36:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:36:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:36:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:36:27 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:36:27 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:36:27 --> Final output sent to browser
DEBUG - 2015-05-07 13:36:27 --> Total execution time: 0.0662
DEBUG - 2015-05-07 13:36:49 --> Config Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:36:49 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:36:49 --> URI Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Router Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Output Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Security Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Input Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:36:49 --> Language Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Loader Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:36:49 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Session Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:36:49 --> Session routines successfully run
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Controller Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Model Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:36:49 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:36:49 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:36:49 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:36:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:36:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:36:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:36:49 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:36:49 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:36:49 --> Final output sent to browser
DEBUG - 2015-05-07 13:36:49 --> Total execution time: 0.0581
DEBUG - 2015-05-07 13:37:01 --> Config Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:37:01 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:37:01 --> URI Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Router Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Output Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Security Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Input Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:37:01 --> Language Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Loader Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:37:01 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Session Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:37:01 --> Session routines successfully run
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Controller Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Model Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:37:01 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:37:01 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:37:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:37:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:37:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:37:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:37:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:37:01 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 13:37:01 --> Final output sent to browser
DEBUG - 2015-05-07 13:37:01 --> Total execution time: 0.0646
DEBUG - 2015-05-07 13:45:37 --> Config Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:45:37 --> URI Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Router Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Output Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Security Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Input Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:45:37 --> Language Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Loader Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:45:37 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Session Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:45:37 --> Session routines successfully run
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Controller Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:45:37 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:45:37 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:45:37 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:45:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:45:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:45:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:45:37 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:45:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 13:45:37 --> Final output sent to browser
DEBUG - 2015-05-07 13:45:37 --> Total execution time: 0.0839
DEBUG - 2015-05-07 13:45:48 --> Config Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:45:48 --> URI Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Router Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Output Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Security Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Input Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:45:48 --> Language Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Loader Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:45:48 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Session Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:45:48 --> Session routines successfully run
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Controller Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:45:48 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 13:45:48 --> Config Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:45:48 --> URI Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Router Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Output Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Security Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Input Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:45:48 --> Language Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Loader Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:45:48 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Session Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:45:48 --> Session routines successfully run
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Controller Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Model Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:45:48 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:45:48 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:45:48 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:45:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:45:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:45:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:45:48 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:45:48 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:45:48 --> Final output sent to browser
DEBUG - 2015-05-07 13:45:48 --> Total execution time: 0.0544
DEBUG - 2015-05-07 13:46:37 --> Config Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:46:37 --> URI Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Router Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Output Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Security Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Input Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:46:37 --> Language Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Loader Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:46:37 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Session Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:46:37 --> Session routines successfully run
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Controller Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:46:37 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:46:37 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:46:37 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:46:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:46:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:46:37 --> File loaded: application/views/sidebar.php
ERROR - 2015-05-07 13:46:37 --> Severity: Notice  --> Use of undefined constant RECEIPT_URL - assumed 'RECEIPT_URL' /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/invoiceView.php 252
DEBUG - 2015-05-07 13:46:37 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:46:37 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:46:37 --> Final output sent to browser
DEBUG - 2015-05-07 13:46:37 --> Total execution time: 0.0637
DEBUG - 2015-05-07 13:47:36 --> Config Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:47:36 --> URI Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Router Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Output Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Security Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Input Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:47:36 --> Language Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Loader Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:47:36 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Session Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:47:36 --> Session routines successfully run
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Controller Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Model Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:47:36 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:47:36 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:47:36 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:47:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:47:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:47:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:47:36 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:47:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:47:36 --> Final output sent to browser
DEBUG - 2015-05-07 13:47:36 --> Total execution time: 0.0588
DEBUG - 2015-05-07 13:48:29 --> Config Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:48:29 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:48:29 --> URI Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Router Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Output Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Security Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Input Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:48:29 --> Language Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Loader Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:48:29 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Session Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:48:29 --> Session routines successfully run
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Controller Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:48:29 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:48:29 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:48:29 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:48:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:48:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:48:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:48:29 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:48:29 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:48:29 --> Final output sent to browser
DEBUG - 2015-05-07 13:48:29 --> Total execution time: 0.0629
DEBUG - 2015-05-07 13:48:35 --> Config Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:48:35 --> URI Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Router Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Output Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Security Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Input Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:48:35 --> Language Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Loader Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:48:35 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Session Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:48:35 --> Session routines successfully run
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Controller Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:48:35 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:48:35 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:48:35 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:48:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:48:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:48:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:48:35 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:48:35 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-07 13:48:35 --> Final output sent to browser
DEBUG - 2015-05-07 13:48:35 --> Total execution time: 0.0578
DEBUG - 2015-05-07 13:48:37 --> Config Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:48:37 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:48:37 --> URI Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Router Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Output Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Security Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Input Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:48:37 --> Language Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Loader Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:48:37 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Session Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:48:37 --> Session routines successfully run
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Controller Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:48:37 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:48:37 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:48:37 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:48:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:48:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:48:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:48:37 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:48:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-07 13:48:37 --> Final output sent to browser
DEBUG - 2015-05-07 13:48:37 --> Total execution time: 0.0650
DEBUG - 2015-05-07 13:48:40 --> Config Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:48:40 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:48:40 --> URI Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Router Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Output Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Security Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Input Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:48:40 --> Language Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Loader Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:48:40 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Session Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:48:40 --> Session routines successfully run
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Controller Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:48:40 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-07 13:48:40 --> Config Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Hooks Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Utf8 Class Initialized
DEBUG - 2015-05-07 13:48:40 --> UTF-8 Support Enabled
DEBUG - 2015-05-07 13:48:40 --> URI Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Router Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Output Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Security Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Input Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-07 13:48:40 --> Language Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Loader Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Helper loaded: url_helper
DEBUG - 2015-05-07 13:48:40 --> Database Driver Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Session Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Helper loaded: string_helper
DEBUG - 2015-05-07 13:48:40 --> Session routines successfully run
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Controller Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Model Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Helper loaded: form_helper
DEBUG - 2015-05-07 13:48:40 --> Form Validation Class Initialized
DEBUG - 2015-05-07 13:48:40 --> Pagination Class Initialized
DEBUG - 2015-05-07 13:48:40 --> File loaded: application/views/header.php
DEBUG - 2015-05-07 13:48:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-07 13:48:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-07 13:48:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-07 13:48:40 --> File loaded: application/views/footer.php
DEBUG - 2015-05-07 13:48:40 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-07 13:48:40 --> Final output sent to browser
DEBUG - 2015-05-07 13:48:40 --> Total execution time: 0.0545
