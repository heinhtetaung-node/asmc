<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-05-06 09:25:44 --> Config Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Hooks Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Utf8 Class Initialized
DEBUG - 2015-05-06 09:25:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 09:25:44 --> URI Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Router Class Initialized
DEBUG - 2015-05-06 09:25:44 --> No URI present. Default controller set.
DEBUG - 2015-05-06 09:25:44 --> Output Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Security Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Input Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 09:25:44 --> Language Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Loader Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Helper loaded: url_helper
DEBUG - 2015-05-06 09:25:44 --> Database Driver Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Session Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Helper loaded: string_helper
DEBUG - 2015-05-06 09:25:44 --> A session cookie was not found.
DEBUG - 2015-05-06 09:25:44 --> Session routines successfully run
DEBUG - 2015-05-06 09:25:44 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Controller Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:44 --> Helper loaded: form_helper
DEBUG - 2015-05-06 09:25:44 --> Form Validation Class Initialized
DEBUG - 2015-05-06 09:25:44 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-06 09:25:44 --> Final output sent to browser
DEBUG - 2015-05-06 09:25:44 --> Total execution time: 0.0564
DEBUG - 2015-05-06 09:25:50 --> Config Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Hooks Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Utf8 Class Initialized
DEBUG - 2015-05-06 09:25:50 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 09:25:50 --> URI Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Router Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Output Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Security Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Input Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 09:25:50 --> Language Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Loader Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Helper loaded: url_helper
DEBUG - 2015-05-06 09:25:50 --> Database Driver Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Session Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Helper loaded: string_helper
DEBUG - 2015-05-06 09:25:50 --> Session routines successfully run
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Controller Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Helper loaded: form_helper
DEBUG - 2015-05-06 09:25:50 --> Form Validation Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-06 09:25:50 --> Config Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Hooks Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Utf8 Class Initialized
DEBUG - 2015-05-06 09:25:50 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 09:25:50 --> URI Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Router Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Output Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Security Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Input Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 09:25:50 --> Language Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Loader Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Helper loaded: url_helper
DEBUG - 2015-05-06 09:25:50 --> Database Driver Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Session Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Helper loaded: string_helper
DEBUG - 2015-05-06 09:25:50 --> Session routines successfully run
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Controller Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Helper loaded: form_helper
DEBUG - 2015-05-06 09:25:50 --> Form Validation Class Initialized
DEBUG - 2015-05-06 09:25:50 --> Pagination Class Initialized
DEBUG - 2015-05-06 09:25:50 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 09:25:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 09:25:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 09:25:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 09:25:50 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 09:25:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-06 09:25:50 --> Final output sent to browser
DEBUG - 2015-05-06 09:25:50 --> Total execution time: 0.0471
DEBUG - 2015-05-06 09:25:52 --> Config Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Hooks Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Utf8 Class Initialized
DEBUG - 2015-05-06 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 09:25:52 --> URI Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Router Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Output Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Security Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Input Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 09:25:52 --> Language Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Loader Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Helper loaded: url_helper
DEBUG - 2015-05-06 09:25:52 --> Database Driver Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Session Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Helper loaded: string_helper
DEBUG - 2015-05-06 09:25:52 --> Session routines successfully run
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Controller Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Helper loaded: form_helper
DEBUG - 2015-05-06 09:25:52 --> Form Validation Class Initialized
DEBUG - 2015-05-06 09:25:52 --> Pagination Class Initialized
DEBUG - 2015-05-06 09:25:52 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 09:25:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 09:25:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 09:25:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 09:25:52 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 09:25:52 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-06 09:25:52 --> Final output sent to browser
DEBUG - 2015-05-06 09:25:52 --> Total execution time: 0.0806
DEBUG - 2015-05-06 09:25:58 --> Config Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Hooks Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Utf8 Class Initialized
DEBUG - 2015-05-06 09:25:58 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 09:25:58 --> URI Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Router Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Output Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Security Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Input Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 09:25:58 --> Language Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Loader Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Helper loaded: url_helper
DEBUG - 2015-05-06 09:25:58 --> Database Driver Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Session Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Helper loaded: string_helper
DEBUG - 2015-05-06 09:25:58 --> Session routines successfully run
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Controller Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Model Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Helper loaded: form_helper
DEBUG - 2015-05-06 09:25:58 --> Form Validation Class Initialized
DEBUG - 2015-05-06 09:25:58 --> Pagination Class Initialized
DEBUG - 2015-05-06 09:25:58 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 09:25:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 09:25:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 09:25:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 09:25:58 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 09:25:58 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-06 09:25:58 --> Final output sent to browser
DEBUG - 2015-05-06 09:25:58 --> Total execution time: 0.0843
DEBUG - 2015-05-06 09:27:01 --> Config Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Hooks Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Utf8 Class Initialized
DEBUG - 2015-05-06 09:27:01 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 09:27:01 --> URI Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Router Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Output Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Security Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Input Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 09:27:01 --> Language Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Loader Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Helper loaded: url_helper
DEBUG - 2015-05-06 09:27:01 --> Database Driver Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Session Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Helper loaded: string_helper
DEBUG - 2015-05-06 09:27:01 --> Session routines successfully run
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Controller Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Model Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Helper loaded: form_helper
DEBUG - 2015-05-06 09:27:01 --> Form Validation Class Initialized
DEBUG - 2015-05-06 09:27:01 --> Pagination Class Initialized
DEBUG - 2015-05-06 09:27:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 09:27:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 09:27:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 09:27:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 09:27:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 09:27:01 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-06 09:27:01 --> Final output sent to browser
DEBUG - 2015-05-06 09:27:01 --> Total execution time: 0.0736
DEBUG - 2015-05-06 15:49:03 --> Config Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:49:03 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:49:03 --> URI Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Router Class Initialized
DEBUG - 2015-05-06 15:49:03 --> No URI present. Default controller set.
DEBUG - 2015-05-06 15:49:03 --> Output Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Security Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Input Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:49:03 --> Language Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Loader Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:49:03 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Session Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:49:03 --> A session cookie was not found.
DEBUG - 2015-05-06 15:49:03 --> Session routines successfully run
DEBUG - 2015-05-06 15:49:03 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Controller Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:03 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:49:03 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:49:03 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-06 15:49:03 --> Final output sent to browser
DEBUG - 2015-05-06 15:49:03 --> Total execution time: 0.1294
DEBUG - 2015-05-06 15:49:08 --> Config Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:49:08 --> URI Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Router Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Output Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Security Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Input Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:49:08 --> Language Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Loader Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:49:08 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Session Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:49:08 --> Session routines successfully run
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Controller Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:49:08 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-06 15:49:08 --> Config Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:49:08 --> URI Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Router Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Output Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Security Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Input Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:49:08 --> Language Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Loader Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:49:08 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Session Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:49:08 --> Session routines successfully run
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Controller Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:49:08 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:49:08 --> Pagination Class Initialized
DEBUG - 2015-05-06 15:49:08 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 15:49:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 15:49:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 15:49:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 15:49:08 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 15:49:08 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-06 15:49:08 --> Final output sent to browser
DEBUG - 2015-05-06 15:49:08 --> Total execution time: 0.0512
DEBUG - 2015-05-06 15:49:42 --> Config Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:49:42 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:49:42 --> URI Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Router Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Output Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Security Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Input Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:49:42 --> Language Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Loader Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:49:42 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Session Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:49:42 --> Session routines successfully run
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Controller Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:49:42 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:49:42 --> Pagination Class Initialized
DEBUG - 2015-05-06 15:49:42 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 15:49:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 15:49:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 15:49:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 15:49:42 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 15:49:42 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-06 15:49:42 --> Final output sent to browser
DEBUG - 2015-05-06 15:49:42 --> Total execution time: 0.0876
DEBUG - 2015-05-06 15:49:44 --> Config Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:49:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:49:44 --> URI Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Router Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Output Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Security Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Input Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:49:44 --> Language Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Loader Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:49:44 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Session Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:49:44 --> Session routines successfully run
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Controller Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Model Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:49:44 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:49:44 --> Pagination Class Initialized
DEBUG - 2015-05-06 15:49:44 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 15:49:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 15:49:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 15:49:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 15:49:44 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 15:49:44 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-06 15:49:44 --> Final output sent to browser
DEBUG - 2015-05-06 15:49:44 --> Total execution time: 0.0582
DEBUG - 2015-05-06 15:54:25 --> Config Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:54:25 --> URI Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Router Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Output Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Security Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Input Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:54:25 --> Language Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Loader Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:54:25 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Session Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:54:25 --> Session routines successfully run
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Controller Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Model Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:54:25 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:54:25 --> Pagination Class Initialized
DEBUG - 2015-05-06 15:54:25 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 15:54:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 15:54:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 15:54:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 15:54:25 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 15:54:25 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-06 15:54:25 --> Final output sent to browser
DEBUG - 2015-05-06 15:54:25 --> Total execution time: 0.0698
DEBUG - 2015-05-06 15:55:23 --> Config Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Hooks Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Utf8 Class Initialized
DEBUG - 2015-05-06 15:55:23 --> UTF-8 Support Enabled
DEBUG - 2015-05-06 15:55:23 --> URI Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Router Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Output Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Security Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Input Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-06 15:55:23 --> Language Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Loader Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Helper loaded: url_helper
DEBUG - 2015-05-06 15:55:23 --> Database Driver Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Session Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Helper loaded: string_helper
DEBUG - 2015-05-06 15:55:23 --> Session routines successfully run
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Controller Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Model Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Helper loaded: form_helper
DEBUG - 2015-05-06 15:55:23 --> Form Validation Class Initialized
DEBUG - 2015-05-06 15:55:23 --> Pagination Class Initialized
DEBUG - 2015-05-06 15:55:23 --> File loaded: application/views/header.php
DEBUG - 2015-05-06 15:55:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-06 15:55:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-06 15:55:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-06 15:55:23 --> File loaded: application/views/footer.php
DEBUG - 2015-05-06 15:55:23 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-06 15:55:23 --> Final output sent to browser
DEBUG - 2015-05-06 15:55:23 --> Total execution time: 0.0626
