<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-05-03 15:16:28 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:28 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:28 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Router Class Initialized
DEBUG - 2016-05-03 15:16:28 --> No URI present. Default controller set.
DEBUG - 2016-05-03 15:16:28 --> Output Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Security Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Input Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:16:28 --> Language Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Loader Class Initialized
DEBUG - 2016-05-03 15:16:28 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:16:29 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Session Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:16:29 --> A session cookie was not found.
DEBUG - 2016-05-03 15:16:29 --> Session routines successfully run
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Controller Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:16:29 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:16:29 --> File loaded: application/views/loginView.php
DEBUG - 2016-05-03 15:16:29 --> Final output sent to browser
DEBUG - 2016-05-03 15:16:29 --> Total execution time: 0.1198
DEBUG - 2016-05-03 15:16:29 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:29 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:29 --> Router Class Initialized
ERROR - 2016-05-03 15:16:29 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:16:36 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:36 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Router Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Output Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Security Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Input Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:16:36 --> Language Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Loader Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:16:36 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Session Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:16:36 --> Session routines successfully run
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Controller Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:16:36 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-05-03 15:16:36 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:36 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Router Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Output Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Security Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Input Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:16:36 --> Language Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Loader Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:16:36 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Session Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:16:36 --> Session routines successfully run
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Controller Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:16:36 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:16:36 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:16:36 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:16:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:16:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:16:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:16:36 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:16:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-05-03 15:16:36 --> Final output sent to browser
DEBUG - 2016-05-03 15:16:36 --> Total execution time: 0.0492
DEBUG - 2016-05-03 15:16:37 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:37 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:37 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:37 --> Router Class Initialized
ERROR - 2016-05-03 15:16:37 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:16:39 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:39 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Router Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Output Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Security Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Input Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:16:39 --> Language Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Loader Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:16:39 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Session Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:16:39 --> Session routines successfully run
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Controller Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:39 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:16:39 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:16:39 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:16:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:16:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:16:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:16:39 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:16:39 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-05-03 15:16:39 --> Final output sent to browser
DEBUG - 2016-05-03 15:16:39 --> Total execution time: 0.0509
DEBUG - 2016-05-03 15:16:40 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:40 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:40 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:40 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:40 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:40 --> Router Class Initialized
ERROR - 2016-05-03 15:16:40 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:16:41 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:41 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:41 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Router Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Output Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Security Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Input Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:16:41 --> Language Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Loader Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:16:41 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Session Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:16:41 --> Session routines successfully run
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Controller Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:41 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:42 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:16:42 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:16:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:16:42 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:16:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:16:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:16:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:16:42 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:16:42 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-05-03 15:16:42 --> Final output sent to browser
DEBUG - 2016-05-03 15:16:42 --> Total execution time: 0.0903
DEBUG - 2016-05-03 15:16:42 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:42 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:42 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:42 --> Router Class Initialized
ERROR - 2016-05-03 15:16:42 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:16:44 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:44 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Router Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Output Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Security Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Input Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:16:44 --> Language Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Loader Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:16:44 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Session Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:16:44 --> Session routines successfully run
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Controller Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:16:44 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:16:44 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:16:44 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:16:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:16:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:16:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:16:44 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:16:44 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:16:44 --> Final output sent to browser
DEBUG - 2016-05-03 15:16:44 --> Total execution time: 0.0899
DEBUG - 2016-05-03 15:16:45 --> Config Class Initialized
DEBUG - 2016-05-03 15:16:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:16:45 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:16:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:16:45 --> URI Class Initialized
DEBUG - 2016-05-03 15:16:45 --> Router Class Initialized
ERROR - 2016-05-03 15:16:45 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:18:45 --> Config Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:18:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:18:45 --> URI Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Router Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Output Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Security Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Input Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:18:45 --> Language Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Loader Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:18:45 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Session Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:18:45 --> Session routines successfully run
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Controller Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:18:45 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:18:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Config Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:18:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:18:46 --> URI Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Router Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Output Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Security Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Input Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:18:46 --> Language Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Loader Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:18:46 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Session Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:18:46 --> Session routines successfully run
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Controller Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:18:46 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:18:46 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:18:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:18:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:18:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:18:46 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:18:46 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:18:46 --> Final output sent to browser
DEBUG - 2016-05-03 15:18:46 --> Total execution time: 0.0712
DEBUG - 2016-05-03 15:18:46 --> Config Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:18:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:18:46 --> URI Class Initialized
DEBUG - 2016-05-03 15:18:46 --> Router Class Initialized
ERROR - 2016-05-03 15:18:46 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:19:44 --> Config Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:19:44 --> URI Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Router Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Output Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Security Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Input Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:19:44 --> Language Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Loader Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:19:44 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Session Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:19:44 --> Session routines successfully run
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Controller Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:19:44 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Config Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:19:44 --> URI Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Router Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Output Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Security Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Input Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:19:44 --> Language Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Loader Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:19:44 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Session Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:19:44 --> Session routines successfully run
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Controller Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:19:44 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:19:44 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:19:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:19:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:19:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:19:44 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:19:44 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:19:44 --> Final output sent to browser
DEBUG - 2016-05-03 15:19:44 --> Total execution time: 0.0795
DEBUG - 2016-05-03 15:19:44 --> Config Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:19:44 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:19:44 --> URI Class Initialized
DEBUG - 2016-05-03 15:19:44 --> Router Class Initialized
ERROR - 2016-05-03 15:19:44 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:19:48 --> Config Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:19:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:19:48 --> URI Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Router Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Output Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Security Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Input Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:19:48 --> Language Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Loader Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:19:48 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Session Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:19:48 --> Session routines successfully run
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Controller Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:19:48 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:19:48 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:19:48 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2016-05-03 15:19:48 --> Final output sent to browser
DEBUG - 2016-05-03 15:19:48 --> Total execution time: 0.5682
DEBUG - 2016-05-03 15:20:57 --> Config Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:20:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:20:57 --> URI Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Router Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Output Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Security Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Input Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:20:57 --> Language Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Loader Class Initialized
DEBUG - 2016-05-03 15:20:57 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:20:57 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Session Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:20:58 --> Session routines successfully run
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Controller Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:20:58 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2016-05-03 15:20:58 --> Config Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:20:58 --> URI Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Router Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Output Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Security Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Input Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:20:58 --> Language Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Loader Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:20:58 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Session Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:20:58 --> Session routines successfully run
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Controller Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Model Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:20:58 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:20:58 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:20:58 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:20:58 --> Final output sent to browser
DEBUG - 2016-05-03 15:20:58 --> Total execution time: 0.0674
DEBUG - 2016-05-03 15:20:59 --> Config Class Initialized
DEBUG - 2016-05-03 15:20:59 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:20:59 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:20:59 --> URI Class Initialized
DEBUG - 2016-05-03 15:20:59 --> Router Class Initialized
ERROR - 2016-05-03 15:20:59 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:22:01 --> Config Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:22:01 --> URI Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Router Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Output Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Security Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Input Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:22:01 --> Language Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Loader Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:22:01 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Session Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:22:01 --> Session routines successfully run
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Controller Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:22:01 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2016-05-03 15:22:01 --> Config Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:22:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:22:01 --> URI Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Router Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Output Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Security Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Input Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:22:01 --> Language Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Loader Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:22:01 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Session Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:22:01 --> Session routines successfully run
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Controller Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:22:01 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:22:01 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:22:01 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:22:01 --> Final output sent to browser
DEBUG - 2016-05-03 15:22:01 --> Total execution time: 0.0659
DEBUG - 2016-05-03 15:22:02 --> Config Class Initialized
DEBUG - 2016-05-03 15:22:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:22:02 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:22:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:22:02 --> URI Class Initialized
DEBUG - 2016-05-03 15:22:02 --> Router Class Initialized
ERROR - 2016-05-03 15:22:02 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:23:16 --> Config Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:23:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:23:16 --> URI Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Router Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Output Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Security Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Input Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:23:16 --> Language Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Loader Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:23:16 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Session Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:23:16 --> Session routines successfully run
DEBUG - 2016-05-03 15:23:16 --> Model Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Model Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Controller Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Model Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Email Class Initialized
DEBUG - 2016-05-03 15:23:16 --> Language file loaded: language/english/email_lang.php
DEBUG - 2016-05-03 15:23:17 --> Final output sent to browser
DEBUG - 2016-05-03 15:23:17 --> Total execution time: 1.0295
DEBUG - 2016-05-03 15:25:42 --> Config Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:25:42 --> URI Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Router Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Output Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Security Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Input Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:25:42 --> Language Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Loader Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:25:42 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Session Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:25:42 --> Session routines successfully run
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Controller Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Model Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:25:42 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:25:42 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:25:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:25:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:25:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:25:42 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:25:42 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-05-03 15:25:42 --> Final output sent to browser
DEBUG - 2016-05-03 15:25:42 --> Total execution time: 0.0891
DEBUG - 2016-05-03 15:25:42 --> Config Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:25:42 --> URI Class Initialized
DEBUG - 2016-05-03 15:25:42 --> Router Class Initialized
ERROR - 2016-05-03 15:25:42 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:26:21 --> Config Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:26:21 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:26:21 --> URI Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Router Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Output Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Security Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Input Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:26:21 --> Language Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Loader Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:26:21 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Session Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:26:21 --> Session routines successfully run
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Controller Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:26:21 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:26:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-05-03 15:26:21 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:26:21 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-05-03 15:26:23 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-05-03 15:26:24 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-05-03 15:26:25 --> Config Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:26:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:26:25 --> URI Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Router Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Output Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Security Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Input Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:26:25 --> Language Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Loader Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:26:25 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Session Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:26:25 --> Session routines successfully run
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Controller Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Model Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:26:25 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:26:25 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:26:25 --> Final output sent to browser
DEBUG - 2016-05-03 15:26:25 --> Total execution time: 0.0610
DEBUG - 2016-05-03 15:26:25 --> Config Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:26:25 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:26:25 --> URI Class Initialized
DEBUG - 2016-05-03 15:26:25 --> Router Class Initialized
ERROR - 2016-05-03 15:26:25 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:33:38 --> Config Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:33:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:33:38 --> URI Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Router Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Output Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Security Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Input Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:33:38 --> Language Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Loader Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:33:38 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Session Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:33:38 --> Session routines successfully run
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Controller Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:33:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Config Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:34:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:34:31 --> URI Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Router Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Output Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Security Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Input Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:34:31 --> Language Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Loader Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:34:31 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Session Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:34:31 --> Session routines successfully run
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Controller Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:34:31 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:34:31 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:34:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:34:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:34:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:34:31 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:34:31 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-05-03 15:34:31 --> Final output sent to browser
DEBUG - 2016-05-03 15:34:31 --> Total execution time: 0.1146
DEBUG - 2016-05-03 15:34:31 --> Config Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:34:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:34:31 --> URI Class Initialized
DEBUG - 2016-05-03 15:34:31 --> Router Class Initialized
ERROR - 2016-05-03 15:34:31 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:34:43 --> Config Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:34:43 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:34:43 --> URI Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Router Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Output Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Security Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Input Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:34:43 --> Language Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Loader Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:34:43 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Session Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:34:43 --> Session routines successfully run
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Controller Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:34:43 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:34:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-05-03 15:34:43 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:34:44 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-05-03 15:34:45 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-05-03 15:34:46 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-05-03 15:34:48 --> Config Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:34:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:34:48 --> URI Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Router Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Output Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Security Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Input Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:34:48 --> Language Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Loader Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:34:48 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Session Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:34:48 --> Session routines successfully run
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Controller Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Model Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:34:48 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:34:48 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:34:48 --> Final output sent to browser
DEBUG - 2016-05-03 15:34:48 --> Total execution time: 0.0623
DEBUG - 2016-05-03 15:34:48 --> Config Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:34:48 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:34:48 --> URI Class Initialized
DEBUG - 2016-05-03 15:34:48 --> Router Class Initialized
ERROR - 2016-05-03 15:34:48 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:35:49 --> Config Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:35:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:35:49 --> URI Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Router Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Output Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Security Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Input Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:35:49 --> Language Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Loader Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:35:49 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Session Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:35:49 --> Session routines successfully run
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Controller Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:35:49 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:35:49 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:35:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:35:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:35:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:35:49 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:35:49 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-05-03 15:35:49 --> Final output sent to browser
DEBUG - 2016-05-03 15:35:49 --> Total execution time: 0.0996
DEBUG - 2016-05-03 15:35:49 --> Config Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:35:49 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:35:49 --> URI Class Initialized
DEBUG - 2016-05-03 15:35:49 --> Router Class Initialized
ERROR - 2016-05-03 15:35:49 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:35:53 --> Config Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:35:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:35:53 --> URI Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Router Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Output Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Security Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Input Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:35:53 --> Language Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Loader Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:35:53 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Session Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:35:53 --> Session routines successfully run
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Controller Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:35:53 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:35:53 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Notice  --> Undefined variable: last_day /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 615
ERROR - 2016-05-03 15:35:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2016-05-03 15:35:53 --> Helper loaded: pdf_helper
ERROR - 2016-05-03 15:35:54 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/tcpdf.php 7624
DEBUG - 2016-05-03 15:36:19 --> Config Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:36:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:36:19 --> URI Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Router Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Output Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Security Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Input Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:36:19 --> Language Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Loader Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:36:19 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Session Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:36:19 --> Session routines successfully run
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Controller Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:36:19 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:36:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-05-03 15:36:19 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:36:20 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-05-03 15:36:21 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-05-03 15:36:22 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-05-03 15:36:23 --> Config Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:36:23 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:36:23 --> URI Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Router Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Output Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Security Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Input Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:36:23 --> Language Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Loader Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:36:23 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Session Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:36:23 --> Session routines successfully run
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Controller Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Model Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:36:23 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:36:23 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:36:23 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:36:23 --> Final output sent to browser
DEBUG - 2016-05-03 15:36:23 --> Total execution time: 0.0603
DEBUG - 2016-05-03 15:36:24 --> Config Class Initialized
DEBUG - 2016-05-03 15:36:24 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:36:24 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:36:24 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:36:24 --> URI Class Initialized
DEBUG - 2016-05-03 15:36:24 --> Router Class Initialized
ERROR - 2016-05-03 15:36:24 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:42:38 --> Config Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:42:38 --> URI Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Router Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Output Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Security Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Input Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:42:38 --> Language Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Loader Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:42:38 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Session Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:42:38 --> Session routines successfully run
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Controller Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:42:38 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:42:38 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:42:38 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:42:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:42:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:42:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:42:38 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:42:38 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:42:38 --> Final output sent to browser
DEBUG - 2016-05-03 15:42:38 --> Total execution time: 0.0944
DEBUG - 2016-05-03 15:42:39 --> Config Class Initialized
DEBUG - 2016-05-03 15:42:39 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:42:39 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:42:39 --> URI Class Initialized
DEBUG - 2016-05-03 15:42:39 --> Router Class Initialized
ERROR - 2016-05-03 15:42:39 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:42:53 --> Config Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:42:53 --> URI Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Router Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Output Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Security Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Input Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:42:53 --> Language Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Loader Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:42:53 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Session Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:42:53 --> Session routines successfully run
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Controller Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Model Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:42:53 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:42:53 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:42:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:42:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:42:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:42:53 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:42:53 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:42:53 --> Final output sent to browser
DEBUG - 2016-05-03 15:42:53 --> Total execution time: 0.1099
DEBUG - 2016-05-03 15:42:53 --> Config Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:42:53 --> URI Class Initialized
DEBUG - 2016-05-03 15:42:53 --> Router Class Initialized
ERROR - 2016-05-03 15:42:53 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:44:04 --> Config Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:44:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:44:04 --> URI Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Router Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Output Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Security Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Input Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:44:04 --> Language Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Loader Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:44:04 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Session Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:44:04 --> Session routines successfully run
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Controller Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:44:04 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:44:04 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:44:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:44:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:44:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:44:04 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:44:04 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:44:04 --> Final output sent to browser
DEBUG - 2016-05-03 15:44:04 --> Total execution time: 0.0858
DEBUG - 2016-05-03 15:44:04 --> Config Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:44:04 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:44:04 --> URI Class Initialized
DEBUG - 2016-05-03 15:44:04 --> Router Class Initialized
ERROR - 2016-05-03 15:44:04 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:44:46 --> Config Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:44:46 --> URI Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Router Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Output Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Security Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Input Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:44:46 --> Language Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Loader Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:44:46 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Session Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:44:46 --> Session routines successfully run
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Controller Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Model Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:44:46 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:44:46 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:44:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:44:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:44:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:44:46 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:44:46 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:44:46 --> Final output sent to browser
DEBUG - 2016-05-03 15:44:46 --> Total execution time: 0.0718
DEBUG - 2016-05-03 15:44:46 --> Config Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:44:46 --> URI Class Initialized
DEBUG - 2016-05-03 15:44:46 --> Router Class Initialized
ERROR - 2016-05-03 15:44:46 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:45:09 --> Config Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:45:09 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:45:09 --> URI Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Router Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Output Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Security Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Input Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:45:09 --> Language Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Loader Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:45:09 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Session Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:45:09 --> Session routines successfully run
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Controller Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Model Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:45:09 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:45:09 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:45:09 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:45:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:45:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:45:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:45:09 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:45:09 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:45:09 --> Final output sent to browser
DEBUG - 2016-05-03 15:45:09 --> Total execution time: 0.0601
DEBUG - 2016-05-03 15:45:10 --> Config Class Initialized
DEBUG - 2016-05-03 15:45:10 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:45:10 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:45:10 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:45:10 --> URI Class Initialized
DEBUG - 2016-05-03 15:45:10 --> Router Class Initialized
ERROR - 2016-05-03 15:45:10 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:46:17 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:17 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:17 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Router Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Output Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Security Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Input Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:46:17 --> Language Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Loader Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:46:17 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Session Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:46:17 --> Session routines successfully run
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Controller Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:46:17 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:46:17 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:46:17 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:46:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:46:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:46:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:46:17 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:46:18 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:46:18 --> Final output sent to browser
DEBUG - 2016-05-03 15:46:18 --> Total execution time: 0.0743
DEBUG - 2016-05-03 15:46:18 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:18 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:18 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:18 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:18 --> Router Class Initialized
ERROR - 2016-05-03 15:46:18 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:46:26 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:26 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Router Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Output Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Security Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Input Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:46:26 --> Language Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Loader Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:46:26 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Session Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:46:26 --> Session routines successfully run
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Controller Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:26 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:46:26 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:46:26 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:46:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:46:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:46:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:46:26 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:46:26 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-05-03 15:46:26 --> Final output sent to browser
DEBUG - 2016-05-03 15:46:26 --> Total execution time: 0.0417
DEBUG - 2016-05-03 15:46:27 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:27 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:27 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:27 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:27 --> Router Class Initialized
ERROR - 2016-05-03 15:46:27 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:46:29 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:29 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Router Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Output Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Security Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Input Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:46:29 --> Language Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Loader Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:46:29 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Session Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:46:29 --> Session routines successfully run
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Controller Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:46:29 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:46:29 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:46:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:46:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:46:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:46:29 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:46:29 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2016-05-03 15:46:29 --> Final output sent to browser
DEBUG - 2016-05-03 15:46:29 --> Total execution time: 0.0390
DEBUG - 2016-05-03 15:46:29 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:29 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:29 --> Router Class Initialized
ERROR - 2016-05-03 15:46:29 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:46:31 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:31 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:31 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Router Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Output Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Security Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Input Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:46:31 --> Language Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Loader Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:46:31 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Session Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:46:31 --> Session routines successfully run
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Controller Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:31 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:46:31 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:46:31 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:46:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:46:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:46:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:46:31 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:46:31 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-05-03 15:46:31 --> Final output sent to browser
DEBUG - 2016-05-03 15:46:31 --> Total execution time: 0.0395
DEBUG - 2016-05-03 15:46:32 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:32 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:32 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:32 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:32 --> Router Class Initialized
ERROR - 2016-05-03 15:46:32 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:46:36 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:36 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Router Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Output Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Security Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Input Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:46:36 --> Language Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Loader Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:46:36 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Session Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:46:36 --> Session routines successfully run
DEBUG - 2016-05-03 15:46:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Controller Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:46:36 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:46:36 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:46:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:46:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:46:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:46:36 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:46:36 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-05-03 15:46:36 --> Final output sent to browser
DEBUG - 2016-05-03 15:46:36 --> Total execution time: 0.0472
DEBUG - 2016-05-03 15:46:36 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:36 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:36 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:36 --> Router Class Initialized
ERROR - 2016-05-03 15:46:36 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:46:37 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:37 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:37 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Router Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Output Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Security Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Input Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:46:37 --> Language Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Loader Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:46:37 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Session Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:46:37 --> Session routines successfully run
DEBUG - 2016-05-03 15:46:37 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Controller Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Model Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:46:37 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:46:37 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:46:37 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:46:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:46:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:46:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:46:37 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:46:37 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-05-03 15:46:37 --> Final output sent to browser
DEBUG - 2016-05-03 15:46:37 --> Total execution time: 0.0357
DEBUG - 2016-05-03 15:46:38 --> Config Class Initialized
DEBUG - 2016-05-03 15:46:38 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:46:38 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:46:38 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:46:38 --> URI Class Initialized
DEBUG - 2016-05-03 15:46:38 --> Router Class Initialized
ERROR - 2016-05-03 15:46:38 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:47:16 --> Config Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:47:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:47:16 --> URI Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Router Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Output Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Security Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Input Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:47:16 --> Language Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Loader Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:47:16 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Session Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:47:16 --> Session routines successfully run
DEBUG - 2016-05-03 15:47:16 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Controller Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:47:16 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:47:16 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:47:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:47:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:47:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:47:16 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:47:16 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-05-03 15:47:16 --> Final output sent to browser
DEBUG - 2016-05-03 15:47:16 --> Total execution time: 0.0578
DEBUG - 2016-05-03 15:47:16 --> Config Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:47:16 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:47:16 --> URI Class Initialized
DEBUG - 2016-05-03 15:47:16 --> Router Class Initialized
ERROR - 2016-05-03 15:47:16 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:47:18 --> Config Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:47:18 --> URI Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Router Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Output Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Security Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Input Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:47:18 --> Language Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Loader Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:47:18 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Session Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:47:18 --> Session routines successfully run
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Controller Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:47:18 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:47:18 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:47:18 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:47:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:47:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:47:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:47:18 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:47:18 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-05-03 15:47:18 --> Final output sent to browser
DEBUG - 2016-05-03 15:47:18 --> Total execution time: 0.0566
DEBUG - 2016-05-03 15:47:19 --> Config Class Initialized
DEBUG - 2016-05-03 15:47:19 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:47:19 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:47:19 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:47:19 --> URI Class Initialized
DEBUG - 2016-05-03 15:47:19 --> Router Class Initialized
ERROR - 2016-05-03 15:47:19 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:47:22 --> Config Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:47:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:47:22 --> URI Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Router Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Output Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Security Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Input Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:47:22 --> Language Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Loader Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:47:22 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Session Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:47:22 --> Session routines successfully run
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Controller Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Model Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:47:22 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:47:22 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:47:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:47:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:47:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:47:22 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:47:22 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:47:22 --> Final output sent to browser
DEBUG - 2016-05-03 15:47:22 --> Total execution time: 0.0636
DEBUG - 2016-05-03 15:47:22 --> Config Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:47:22 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:47:22 --> URI Class Initialized
DEBUG - 2016-05-03 15:47:22 --> Router Class Initialized
ERROR - 2016-05-03 15:47:22 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:48:45 --> Config Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:48:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:48:45 --> URI Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Router Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Output Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Security Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Input Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:48:45 --> Language Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Loader Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:48:45 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Session Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:48:45 --> Session routines successfully run
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Controller Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:48:45 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:48:45 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:48:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:48:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:48:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:48:45 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:48:45 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:48:45 --> Final output sent to browser
DEBUG - 2016-05-03 15:48:45 --> Total execution time: 0.0850
DEBUG - 2016-05-03 15:48:45 --> Config Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:48:45 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:48:45 --> URI Class Initialized
DEBUG - 2016-05-03 15:48:45 --> Router Class Initialized
ERROR - 2016-05-03 15:48:45 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:48:50 --> Config Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:48:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:48:50 --> URI Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Router Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Output Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Security Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Input Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:48:50 --> Language Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Loader Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:48:50 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Session Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:48:50 --> Session routines successfully run
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Controller Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:48:50 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:48:50 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:48:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:48:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:48:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:48:50 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:48:50 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-05-03 15:48:50 --> Final output sent to browser
DEBUG - 2016-05-03 15:48:50 --> Total execution time: 0.0663
DEBUG - 2016-05-03 15:48:50 --> Config Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:48:50 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:48:50 --> URI Class Initialized
DEBUG - 2016-05-03 15:48:50 --> Router Class Initialized
ERROR - 2016-05-03 15:48:50 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:48:57 --> Config Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:48:57 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:48:57 --> URI Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Router Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Output Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Security Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Input Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:48:57 --> Language Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Loader Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:48:57 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Session Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:48:57 --> Session routines successfully run
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Controller Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Model Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:48:57 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:48:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-05-03 15:48:57 --> Helper loaded: pdf_helper
DEBUG - 2016-05-03 15:48:57 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-05-03 15:48:59 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-05-03 15:49:00 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-05-03 15:49:01 --> Config Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:49:01 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:49:01 --> URI Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Router Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Output Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Security Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Input Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:49:01 --> Language Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Loader Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:49:01 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Session Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:49:01 --> Session routines successfully run
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Controller Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:49:01 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:49:01 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:49:01 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-05-03 15:49:01 --> Final output sent to browser
DEBUG - 2016-05-03 15:49:01 --> Total execution time: 0.0603
DEBUG - 2016-05-03 15:49:02 --> Config Class Initialized
DEBUG - 2016-05-03 15:49:02 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:49:02 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:49:02 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:49:02 --> URI Class Initialized
DEBUG - 2016-05-03 15:49:02 --> Router Class Initialized
ERROR - 2016-05-03 15:49:02 --> 404 Page Not Found --> js
DEBUG - 2016-05-03 15:49:05 --> Config Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:49:05 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:49:05 --> URI Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Router Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Output Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Security Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Input Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-03 15:49:05 --> Language Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Loader Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Helper loaded: url_helper
DEBUG - 2016-05-03 15:49:05 --> Database Driver Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Session Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Helper loaded: string_helper
DEBUG - 2016-05-03 15:49:05 --> Session routines successfully run
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Controller Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Model Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Helper loaded: form_helper
DEBUG - 2016-05-03 15:49:05 --> Form Validation Class Initialized
DEBUG - 2016-05-03 15:49:05 --> Pagination Class Initialized
DEBUG - 2016-05-03 15:49:05 --> File loaded: application/views/header.php
DEBUG - 2016-05-03 15:49:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-05-03 15:49:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-05-03 15:49:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-05-03 15:49:05 --> File loaded: application/views/footer.php
DEBUG - 2016-05-03 15:49:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-05-03 15:49:05 --> Final output sent to browser
DEBUG - 2016-05-03 15:49:05 --> Total execution time: 0.0614
DEBUG - 2016-05-03 15:49:06 --> Config Class Initialized
DEBUG - 2016-05-03 15:49:06 --> Hooks Class Initialized
DEBUG - 2016-05-03 15:49:06 --> Utf8 Class Initialized
DEBUG - 2016-05-03 15:49:06 --> UTF-8 Support Enabled
DEBUG - 2016-05-03 15:49:06 --> URI Class Initialized
DEBUG - 2016-05-03 15:49:06 --> Router Class Initialized
ERROR - 2016-05-03 15:49:06 --> 404 Page Not Found --> js
