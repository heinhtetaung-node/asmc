<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-09 10:21:32 --> Config Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:21:32 --> URI Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Router Class Initialized
DEBUG - 2015-12-09 10:21:32 --> No URI present. Default controller set.
DEBUG - 2015-12-09 10:21:32 --> Output Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Security Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Input Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:21:32 --> Language Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Loader Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:21:32 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Session Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:21:32 --> A session cookie was not found.
DEBUG - 2015-12-09 10:21:32 --> Session routines successfully run
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Controller Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:32 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:21:32 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:21:32 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-09 10:21:32 --> Final output sent to browser
DEBUG - 2015-12-09 10:21:32 --> Total execution time: 0.0622
DEBUG - 2015-12-09 10:21:39 --> Config Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:21:39 --> URI Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Router Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Output Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Security Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Input Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:21:39 --> Language Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Loader Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:21:39 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Session Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:21:39 --> Session routines successfully run
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Controller Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:21:39 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 10:21:39 --> Config Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:21:39 --> URI Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Router Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Output Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Security Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Input Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:21:39 --> Language Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Loader Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:21:39 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Session Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:21:39 --> Session routines successfully run
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Controller Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:21:39 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:21:39 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:21:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:21:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:21:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:21:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:21:39 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:21:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-09 10:21:39 --> Final output sent to browser
DEBUG - 2015-12-09 10:21:39 --> Total execution time: 0.0429
DEBUG - 2015-12-09 10:21:45 --> Config Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:21:45 --> URI Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Router Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Output Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Security Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Input Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:21:45 --> Language Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Loader Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:21:45 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Session Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:21:45 --> Session routines successfully run
DEBUG - 2015-12-09 10:21:45 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Controller Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:45 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:21:45 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:21:45 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:21:45 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 10:21:45 --> Final output sent to browser
DEBUG - 2015-12-09 10:21:45 --> Total execution time: 0.0374
DEBUG - 2015-12-09 10:21:52 --> Config Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:21:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:21:52 --> URI Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Router Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Output Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Security Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Input Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:21:52 --> Language Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Loader Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:21:52 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Session Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:21:52 --> Session routines successfully run
DEBUG - 2015-12-09 10:21:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Controller Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:21:52 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:21:52 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:21:52 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:21:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:21:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:21:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:21:52 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:21:52 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:21:52 --> Final output sent to browser
DEBUG - 2015-12-09 10:21:52 --> Total execution time: 0.0550
DEBUG - 2015-12-09 10:23:25 --> Config Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:23:25 --> URI Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Router Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Output Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Security Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Input Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:23:25 --> Language Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Loader Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:23:25 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Session Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:23:25 --> Session routines successfully run
DEBUG - 2015-12-09 10:23:25 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Controller Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:25 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:23:25 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:23:25 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:23:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:23:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:23:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:23:25 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:23:25 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:23:25 --> Final output sent to browser
DEBUG - 2015-12-09 10:23:25 --> Total execution time: 0.0429
DEBUG - 2015-12-09 10:23:49 --> Config Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:23:49 --> URI Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Router Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Output Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Security Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Input Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:23:49 --> Language Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Loader Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:23:49 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Session Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:23:49 --> Session routines successfully run
DEBUG - 2015-12-09 10:23:49 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Controller Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Model Class Initialized
DEBUG - 2015-12-09 10:23:49 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:23:49 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:23:49 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:23:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:23:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:23:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:23:49 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:23:49 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:23:49 --> Final output sent to browser
DEBUG - 2015-12-09 10:23:49 --> Total execution time: 0.0518
DEBUG - 2015-12-09 10:24:09 --> Config Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:24:09 --> URI Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Router Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Output Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Security Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Input Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:24:09 --> Language Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Loader Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:24:09 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Session Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:24:09 --> Session routines successfully run
DEBUG - 2015-12-09 10:24:09 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Controller Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:24:09 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:24:09 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:24:09 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:24:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:24:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:24:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:24:09 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:24:09 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-09 10:24:09 --> Final output sent to browser
DEBUG - 2015-12-09 10:24:09 --> Total execution time: 0.0672
DEBUG - 2015-12-09 10:24:24 --> Config Class Initialized
DEBUG - 2015-12-09 10:24:24 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:24:24 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:24:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:24:24 --> URI Class Initialized
DEBUG - 2015-12-09 10:24:24 --> Router Class Initialized
ERROR - 2015-12-09 10:24:24 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:24:43 --> Config Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:24:43 --> URI Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Router Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Output Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Security Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Input Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:24:43 --> Language Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Loader Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:24:43 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Session Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:24:43 --> Session routines successfully run
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Controller Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Model Class Initialized
DEBUG - 2015-12-09 10:24:43 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:24:43 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:24:43 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:24:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:24:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:24:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:24:43 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:24:43 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-12-09 10:24:43 --> Final output sent to browser
DEBUG - 2015-12-09 10:24:43 --> Total execution time: 0.0816
DEBUG - 2015-12-09 10:24:44 --> Config Class Initialized
DEBUG - 2015-12-09 10:24:44 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:24:44 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:24:44 --> URI Class Initialized
DEBUG - 2015-12-09 10:24:44 --> Router Class Initialized
ERROR - 2015-12-09 10:24:44 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:25:50 --> Config Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:25:50 --> URI Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Router Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Output Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Security Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Input Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:25:50 --> Language Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Loader Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:25:50 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Session Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:25:50 --> Session routines successfully run
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Controller Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Model Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:25:50 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:25:50 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:25:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:25:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:25:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:25:50 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:25:50 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-12-09 10:25:50 --> Final output sent to browser
DEBUG - 2015-12-09 10:25:50 --> Total execution time: 0.0378
DEBUG - 2015-12-09 10:25:50 --> Config Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:25:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:25:50 --> URI Class Initialized
DEBUG - 2015-12-09 10:25:50 --> Router Class Initialized
ERROR - 2015-12-09 10:25:50 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:26:03 --> Config Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:26:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:26:03 --> URI Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Router Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Output Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Security Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Input Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:26:03 --> Language Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Loader Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:26:03 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Session Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:26:03 --> Session routines successfully run
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Controller Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:03 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:26:03 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:26:03 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:26:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:26:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:26:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:26:03 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:26:03 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-12-09 10:26:03 --> Final output sent to browser
DEBUG - 2015-12-09 10:26:03 --> Total execution time: 0.0491
DEBUG - 2015-12-09 10:26:04 --> Config Class Initialized
DEBUG - 2015-12-09 10:26:04 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:26:04 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:26:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:26:04 --> URI Class Initialized
DEBUG - 2015-12-09 10:26:04 --> Router Class Initialized
ERROR - 2015-12-09 10:26:04 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:26:52 --> Config Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:26:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:26:52 --> URI Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Router Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Output Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Security Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Input Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:26:52 --> Language Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Loader Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:26:52 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Session Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:26:52 --> Session routines successfully run
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Controller Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Model Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:26:52 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:26:52 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:26:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:26:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:26:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:26:52 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:26:52 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-12-09 10:26:52 --> Final output sent to browser
DEBUG - 2015-12-09 10:26:52 --> Total execution time: 0.0613
DEBUG - 2015-12-09 10:26:52 --> Config Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:26:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:26:52 --> URI Class Initialized
DEBUG - 2015-12-09 10:26:52 --> Router Class Initialized
ERROR - 2015-12-09 10:26:52 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:27:16 --> Config Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:27:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:27:16 --> URI Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Router Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Output Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Security Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Input Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:27:16 --> Language Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Loader Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:27:16 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Session Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:27:16 --> Session routines successfully run
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Controller Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Model Class Initialized
DEBUG - 2015-12-09 10:27:16 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:27:16 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:27:16 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:27:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:27:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:27:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:27:16 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:27:16 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-12-09 10:27:16 --> Final output sent to browser
DEBUG - 2015-12-09 10:27:16 --> Total execution time: 0.0672
DEBUG - 2015-12-09 10:27:17 --> Config Class Initialized
DEBUG - 2015-12-09 10:27:17 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:27:17 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:27:17 --> URI Class Initialized
DEBUG - 2015-12-09 10:27:17 --> Router Class Initialized
ERROR - 2015-12-09 10:27:17 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:30:29 --> Config Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:30:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:30:29 --> URI Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Router Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Output Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Security Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Input Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:30:29 --> Language Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Loader Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:30:29 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Session Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:30:29 --> Session routines successfully run
DEBUG - 2015-12-09 10:30:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Controller Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:30:29 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:30:29 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:30:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:30:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:30:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:30:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:30:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:30:29 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:30:29 --> Final output sent to browser
DEBUG - 2015-12-09 10:30:29 --> Total execution time: 0.0578
DEBUG - 2015-12-09 10:30:54 --> Config Class Initialized
DEBUG - 2015-12-09 10:30:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:30:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:30:54 --> URI Class Initialized
DEBUG - 2015-12-09 10:30:54 --> Router Class Initialized
ERROR - 2015-12-09 10:30:54 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:31:55 --> Config Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:31:55 --> URI Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Router Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Output Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Security Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Input Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:31:55 --> Language Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Loader Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:31:55 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Session Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:31:55 --> Session routines successfully run
DEBUG - 2015-12-09 10:31:55 --> Model Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Model Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Controller Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Model Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Model Class Initialized
DEBUG - 2015-12-09 10:31:55 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:31:55 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:31:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:31:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:31:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:31:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:31:55 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:31:55 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:31:55 --> Final output sent to browser
DEBUG - 2015-12-09 10:31:55 --> Total execution time: 0.0489
DEBUG - 2015-12-09 10:31:56 --> Config Class Initialized
DEBUG - 2015-12-09 10:31:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:31:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:31:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:31:56 --> URI Class Initialized
DEBUG - 2015-12-09 10:31:56 --> Router Class Initialized
ERROR - 2015-12-09 10:31:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:33:14 --> Config Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:33:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:33:14 --> URI Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Router Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Output Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Security Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Input Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:33:14 --> Language Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Loader Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:33:14 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Session Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:33:14 --> Session routines successfully run
DEBUG - 2015-12-09 10:33:14 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Controller Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:33:14 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:33:14 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:33:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:33:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:33:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:33:14 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:33:14 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:33:14 --> Final output sent to browser
DEBUG - 2015-12-09 10:33:14 --> Total execution time: 0.0714
DEBUG - 2015-12-09 10:33:14 --> Config Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:33:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:33:14 --> URI Class Initialized
DEBUG - 2015-12-09 10:33:14 --> Router Class Initialized
ERROR - 2015-12-09 10:33:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:33:21 --> Config Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:33:21 --> URI Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Router Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Output Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Security Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Input Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:33:21 --> Language Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Loader Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:33:21 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Session Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:33:21 --> Session routines successfully run
DEBUG - 2015-12-09 10:33:21 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Controller Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Model Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:33:21 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:33:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:33:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:33:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:33:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:33:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:33:21 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:33:21 --> Final output sent to browser
DEBUG - 2015-12-09 10:33:21 --> Total execution time: 0.0682
DEBUG - 2015-12-09 10:33:21 --> Config Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:33:21 --> URI Class Initialized
DEBUG - 2015-12-09 10:33:21 --> Router Class Initialized
ERROR - 2015-12-09 10:33:21 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:34:04 --> Config Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:34:04 --> URI Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Router Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Output Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Security Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Input Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:34:04 --> Language Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Loader Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:34:04 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Session Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:34:04 --> Session routines successfully run
DEBUG - 2015-12-09 10:34:04 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Controller Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:04 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:34:04 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:34:04 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:34:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:34:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:34:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:34:04 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:34:04 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:34:04 --> Final output sent to browser
DEBUG - 2015-12-09 10:34:04 --> Total execution time: 0.0611
DEBUG - 2015-12-09 10:34:05 --> Config Class Initialized
DEBUG - 2015-12-09 10:34:05 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:34:05 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:34:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:34:05 --> URI Class Initialized
DEBUG - 2015-12-09 10:34:05 --> Router Class Initialized
ERROR - 2015-12-09 10:34:05 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:34:56 --> Config Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:34:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:34:56 --> URI Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Router Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Output Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Security Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Input Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:34:56 --> Language Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Loader Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:34:56 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Session Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:34:56 --> Session routines successfully run
DEBUG - 2015-12-09 10:34:56 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Controller Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Model Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:34:56 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:34:56 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:34:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:34:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:34:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:34:56 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:34:56 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:34:56 --> Final output sent to browser
DEBUG - 2015-12-09 10:34:56 --> Total execution time: 0.0447
DEBUG - 2015-12-09 10:34:56 --> Config Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:34:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:34:56 --> URI Class Initialized
DEBUG - 2015-12-09 10:34:56 --> Router Class Initialized
ERROR - 2015-12-09 10:34:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:35:41 --> Config Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:35:41 --> URI Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Router Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Output Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Security Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Input Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:35:41 --> Language Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Loader Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:35:41 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Session Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:35:41 --> Session routines successfully run
DEBUG - 2015-12-09 10:35:41 --> Model Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Model Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Controller Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Model Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Model Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:35:41 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:35:41 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:35:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:35:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:35:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:35:41 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:35:41 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:35:41 --> Final output sent to browser
DEBUG - 2015-12-09 10:35:41 --> Total execution time: 0.0543
DEBUG - 2015-12-09 10:35:41 --> Config Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:35:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:35:41 --> URI Class Initialized
DEBUG - 2015-12-09 10:35:41 --> Router Class Initialized
ERROR - 2015-12-09 10:35:41 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:36:29 --> Config Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:36:29 --> URI Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Router Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Output Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Security Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Input Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:36:29 --> Language Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Loader Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:36:29 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Session Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:36:29 --> Session routines successfully run
DEBUG - 2015-12-09 10:36:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Controller Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:29 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:36:29 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:36:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:36:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:36:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:36:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:36:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:36:29 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:36:29 --> Final output sent to browser
DEBUG - 2015-12-09 10:36:29 --> Total execution time: 0.0433
DEBUG - 2015-12-09 10:36:30 --> Config Class Initialized
DEBUG - 2015-12-09 10:36:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:36:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:36:30 --> URI Class Initialized
DEBUG - 2015-12-09 10:36:30 --> Router Class Initialized
ERROR - 2015-12-09 10:36:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:36:47 --> Config Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:36:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:36:47 --> URI Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Router Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Output Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Security Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Input Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:36:47 --> Language Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Loader Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:36:47 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Session Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:36:47 --> Session routines successfully run
DEBUG - 2015-12-09 10:36:47 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Controller Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Model Class Initialized
DEBUG - 2015-12-09 10:36:47 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:36:47 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:36:47 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:36:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:36:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:36:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:36:47 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:36:47 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:36:47 --> Final output sent to browser
DEBUG - 2015-12-09 10:36:47 --> Total execution time: 0.0692
DEBUG - 2015-12-09 10:36:48 --> Config Class Initialized
DEBUG - 2015-12-09 10:36:48 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:36:48 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:36:48 --> URI Class Initialized
DEBUG - 2015-12-09 10:36:48 --> Router Class Initialized
ERROR - 2015-12-09 10:36:48 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:37:03 --> Config Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:37:03 --> URI Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Router Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Output Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Security Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Input Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:37:03 --> Language Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Loader Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:37:03 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Session Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:37:03 --> Session routines successfully run
DEBUG - 2015-12-09 10:37:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Controller Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:37:03 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:37:03 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:37:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:37:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:37:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:37:03 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:37:03 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:37:03 --> Final output sent to browser
DEBUG - 2015-12-09 10:37:03 --> Total execution time: 0.0455
DEBUG - 2015-12-09 10:37:03 --> Config Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:37:03 --> URI Class Initialized
DEBUG - 2015-12-09 10:37:03 --> Router Class Initialized
ERROR - 2015-12-09 10:37:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:37:10 --> Config Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:37:10 --> URI Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Router Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Output Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Security Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Input Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:37:10 --> Language Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Loader Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:37:10 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Session Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:37:10 --> Session routines successfully run
DEBUG - 2015-12-09 10:37:10 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Controller Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Model Class Initialized
DEBUG - 2015-12-09 10:37:10 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:37:10 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:37:10 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:37:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:37:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:37:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:37:10 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:37:10 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:37:10 --> Final output sent to browser
DEBUG - 2015-12-09 10:37:10 --> Total execution time: 0.0425
DEBUG - 2015-12-09 10:37:11 --> Config Class Initialized
DEBUG - 2015-12-09 10:37:11 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:37:11 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:37:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:37:11 --> URI Class Initialized
DEBUG - 2015-12-09 10:37:11 --> Router Class Initialized
ERROR - 2015-12-09 10:37:11 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:38:57 --> Config Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:38:57 --> URI Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Router Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Output Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Security Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Input Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:38:57 --> Language Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Loader Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:38:57 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Session Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:38:57 --> Session routines successfully run
DEBUG - 2015-12-09 10:38:57 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Controller Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:38:57 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:38:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:38:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:38:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:38:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:38:57 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:38:57 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:38:57 --> Final output sent to browser
DEBUG - 2015-12-09 10:38:57 --> Total execution time: 0.0719
DEBUG - 2015-12-09 10:38:57 --> Config Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:38:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:38:58 --> URI Class Initialized
DEBUG - 2015-12-09 10:38:58 --> Router Class Initialized
ERROR - 2015-12-09 10:38:58 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:38:59 --> Config Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:38:59 --> URI Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Router Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Output Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Security Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Input Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:38:59 --> Language Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Loader Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:38:59 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Session Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:38:59 --> Session routines successfully run
DEBUG - 2015-12-09 10:38:59 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Controller Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Model Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:38:59 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:38:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:38:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 10:38:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 10:38:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 10:38:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 10:38:59 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 10:38:59 --> Final output sent to browser
DEBUG - 2015-12-09 10:38:59 --> Total execution time: 0.0600
DEBUG - 2015-12-09 10:38:59 --> Config Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:38:59 --> URI Class Initialized
DEBUG - 2015-12-09 10:38:59 --> Router Class Initialized
ERROR - 2015-12-09 10:38:59 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:39:03 --> Config Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:39:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:39:03 --> URI Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Router Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Output Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Security Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Input Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 10:39:03 --> Language Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Loader Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Helper loaded: url_helper
DEBUG - 2015-12-09 10:39:03 --> Database Driver Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Session Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Helper loaded: string_helper
DEBUG - 2015-12-09 10:39:03 --> Session routines successfully run
DEBUG - 2015-12-09 10:39:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Controller Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Pagination Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Model Class Initialized
DEBUG - 2015-12-09 10:39:03 --> Helper loaded: form_helper
DEBUG - 2015-12-09 10:39:03 --> Form Validation Class Initialized
DEBUG - 2015-12-09 10:39:03 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 10:39:03 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 10:39:03 --> Final output sent to browser
DEBUG - 2015-12-09 10:39:03 --> Total execution time: 0.0511
DEBUG - 2015-12-09 10:39:04 --> Config Class Initialized
DEBUG - 2015-12-09 10:39:04 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:39:04 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:39:04 --> URI Class Initialized
DEBUG - 2015-12-09 10:39:04 --> Router Class Initialized
ERROR - 2015-12-09 10:39:04 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 10:39:06 --> Config Class Initialized
DEBUG - 2015-12-09 10:39:06 --> Hooks Class Initialized
DEBUG - 2015-12-09 10:39:06 --> Utf8 Class Initialized
DEBUG - 2015-12-09 10:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 10:39:06 --> URI Class Initialized
DEBUG - 2015-12-09 10:39:06 --> Router Class Initialized
ERROR - 2015-12-09 10:39:06 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 11:31:52 --> Config Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Hooks Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Utf8 Class Initialized
DEBUG - 2015-12-09 11:31:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 11:31:52 --> URI Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Router Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Output Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Security Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Input Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 11:31:52 --> Language Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Loader Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Helper loaded: url_helper
DEBUG - 2015-12-09 11:31:52 --> Database Driver Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Session Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Helper loaded: string_helper
DEBUG - 2015-12-09 11:31:52 --> Session routines successfully run
DEBUG - 2015-12-09 11:31:52 --> Model Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Model Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Controller Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Pagination Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Model Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Model Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Helper loaded: form_helper
DEBUG - 2015-12-09 11:31:52 --> Form Validation Class Initialized
DEBUG - 2015-12-09 11:31:52 --> Model Class Initialized
DEBUG - 2015-12-09 11:31:52 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 11:31:52 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 11:31:52 --> Final output sent to browser
DEBUG - 2015-12-09 11:31:52 --> Total execution time: 0.0705
DEBUG - 2015-12-09 11:31:53 --> Config Class Initialized
DEBUG - 2015-12-09 11:31:53 --> Hooks Class Initialized
DEBUG - 2015-12-09 11:31:53 --> Utf8 Class Initialized
DEBUG - 2015-12-09 11:31:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 11:31:53 --> URI Class Initialized
DEBUG - 2015-12-09 11:31:53 --> Router Class Initialized
ERROR - 2015-12-09 11:31:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 12:01:13 --> Config Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:01:13 --> URI Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Router Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Output Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Security Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Input Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:01:13 --> Language Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Loader Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:01:13 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Session Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:01:13 --> Session routines successfully run
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Controller Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:01:13 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:13 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 12:01:13 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 12:01:13 --> Final output sent to browser
DEBUG - 2015-12-09 12:01:13 --> Total execution time: 0.0682
DEBUG - 2015-12-09 12:01:14 --> Config Class Initialized
DEBUG - 2015-12-09 12:01:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:01:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:01:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:01:14 --> URI Class Initialized
DEBUG - 2015-12-09 12:01:14 --> Router Class Initialized
ERROR - 2015-12-09 12:01:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 12:01:45 --> Config Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:01:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:01:45 --> URI Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Router Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Output Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Security Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Input Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:01:45 --> Language Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Loader Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:01:45 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Session Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:01:45 --> Session routines successfully run
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Controller Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:01:45 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Model Class Initialized
DEBUG - 2015-12-09 12:01:45 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 12:01:45 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 12:01:45 --> Final output sent to browser
DEBUG - 2015-12-09 12:01:45 --> Total execution time: 0.0488
DEBUG - 2015-12-09 12:01:45 --> Config Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:01:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:01:45 --> URI Class Initialized
DEBUG - 2015-12-09 12:01:45 --> Router Class Initialized
ERROR - 2015-12-09 12:01:45 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 12:02:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:02:00 --> URI Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Router Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Output Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Security Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Input Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:02:00 --> Language Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Loader Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:02:00 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Session Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:02:00 --> Session routines successfully run
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Controller Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:02:00 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Model Class Initialized
DEBUG - 2015-12-09 12:02:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 12:02:00 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 12:02:00 --> Final output sent to browser
DEBUG - 2015-12-09 12:02:00 --> Total execution time: 0.0387
DEBUG - 2015-12-09 12:02:00 --> Config Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:02:00 --> URI Class Initialized
DEBUG - 2015-12-09 12:02:00 --> Router Class Initialized
ERROR - 2015-12-09 12:02:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 12:03:16 --> Config Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:03:16 --> URI Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Router Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Output Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Security Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Input Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:03:16 --> Language Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Loader Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:03:16 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Session Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:03:16 --> Session routines successfully run
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Controller Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:03:16 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:16 --> File loaded: application/views/header.php
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$director_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 257
ERROR - 2015-12-09 12:03:16 --> Severity: Notice  --> Undefined property: stdClass::$direct_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 257
DEBUG - 2015-12-09 12:03:16 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 12:03:16 --> Final output sent to browser
DEBUG - 2015-12-09 12:03:16 --> Total execution time: 0.0466
DEBUG - 2015-12-09 12:03:16 --> Config Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:03:16 --> URI Class Initialized
DEBUG - 2015-12-09 12:03:16 --> Router Class Initialized
ERROR - 2015-12-09 12:03:16 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 12:03:31 --> Config Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:03:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:03:31 --> URI Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Router Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Output Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Security Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Input Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:03:31 --> Language Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Loader Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:03:31 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Session Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:03:31 --> Session routines successfully run
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Controller Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:03:31 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:31 --> File loaded: application/views/header.php
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$manager_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 241
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$director_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 257
ERROR - 2015-12-09 12:03:31 --> Severity: Notice  --> Undefined property: stdClass::$director_name /Applications/MAMP/htdocs/asmc/crm/application/views/form/index.php 257
DEBUG - 2015-12-09 12:03:31 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 12:03:31 --> Final output sent to browser
DEBUG - 2015-12-09 12:03:31 --> Total execution time: 0.0448
DEBUG - 2015-12-09 12:03:31 --> Config Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:03:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:03:31 --> URI Class Initialized
DEBUG - 2015-12-09 12:03:31 --> Router Class Initialized
ERROR - 2015-12-09 12:03:31 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 12:03:57 --> Config Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:03:57 --> URI Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Router Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Output Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Security Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Input Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 12:03:57 --> Language Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Loader Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Helper loaded: url_helper
DEBUG - 2015-12-09 12:03:57 --> Database Driver Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Session Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Helper loaded: string_helper
DEBUG - 2015-12-09 12:03:57 --> Session routines successfully run
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Controller Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Pagination Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Helper loaded: form_helper
DEBUG - 2015-12-09 12:03:57 --> Form Validation Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Model Class Initialized
DEBUG - 2015-12-09 12:03:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 12:03:57 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 12:03:57 --> Final output sent to browser
DEBUG - 2015-12-09 12:03:57 --> Total execution time: 0.0379
DEBUG - 2015-12-09 12:03:57 --> Config Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 12:03:57 --> URI Class Initialized
DEBUG - 2015-12-09 12:03:57 --> Router Class Initialized
ERROR - 2015-12-09 12:03:57 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:24:12 --> Config Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:24:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:24:12 --> URI Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Router Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Output Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Security Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Input Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:24:12 --> Language Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Loader Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:24:12 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Session Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:24:12 --> Session routines successfully run
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Controller Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:24:12 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:24:12 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:24:12 --> Final output sent to browser
DEBUG - 2015-12-09 13:24:12 --> Total execution time: 0.0635
DEBUG - 2015-12-09 13:24:13 --> Config Class Initialized
DEBUG - 2015-12-09 13:24:13 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:24:13 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:24:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:24:13 --> URI Class Initialized
DEBUG - 2015-12-09 13:24:13 --> Router Class Initialized
ERROR - 2015-12-09 13:24:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:24:24 --> Config Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:24:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:24:24 --> URI Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Router Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Output Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Security Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Input Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:24:24 --> Language Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Loader Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:24:24 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Session Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:24:24 --> Session routines successfully run
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Controller Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:24:24 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> Model Class Initialized
DEBUG - 2015-12-09 13:24:24 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:24:24 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:24:24 --> Final output sent to browser
DEBUG - 2015-12-09 13:24:24 --> Total execution time: 0.0513
DEBUG - 2015-12-09 13:24:25 --> Config Class Initialized
DEBUG - 2015-12-09 13:24:25 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:24:25 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:24:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:24:25 --> URI Class Initialized
DEBUG - 2015-12-09 13:24:25 --> Router Class Initialized
ERROR - 2015-12-09 13:24:25 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:27:27 --> Config Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:27:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:27:27 --> URI Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Router Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Output Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Security Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Input Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:27:27 --> Language Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Loader Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:27:27 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Session Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:27:27 --> Session routines successfully run
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Controller Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:27:27 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> Model Class Initialized
DEBUG - 2015-12-09 13:27:27 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:27:27 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:27:27 --> Final output sent to browser
DEBUG - 2015-12-09 13:27:27 --> Total execution time: 0.0419
DEBUG - 2015-12-09 13:27:28 --> Config Class Initialized
DEBUG - 2015-12-09 13:27:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:27:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:27:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:27:28 --> URI Class Initialized
DEBUG - 2015-12-09 13:27:28 --> Router Class Initialized
ERROR - 2015-12-09 13:27:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:28:23 --> Config Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:28:23 --> URI Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Router Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Output Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Security Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Input Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:28:23 --> Language Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Loader Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:28:23 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Session Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:28:23 --> Session routines successfully run
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Controller Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:28:23 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:28:23 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:28:23 --> Final output sent to browser
DEBUG - 2015-12-09 13:28:23 --> Total execution time: 0.0403
DEBUG - 2015-12-09 13:28:24 --> Config Class Initialized
DEBUG - 2015-12-09 13:28:24 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:28:24 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:28:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:28:24 --> URI Class Initialized
DEBUG - 2015-12-09 13:28:24 --> Router Class Initialized
ERROR - 2015-12-09 13:28:24 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:28:41 --> Config Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:28:41 --> URI Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Router Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Output Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Security Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Input Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:28:41 --> Language Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Loader Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:28:41 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Session Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:28:41 --> Session routines successfully run
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Controller Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:28:41 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Model Class Initialized
DEBUG - 2015-12-09 13:28:41 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:28:41 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:28:41 --> Final output sent to browser
DEBUG - 2015-12-09 13:28:41 --> Total execution time: 0.0451
DEBUG - 2015-12-09 13:28:41 --> Config Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:28:41 --> URI Class Initialized
DEBUG - 2015-12-09 13:28:41 --> Router Class Initialized
ERROR - 2015-12-09 13:28:41 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:29:38 --> Config Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:29:38 --> URI Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Router Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Output Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Security Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Input Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:29:38 --> Language Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Loader Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:29:38 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Session Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:29:38 --> Session routines successfully run
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Controller Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:29:38 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Model Class Initialized
DEBUG - 2015-12-09 13:29:38 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:29:38 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:29:38 --> Final output sent to browser
DEBUG - 2015-12-09 13:29:38 --> Total execution time: 0.0450
DEBUG - 2015-12-09 13:29:38 --> Config Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:29:38 --> URI Class Initialized
DEBUG - 2015-12-09 13:29:38 --> Router Class Initialized
ERROR - 2015-12-09 13:29:38 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:30:13 --> Config Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:30:13 --> URI Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Router Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Output Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Security Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Input Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:30:13 --> Language Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Loader Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:30:13 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Session Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:30:13 --> Session routines successfully run
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Controller Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:30:13 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:13 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:30:13 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:30:13 --> Final output sent to browser
DEBUG - 2015-12-09 13:30:13 --> Total execution time: 0.0478
DEBUG - 2015-12-09 13:30:13 --> Config Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:30:13 --> URI Class Initialized
DEBUG - 2015-12-09 13:30:13 --> Router Class Initialized
ERROR - 2015-12-09 13:30:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:30:31 --> Config Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:30:31 --> URI Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Router Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Output Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Security Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Input Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:30:31 --> Language Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Loader Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:30:31 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Session Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:30:31 --> Session routines successfully run
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Controller Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:30:31 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:30:31 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:30:31 --> Final output sent to browser
DEBUG - 2015-12-09 13:30:31 --> Total execution time: 0.0399
DEBUG - 2015-12-09 13:30:31 --> Config Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:30:31 --> URI Class Initialized
DEBUG - 2015-12-09 13:30:31 --> Router Class Initialized
ERROR - 2015-12-09 13:30:31 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:30:53 --> Config Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:30:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:30:53 --> URI Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Router Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Output Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Security Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Input Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:30:53 --> Language Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Loader Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:30:53 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Session Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:30:53 --> Session routines successfully run
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Controller Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:30:53 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:30:53 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:30:53 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:30:53 --> Final output sent to browser
DEBUG - 2015-12-09 13:30:53 --> Total execution time: 0.0377
DEBUG - 2015-12-09 13:30:54 --> Config Class Initialized
DEBUG - 2015-12-09 13:30:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:30:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:30:54 --> URI Class Initialized
DEBUG - 2015-12-09 13:30:54 --> Router Class Initialized
ERROR - 2015-12-09 13:30:54 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:31:28 --> Config Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:31:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:31:28 --> URI Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Router Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Output Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Security Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Input Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:31:28 --> Language Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Loader Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:31:28 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Session Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:31:28 --> Session routines successfully run
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Controller Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:31:28 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:28 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:31:28 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:31:28 --> Final output sent to browser
DEBUG - 2015-12-09 13:31:28 --> Total execution time: 0.0389
DEBUG - 2015-12-09 13:31:28 --> Config Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:31:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:31:28 --> URI Class Initialized
DEBUG - 2015-12-09 13:31:28 --> Router Class Initialized
ERROR - 2015-12-09 13:31:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:31:40 --> Config Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:31:40 --> URI Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Router Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Output Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Security Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Input Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:31:40 --> Language Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Loader Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:31:40 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Session Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:31:40 --> Session routines successfully run
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Controller Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:31:40 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:40 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:31:40 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:31:40 --> Final output sent to browser
DEBUG - 2015-12-09 13:31:40 --> Total execution time: 0.0383
DEBUG - 2015-12-09 13:31:40 --> Config Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:31:40 --> URI Class Initialized
DEBUG - 2015-12-09 13:31:40 --> Router Class Initialized
ERROR - 2015-12-09 13:31:40 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:31:56 --> Config Class Initialized
DEBUG - 2015-12-09 13:31:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:31:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:31:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:31:56 --> URI Class Initialized
DEBUG - 2015-12-09 13:31:56 --> Router Class Initialized
DEBUG - 2015-12-09 13:31:56 --> Output Class Initialized
DEBUG - 2015-12-09 13:31:56 --> Security Class Initialized
DEBUG - 2015-12-09 13:31:56 --> Input Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:31:57 --> Language Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Loader Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:31:57 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Session Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:31:57 --> Session routines successfully run
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Controller Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:31:57 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Model Class Initialized
DEBUG - 2015-12-09 13:31:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:31:57 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:31:57 --> Final output sent to browser
DEBUG - 2015-12-09 13:31:57 --> Total execution time: 0.0435
DEBUG - 2015-12-09 13:31:57 --> Config Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:31:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:31:57 --> URI Class Initialized
DEBUG - 2015-12-09 13:31:57 --> Router Class Initialized
ERROR - 2015-12-09 13:31:57 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:32:20 --> Config Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:32:20 --> URI Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Router Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Output Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Security Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Input Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:32:20 --> Language Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Loader Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:32:20 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Session Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:32:20 --> Session routines successfully run
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Controller Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:32:20 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> Model Class Initialized
DEBUG - 2015-12-09 13:32:20 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:32:20 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:32:20 --> Final output sent to browser
DEBUG - 2015-12-09 13:32:20 --> Total execution time: 0.0552
DEBUG - 2015-12-09 13:32:21 --> Config Class Initialized
DEBUG - 2015-12-09 13:32:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:32:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:32:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:32:21 --> URI Class Initialized
DEBUG - 2015-12-09 13:32:21 --> Router Class Initialized
ERROR - 2015-12-09 13:32:21 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:34:18 --> Config Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:34:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:34:18 --> URI Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Router Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Output Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Security Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Input Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:34:18 --> Language Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Loader Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:34:18 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Session Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:34:18 --> Session routines successfully run
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Controller Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:34:18 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:18 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Config Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:34:46 --> URI Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Router Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Output Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Security Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Input Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:34:46 --> Language Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Loader Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:34:46 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Session Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:34:46 --> Session routines successfully run
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Controller Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:34:46 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:34:46 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Config Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:35:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:35:01 --> URI Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Router Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Output Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Security Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Input Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:35:01 --> Language Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Loader Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:35:01 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Session Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:35:01 --> Session routines successfully run
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Controller Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:35:01 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:01 --> DB Transaction Failure
ERROR - 2015-12-09 13:35:01 --> Query error: Unknown column 'customer_bank_type' in 'field list'
DEBUG - 2015-12-09 13:35:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-09 13:35:21 --> Config Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:35:21 --> URI Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Router Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Output Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Security Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Input Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:35:21 --> Language Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Loader Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:35:21 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Session Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:35:21 --> Session routines successfully run
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Controller Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:35:21 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:21 --> DB Transaction Failure
ERROR - 2015-12-09 13:35:21 --> Query error: Unknown column 'director_signature' in 'field list'
DEBUG - 2015-12-09 13:35:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-09 13:35:52 --> Config Class Initialized
DEBUG - 2015-12-09 13:35:52 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:35:52 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:35:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:35:53 --> URI Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Router Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Output Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Security Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Input Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:35:53 --> Language Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Loader Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:35:53 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Session Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:35:53 --> Session routines successfully run
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Controller Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:35:53 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Model Class Initialized
ERROR - 2015-12-09 13:35:53 --> Severity: Notice  --> Undefined variable: crm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 130
ERROR - 2015-12-09 13:35:53 --> Severity: Notice  --> Undefined variable: sm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 132
DEBUG - 2015-12-09 13:35:53 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-09 13:35:53 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:35:53 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 13:35:53 --> Final output sent to browser
DEBUG - 2015-12-09 13:35:53 --> Total execution time: 0.0524
DEBUG - 2015-12-09 13:35:53 --> Config Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:35:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:35:53 --> URI Class Initialized
DEBUG - 2015-12-09 13:35:53 --> Router Class Initialized
ERROR - 2015-12-09 13:35:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:35:59 --> Config Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:35:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:35:59 --> URI Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Router Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Output Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Security Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Input Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:35:59 --> Language Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Loader Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:35:59 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Session Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:35:59 --> Session routines successfully run
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Controller Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:35:59 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 13:35:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:35:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 13:35:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 13:35:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 13:35:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 13:35:59 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 13:35:59 --> Final output sent to browser
DEBUG - 2015-12-09 13:35:59 --> Total execution time: 0.0441
DEBUG - 2015-12-09 13:36:00 --> Config Class Initialized
DEBUG - 2015-12-09 13:36:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:36:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:36:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:36:00 --> URI Class Initialized
DEBUG - 2015-12-09 13:36:00 --> Router Class Initialized
ERROR - 2015-12-09 13:36:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 13:36:03 --> Config Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:36:03 --> URI Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Router Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Output Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Security Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Input Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 13:36:03 --> Language Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Loader Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Helper loaded: url_helper
DEBUG - 2015-12-09 13:36:03 --> Database Driver Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Session Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Helper loaded: string_helper
DEBUG - 2015-12-09 13:36:03 --> Session routines successfully run
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Controller Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Pagination Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Helper loaded: form_helper
DEBUG - 2015-12-09 13:36:03 --> Form Validation Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Model Class Initialized
DEBUG - 2015-12-09 13:36:03 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 13:36:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 13:36:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 13:36:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 13:36:03 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 13:36:03 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-09 13:36:03 --> Final output sent to browser
DEBUG - 2015-12-09 13:36:03 --> Total execution time: 0.0644
DEBUG - 2015-12-09 13:36:03 --> Config Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 13:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 13:36:03 --> URI Class Initialized
DEBUG - 2015-12-09 13:36:03 --> Router Class Initialized
ERROR - 2015-12-09 13:36:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:38:27 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:27 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Router Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Output Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Security Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Input Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:38:27 --> Language Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Loader Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:38:27 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Session Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:38:27 --> A session cookie was not found.
DEBUG - 2015-12-09 15:38:27 --> Session routines successfully run
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Controller Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:27 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Router Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Output Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Security Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Input Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:38:27 --> Language Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Loader Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:38:27 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Session Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:38:27 --> Session routines successfully run
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Controller Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:27 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:38:27 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:38:27 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-09 15:38:27 --> Final output sent to browser
DEBUG - 2015-12-09 15:38:27 --> Total execution time: 0.0665
DEBUG - 2015-12-09 15:38:28 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:28 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:28 --> Router Class Initialized
ERROR - 2015-12-09 15:38:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:38:33 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:33 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Router Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Output Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Security Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Input Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:38:33 --> Language Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Loader Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:38:33 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Session Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:38:33 --> Session routines successfully run
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Controller Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:38:33 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 15:38:33 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:33 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Router Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Output Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Security Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Input Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:38:33 --> Language Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Loader Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:38:33 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Session Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:38:33 --> Session routines successfully run
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Controller Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:38:33 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:38:33 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:38:33 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:38:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:38:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:38:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:38:33 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:38:33 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-09 15:38:33 --> Final output sent to browser
DEBUG - 2015-12-09 15:38:33 --> Total execution time: 0.0476
DEBUG - 2015-12-09 15:38:34 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:34 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:34 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:34 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:34 --> Router Class Initialized
ERROR - 2015-12-09 15:38:34 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:38:36 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:36 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Router Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Output Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Security Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Input Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:38:36 --> Language Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Loader Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:38:36 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Session Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:38:36 --> Session routines successfully run
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Controller Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Model Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:38:36 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:38:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:38:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:38:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:38:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:38:36 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:38:36 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:38:36 --> Final output sent to browser
DEBUG - 2015-12-09 15:38:36 --> Total execution time: 0.0823
DEBUG - 2015-12-09 15:38:36 --> Config Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:38:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:38:36 --> URI Class Initialized
DEBUG - 2015-12-09 15:38:36 --> Router Class Initialized
ERROR - 2015-12-09 15:38:36 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:40:29 --> Config Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:40:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:40:29 --> URI Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Router Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Output Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Security Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Input Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:40:29 --> Language Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Loader Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:40:29 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Session Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:40:29 --> Session routines successfully run
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Controller Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:40:29 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:40:29 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:40:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:40:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:40:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:40:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:40:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:40:29 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:40:29 --> Final output sent to browser
DEBUG - 2015-12-09 15:40:29 --> Total execution time: 0.0823
DEBUG - 2015-12-09 15:40:30 --> Config Class Initialized
DEBUG - 2015-12-09 15:40:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:40:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:40:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:40:30 --> URI Class Initialized
DEBUG - 2015-12-09 15:40:30 --> Router Class Initialized
ERROR - 2015-12-09 15:40:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:41:09 --> Config Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:41:09 --> URI Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Router Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Output Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Security Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Input Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:41:09 --> Language Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Loader Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:41:09 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Session Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:41:09 --> Session routines successfully run
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Controller Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:41:09 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:41:09 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:41:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:41:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:41:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:41:09 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:41:09 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:41:09 --> Final output sent to browser
DEBUG - 2015-12-09 15:41:09 --> Total execution time: 0.1076
DEBUG - 2015-12-09 15:41:09 --> Config Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:41:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:41:09 --> URI Class Initialized
DEBUG - 2015-12-09 15:41:09 --> Router Class Initialized
ERROR - 2015-12-09 15:41:10 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:41:45 --> Config Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:41:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:41:45 --> URI Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Router Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Output Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Security Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Input Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:41:45 --> Language Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Loader Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:41:45 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Session Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:41:45 --> Session routines successfully run
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Controller Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Model Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:41:45 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:41:45 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:41:45 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:41:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:41:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:41:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:41:45 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:41:45 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:41:45 --> Final output sent to browser
DEBUG - 2015-12-09 15:41:45 --> Total execution time: 0.0831
DEBUG - 2015-12-09 15:41:46 --> Config Class Initialized
DEBUG - 2015-12-09 15:41:46 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:41:46 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:41:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:41:46 --> URI Class Initialized
DEBUG - 2015-12-09 15:41:46 --> Router Class Initialized
ERROR - 2015-12-09 15:41:46 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:42:19 --> Config Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:42:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:42:19 --> URI Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Router Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Output Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Security Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Input Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:42:19 --> Language Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Loader Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:42:19 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Session Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:42:19 --> Session routines successfully run
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Controller Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Model Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:42:19 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:42:19 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:42:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:42:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:42:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:42:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:42:19 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:42:19 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:42:19 --> Final output sent to browser
DEBUG - 2015-12-09 15:42:19 --> Total execution time: 0.0728
DEBUG - 2015-12-09 15:42:20 --> Config Class Initialized
DEBUG - 2015-12-09 15:42:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:42:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:42:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:42:20 --> URI Class Initialized
DEBUG - 2015-12-09 15:42:20 --> Router Class Initialized
ERROR - 2015-12-09 15:42:20 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:43:23 --> Config Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:43:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:43:23 --> URI Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Router Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Output Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Security Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Input Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:43:23 --> Language Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Loader Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:43:23 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Session Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:43:23 --> Session routines successfully run
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Controller Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:43:23 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:43:23 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:43:24 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:43:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:43:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:43:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:43:24 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:43:24 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-09 15:43:24 --> Final output sent to browser
DEBUG - 2015-12-09 15:43:24 --> Total execution time: 0.2561
DEBUG - 2015-12-09 15:43:24 --> Config Class Initialized
DEBUG - 2015-12-09 15:43:24 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:43:24 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:43:24 --> URI Class Initialized
DEBUG - 2015-12-09 15:43:24 --> Router Class Initialized
ERROR - 2015-12-09 15:43:24 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:43:26 --> Config Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:43:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:43:26 --> URI Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Router Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Output Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Security Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Input Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:43:26 --> Language Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Loader Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:43:26 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Session Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:43:26 --> Session routines successfully run
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Controller Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:43:26 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:43:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:43:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:43:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:43:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:43:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:43:26 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 15:43:26 --> Final output sent to browser
DEBUG - 2015-12-09 15:43:26 --> Total execution time: 0.0715
DEBUG - 2015-12-09 15:43:26 --> Config Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:43:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:43:26 --> URI Class Initialized
DEBUG - 2015-12-09 15:43:26 --> Router Class Initialized
ERROR - 2015-12-09 15:43:26 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:50:47 --> Config Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:50:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:50:47 --> URI Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Router Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Output Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Security Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Input Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:50:47 --> Language Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Loader Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:50:47 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Session Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:50:47 --> Session routines successfully run
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Controller Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:50:47 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:47 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:50:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:50:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:50:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:50:47 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:50:47 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 15:50:47 --> Final output sent to browser
DEBUG - 2015-12-09 15:50:47 --> Total execution time: 0.0836
DEBUG - 2015-12-09 15:50:47 --> Config Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:50:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:50:47 --> URI Class Initialized
DEBUG - 2015-12-09 15:50:47 --> Router Class Initialized
ERROR - 2015-12-09 15:50:47 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:50:50 --> Config Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:50:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:50:50 --> URI Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Router Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Output Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Security Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Input Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:50:50 --> Language Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Loader Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:50:50 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Session Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:50:50 --> Session routines successfully run
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Controller Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Model Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:50:50 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:50:50 --> Pagination Class Initialized
ERROR - 2015-12-09 15:50:50 --> Severity: Notice  --> Undefined property: Invoice::$Form_model /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 236
DEBUG - 2015-12-09 15:51:02 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:02 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Router Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Output Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Security Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Input Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:51:02 --> Language Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Loader Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:51:02 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Session Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:51:02 --> Session routines successfully run
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Controller Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:51:02 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:51:02 --> Pagination Class Initialized
ERROR - 2015-12-09 15:51:02 --> Severity: Notice  --> Undefined property: stdClass::$date /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 240
DEBUG - 2015-12-09 15:51:02 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:51:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:51:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:51:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:51:02 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:51:02 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:51:02 --> Final output sent to browser
DEBUG - 2015-12-09 15:51:02 --> Total execution time: 0.0555
DEBUG - 2015-12-09 15:51:03 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:03 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:03 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:03 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:03 --> Router Class Initialized
ERROR - 2015-12-09 15:51:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:51:29 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:29 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Router Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Output Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Security Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Input Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:51:29 --> Language Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Loader Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:51:29 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Session Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:51:29 --> Session routines successfully run
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Controller Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:51:29 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:51:29 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:51:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:51:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:51:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:51:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:51:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:51:29 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:51:29 --> Final output sent to browser
DEBUG - 2015-12-09 15:51:29 --> Total execution time: 0.0720
DEBUG - 2015-12-09 15:51:30 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:30 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:30 --> Router Class Initialized
ERROR - 2015-12-09 15:51:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:51:46 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:46 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Router Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Output Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Security Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Input Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:51:46 --> Language Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Loader Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:51:46 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Session Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:51:46 --> Session routines successfully run
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Controller Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:51:46 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:51:46 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:54 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Router Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Output Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Security Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Input Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:51:54 --> Language Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Loader Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:51:54 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Session Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:51:54 --> Session routines successfully run
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Controller Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Model Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:51:54 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:51:54 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:51:54 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:51:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:51:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:51:54 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 46
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 46
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 51
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 51
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 72
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 72
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 79
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 79
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 86
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 86
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 93
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 93
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 107
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 107
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 114
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 114
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 121
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 121
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 127
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 127
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 138
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 161
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 161
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 181
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 221
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 277
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 277
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 292
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 292
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 300
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 300
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 308
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 308
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 316
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 316
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 324
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 324
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 332
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 332
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 348
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 348
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 360
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 360
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 373
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 373
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 386
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 386
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 400
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 400
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 412
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 412
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 424
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 424
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 436
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 436
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 448
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 448
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: inv /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 457
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 457
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: comm /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 642
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: pipeline /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 642
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: m_comm /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 752
ERROR - 2015-12-09 15:51:54 --> Severity: Notice  --> Undefined variable: m_pipeline /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 752
DEBUG - 2015-12-09 15:51:54 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:51:54 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 15:51:54 --> Final output sent to browser
DEBUG - 2015-12-09 15:51:54 --> Total execution time: 0.1690
DEBUG - 2015-12-09 15:51:55 --> Config Class Initialized
DEBUG - 2015-12-09 15:51:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:51:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:51:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:51:55 --> URI Class Initialized
DEBUG - 2015-12-09 15:51:55 --> Router Class Initialized
ERROR - 2015-12-09 15:51:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:53:00 --> Config Class Initialized
DEBUG - 2015-12-09 15:53:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:53:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:53:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:53:00 --> URI Class Initialized
DEBUG - 2015-12-09 15:53:00 --> Router Class Initialized
DEBUG - 2015-12-09 15:53:00 --> Output Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Security Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Input Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:53:01 --> Language Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Loader Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:53:01 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Session Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:53:01 --> Session routines successfully run
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Controller Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:53:01 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:53:01 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:53:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:53:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:53:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:53:01 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:53:01 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:53:01 --> Final output sent to browser
DEBUG - 2015-12-09 15:53:01 --> Total execution time: 0.0780
DEBUG - 2015-12-09 15:53:01 --> Config Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:53:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:53:01 --> URI Class Initialized
DEBUG - 2015-12-09 15:53:01 --> Router Class Initialized
ERROR - 2015-12-09 15:53:01 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:54:30 --> Config Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:54:30 --> URI Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Router Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Output Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Security Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Input Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:54:30 --> Language Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Loader Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:54:30 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Session Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:54:30 --> Session routines successfully run
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Controller Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:54:30 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:54:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:54:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:54:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:54:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:54:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:54:30 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:54:30 --> Final output sent to browser
DEBUG - 2015-12-09 15:54:30 --> Total execution time: 0.1013
DEBUG - 2015-12-09 15:54:30 --> Config Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:54:30 --> URI Class Initialized
DEBUG - 2015-12-09 15:54:30 --> Router Class Initialized
ERROR - 2015-12-09 15:54:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:55:27 --> Config Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:55:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:55:27 --> URI Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Router Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Output Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Security Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Input Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:55:27 --> Language Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Loader Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:55:27 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Session Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:55:27 --> Session routines successfully run
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Controller Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:55:27 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:55:27 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:55:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:55:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:55:27 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-09 15:55:27 --> Severity: Notice  --> Undefined property: stdClass::$$dr_id /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/addInvoiceView.php 160
DEBUG - 2015-12-09 15:55:27 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:55:27 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:55:27 --> Final output sent to browser
DEBUG - 2015-12-09 15:55:27 --> Total execution time: 0.0510
DEBUG - 2015-12-09 15:55:27 --> Config Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:55:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:55:27 --> URI Class Initialized
DEBUG - 2015-12-09 15:55:27 --> Router Class Initialized
ERROR - 2015-12-09 15:55:27 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:55:30 --> Config Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:55:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:55:30 --> URI Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Router Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Output Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Security Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Input Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:55:30 --> Language Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Loader Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:55:30 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Session Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:55:30 --> Session routines successfully run
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Controller Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:55:30 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:55:30 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:55:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:55:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:55:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:55:30 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-09 15:55:30 --> Severity: Notice  --> Undefined property: stdClass::$$dr_id /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/addInvoiceView.php 160
DEBUG - 2015-12-09 15:55:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:55:30 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:55:30 --> Final output sent to browser
DEBUG - 2015-12-09 15:55:30 --> Total execution time: 0.0518
DEBUG - 2015-12-09 15:55:31 --> Config Class Initialized
DEBUG - 2015-12-09 15:55:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:55:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:55:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:55:31 --> URI Class Initialized
DEBUG - 2015-12-09 15:55:31 --> Router Class Initialized
ERROR - 2015-12-09 15:55:31 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:56:30 --> Config Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:56:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:56:30 --> URI Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Router Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Output Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Security Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Input Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:56:30 --> Language Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Loader Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:56:30 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Session Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:56:30 --> Session routines successfully run
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Controller Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Model Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:56:30 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:56:30 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:56:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:56:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:56:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:56:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:56:31 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:56:31 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:56:31 --> Final output sent to browser
DEBUG - 2015-12-09 15:56:31 --> Total execution time: 0.0653
DEBUG - 2015-12-09 15:56:31 --> Config Class Initialized
DEBUG - 2015-12-09 15:56:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:56:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:56:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:56:31 --> URI Class Initialized
DEBUG - 2015-12-09 15:56:31 --> Router Class Initialized
ERROR - 2015-12-09 15:56:31 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:57:01 --> Config Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:57:01 --> URI Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Router Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Output Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Security Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Input Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:57:01 --> Language Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Loader Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:57:01 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Session Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:57:01 --> Session routines successfully run
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Controller Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:57:01 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:01 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:57:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:57:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:57:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:57:01 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:57:01 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 15:57:01 --> Final output sent to browser
DEBUG - 2015-12-09 15:57:01 --> Total execution time: 0.0442
DEBUG - 2015-12-09 15:57:02 --> Config Class Initialized
DEBUG - 2015-12-09 15:57:02 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:57:02 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:57:02 --> URI Class Initialized
DEBUG - 2015-12-09 15:57:02 --> Router Class Initialized
ERROR - 2015-12-09 15:57:02 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 15:57:04 --> Config Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:57:04 --> URI Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Router Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Output Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Security Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Input Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 15:57:04 --> Language Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Loader Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Helper loaded: url_helper
DEBUG - 2015-12-09 15:57:04 --> Database Driver Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Session Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Helper loaded: string_helper
DEBUG - 2015-12-09 15:57:04 --> Session routines successfully run
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Controller Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Model Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Helper loaded: form_helper
DEBUG - 2015-12-09 15:57:04 --> Form Validation Class Initialized
DEBUG - 2015-12-09 15:57:04 --> Pagination Class Initialized
DEBUG - 2015-12-09 15:57:04 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 15:57:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 15:57:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 15:57:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 15:57:04 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 15:57:04 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 15:57:04 --> Final output sent to browser
DEBUG - 2015-12-09 15:57:04 --> Total execution time: 0.0702
DEBUG - 2015-12-09 15:57:06 --> Config Class Initialized
DEBUG - 2015-12-09 15:57:06 --> Hooks Class Initialized
DEBUG - 2015-12-09 15:57:06 --> Utf8 Class Initialized
DEBUG - 2015-12-09 15:57:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 15:57:06 --> URI Class Initialized
DEBUG - 2015-12-09 15:57:06 --> Router Class Initialized
ERROR - 2015-12-09 15:57:06 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:00:21 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:21 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Router Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Output Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Security Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Input Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:00:21 --> Language Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Loader Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:00:21 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Session Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:00:21 --> Session routines successfully run
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Controller Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:00:21 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Model Class Initialized
ERROR - 2015-12-09 16:00:21 --> Severity: Notice  --> Undefined variable: crm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 130
ERROR - 2015-12-09 16:00:21 --> Severity: Notice  --> Undefined variable: sm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 132
DEBUG - 2015-12-09 16:00:21 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-09 16:00:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:00:21 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 16:00:21 --> Final output sent to browser
DEBUG - 2015-12-09 16:00:21 --> Total execution time: 0.0484
DEBUG - 2015-12-09 16:00:21 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:21 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:21 --> Router Class Initialized
ERROR - 2015-12-09 16:00:21 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:00:26 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:26 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:26 --> Router Class Initialized
ERROR - 2015-12-09 16:00:26 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:00:28 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:28 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Router Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Output Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Security Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Input Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:00:28 --> Language Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Loader Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:00:28 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Session Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:00:28 --> Session routines successfully run
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Controller Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:00:28 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:28 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:00:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:00:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:00:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:00:28 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:00:28 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 16:00:28 --> Final output sent to browser
DEBUG - 2015-12-09 16:00:28 --> Total execution time: 0.0465
DEBUG - 2015-12-09 16:00:29 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:29 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:29 --> Router Class Initialized
ERROR - 2015-12-09 16:00:29 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:00:31 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:31 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Router Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Output Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Security Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Input Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:00:31 --> Language Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Loader Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:00:31 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Session Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:00:31 --> Session routines successfully run
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Controller Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:00:31 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:00:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:00:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:00:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:00:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:00:31 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:00:31 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:00:31 --> Final output sent to browser
DEBUG - 2015-12-09 16:00:31 --> Total execution time: 0.0739
DEBUG - 2015-12-09 16:00:31 --> Config Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:00:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:00:31 --> URI Class Initialized
DEBUG - 2015-12-09 16:00:31 --> Router Class Initialized
ERROR - 2015-12-09 16:00:31 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:01:36 --> Config Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:01:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:01:36 --> URI Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Router Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Output Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Security Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Input Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:01:36 --> Language Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Loader Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:01:36 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Session Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:01:36 --> Session routines successfully run
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Controller Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:01:36 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:01:36 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:01:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:01:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:01:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:01:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:01:36 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:01:36 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:01:36 --> Final output sent to browser
DEBUG - 2015-12-09 16:01:36 --> Total execution time: 0.0541
DEBUG - 2015-12-09 16:01:37 --> Config Class Initialized
DEBUG - 2015-12-09 16:01:37 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:01:37 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:01:37 --> URI Class Initialized
DEBUG - 2015-12-09 16:01:37 --> Router Class Initialized
ERROR - 2015-12-09 16:01:37 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:04:27 --> Config Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:04:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:04:27 --> URI Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Router Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Output Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Security Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Input Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:04:27 --> Language Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Loader Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:04:27 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Session Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:04:27 --> Session routines successfully run
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Controller Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Model Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:04:27 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:04:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 16:04:27 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:04:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:04:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:04:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:04:27 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:04:27 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:04:27 --> Final output sent to browser
DEBUG - 2015-12-09 16:04:27 --> Total execution time: 0.0781
DEBUG - 2015-12-09 16:04:28 --> Config Class Initialized
DEBUG - 2015-12-09 16:04:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:04:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:04:28 --> URI Class Initialized
DEBUG - 2015-12-09 16:04:28 --> Router Class Initialized
ERROR - 2015-12-09 16:04:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:05:54 --> Config Class Initialized
DEBUG - 2015-12-09 16:05:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:05:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:05:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:05:54 --> URI Class Initialized
DEBUG - 2015-12-09 16:05:54 --> Router Class Initialized
ERROR - 2015-12-09 16:05:54 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:05:56 --> Config Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:05:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:05:56 --> URI Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Router Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Output Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Security Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Input Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:05:56 --> Language Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Loader Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:05:56 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Session Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:05:56 --> Session routines successfully run
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Controller Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:05:56 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:05:56 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:05:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:05:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:05:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:05:56 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:05:56 --> File loaded: application/views/invoice/addFormInvoiceView.php
DEBUG - 2015-12-09 16:05:56 --> Final output sent to browser
DEBUG - 2015-12-09 16:05:56 --> Total execution time: 0.0732
DEBUG - 2015-12-09 16:05:56 --> Config Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:05:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:05:56 --> URI Class Initialized
DEBUG - 2015-12-09 16:05:56 --> Router Class Initialized
ERROR - 2015-12-09 16:05:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:06:06 --> Config Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:06:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:06:06 --> URI Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Router Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Output Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Security Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Input Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:06:06 --> Language Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Loader Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:06:06 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Session Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:06:06 --> Session routines successfully run
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Controller Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Model Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:06:06 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:06:06 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:06:06 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:06:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:06:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:06:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:06:06 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:06:06 --> File loaded: application/views/invoice/addFormInvoiceView.php
DEBUG - 2015-12-09 16:06:06 --> Final output sent to browser
DEBUG - 2015-12-09 16:06:06 --> Total execution time: 0.0509
DEBUG - 2015-12-09 16:06:07 --> Config Class Initialized
DEBUG - 2015-12-09 16:06:07 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:06:07 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:06:07 --> URI Class Initialized
DEBUG - 2015-12-09 16:06:07 --> Router Class Initialized
ERROR - 2015-12-09 16:06:07 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:07:17 --> Config Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:07:17 --> URI Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Router Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Output Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Security Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Input Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:07:17 --> Language Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Loader Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:07:17 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Session Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:07:17 --> Session routines successfully run
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Controller Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:07:17 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:07:17 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:07:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:07:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:07:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:07:17 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:07:17 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:07:17 --> Final output sent to browser
DEBUG - 2015-12-09 16:07:17 --> Total execution time: 0.0736
DEBUG - 2015-12-09 16:07:17 --> Config Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:07:17 --> URI Class Initialized
DEBUG - 2015-12-09 16:07:17 --> Router Class Initialized
ERROR - 2015-12-09 16:07:17 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:07:22 --> Config Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:07:22 --> URI Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Router Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Output Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Security Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Input Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:07:22 --> Language Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Loader Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:07:22 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Session Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:07:22 --> Session routines successfully run
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Controller Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:07:22 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:07:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 16:07:22 --> Helper loaded: pdf_helper
DEBUG - 2015-12-09 16:07:22 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-09 16:07:24 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-09 16:07:25 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-09 16:07:26 --> Config Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:07:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:07:26 --> URI Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Router Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Output Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Security Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Input Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:07:26 --> Language Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Loader Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:07:26 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Session Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:07:26 --> Session routines successfully run
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Controller Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:07:26 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:07:26 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:07:26 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 16:07:26 --> Final output sent to browser
DEBUG - 2015-12-09 16:07:26 --> Total execution time: 0.0608
DEBUG - 2015-12-09 16:07:27 --> Config Class Initialized
DEBUG - 2015-12-09 16:07:27 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:07:27 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:07:27 --> URI Class Initialized
DEBUG - 2015-12-09 16:07:27 --> Router Class Initialized
ERROR - 2015-12-09 16:07:27 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:08:08 --> Config Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:08:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:08:08 --> URI Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Router Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Output Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Security Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Input Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:08:08 --> Language Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Loader Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:08:08 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Session Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:08:08 --> Session routines successfully run
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Controller Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:08:08 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:08:08 --> Helper loaded: pdf_helper
ERROR - 2015-12-09 16:08:08 --> Severity: Warning  --> fopen(file:///Applications/MAMP/htdocs/asmc/crm/pdf/receipts/admin/136.pdf): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/include/tcpdf_static.php 2440
DEBUG - 2015-12-09 16:09:02 --> Config Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:09:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:09:02 --> URI Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Router Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Output Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Security Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Input Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:09:02 --> Language Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Loader Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:09:02 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Session Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:09:02 --> Session routines successfully run
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Controller Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:09:02 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:09:02 --> Helper loaded: pdf_helper
ERROR - 2015-12-09 16:09:02 --> Severity: Warning  --> fopen(file:///Applications/MAMP/htdocs/asmc/crm/pdf/receipts/admin/136.pdf): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/include/tcpdf_static.php 2440
DEBUG - 2015-12-09 16:09:22 --> Config Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:09:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:09:22 --> URI Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Router Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Output Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Security Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Input Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:09:22 --> Language Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Loader Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:09:22 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Session Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:09:22 --> Session routines successfully run
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Controller Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:09:22 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:09:22 --> Helper loaded: pdf_helper
DEBUG - 2015-12-09 16:09:22 --> File loaded: application/views/invoice/pdf/adminreceiptPDF.php
DEBUG - 2015-12-09 16:09:22 --> Final output sent to browser
DEBUG - 2015-12-09 16:09:22 --> Total execution time: 0.4465
DEBUG - 2015-12-09 16:09:26 --> Config Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:09:26 --> URI Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Router Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Output Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Security Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Input Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:09:26 --> Language Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Loader Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:09:26 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Session Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:09:26 --> Session routines successfully run
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Controller Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Model Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:09:26 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:09:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:09:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:09:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:09:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:09:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:09:26 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 16:09:26 --> Final output sent to browser
DEBUG - 2015-12-09 16:09:26 --> Total execution time: 0.0622
DEBUG - 2015-12-09 16:09:26 --> Config Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:09:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:09:26 --> URI Class Initialized
DEBUG - 2015-12-09 16:09:26 --> Router Class Initialized
ERROR - 2015-12-09 16:09:26 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:16:36 --> Config Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:16:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:16:36 --> URI Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Router Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Output Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Security Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Input Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:16:36 --> Language Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Loader Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:16:36 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Session Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:16:36 --> Session routines successfully run
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Controller Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:16:36 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Model Class Initialized
DEBUG - 2015-12-09 16:16:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:16:36 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 16:16:36 --> Final output sent to browser
DEBUG - 2015-12-09 16:16:36 --> Total execution time: 0.0664
DEBUG - 2015-12-09 16:16:36 --> Config Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:16:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:16:36 --> URI Class Initialized
DEBUG - 2015-12-09 16:16:36 --> Router Class Initialized
ERROR - 2015-12-09 16:16:36 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:23:18 --> Config Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:23:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:23:18 --> URI Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Router Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Output Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Security Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Input Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:23:18 --> Language Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Loader Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:23:18 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Session Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:23:18 --> Session routines successfully run
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Controller Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Model Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:23:18 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:23:18 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:23:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:23:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:23:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:23:18 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:23:18 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:23:18 --> Final output sent to browser
DEBUG - 2015-12-09 16:23:18 --> Total execution time: 0.0764
DEBUG - 2015-12-09 16:23:18 --> Config Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:23:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:23:18 --> URI Class Initialized
DEBUG - 2015-12-09 16:23:18 --> Router Class Initialized
ERROR - 2015-12-09 16:23:18 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:24:08 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:08 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Router Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Output Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Security Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Input Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:24:08 --> Language Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Loader Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:24:08 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Session Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:24:08 --> Session routines successfully run
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Controller Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:24:08 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:24:08 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:24:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:24:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:24:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:24:08 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:24:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-09 16:24:08 --> Final output sent to browser
DEBUG - 2015-12-09 16:24:08 --> Total execution time: 0.1699
DEBUG - 2015-12-09 16:24:08 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:08 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:08 --> Router Class Initialized
ERROR - 2015-12-09 16:24:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:24:10 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:10 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Router Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Output Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Security Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Input Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:24:10 --> Language Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Loader Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:24:10 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Session Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:24:10 --> Session routines successfully run
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Controller Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:24:10 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:24:10 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:24:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:24:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:24:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:24:10 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:24:10 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 16:24:10 --> Final output sent to browser
DEBUG - 2015-12-09 16:24:10 --> Total execution time: 0.0711
DEBUG - 2015-12-09 16:24:10 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:10 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:10 --> Router Class Initialized
ERROR - 2015-12-09 16:24:10 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:24:12 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:12 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Router Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Output Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Security Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Input Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:24:12 --> Language Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Loader Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:24:12 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Session Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:24:12 --> Session routines successfully run
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Controller Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:24:12 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:24:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:24:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:24:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:24:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:24:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:24:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-09 16:24:12 --> Final output sent to browser
DEBUG - 2015-12-09 16:24:12 --> Total execution time: 0.0892
DEBUG - 2015-12-09 16:24:12 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:12 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:12 --> Router Class Initialized
ERROR - 2015-12-09 16:24:12 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:24:14 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:14 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Router Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Output Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Security Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Input Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:24:14 --> Language Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Loader Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:24:14 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Session Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:24:14 --> Session routines successfully run
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Controller Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Model Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:24:14 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:24:14 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:24:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:24:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:24:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:24:14 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:24:14 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 16:24:14 --> Final output sent to browser
DEBUG - 2015-12-09 16:24:14 --> Total execution time: 0.0747
DEBUG - 2015-12-09 16:24:14 --> Config Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:24:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:24:14 --> URI Class Initialized
DEBUG - 2015-12-09 16:24:14 --> Router Class Initialized
ERROR - 2015-12-09 16:24:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:25:30 --> Config Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:25:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:25:30 --> URI Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Router Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Output Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Security Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Input Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:25:30 --> Language Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Loader Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:25:30 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Session Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:25:30 --> Session routines successfully run
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Controller Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Model Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:25:30 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:25:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:25:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:25:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:25:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:25:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:25:30 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-09 16:25:30 --> Final output sent to browser
DEBUG - 2015-12-09 16:25:30 --> Total execution time: 0.1073
DEBUG - 2015-12-09 16:25:30 --> Config Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:25:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:25:30 --> URI Class Initialized
DEBUG - 2015-12-09 16:25:30 --> Router Class Initialized
ERROR - 2015-12-09 16:25:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:34:29 --> Config Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:34:29 --> URI Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Router Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Output Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Security Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Input Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:34:29 --> Language Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Loader Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:34:29 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Session Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:34:29 --> Session routines successfully run
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Controller Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Model Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:34:29 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:34:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:34:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:34:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:34:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:34:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:34:29 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:34:29 --> Final output sent to browser
DEBUG - 2015-12-09 16:34:29 --> Total execution time: 0.1023
DEBUG - 2015-12-09 16:34:29 --> Config Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:34:29 --> URI Class Initialized
DEBUG - 2015-12-09 16:34:29 --> Router Class Initialized
ERROR - 2015-12-09 16:34:29 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:35:31 --> Config Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:35:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:35:31 --> URI Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Router Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Output Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Security Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Input Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:35:31 --> Language Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Loader Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:35:31 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Session Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:35:31 --> Session routines successfully run
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Controller Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:35:31 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:35:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:35:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:35:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:35:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:35:31 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:35:31 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:35:31 --> Final output sent to browser
DEBUG - 2015-12-09 16:35:31 --> Total execution time: 0.0881
DEBUG - 2015-12-09 16:35:31 --> Config Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:35:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:35:31 --> URI Class Initialized
DEBUG - 2015-12-09 16:35:31 --> Router Class Initialized
ERROR - 2015-12-09 16:35:31 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:35:35 --> Config Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:35:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:35:35 --> URI Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Router Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Output Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Security Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Input Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:35:35 --> Language Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Loader Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:35:35 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Session Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:35:35 --> Session routines successfully run
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Controller Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:35:35 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:35 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:35:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:35:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:35:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:35:35 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:35:35 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 16:35:35 --> Final output sent to browser
DEBUG - 2015-12-09 16:35:35 --> Total execution time: 0.0509
DEBUG - 2015-12-09 16:35:35 --> Config Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:35:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:35:35 --> URI Class Initialized
DEBUG - 2015-12-09 16:35:35 --> Router Class Initialized
ERROR - 2015-12-09 16:35:35 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:35:38 --> Config Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:35:38 --> URI Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Router Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Output Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Security Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Input Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:35:38 --> Language Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Loader Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:35:38 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Session Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:35:38 --> Session routines successfully run
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Controller Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Model Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:35:38 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:35:38 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:35:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:35:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:35:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:35:38 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:35:38 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:35:38 --> Final output sent to browser
DEBUG - 2015-12-09 16:35:38 --> Total execution time: 0.0705
DEBUG - 2015-12-09 16:35:38 --> Config Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:35:38 --> URI Class Initialized
DEBUG - 2015-12-09 16:35:38 --> Router Class Initialized
ERROR - 2015-12-09 16:35:38 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:39:58 --> Config Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:39:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:39:58 --> URI Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Router Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Output Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Security Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Input Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:39:58 --> Language Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Loader Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:39:58 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Session Class Initialized
DEBUG - 2015-12-09 16:39:58 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:39:58 --> Session routines successfully run
DEBUG - 2015-12-09 16:39:58 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Controller Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Model Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:39:59 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:39:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:39:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:39:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:39:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:39:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:39:59 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:39:59 --> Final output sent to browser
DEBUG - 2015-12-09 16:39:59 --> Total execution time: 0.0820
DEBUG - 2015-12-09 16:39:59 --> Config Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:39:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:39:59 --> URI Class Initialized
DEBUG - 2015-12-09 16:39:59 --> Router Class Initialized
ERROR - 2015-12-09 16:39:59 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:40:02 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:02 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Router Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Output Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Security Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Input Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:40:02 --> Language Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Loader Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:40:02 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Session Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:40:02 --> Session routines successfully run
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Controller Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:40:02 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 16:40:02 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:40:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:40:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:40:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:40:02 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:40:02 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:40:02 --> Final output sent to browser
DEBUG - 2015-12-09 16:40:02 --> Total execution time: 0.0626
DEBUG - 2015-12-09 16:40:02 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:02 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:02 --> Router Class Initialized
ERROR - 2015-12-09 16:40:02 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:40:16 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:16 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:16 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:16 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:16 --> Router Class Initialized
ERROR - 2015-12-09 16:40:16 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:40:19 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:19 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Router Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Output Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Security Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Input Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:40:19 --> Language Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Loader Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:40:19 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Session Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:40:19 --> Session routines successfully run
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Controller Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:40:19 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:40:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:40:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:40:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:40:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:40:19 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:40:19 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:40:19 --> Final output sent to browser
DEBUG - 2015-12-09 16:40:19 --> Total execution time: 0.0670
DEBUG - 2015-12-09 16:40:19 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:19 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:19 --> Router Class Initialized
ERROR - 2015-12-09 16:40:19 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:40:21 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:21 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Router Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Output Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Security Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Input Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:40:21 --> Language Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Loader Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:40:21 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Session Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:40:21 --> Session routines successfully run
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Controller Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Model Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:40:21 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:40:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 16:40:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:40:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:40:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:40:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:40:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:40:21 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:40:21 --> Final output sent to browser
DEBUG - 2015-12-09 16:40:21 --> Total execution time: 0.0525
DEBUG - 2015-12-09 16:40:22 --> Config Class Initialized
DEBUG - 2015-12-09 16:40:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:40:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:40:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:40:22 --> URI Class Initialized
DEBUG - 2015-12-09 16:40:22 --> Router Class Initialized
ERROR - 2015-12-09 16:40:22 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:41:17 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:17 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Router Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Output Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Security Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Input Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:41:17 --> Language Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Loader Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:41:17 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Session Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:41:17 --> Session routines successfully run
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Controller Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:41:17 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:41:17 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:41:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:41:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:41:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:41:17 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:41:17 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:41:17 --> Final output sent to browser
DEBUG - 2015-12-09 16:41:17 --> Total execution time: 0.0697
DEBUG - 2015-12-09 16:41:17 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:17 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:17 --> Router Class Initialized
ERROR - 2015-12-09 16:41:17 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:41:20 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:20 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Router Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Output Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Security Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Input Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:41:20 --> Language Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Loader Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:41:20 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Session Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:41:20 --> Session routines successfully run
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Controller Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:41:20 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 16:41:20 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:41:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:41:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:41:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:41:20 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:41:20 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:41:20 --> Final output sent to browser
DEBUG - 2015-12-09 16:41:20 --> Total execution time: 0.0599
DEBUG - 2015-12-09 16:41:20 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:20 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:20 --> Router Class Initialized
ERROR - 2015-12-09 16:41:20 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:41:54 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:54 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Router Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Output Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Security Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Input Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:41:54 --> Language Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Loader Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:41:54 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Session Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:41:54 --> Session routines successfully run
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Controller Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:41:54 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:41:54 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:41:54 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:41:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:41:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:41:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:41:54 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:41:54 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:41:54 --> Final output sent to browser
DEBUG - 2015-12-09 16:41:54 --> Total execution time: 0.0688
DEBUG - 2015-12-09 16:41:55 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:55 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:55 --> Router Class Initialized
ERROR - 2015-12-09 16:41:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:41:56 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:56 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Router Class Initialized
ERROR - 2015-12-09 16:41:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:41:56 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:56 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Router Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Output Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Security Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Input Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:41:56 --> Language Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Loader Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:41:56 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Session Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:41:56 --> Session routines successfully run
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Controller Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Model Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:41:56 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:41:56 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:41:56 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:41:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:41:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:41:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:41:56 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:41:56 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:41:56 --> Final output sent to browser
DEBUG - 2015-12-09 16:41:56 --> Total execution time: 0.0449
DEBUG - 2015-12-09 16:41:57 --> Config Class Initialized
DEBUG - 2015-12-09 16:41:57 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:41:57 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:41:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:41:57 --> URI Class Initialized
DEBUG - 2015-12-09 16:41:57 --> Router Class Initialized
ERROR - 2015-12-09 16:41:57 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:42:22 --> Config Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:42:22 --> URI Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Router Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Output Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Security Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Input Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:42:22 --> Language Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Loader Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:42:22 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Session Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:42:22 --> Session routines successfully run
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Controller Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Model Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:42:22 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:42:22 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:42:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:42:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:42:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:42:22 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:42:22 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:42:22 --> Final output sent to browser
DEBUG - 2015-12-09 16:42:22 --> Total execution time: 0.0828
DEBUG - 2015-12-09 16:42:22 --> Config Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:42:22 --> URI Class Initialized
DEBUG - 2015-12-09 16:42:22 --> Router Class Initialized
ERROR - 2015-12-09 16:42:22 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:43:54 --> Config Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:43:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:43:54 --> URI Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Router Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Output Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Security Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Input Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:43:54 --> Language Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Loader Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:43:54 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Session Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:43:54 --> Session routines successfully run
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Controller Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Model Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:43:54 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:43:54 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:43:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:43:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:43:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:43:54 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:43:54 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:43:54 --> Final output sent to browser
DEBUG - 2015-12-09 16:43:54 --> Total execution time: 0.0623
DEBUG - 2015-12-09 16:43:54 --> Config Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:43:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:43:54 --> URI Class Initialized
DEBUG - 2015-12-09 16:43:54 --> Router Class Initialized
ERROR - 2015-12-09 16:43:54 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:44:45 --> Config Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:44:45 --> URI Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Router Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Output Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Security Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Input Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:44:45 --> Language Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Loader Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:44:45 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Session Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:44:45 --> Session routines successfully run
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Controller Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:44:45 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:44:45 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:44:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:44:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:44:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:44:45 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:44:45 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 16:44:45 --> Final output sent to browser
DEBUG - 2015-12-09 16:44:45 --> Total execution time: 0.0779
DEBUG - 2015-12-09 16:44:45 --> Config Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:44:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:44:45 --> URI Class Initialized
DEBUG - 2015-12-09 16:44:45 --> Router Class Initialized
ERROR - 2015-12-09 16:44:45 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 16:44:51 --> Config Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:44:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:44:51 --> URI Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Router Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Output Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Security Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Input Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:44:51 --> Language Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Loader Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:44:51 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Session Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:44:51 --> Session routines successfully run
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Controller Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:44:51 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:44:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 16:44:51 --> Helper loaded: pdf_helper
DEBUG - 2015-12-09 16:44:52 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-09 16:44:53 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-09 16:44:54 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-09 16:44:55 --> Config Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:44:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:44:55 --> URI Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Router Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Output Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Security Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Input Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 16:44:55 --> Language Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Loader Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Helper loaded: url_helper
DEBUG - 2015-12-09 16:44:55 --> Database Driver Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Session Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Helper loaded: string_helper
DEBUG - 2015-12-09 16:44:55 --> Session routines successfully run
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Controller Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Model Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Helper loaded: form_helper
DEBUG - 2015-12-09 16:44:55 --> Form Validation Class Initialized
DEBUG - 2015-12-09 16:44:55 --> Pagination Class Initialized
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 16:44:55 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 16:44:55 --> Final output sent to browser
DEBUG - 2015-12-09 16:44:55 --> Total execution time: 0.0598
DEBUG - 2015-12-09 16:44:56 --> Config Class Initialized
DEBUG - 2015-12-09 16:44:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 16:44:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 16:44:56 --> URI Class Initialized
DEBUG - 2015-12-09 16:44:56 --> Router Class Initialized
ERROR - 2015-12-09 16:44:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:32:08 --> Config Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:32:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:32:08 --> URI Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Router Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Output Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Security Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Input Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:32:08 --> Language Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Loader Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:32:08 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Session Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:32:08 --> Session routines successfully run
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Controller Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:32:08 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:08 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:32:08 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-09 17:32:08 --> Final output sent to browser
DEBUG - 2015-12-09 17:32:08 --> Total execution time: 0.0697
DEBUG - 2015-12-09 17:32:08 --> Config Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:32:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:32:08 --> URI Class Initialized
DEBUG - 2015-12-09 17:32:08 --> Router Class Initialized
ERROR - 2015-12-09 17:32:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:32:46 --> Config Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:32:46 --> URI Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Router Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Output Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Security Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Input Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:32:46 --> Language Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Loader Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:32:46 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Session Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:32:46 --> Session routines successfully run
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Controller Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Model Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:32:46 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:32:46 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:32:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:32:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:32:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:32:46 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:32:46 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 17:32:46 --> Final output sent to browser
DEBUG - 2015-12-09 17:32:46 --> Total execution time: 0.0800
DEBUG - 2015-12-09 17:32:46 --> Config Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:32:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:32:46 --> URI Class Initialized
DEBUG - 2015-12-09 17:32:46 --> Router Class Initialized
ERROR - 2015-12-09 17:32:46 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:33:23 --> Config Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:33:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:33:23 --> URI Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Router Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Output Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Security Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Input Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:33:23 --> Language Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Loader Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:33:23 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Session Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:33:23 --> Session routines successfully run
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Controller Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Model Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:33:23 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:33:23 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:33:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:33:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:33:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:33:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:33:23 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:33:23 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 17:33:23 --> Final output sent to browser
DEBUG - 2015-12-09 17:33:23 --> Total execution time: 0.0796
DEBUG - 2015-12-09 17:33:24 --> Config Class Initialized
DEBUG - 2015-12-09 17:33:24 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:33:24 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:33:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:33:24 --> URI Class Initialized
DEBUG - 2015-12-09 17:33:24 --> Router Class Initialized
ERROR - 2015-12-09 17:33:24 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:35:56 --> Config Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:35:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:35:56 --> URI Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Router Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Output Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Security Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Input Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:35:56 --> Language Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Loader Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:35:56 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Session Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:35:56 --> Session routines successfully run
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Controller Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:35:56 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:56 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:35:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:35:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:35:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:35:56 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:35:56 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-09 17:35:56 --> Final output sent to browser
DEBUG - 2015-12-09 17:35:56 --> Total execution time: 0.0643
DEBUG - 2015-12-09 17:35:56 --> Config Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:35:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:35:56 --> URI Class Initialized
DEBUG - 2015-12-09 17:35:56 --> Router Class Initialized
ERROR - 2015-12-09 17:35:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:35:59 --> Config Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:35:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:35:59 --> URI Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Router Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Output Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Security Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Input Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:35:59 --> Language Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Loader Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:35:59 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Session Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:35:59 --> Session routines successfully run
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Controller Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Model Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:35:59 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:35:59 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:35:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:35:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:35:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:35:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:35:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:35:59 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 17:35:59 --> Final output sent to browser
DEBUG - 2015-12-09 17:35:59 --> Total execution time: 0.0603
DEBUG - 2015-12-09 17:36:00 --> Config Class Initialized
DEBUG - 2015-12-09 17:36:00 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:36:00 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:36:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:36:00 --> URI Class Initialized
DEBUG - 2015-12-09 17:36:00 --> Router Class Initialized
ERROR - 2015-12-09 17:36:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:36:16 --> Config Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:36:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:36:16 --> URI Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Router Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Output Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Security Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Input Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:36:16 --> Language Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Loader Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:36:16 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Session Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:36:16 --> Session routines successfully run
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Controller Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:36:16 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:36:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 17:36:16 --> Helper loaded: pdf_helper
DEBUG - 2015-12-09 17:36:17 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-09 17:36:18 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-09 17:36:19 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-09 17:36:21 --> Config Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:36:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:36:21 --> URI Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Router Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Output Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Security Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Input Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:36:21 --> Language Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Loader Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:36:21 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Session Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:36:21 --> Session routines successfully run
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Controller Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Model Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:36:21 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:36:21 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 17:36:21 --> Final output sent to browser
DEBUG - 2015-12-09 17:36:21 --> Total execution time: 0.0562
DEBUG - 2015-12-09 17:36:21 --> Config Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:36:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:36:21 --> URI Class Initialized
DEBUG - 2015-12-09 17:36:21 --> Router Class Initialized
ERROR - 2015-12-09 17:36:21 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:37:23 --> Config Class Initialized
DEBUG - 2015-12-09 17:37:23 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:37:23 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:37:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:37:23 --> URI Class Initialized
DEBUG - 2015-12-09 17:37:23 --> Router Class Initialized
ERROR - 2015-12-09 17:37:23 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:37:26 --> Config Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:37:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:37:26 --> URI Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Router Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Output Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Security Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Input Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:37:26 --> Language Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Loader Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:37:26 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Session Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:37:26 --> Session routines successfully run
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Controller Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:37:26 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:37:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:37:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:37:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:37:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:37:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:37:26 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-09 17:37:26 --> Final output sent to browser
DEBUG - 2015-12-09 17:37:26 --> Total execution time: 0.0889
DEBUG - 2015-12-09 17:37:26 --> Config Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:37:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:37:26 --> URI Class Initialized
DEBUG - 2015-12-09 17:37:26 --> Router Class Initialized
ERROR - 2015-12-09 17:37:26 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:37:29 --> Config Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:37:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:37:29 --> URI Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Router Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Output Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Security Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Input Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:37:29 --> Language Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Loader Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:37:29 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Session Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:37:29 --> Session routines successfully run
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Controller Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:37:29 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:37:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 17:37:29 --> Helper loaded: pdf_helper
DEBUG - 2015-12-09 17:37:30 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-09 17:37:31 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-09 17:37:32 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-09 17:37:33 --> Config Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:37:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:37:33 --> URI Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Router Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Output Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Security Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Input Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:37:33 --> Language Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Loader Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:37:33 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Session Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:37:33 --> Session routines successfully run
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Controller Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Model Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:37:33 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:37:33 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:37:33 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 17:37:33 --> Final output sent to browser
DEBUG - 2015-12-09 17:37:33 --> Total execution time: 0.0568
DEBUG - 2015-12-09 17:37:34 --> Config Class Initialized
DEBUG - 2015-12-09 17:37:34 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:37:34 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:37:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:37:34 --> URI Class Initialized
DEBUG - 2015-12-09 17:37:34 --> Router Class Initialized
ERROR - 2015-12-09 17:37:34 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:43:26 --> Config Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:43:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:43:26 --> URI Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Router Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Output Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Security Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Input Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:43:26 --> Language Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Loader Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:43:26 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Session Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:43:26 --> Session routines successfully run
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Controller Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:43:26 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:43:26 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:43:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:43:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:43:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:43:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:43:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:43:26 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 17:43:26 --> Final output sent to browser
DEBUG - 2015-12-09 17:43:26 --> Total execution time: 0.0864
DEBUG - 2015-12-09 17:43:28 --> Config Class Initialized
DEBUG - 2015-12-09 17:43:28 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:43:28 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:43:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:43:28 --> URI Class Initialized
DEBUG - 2015-12-09 17:43:28 --> Router Class Initialized
ERROR - 2015-12-09 17:43:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:43:36 --> Config Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:43:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:43:36 --> URI Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Router Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Output Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Security Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Input Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:43:36 --> Language Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Loader Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:43:36 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Session Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:43:36 --> Session routines successfully run
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Controller Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:43:36 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:43:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-12-09 17:43:36 --> Severity: Notice  --> Undefined index: marketing /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 493
ERROR - 2015-12-09 17:43:36 --> Severity: Notice  --> Undefined index: referral /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 494
ERROR - 2015-12-09 17:43:36 --> Severity: Notice  --> Undefined index: source /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 495
ERROR - 2015-12-09 17:43:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
ERROR - 2015-12-09 17:43:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/helpers/url_helper.php 542
DEBUG - 2015-12-09 17:44:05 --> Config Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:44:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:44:05 --> URI Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Router Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Output Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Security Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Input Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:44:05 --> Language Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Loader Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:44:05 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Session Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:44:05 --> Session routines successfully run
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Controller Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Model Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:44:05 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:44:05 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:44:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:44:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:44:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:44:05 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:44:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 17:44:05 --> Final output sent to browser
DEBUG - 2015-12-09 17:44:05 --> Total execution time: 0.0717
DEBUG - 2015-12-09 17:44:05 --> Config Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:44:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:44:05 --> URI Class Initialized
DEBUG - 2015-12-09 17:44:05 --> Router Class Initialized
ERROR - 2015-12-09 17:44:05 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:45:11 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:11 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Router Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Output Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Security Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Input Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:45:11 --> Language Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Loader Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:45:11 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Session Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:45:11 --> Session routines successfully run
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Controller Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:45:11 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:45:11 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:45:11 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:45:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:45:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:45:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:45:11 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:45:11 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 17:45:11 --> Final output sent to browser
DEBUG - 2015-12-09 17:45:11 --> Total execution time: 0.0967
DEBUG - 2015-12-09 17:45:12 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:12 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:12 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:12 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:12 --> Router Class Initialized
ERROR - 2015-12-09 17:45:12 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:45:14 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:14 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Router Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Output Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Security Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Input Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:45:14 --> Language Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Loader Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:45:14 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Session Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:45:14 --> Session routines successfully run
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Controller Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:45:14 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:45:14 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:45:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:45:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:45:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:45:14 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:45:14 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 17:45:14 --> Final output sent to browser
DEBUG - 2015-12-09 17:45:14 --> Total execution time: 0.0666
DEBUG - 2015-12-09 17:45:14 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:14 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:14 --> Router Class Initialized
ERROR - 2015-12-09 17:45:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:45:43 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:43 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Router Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Output Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Security Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Input Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:45:43 --> Language Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Loader Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:45:43 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Session Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:45:43 --> Session routines successfully run
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Controller Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:45:43 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:45:43 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:45:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:45:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:45:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:45:43 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:45:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-09 17:45:43 --> Final output sent to browser
DEBUG - 2015-12-09 17:45:43 --> Total execution time: 0.1021
DEBUG - 2015-12-09 17:45:43 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:43 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:43 --> Router Class Initialized
ERROR - 2015-12-09 17:45:43 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:45:54 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:54 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Router Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Output Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Security Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Input Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:45:54 --> Language Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Loader Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:45:54 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Session Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:45:54 --> Session routines successfully run
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Controller Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:45:54 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-09 17:45:54 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:54 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Router Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Output Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Security Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Input Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:45:54 --> Language Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Loader Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:45:54 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Session Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:45:54 --> Session routines successfully run
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Controller Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Model Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:45:54 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:45:54 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:45:54 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:45:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:45:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:45:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:45:54 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:45:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 17:45:54 --> Final output sent to browser
DEBUG - 2015-12-09 17:45:54 --> Total execution time: 0.0678
DEBUG - 2015-12-09 17:45:55 --> Config Class Initialized
DEBUG - 2015-12-09 17:45:55 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:45:55 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:45:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:45:55 --> URI Class Initialized
DEBUG - 2015-12-09 17:45:55 --> Router Class Initialized
ERROR - 2015-12-09 17:45:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:47:12 --> Config Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:47:12 --> URI Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Router Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Output Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Security Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Input Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:47:12 --> Language Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Loader Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:47:12 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Session Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:47:12 --> Session routines successfully run
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Controller Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:47:12 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:47:12 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:47:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:47:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:47:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:47:12 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-09 17:47:12 --> Severity: Notice  --> Undefined variable: agreement_type /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/invoiceView.php 52
ERROR - 2015-12-09 17:47:12 --> Severity: Notice  --> Undefined variable: agreement_type /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/invoiceView.php 54
DEBUG - 2015-12-09 17:47:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:47:12 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 17:47:12 --> Final output sent to browser
DEBUG - 2015-12-09 17:47:12 --> Total execution time: 0.0864
DEBUG - 2015-12-09 17:47:13 --> Config Class Initialized
DEBUG - 2015-12-09 17:47:13 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:47:13 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:47:13 --> URI Class Initialized
DEBUG - 2015-12-09 17:47:13 --> Router Class Initialized
ERROR - 2015-12-09 17:47:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-09 17:47:36 --> Config Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:47:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:47:36 --> URI Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Router Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Output Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Security Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Input Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-09 17:47:36 --> Language Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Loader Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Helper loaded: url_helper
DEBUG - 2015-12-09 17:47:36 --> Database Driver Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Session Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Helper loaded: string_helper
DEBUG - 2015-12-09 17:47:36 --> Session routines successfully run
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Controller Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Model Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Helper loaded: form_helper
DEBUG - 2015-12-09 17:47:36 --> Form Validation Class Initialized
DEBUG - 2015-12-09 17:47:36 --> Pagination Class Initialized
DEBUG - 2015-12-09 17:47:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-09 17:47:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-09 17:47:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-09 17:47:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-09 17:47:36 --> File loaded: application/views/footer.php
DEBUG - 2015-12-09 17:47:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-09 17:47:36 --> Final output sent to browser
DEBUG - 2015-12-09 17:47:36 --> Total execution time: 0.0656
DEBUG - 2015-12-09 17:47:37 --> Config Class Initialized
DEBUG - 2015-12-09 17:47:37 --> Hooks Class Initialized
DEBUG - 2015-12-09 17:47:37 --> Utf8 Class Initialized
DEBUG - 2015-12-09 17:47:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-09 17:47:37 --> URI Class Initialized
DEBUG - 2015-12-09 17:47:37 --> Router Class Initialized
ERROR - 2015-12-09 17:47:37 --> 404 Page Not Found --> js
