<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-23 10:17:03 --> Config Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:17:03 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:17:03 --> URI Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Router Class Initialized
DEBUG - 2015-10-23 10:17:03 --> No URI present. Default controller set.
DEBUG - 2015-10-23 10:17:03 --> Output Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Security Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Input Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:17:03 --> Language Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Loader Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:17:03 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Session Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:17:03 --> A session cookie was not found.
DEBUG - 2015-10-23 10:17:03 --> Session routines successfully run
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Controller Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Model Class Initialized
DEBUG - 2015-10-23 10:17:03 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:17:03 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:17:03 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-23 10:17:03 --> Final output sent to browser
DEBUG - 2015-10-23 10:17:03 --> Total execution time: 0.0758
DEBUG - 2015-10-23 10:17:04 --> Config Class Initialized
DEBUG - 2015-10-23 10:17:04 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:17:04 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:17:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:17:04 --> URI Class Initialized
DEBUG - 2015-10-23 10:17:04 --> Router Class Initialized
ERROR - 2015-10-23 10:17:04 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:18:33 --> Config Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:18:33 --> URI Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Router Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Output Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Security Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Input Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:18:33 --> Language Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Loader Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:18:33 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Session Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:18:33 --> Session routines successfully run
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Controller Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:18:33 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:18:33 --> Config Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:18:33 --> URI Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Router Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Output Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Security Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Input Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:18:33 --> Language Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Loader Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:18:33 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Session Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:18:33 --> Session routines successfully run
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Controller Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:33 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:34 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:18:34 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:18:34 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:18:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:18:34 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-10-23 10:18:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:18:34 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:18:34 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-23 10:18:34 --> Final output sent to browser
DEBUG - 2015-10-23 10:18:34 --> Total execution time: 0.0452
DEBUG - 2015-10-23 10:18:34 --> Config Class Initialized
DEBUG - 2015-10-23 10:18:34 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:18:34 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:18:34 --> URI Class Initialized
DEBUG - 2015-10-23 10:18:34 --> Router Class Initialized
ERROR - 2015-10-23 10:18:34 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:18:36 --> Config Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:18:36 --> URI Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Router Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Output Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Security Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Input Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:18:36 --> Language Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Loader Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:18:36 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Session Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:18:36 --> Session routines successfully run
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Controller Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:18:36 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:18:36 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:18:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:18:36 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-10-23 10:18:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:18:36 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:18:36 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-10-23 10:18:36 --> Final output sent to browser
DEBUG - 2015-10-23 10:18:36 --> Total execution time: 0.0992
DEBUG - 2015-10-23 10:18:36 --> Config Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:18:36 --> URI Class Initialized
DEBUG - 2015-10-23 10:18:36 --> Router Class Initialized
ERROR - 2015-10-23 10:18:36 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:19:28 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:28 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Router Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Output Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Security Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Input Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:19:28 --> Language Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Loader Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:19:28 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Session Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:19:28 --> Session routines successfully run
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Controller Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:19:28 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:28 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Router Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Output Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Security Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Input Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:19:28 --> Language Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Loader Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:19:28 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Session Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:19:28 --> Session routines successfully run
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Controller Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:19:28 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:19:28 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-23 10:19:28 --> Final output sent to browser
DEBUG - 2015-10-23 10:19:28 --> Total execution time: 0.0342
DEBUG - 2015-10-23 10:19:28 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:28 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:28 --> Router Class Initialized
ERROR - 2015-10-23 10:19:28 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:19:34 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:34 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Router Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Output Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Security Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Input Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:19:34 --> Language Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Loader Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:19:34 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Session Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:19:34 --> Session routines successfully run
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Controller Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:19:34 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:19:34 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:34 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Router Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Output Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Security Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Input Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:19:34 --> Language Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Loader Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:19:34 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Session Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:19:34 --> Session routines successfully run
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Controller Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:19:34 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:19:34 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:19:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:19:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:19:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:19:34 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:19:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-10-23 10:19:34 --> Final output sent to browser
DEBUG - 2015-10-23 10:19:34 --> Total execution time: 0.0437
DEBUG - 2015-10-23 10:19:34 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:34 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:34 --> Router Class Initialized
ERROR - 2015-10-23 10:19:34 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:19:37 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:37 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Router Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Output Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Security Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Input Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:19:37 --> Language Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Loader Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:19:37 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Session Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:19:37 --> Session routines successfully run
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Controller Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:19:37 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:19:37 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:19:38 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:19:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:19:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:19:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:19:38 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:19:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-23 10:19:38 --> Final output sent to browser
DEBUG - 2015-10-23 10:19:38 --> Total execution time: 0.1604
DEBUG - 2015-10-23 10:19:38 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:38 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:38 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:38 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:38 --> Router Class Initialized
ERROR - 2015-10-23 10:19:38 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:19:39 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:39 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Router Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Output Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Security Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Input Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:19:39 --> Language Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Loader Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:19:39 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Session Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:19:39 --> Session routines successfully run
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Controller Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Model Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:19:39 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:19:39 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:19:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:19:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:19:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:19:39 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:19:39 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-10-23 10:19:39 --> Final output sent to browser
DEBUG - 2015-10-23 10:19:39 --> Total execution time: 0.0683
DEBUG - 2015-10-23 10:19:39 --> Config Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:19:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:19:39 --> URI Class Initialized
DEBUG - 2015-10-23 10:19:39 --> Router Class Initialized
ERROR - 2015-10-23 10:19:39 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:20:09 --> Config Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:20:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:20:09 --> URI Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Router Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Output Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Security Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Input Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:20:09 --> Language Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Loader Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:20:09 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Session Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:20:09 --> Session routines successfully run
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Controller Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:09 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:20:09 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:20:10 --> Config Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:20:10 --> URI Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Router Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Output Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Security Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Input Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:20:10 --> Language Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Loader Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:20:10 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Session Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:20:10 --> Session routines successfully run
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Controller Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:20:10 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:20:10 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:20:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:20:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:20:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:20:10 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:20:10 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-23 10:20:10 --> Final output sent to browser
DEBUG - 2015-10-23 10:20:10 --> Total execution time: 0.0635
DEBUG - 2015-10-23 10:20:10 --> Config Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:20:10 --> URI Class Initialized
DEBUG - 2015-10-23 10:20:10 --> Router Class Initialized
ERROR - 2015-10-23 10:20:10 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:20:49 --> Config Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:20:49 --> URI Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Router Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Output Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Security Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Input Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:20:49 --> Language Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Loader Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:20:49 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Session Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:20:49 --> Session routines successfully run
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Controller Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Model Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:20:49 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:20:49 --> Helper loaded: pdf_helper
ERROR - 2015-10-23 10:20:49 --> Severity: Warning  --> fopen(file:///Applications/MAMP/htdocs/asmc/crm/pdf/receipts/admin/134.pdf): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/include/tcpdf_static.php 2440
DEBUG - 2015-10-23 10:22:24 --> Config Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:22:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:22:24 --> URI Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Router Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Output Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Security Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Input Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:22:24 --> Language Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Loader Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:22:24 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Session Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:22:24 --> Session routines successfully run
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Controller Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:24 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:25 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:25 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:22:25 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:22:25 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:22:25 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:22:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:22:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:22:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:22:25 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:22:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-23 10:22:25 --> Final output sent to browser
DEBUG - 2015-10-23 10:22:25 --> Total execution time: 0.1368
DEBUG - 2015-10-23 10:22:25 --> Config Class Initialized
DEBUG - 2015-10-23 10:22:25 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:22:25 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:22:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:22:25 --> URI Class Initialized
DEBUG - 2015-10-23 10:22:25 --> Router Class Initialized
ERROR - 2015-10-23 10:22:25 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:22:31 --> Config Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:22:31 --> URI Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Router Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Output Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Security Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Input Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:22:31 --> Language Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Loader Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:22:31 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Session Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:22:31 --> Session routines successfully run
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Controller Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Model Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:22:31 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:22:31 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:22:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:22:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:22:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:22:31 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:22:31 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-23 10:22:31 --> Final output sent to browser
DEBUG - 2015-10-23 10:22:31 --> Total execution time: 0.0883
DEBUG - 2015-10-23 10:22:31 --> Config Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:22:31 --> URI Class Initialized
DEBUG - 2015-10-23 10:22:31 --> Router Class Initialized
ERROR - 2015-10-23 10:22:31 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:28:56 --> Config Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:28:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:28:56 --> URI Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Router Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Output Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Security Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Input Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:28:56 --> Language Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Loader Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:28:56 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Session Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:28:56 --> Session routines successfully run
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Controller Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:28:56 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:28:56 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:28:56 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:28:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:28:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:28:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:28:56 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:28:56 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-23 10:28:56 --> Final output sent to browser
DEBUG - 2015-10-23 10:28:56 --> Total execution time: 0.0845
DEBUG - 2015-10-23 10:28:57 --> Config Class Initialized
DEBUG - 2015-10-23 10:28:57 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:28:57 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:28:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:28:57 --> URI Class Initialized
DEBUG - 2015-10-23 10:28:57 --> Router Class Initialized
ERROR - 2015-10-23 10:28:57 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:30:32 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:32 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Router Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Output Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Security Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Input Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:30:32 --> Language Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Loader Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:30:32 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Session Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:30:32 --> Session routines successfully run
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Controller Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:30:32 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:30:32 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:30:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:30:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:30:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:30:32 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:30:32 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-10-23 10:30:32 --> Final output sent to browser
DEBUG - 2015-10-23 10:30:32 --> Total execution time: 0.1181
DEBUG - 2015-10-23 10:30:32 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:32 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:32 --> Router Class Initialized
ERROR - 2015-10-23 10:30:32 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:30:47 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:47 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Router Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Output Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Security Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Input Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:30:47 --> Language Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Loader Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:30:47 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Session Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:30:47 --> Session routines successfully run
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Controller Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:30:47 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:30:47 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:47 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Router Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Output Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Security Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Input Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:30:47 --> Language Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Loader Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:30:47 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Session Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:30:47 --> Session routines successfully run
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Controller Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:30:47 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:30:47 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:30:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:30:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:30:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:30:47 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:30:47 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-23 10:30:47 --> Final output sent to browser
DEBUG - 2015-10-23 10:30:47 --> Total execution time: 0.0587
DEBUG - 2015-10-23 10:30:47 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:47 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:47 --> Router Class Initialized
ERROR - 2015-10-23 10:30:47 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:30:56 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:56 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Router Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Output Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Security Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Input Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:30:56 --> Language Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Loader Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:30:56 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Session Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:30:56 --> Session routines successfully run
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Controller Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Model Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:30:56 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:30:56 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:30:56 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:30:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:30:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:30:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:30:56 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:30:56 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-10-23 10:30:56 --> Final output sent to browser
DEBUG - 2015-10-23 10:30:56 --> Total execution time: 0.0672
DEBUG - 2015-10-23 10:30:57 --> Config Class Initialized
DEBUG - 2015-10-23 10:30:57 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:30:57 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:30:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:30:57 --> URI Class Initialized
DEBUG - 2015-10-23 10:30:57 --> Router Class Initialized
ERROR - 2015-10-23 10:30:57 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:31:14 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:14 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Router Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Output Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Security Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Input Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:31:14 --> Language Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Loader Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:31:14 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Session Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:31:14 --> Session routines successfully run
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Controller Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:31:14 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:31:14 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:31:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:31:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:31:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:31:14 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:31:14 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-10-23 10:31:14 --> Final output sent to browser
DEBUG - 2015-10-23 10:31:14 --> Total execution time: 0.0503
DEBUG - 2015-10-23 10:31:14 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:14 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:14 --> Router Class Initialized
ERROR - 2015-10-23 10:31:14 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:31:36 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:36 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Router Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Output Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Security Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Input Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:31:36 --> Language Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Loader Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:31:36 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Session Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:31:36 --> Session routines successfully run
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Controller Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:31:36 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:31:36 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:31:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:31:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:31:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:31:36 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:31:36 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-10-23 10:31:36 --> Final output sent to browser
DEBUG - 2015-10-23 10:31:36 --> Total execution time: 0.0547
DEBUG - 2015-10-23 10:31:36 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:36 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:36 --> Router Class Initialized
ERROR - 2015-10-23 10:31:36 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:31:53 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:53 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Router Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Output Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Security Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Input Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:31:53 --> Language Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Loader Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:31:53 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Session Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:31:53 --> Session routines successfully run
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Controller Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:31:53 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:31:53 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:53 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Router Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Output Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Security Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Input Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:31:53 --> Language Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Loader Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:31:53 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Session Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:31:53 --> Session routines successfully run
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Controller Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Model Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:31:53 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:31:53 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:31:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:31:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:31:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:31:53 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:31:53 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-23 10:31:53 --> Final output sent to browser
DEBUG - 2015-10-23 10:31:53 --> Total execution time: 0.0573
DEBUG - 2015-10-23 10:31:53 --> Config Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:31:53 --> URI Class Initialized
DEBUG - 2015-10-23 10:31:53 --> Router Class Initialized
ERROR - 2015-10-23 10:31:53 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:32:01 --> Config Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:32:01 --> URI Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Router Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Output Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Security Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Input Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:32:01 --> Language Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Loader Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:32:01 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Session Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:32:01 --> Session routines successfully run
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Controller Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:32:01 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:32:01 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:32:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:32:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:32:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:32:01 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:32:01 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-10-23 10:32:01 --> Final output sent to browser
DEBUG - 2015-10-23 10:32:01 --> Total execution time: 0.0675
DEBUG - 2015-10-23 10:32:01 --> Config Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:32:01 --> URI Class Initialized
DEBUG - 2015-10-23 10:32:01 --> Router Class Initialized
ERROR - 2015-10-23 10:32:01 --> 404 Page Not Found --> js
DEBUG - 2015-10-23 10:32:12 --> Config Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:32:12 --> URI Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Router Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Output Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Security Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Input Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:32:12 --> Language Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Loader Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:32:12 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Session Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:32:12 --> Session routines successfully run
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Controller Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:32:12 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-23 10:32:12 --> Config Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:32:12 --> URI Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Router Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Output Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Security Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Input Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-23 10:32:12 --> Language Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Loader Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Helper loaded: url_helper
DEBUG - 2015-10-23 10:32:12 --> Database Driver Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Session Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Helper loaded: string_helper
DEBUG - 2015-10-23 10:32:12 --> Session routines successfully run
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Controller Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Model Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Helper loaded: form_helper
DEBUG - 2015-10-23 10:32:12 --> Form Validation Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Pagination Class Initialized
DEBUG - 2015-10-23 10:32:12 --> File loaded: application/views/header.php
DEBUG - 2015-10-23 10:32:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-23 10:32:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-23 10:32:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-23 10:32:12 --> File loaded: application/views/footer.php
DEBUG - 2015-10-23 10:32:12 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-23 10:32:12 --> Final output sent to browser
DEBUG - 2015-10-23 10:32:12 --> Total execution time: 0.0569
DEBUG - 2015-10-23 10:32:12 --> Config Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Hooks Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Utf8 Class Initialized
DEBUG - 2015-10-23 10:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-23 10:32:12 --> URI Class Initialized
DEBUG - 2015-10-23 10:32:12 --> Router Class Initialized
ERROR - 2015-10-23 10:32:12 --> 404 Page Not Found --> js
