<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-05-25 09:45:25 --> Config Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:45:25 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:45:25 --> URI Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Router Class Initialized
DEBUG - 2015-05-25 09:45:25 --> No URI present. Default controller set.
DEBUG - 2015-05-25 09:45:25 --> Output Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Security Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Input Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:45:25 --> Language Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Loader Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:45:25 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Session Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:45:25 --> A session cookie was not found.
DEBUG - 2015-05-25 09:45:25 --> Session routines successfully run
DEBUG - 2015-05-25 09:45:25 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Controller Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:25 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:45:25 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:45:25 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-25 09:45:25 --> Final output sent to browser
DEBUG - 2015-05-25 09:45:25 --> Total execution time: 0.0663
DEBUG - 2015-05-25 09:45:53 --> Config Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:45:53 --> URI Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Router Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Output Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Security Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Input Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:45:53 --> Language Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Loader Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:45:53 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Session Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:45:53 --> Session routines successfully run
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Controller Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:45:53 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-25 09:45:53 --> Config Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:45:53 --> URI Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Router Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Output Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Security Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Input Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:45:53 --> Language Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Loader Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:45:53 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Session Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:45:53 --> Session routines successfully run
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Controller Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:53 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:45:53 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:45:53 --> File loaded: application/views/header.php
DEBUG - 2015-05-25 09:45:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-25 09:45:53 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-25 09:45:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-25 09:45:53 --> File loaded: application/views/footer.php
DEBUG - 2015-05-25 09:45:53 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-05-25 09:45:53 --> Final output sent to browser
DEBUG - 2015-05-25 09:45:53 --> Total execution time: 0.0397
DEBUG - 2015-05-25 09:45:55 --> Config Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:45:55 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:45:55 --> URI Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Router Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Output Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Security Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Input Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:45:55 --> Language Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Loader Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:45:55 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Session Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:45:55 --> Session routines successfully run
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Controller Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Model Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:45:55 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:45:55 --> Pagination Class Initialized
DEBUG - 2015-05-25 09:45:55 --> File loaded: application/views/header.php
DEBUG - 2015-05-25 09:45:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-25 09:45:55 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-25 09:45:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-25 09:45:55 --> File loaded: application/views/footer.php
DEBUG - 2015-05-25 09:45:55 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-25 09:45:55 --> Final output sent to browser
DEBUG - 2015-05-25 09:45:55 --> Total execution time: 0.0616
DEBUG - 2015-05-25 09:48:43 --> Config Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:48:43 --> URI Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Router Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Output Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Security Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Input Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:48:43 --> Language Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Loader Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:48:43 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Session Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:48:43 --> Session routines successfully run
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Controller Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Model Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:48:43 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:48:43 --> Pagination Class Initialized
DEBUG - 2015-05-25 09:48:43 --> File loaded: application/views/header.php
DEBUG - 2015-05-25 09:48:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-25 09:48:43 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-25 09:48:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-25 09:48:43 --> File loaded: application/views/footer.php
DEBUG - 2015-05-25 09:48:43 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-25 09:48:43 --> Final output sent to browser
DEBUG - 2015-05-25 09:48:43 --> Total execution time: 0.0510
DEBUG - 2015-05-25 09:49:05 --> Config Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:49:05 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:49:05 --> URI Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Router Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Output Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Security Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Input Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:49:05 --> Language Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Loader Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:49:05 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Session Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:49:05 --> Session routines successfully run
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Controller Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:49:05 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:49:05 --> Pagination Class Initialized
DEBUG - 2015-05-25 09:49:05 --> File loaded: application/views/header.php
DEBUG - 2015-05-25 09:49:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-25 09:49:05 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-25 09:49:05 --> File loaded: application/views/sidebar.php
ERROR - 2015-05-25 09:49:05 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/asmc/crm/application/views/commission/commissionListView.php 55
ERROR - 2015-05-25 09:49:05 --> Severity: Notice  --> Undefined offset: 1 /Applications/MAMP/htdocs/asmc/crm/application/views/commission/commissionListView.php 55
ERROR - 2015-05-25 09:49:05 --> Severity: Notice  --> Undefined offset: 2 /Applications/MAMP/htdocs/asmc/crm/application/views/commission/commissionListView.php 55
ERROR - 2015-05-25 09:49:05 --> Severity: Notice  --> Undefined offset: 0 /Applications/MAMP/htdocs/asmc/crm/application/views/commission/commissionListView.php 87
ERROR - 2015-05-25 09:49:05 --> Severity: Notice  --> Undefined offset: 1 /Applications/MAMP/htdocs/asmc/crm/application/views/commission/commissionListView.php 87
ERROR - 2015-05-25 09:49:05 --> Severity: Notice  --> Undefined offset: 2 /Applications/MAMP/htdocs/asmc/crm/application/views/commission/commissionListView.php 87
DEBUG - 2015-05-25 09:49:05 --> File loaded: application/views/footer.php
DEBUG - 2015-05-25 09:49:05 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-25 09:49:05 --> Final output sent to browser
DEBUG - 2015-05-25 09:49:05 --> Total execution time: 0.0531
DEBUG - 2015-05-25 09:49:21 --> Config Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Hooks Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Utf8 Class Initialized
DEBUG - 2015-05-25 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 09:49:21 --> URI Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Router Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Output Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Security Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Input Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 09:49:21 --> Language Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Loader Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Helper loaded: url_helper
DEBUG - 2015-05-25 09:49:21 --> Database Driver Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Session Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Helper loaded: string_helper
DEBUG - 2015-05-25 09:49:21 --> Session routines successfully run
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Controller Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Model Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Helper loaded: form_helper
DEBUG - 2015-05-25 09:49:21 --> Form Validation Class Initialized
DEBUG - 2015-05-25 09:49:21 --> Pagination Class Initialized
DEBUG - 2015-05-25 09:49:21 --> File loaded: application/views/header.php
DEBUG - 2015-05-25 09:49:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-25 09:49:21 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-25 09:49:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-25 09:49:21 --> File loaded: application/views/footer.php
DEBUG - 2015-05-25 09:49:21 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-25 09:49:21 --> Final output sent to browser
DEBUG - 2015-05-25 09:49:21 --> Total execution time: 0.0558
DEBUG - 2015-05-25 19:16:04 --> Config Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Hooks Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Utf8 Class Initialized
DEBUG - 2015-05-25 19:16:04 --> UTF-8 Support Enabled
DEBUG - 2015-05-25 19:16:04 --> URI Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Router Class Initialized
DEBUG - 2015-05-25 19:16:04 --> No URI present. Default controller set.
DEBUG - 2015-05-25 19:16:04 --> Output Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Security Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Input Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-25 19:16:04 --> Language Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Loader Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Helper loaded: url_helper
DEBUG - 2015-05-25 19:16:04 --> Database Driver Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Session Class Initialized
DEBUG - 2015-05-25 19:16:04 --> Helper loaded: string_helper
DEBUG - 2015-05-25 19:16:04 --> A session cookie was not found.
DEBUG - 2015-05-25 19:16:04 --> Session routines successfully run
DEBUG - 2015-05-25 19:16:04 --> Model Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Model Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Controller Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Model Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Model Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Model Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Model Class Initialized
DEBUG - 2015-05-25 19:16:05 --> Helper loaded: form_helper
DEBUG - 2015-05-25 19:16:05 --> Form Validation Class Initialized
DEBUG - 2015-05-25 19:16:05 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-25 19:16:05 --> Final output sent to browser
DEBUG - 2015-05-25 19:16:05 --> Total execution time: 0.0986
