<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-27 16:04:48 --> Config Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:04:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:04:48 --> URI Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Router Class Initialized
DEBUG - 2015-04-27 16:04:48 --> No URI present. Default controller set.
DEBUG - 2015-04-27 16:04:48 --> Output Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Security Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Input Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:04:48 --> Language Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Loader Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:04:48 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Session Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:04:48 --> A session cookie was not found.
DEBUG - 2015-04-27 16:04:48 --> Session routines successfully run
DEBUG - 2015-04-27 16:04:48 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Controller Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:48 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:04:48 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:04:48 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:04:48 --> Final output sent to browser
DEBUG - 2015-04-27 16:04:48 --> Total execution time: 0.0691
DEBUG - 2015-04-27 16:04:56 --> Config Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:04:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:04:56 --> URI Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Router Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Output Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Security Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Input Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:04:56 --> Language Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Loader Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:04:56 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Session Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:04:56 --> Session routines successfully run
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Controller Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:04:56 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:04:56 --> Config Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:04:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:04:56 --> URI Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Router Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Output Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Security Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Input Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:04:56 --> Language Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Loader Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:04:56 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Session Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:04:56 --> Session routines successfully run
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Controller Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Model Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:04:56 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:04:56 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:04:56 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:04:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:04:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:04:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:04:56 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:04:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-27 16:04:56 --> Final output sent to browser
DEBUG - 2015-04-27 16:04:56 --> Total execution time: 0.0405
DEBUG - 2015-04-27 16:05:04 --> Config Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:05:04 --> URI Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Router Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Output Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Security Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Input Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:05:04 --> Language Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Loader Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:05:04 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Session Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:05:04 --> Session routines successfully run
DEBUG - 2015-04-27 16:05:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Controller Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:05:04 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:05:04 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:05:04 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:05:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:05:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:05:04 --> File loaded: application/views/sidebar.php
ERROR - 2015-04-27 16:05:04 --> Severity: Notice  --> Undefined variable: customer_username /Applications/MAMP/htdocs/asmc/crm/application/views/customer/addCustomerView.php 58
DEBUG - 2015-04-27 16:05:04 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:05:04 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-27 16:05:04 --> Final output sent to browser
DEBUG - 2015-04-27 16:05:04 --> Total execution time: 0.0526
DEBUG - 2015-04-27 16:05:32 --> Config Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:05:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:05:32 --> URI Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Router Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Output Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Security Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Input Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:05:32 --> Language Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Loader Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:05:32 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Session Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:05:32 --> Session routines successfully run
DEBUG - 2015-04-27 16:05:32 --> Model Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Model Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Controller Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Model Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:05:32 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:05:32 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:05:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:05:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:05:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:05:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:05:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:05:32 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-27 16:05:32 --> Final output sent to browser
DEBUG - 2015-04-27 16:05:32 --> Total execution time: 0.0436
DEBUG - 2015-04-27 16:06:07 --> Config Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:06:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:06:07 --> URI Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Router Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Output Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Security Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Input Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:06:07 --> Language Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Loader Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:06:07 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Session Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:06:07 --> Session routines successfully run
DEBUG - 2015-04-27 16:06:07 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Controller Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:06:07 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:06:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:06:07 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:06:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:06:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:06:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:06:07 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:06:07 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-27 16:06:07 --> Final output sent to browser
DEBUG - 2015-04-27 16:06:07 --> Total execution time: 0.0460
DEBUG - 2015-04-27 16:06:16 --> Config Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:06:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:06:16 --> URI Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Router Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Output Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Security Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Input Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:06:16 --> Language Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Loader Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:06:16 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Session Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:06:16 --> Session routines successfully run
DEBUG - 2015-04-27 16:06:16 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Controller Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:06:16 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:06:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:06:16 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:06:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:06:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:06:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:06:16 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:06:16 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-27 16:06:16 --> Final output sent to browser
DEBUG - 2015-04-27 16:06:16 --> Total execution time: 0.0433
DEBUG - 2015-04-27 16:06:21 --> Config Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:06:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:06:21 --> URI Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Router Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Output Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Security Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Input Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:06:21 --> Language Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Loader Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:06:21 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Session Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:06:21 --> Session routines successfully run
DEBUG - 2015-04-27 16:06:21 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Controller Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:06:21 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:06:21 --> Config Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:06:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:06:21 --> URI Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Router Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Output Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Security Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Input Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:06:21 --> Language Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Loader Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:06:21 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Session Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:06:21 --> Session routines successfully run
DEBUG - 2015-04-27 16:06:21 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Controller Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:06:21 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:06:21 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:06:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:06:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:06:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:06:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:06:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:06:21 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-27 16:06:21 --> Final output sent to browser
DEBUG - 2015-04-27 16:06:21 --> Total execution time: 0.0404
DEBUG - 2015-04-27 16:06:30 --> Config Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:06:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:06:30 --> URI Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Router Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Output Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Security Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Input Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:06:30 --> Language Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Loader Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:06:30 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Session Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:06:30 --> Session routines successfully run
DEBUG - 2015-04-27 16:06:30 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Controller Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:06:30 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:06:30 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:06:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:06:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:06:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:06:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:06:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:06:30 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:06:30 --> Final output sent to browser
DEBUG - 2015-04-27 16:06:30 --> Total execution time: 0.0505
DEBUG - 2015-04-27 16:06:36 --> Config Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:06:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:06:36 --> URI Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Router Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Output Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Security Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Input Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:06:36 --> Language Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Loader Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:06:36 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Session Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:06:36 --> Session routines successfully run
DEBUG - 2015-04-27 16:06:36 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Controller Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Model Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:06:36 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:06:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-04-27 16:06:36 --> Severity: Notice  --> Undefined index: customer_username /Applications/MAMP/htdocs/asmc/crm/application/controllers/customer.php 200
ERROR - 2015-04-27 16:06:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-27 16:06:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:06:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:06:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:06:36 --> File loaded: application/views/sidebar.php
ERROR - 2015-04-27 16:06:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-27 16:06:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:06:36 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:06:36 --> Final output sent to browser
DEBUG - 2015-04-27 16:06:36 --> Total execution time: 0.0465
DEBUG - 2015-04-27 16:07:55 --> Config Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:07:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:07:55 --> URI Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Router Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Output Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Security Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Input Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:07:55 --> Language Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Loader Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:07:55 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Session Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:07:55 --> Session routines successfully run
DEBUG - 2015-04-27 16:07:55 --> Model Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Model Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Controller Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Model Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:07:55 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:07:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:07:55 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:07:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:07:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:07:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:07:55 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:07:55 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:07:55 --> Final output sent to browser
DEBUG - 2015-04-27 16:07:55 --> Total execution time: 0.0447
DEBUG - 2015-04-27 16:08:00 --> Config Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:08:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:08:00 --> URI Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Router Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Output Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Security Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Input Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:08:00 --> Language Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Loader Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:08:00 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Session Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:08:00 --> Session routines successfully run
DEBUG - 2015-04-27 16:08:00 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Controller Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:08:00 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:08:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:08:00 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:08:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:08:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:08:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:08:00 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:08:00 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:08:00 --> Final output sent to browser
DEBUG - 2015-04-27 16:08:00 --> Total execution time: 0.0432
DEBUG - 2015-04-27 16:08:26 --> Config Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:08:26 --> URI Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Router Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Output Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Security Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Input Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:08:26 --> Language Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Loader Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:08:26 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Session Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:08:26 --> Session routines successfully run
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Controller Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:08:26 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Config Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:08:26 --> URI Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Router Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Output Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Security Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Input Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:08:26 --> Language Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Loader Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:08:26 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Session Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:08:26 --> Session routines successfully run
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Controller Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:26 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:08:26 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:08:26 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:08:26 --> Final output sent to browser
DEBUG - 2015-04-27 16:08:26 --> Total execution time: 0.0435
DEBUG - 2015-04-27 16:08:35 --> Config Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:08:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:08:35 --> URI Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Router Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Output Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Security Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Input Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:08:35 --> Language Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Loader Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:08:35 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Session Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:08:35 --> Session routines successfully run
DEBUG - 2015-04-27 16:08:35 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Controller Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:08:35 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:08:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:08:35 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:08:35 --> Final output sent to browser
DEBUG - 2015-04-27 16:08:35 --> Total execution time: 0.0312
DEBUG - 2015-04-27 16:08:41 --> Config Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:08:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:08:41 --> URI Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Router Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Output Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Security Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Input Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:08:41 --> Language Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Loader Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:08:41 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Session Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:08:41 --> Session routines successfully run
DEBUG - 2015-04-27 16:08:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Controller Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:08:41 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:08:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:08:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:08:41 --> Final output sent to browser
DEBUG - 2015-04-27 16:08:41 --> Total execution time: 0.0318
DEBUG - 2015-04-27 16:09:23 --> Config Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:09:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:09:23 --> URI Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Router Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Output Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Security Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Input Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:09:23 --> Language Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Loader Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:09:23 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Session Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:09:23 --> Session routines successfully run
DEBUG - 2015-04-27 16:09:23 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Controller Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:09:23 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:09:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:09:23 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:09:23 --> Final output sent to browser
DEBUG - 2015-04-27 16:09:23 --> Total execution time: 0.0324
DEBUG - 2015-04-27 16:09:33 --> Config Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:09:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:09:33 --> URI Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Router Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Output Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Security Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Input Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:09:33 --> Language Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Loader Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:09:33 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Session Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:09:33 --> Session routines successfully run
DEBUG - 2015-04-27 16:09:33 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Controller Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:09:33 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:09:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:09:33 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:09:33 --> Final output sent to browser
DEBUG - 2015-04-27 16:09:33 --> Total execution time: 0.0338
DEBUG - 2015-04-27 16:09:37 --> Config Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:09:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:09:37 --> URI Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Router Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Output Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Security Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Input Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:09:37 --> Language Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Loader Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:09:37 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Session Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:09:37 --> Session routines successfully run
DEBUG - 2015-04-27 16:09:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Controller Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:09:37 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:09:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:09:37 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:09:37 --> Final output sent to browser
DEBUG - 2015-04-27 16:09:37 --> Total execution time: 0.0314
DEBUG - 2015-04-27 16:09:45 --> Config Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:09:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:09:45 --> URI Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Router Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Output Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Security Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Input Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:09:45 --> Language Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Loader Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:09:45 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Session Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:09:45 --> Session routines successfully run
DEBUG - 2015-04-27 16:09:45 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Controller Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Model Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:09:45 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:09:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:09:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:09:45 --> Final output sent to browser
DEBUG - 2015-04-27 16:09:45 --> Total execution time: 0.0356
DEBUG - 2015-04-27 16:10:06 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:06 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:06 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:06 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:06 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:06 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:06 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:10:12 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:12 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:12 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:12 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:12 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:12 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:10:12 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:12 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:12 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:12 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:12 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:12 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:12 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:10:12 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:10:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:10:12 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-27 16:10:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:10:12 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:10:12 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-27 16:10:12 --> Final output sent to browser
DEBUG - 2015-04-27 16:10:12 --> Total execution time: 0.0397
DEBUG - 2015-04-27 16:10:36 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:36 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:36 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:36 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:36 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:36 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:36 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:36 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:10:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:10:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:10:36 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-27 16:10:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:10:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:10:36 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-27 16:10:36 --> Final output sent to browser
DEBUG - 2015-04-27 16:10:36 --> Total execution time: 0.0359
DEBUG - 2015-04-27 16:10:49 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:49 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:49 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:49 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:49 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:49 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:49 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:49 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:49 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:49 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:49 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:49 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:49 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:10:49 --> Final output sent to browser
DEBUG - 2015-04-27 16:10:49 --> Total execution time: 0.0336
DEBUG - 2015-04-27 16:10:59 --> Config Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:10:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:10:59 --> URI Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Router Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Output Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Security Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Input Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:10:59 --> Language Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Loader Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:10:59 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Session Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:10:59 --> Session routines successfully run
DEBUG - 2015-04-27 16:10:59 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Controller Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Model Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:10:59 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:10:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:10:59 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-27 16:10:59 --> Final output sent to browser
DEBUG - 2015-04-27 16:10:59 --> Total execution time: 0.0377
DEBUG - 2015-04-27 16:11:04 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:04 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:04 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:04 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:04 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:04 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:11:04 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:04 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:04 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:04 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:04 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:04 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:04 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:04 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:04 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:04 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-27 16:11:04 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:04 --> Total execution time: 0.0419
DEBUG - 2015-04-27 16:11:07 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:07 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:07 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:07 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:07 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:07 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:07 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:07 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:07 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:07 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:07 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:07 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-27 16:11:07 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:07 --> Total execution time: 0.0467
DEBUG - 2015-04-27 16:11:10 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:10 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:10 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:10 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:10 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:10 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:10 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:10 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:10 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:10 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:10 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:10 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:11:10 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:10 --> Total execution time: 0.0497
DEBUG - 2015-04-27 16:11:28 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:28 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:28 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:28 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:28 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:28 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:28 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:28 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:28 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:28 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:28 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:11:28 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:28 --> Total execution time: 0.0417
DEBUG - 2015-04-27 16:11:30 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:30 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:30 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:30 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:30 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:30 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:30 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:30 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:30 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-27 16:11:30 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:30 --> Total execution time: 0.0529
DEBUG - 2015-04-27 16:11:37 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:37 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:37 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:37 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:37 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:37 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:37 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:37 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:37 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:37 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:11:37 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:37 --> Total execution time: 0.0437
DEBUG - 2015-04-27 16:11:41 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:41 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:41 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:41 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:41 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:41 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-27 16:11:41 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:41 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:41 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2015-04-27 16:11:41 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:41 --> Total execution time: 0.0471
DEBUG - 2015-04-27 16:11:47 --> Config Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Hooks Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Utf8 Class Initialized
DEBUG - 2015-04-27 16:11:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 16:11:47 --> URI Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Router Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Output Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Security Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Input Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 16:11:47 --> Language Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Loader Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Helper loaded: url_helper
DEBUG - 2015-04-27 16:11:47 --> Database Driver Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Session Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Helper loaded: string_helper
DEBUG - 2015-04-27 16:11:47 --> Session routines successfully run
DEBUG - 2015-04-27 16:11:47 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Controller Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Model Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Helper loaded: form_helper
DEBUG - 2015-04-27 16:11:47 --> Form Validation Class Initialized
DEBUG - 2015-04-27 16:11:47 --> Pagination Class Initialized
DEBUG - 2015-04-27 16:11:47 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 16:11:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 16:11:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 16:11:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 16:11:47 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 16:11:47 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-27 16:11:47 --> Final output sent to browser
DEBUG - 2015-04-27 16:11:47 --> Total execution time: 0.0537
DEBUG - 2015-04-27 17:44:08 --> Config Class Initialized
DEBUG - 2015-04-27 17:44:08 --> Hooks Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Utf8 Class Initialized
DEBUG - 2015-04-27 17:44:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-27 17:44:09 --> URI Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Router Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Output Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Security Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Input Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-27 17:44:09 --> Language Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Loader Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Helper loaded: url_helper
DEBUG - 2015-04-27 17:44:09 --> Database Driver Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Session Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Helper loaded: string_helper
DEBUG - 2015-04-27 17:44:09 --> Session routines successfully run
DEBUG - 2015-04-27 17:44:09 --> Model Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Model Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Controller Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Model Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Helper loaded: form_helper
DEBUG - 2015-04-27 17:44:09 --> Form Validation Class Initialized
DEBUG - 2015-04-27 17:44:09 --> Pagination Class Initialized
DEBUG - 2015-04-27 17:44:09 --> File loaded: application/views/header.php
DEBUG - 2015-04-27 17:44:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-27 17:44:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-27 17:44:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-27 17:44:09 --> File loaded: application/views/footer.php
DEBUG - 2015-04-27 17:44:09 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-27 17:44:09 --> Final output sent to browser
DEBUG - 2015-04-27 17:44:09 --> Total execution time: 0.0669
