<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-17 15:44:11 --> Config Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Hooks Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Utf8 Class Initialized
DEBUG - 2015-12-17 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 15:44:11 --> URI Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Router Class Initialized
DEBUG - 2015-12-17 15:44:11 --> No URI present. Default controller set.
DEBUG - 2015-12-17 15:44:11 --> Output Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Security Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Input Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 15:44:11 --> Language Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Loader Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Helper loaded: url_helper
DEBUG - 2015-12-17 15:44:11 --> Database Driver Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Session Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Helper loaded: string_helper
DEBUG - 2015-12-17 15:44:11 --> A session cookie was not found.
DEBUG - 2015-12-17 15:44:11 --> Session routines successfully run
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Controller Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Model Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Helper loaded: form_helper
DEBUG - 2015-12-17 15:44:11 --> Form Validation Class Initialized
DEBUG - 2015-12-17 15:44:11 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-17 15:44:11 --> Final output sent to browser
DEBUG - 2015-12-17 15:44:11 --> Total execution time: 0.0984
DEBUG - 2015-12-17 15:44:11 --> Config Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Hooks Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Utf8 Class Initialized
DEBUG - 2015-12-17 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 15:44:11 --> URI Class Initialized
DEBUG - 2015-12-17 15:44:11 --> Router Class Initialized
ERROR - 2015-12-17 15:44:11 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:51:56 --> Config Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:51:56 --> URI Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Router Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Output Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Security Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Input Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:51:56 --> Language Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Loader Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:51:56 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Session Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:51:56 --> Session routines successfully run
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Controller Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:51:56 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 16:51:56 --> Config Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:51:56 --> URI Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Router Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Output Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Security Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Input Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:51:56 --> Language Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Loader Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:51:56 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Session Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:51:56 --> Session routines successfully run
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Controller Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Model Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:51:56 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:51:56 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:51:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:51:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:51:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:51:56 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:51:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-17 16:51:56 --> Final output sent to browser
DEBUG - 2015-12-17 16:51:56 --> Total execution time: 0.0489
DEBUG - 2015-12-17 16:51:56 --> Config Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:51:56 --> URI Class Initialized
DEBUG - 2015-12-17 16:51:56 --> Router Class Initialized
ERROR - 2015-12-17 16:51:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:52:00 --> Config Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:52:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:52:00 --> URI Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Router Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Output Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Security Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Input Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:52:00 --> Language Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Loader Class Initialized
DEBUG - 2015-12-17 16:52:00 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:52:01 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Session Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:52:01 --> Session routines successfully run
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Controller Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:52:01 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:01 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:52:01 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 16:52:01 --> Final output sent to browser
DEBUG - 2015-12-17 16:52:01 --> Total execution time: 0.0702
DEBUG - 2015-12-17 16:52:01 --> Config Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:52:01 --> URI Class Initialized
DEBUG - 2015-12-17 16:52:01 --> Router Class Initialized
ERROR - 2015-12-17 16:52:01 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:52:03 --> Config Class Initialized
DEBUG - 2015-12-17 16:52:03 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:52:03 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:52:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:52:03 --> URI Class Initialized
DEBUG - 2015-12-17 16:52:03 --> Router Class Initialized
ERROR - 2015-12-17 16:52:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:52:05 --> Config Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:52:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:52:05 --> URI Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Router Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Output Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Security Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Input Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:52:05 --> Language Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Loader Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:52:05 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Session Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:52:05 --> Session routines successfully run
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Controller Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:52:05 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:05 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:52:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:52:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:52:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:52:05 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:52:05 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 16:52:05 --> Final output sent to browser
DEBUG - 2015-12-17 16:52:05 --> Total execution time: 0.0849
DEBUG - 2015-12-17 16:52:06 --> Config Class Initialized
DEBUG - 2015-12-17 16:52:06 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:52:06 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:52:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:52:06 --> URI Class Initialized
DEBUG - 2015-12-17 16:52:06 --> Router Class Initialized
ERROR - 2015-12-17 16:52:06 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:52:11 --> Config Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:52:11 --> URI Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Router Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Output Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Security Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Input Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:52:11 --> Language Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Loader Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:52:11 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Session Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:52:11 --> Session routines successfully run
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Controller Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:52:11 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
DEBUG - 2015-12-17 16:52:11 --> Model Class Initialized
ERROR - 2015-12-17 16:52:11 --> 404 Page Not Found --> form/deleteRecord
DEBUG - 2015-12-17 16:54:09 --> Config Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:54:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:54:09 --> URI Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Router Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Output Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Security Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Input Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:54:09 --> Language Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Loader Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:54:09 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Session Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:54:09 --> Session routines successfully run
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Controller Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:54:09 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Config Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:54:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:54:09 --> URI Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Router Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Output Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Security Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Input Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:54:09 --> Language Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Loader Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:54:09 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Session Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:54:09 --> Session routines successfully run
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Controller Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:54:09 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:09 --> Model Class Initialized
ERROR - 2015-12-17 16:54:09 --> 404 Page Not Found --> form/viewRecord
DEBUG - 2015-12-17 16:54:14 --> Config Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:54:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:54:14 --> URI Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Router Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Output Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Security Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Input Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:54:14 --> Language Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Loader Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:54:14 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Session Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:54:14 --> Session routines successfully run
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Controller Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:54:14 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:14 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:54:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:54:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:54:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:54:14 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:54:14 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 16:54:14 --> Final output sent to browser
DEBUG - 2015-12-17 16:54:14 --> Total execution time: 0.0566
DEBUG - 2015-12-17 16:54:14 --> Config Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:54:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:54:14 --> URI Class Initialized
DEBUG - 2015-12-17 16:54:14 --> Router Class Initialized
ERROR - 2015-12-17 16:54:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:54:55 --> Config Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:54:55 --> URI Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Router Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Output Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Security Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Input Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:54:55 --> Language Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Loader Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:54:55 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Session Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:54:55 --> Session routines successfully run
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Controller Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:54:55 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:54:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:54:55 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 16:54:55 --> Final output sent to browser
DEBUG - 2015-12-17 16:54:55 --> Total execution time: 0.0989
DEBUG - 2015-12-17 16:54:55 --> Config Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:54:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:54:55 --> URI Class Initialized
DEBUG - 2015-12-17 16:54:55 --> Router Class Initialized
ERROR - 2015-12-17 16:54:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:55:49 --> Config Class Initialized
DEBUG - 2015-12-17 16:55:49 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:55:49 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:55:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:55:49 --> URI Class Initialized
DEBUG - 2015-12-17 16:55:49 --> Router Class Initialized
ERROR - 2015-12-17 16:55:49 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:55:51 --> Config Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:55:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:55:51 --> URI Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Router Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Output Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Security Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Input Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:55:51 --> Language Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Loader Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:55:51 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Session Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:55:51 --> Session routines successfully run
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Controller Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:55:51 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:55:51 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:55:51 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:55:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:55:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:55:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:55:51 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:55:51 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-17 16:55:51 --> Final output sent to browser
DEBUG - 2015-12-17 16:55:51 --> Total execution time: 0.3043
DEBUG - 2015-12-17 16:55:52 --> Config Class Initialized
DEBUG - 2015-12-17 16:55:52 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:55:52 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:55:52 --> URI Class Initialized
DEBUG - 2015-12-17 16:55:52 --> Router Class Initialized
ERROR - 2015-12-17 16:55:52 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:55:53 --> Config Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:55:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:55:53 --> URI Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Router Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Output Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Security Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Input Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:55:53 --> Language Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Loader Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:55:53 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Session Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:55:53 --> Session routines successfully run
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Controller Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Model Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:55:53 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:55:53 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:55:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:55:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:55:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:55:53 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:55:53 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 16:55:53 --> Final output sent to browser
DEBUG - 2015-12-17 16:55:53 --> Total execution time: 0.0754
DEBUG - 2015-12-17 16:55:53 --> Config Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:55:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:55:53 --> URI Class Initialized
DEBUG - 2015-12-17 16:55:53 --> Router Class Initialized
ERROR - 2015-12-17 16:55:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:56:27 --> Config Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:56:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:56:27 --> URI Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Router Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Output Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Security Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Input Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:56:27 --> Language Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Loader Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:56:27 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Session Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:56:27 --> Session routines successfully run
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Controller Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:27 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Model Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:56:28 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:56:28 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:56:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:56:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:56:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:56:28 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:56:28 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 16:56:28 --> Final output sent to browser
DEBUG - 2015-12-17 16:56:28 --> Total execution time: 0.0920
DEBUG - 2015-12-17 16:56:28 --> Config Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:56:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:56:28 --> URI Class Initialized
DEBUG - 2015-12-17 16:56:28 --> Router Class Initialized
ERROR - 2015-12-17 16:56:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:57:15 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:15 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Router Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Output Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Security Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Input Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:57:15 --> Language Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Loader Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:57:15 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Session Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:57:15 --> Session routines successfully run
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Controller Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:57:15 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:57:15 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:57:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:57:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:57:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:57:15 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:57:15 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 16:57:15 --> Final output sent to browser
DEBUG - 2015-12-17 16:57:15 --> Total execution time: 0.0934
DEBUG - 2015-12-17 16:57:15 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:15 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:15 --> Router Class Initialized
ERROR - 2015-12-17 16:57:15 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:57:25 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:25 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Router Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Output Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Security Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Input Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:57:25 --> Language Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Loader Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:57:25 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Session Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:57:25 --> Session routines successfully run
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Controller Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:57:25 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:25 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:57:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:57:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:57:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:57:25 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:57:25 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 16:57:25 --> Final output sent to browser
DEBUG - 2015-12-17 16:57:25 --> Total execution time: 0.0531
DEBUG - 2015-12-17 16:57:25 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:25 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:25 --> Router Class Initialized
ERROR - 2015-12-17 16:57:25 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:57:29 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:29 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Router Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Output Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Security Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Input Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:57:29 --> Language Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Loader Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:57:29 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Session Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:57:29 --> Session routines successfully run
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Controller Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:57:29 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:57:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:57:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:57:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:57:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:57:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:57:29 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 16:57:29 --> Final output sent to browser
DEBUG - 2015-12-17 16:57:29 --> Total execution time: 0.0618
DEBUG - 2015-12-17 16:57:29 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:29 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:29 --> Router Class Initialized
ERROR - 2015-12-17 16:57:29 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:57:37 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:37 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Router Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Output Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Security Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Input Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:57:37 --> Language Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Loader Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:57:37 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Session Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:57:37 --> Session routines successfully run
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Controller Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:57:37 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 16:57:37 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:57:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:57:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:57:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:57:37 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:57:37 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 16:57:37 --> Final output sent to browser
DEBUG - 2015-12-17 16:57:37 --> Total execution time: 0.0711
DEBUG - 2015-12-17 16:57:37 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:37 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:37 --> Router Class Initialized
ERROR - 2015-12-17 16:57:37 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:57:54 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:55 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Router Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Output Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Security Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Input Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:57:55 --> Language Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Loader Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:57:55 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Session Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:57:55 --> Session routines successfully run
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Controller Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:57:55 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:57:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 16:57:55 --> Helper loaded: pdf_helper
DEBUG - 2015-12-17 16:57:55 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-17 16:57:57 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-17 16:57:58 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-17 16:57:59 --> Config Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:57:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:57:59 --> URI Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Router Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Output Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Security Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Input Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:57:59 --> Language Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Loader Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:57:59 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Session Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:57:59 --> Session routines successfully run
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Controller Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Model Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:57:59 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:57:59 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:57:59 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-17 16:57:59 --> Final output sent to browser
DEBUG - 2015-12-17 16:57:59 --> Total execution time: 0.0682
DEBUG - 2015-12-17 16:58:00 --> Config Class Initialized
DEBUG - 2015-12-17 16:58:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:58:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:58:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:58:00 --> URI Class Initialized
DEBUG - 2015-12-17 16:58:00 --> Router Class Initialized
ERROR - 2015-12-17 16:58:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:58:12 --> Config Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:58:12 --> URI Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Router Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Output Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Security Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Input Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:58:12 --> Language Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Loader Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:58:12 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Session Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:58:12 --> Session routines successfully run
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Controller Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Model Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:58:12 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:58:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:58:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:58:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:58:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:58:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:58:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-17 16:58:12 --> Final output sent to browser
DEBUG - 2015-12-17 16:58:12 --> Total execution time: 0.1426
DEBUG - 2015-12-17 16:58:12 --> Config Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:58:12 --> URI Class Initialized
DEBUG - 2015-12-17 16:58:12 --> Router Class Initialized
ERROR - 2015-12-17 16:58:12 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:59:06 --> Config Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:59:06 --> URI Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Router Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Output Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Security Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Input Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:59:06 --> Language Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Loader Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:59:06 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Session Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:59:06 --> Session routines successfully run
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Controller Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:59:06 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:06 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:59:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:59:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:59:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:59:06 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:59:06 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 16:59:06 --> Final output sent to browser
DEBUG - 2015-12-17 16:59:06 --> Total execution time: 0.1001
DEBUG - 2015-12-17 16:59:07 --> Config Class Initialized
DEBUG - 2015-12-17 16:59:07 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:59:07 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:59:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:59:07 --> URI Class Initialized
DEBUG - 2015-12-17 16:59:07 --> Router Class Initialized
ERROR - 2015-12-17 16:59:07 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 16:59:09 --> Config Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:59:09 --> URI Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Router Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Output Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Security Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Input Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 16:59:09 --> Language Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Loader Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Helper loaded: url_helper
DEBUG - 2015-12-17 16:59:09 --> Database Driver Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Session Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Helper loaded: string_helper
DEBUG - 2015-12-17 16:59:09 --> Session routines successfully run
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Controller Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Model Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Helper loaded: form_helper
DEBUG - 2015-12-17 16:59:09 --> Form Validation Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Pagination Class Initialized
DEBUG - 2015-12-17 16:59:09 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 16:59:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 16:59:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 16:59:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 16:59:09 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 16:59:09 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 16:59:09 --> Final output sent to browser
DEBUG - 2015-12-17 16:59:09 --> Total execution time: 0.0648
DEBUG - 2015-12-17 16:59:09 --> Config Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Hooks Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Utf8 Class Initialized
DEBUG - 2015-12-17 16:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 16:59:09 --> URI Class Initialized
DEBUG - 2015-12-17 16:59:09 --> Router Class Initialized
ERROR - 2015-12-17 16:59:09 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:00:35 --> Config Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:00:35 --> URI Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Router Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Output Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Security Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Input Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:00:35 --> Language Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Loader Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:00:35 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Session Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:00:35 --> Session routines successfully run
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Controller Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:00:35 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:00:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:00:35 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:00:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:00:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:00:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:00:35 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:00:35 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 17:00:35 --> Final output sent to browser
DEBUG - 2015-12-17 17:00:35 --> Total execution time: 0.0916
DEBUG - 2015-12-17 17:00:36 --> Config Class Initialized
DEBUG - 2015-12-17 17:00:36 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:00:36 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:00:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:00:36 --> URI Class Initialized
DEBUG - 2015-12-17 17:00:36 --> Router Class Initialized
ERROR - 2015-12-17 17:00:36 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:00:48 --> Config Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:00:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:00:48 --> URI Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Router Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Output Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Security Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Input Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:00:48 --> Language Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Loader Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:00:48 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Session Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:00:48 --> Session routines successfully run
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Controller Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:00:48 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:00:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:00:48 --> Helper loaded: pdf_helper
DEBUG - 2015-12-17 17:00:48 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-17 17:00:50 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-17 17:00:51 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-17 17:00:52 --> Config Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:00:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:00:52 --> URI Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Router Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Output Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Security Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Input Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:00:52 --> Language Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Loader Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:00:52 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Session Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:00:52 --> Session routines successfully run
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Controller Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Model Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:00:52 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:00:52 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:00:52 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-17 17:00:52 --> Final output sent to browser
DEBUG - 2015-12-17 17:00:52 --> Total execution time: 0.0644
DEBUG - 2015-12-17 17:00:53 --> Config Class Initialized
DEBUG - 2015-12-17 17:00:53 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:00:53 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:00:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:00:53 --> URI Class Initialized
DEBUG - 2015-12-17 17:00:53 --> Router Class Initialized
ERROR - 2015-12-17 17:00:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:02:03 --> Config Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:02:03 --> URI Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Router Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Output Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Security Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Input Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:02:03 --> Language Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Loader Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:02:03 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Session Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:02:03 --> Session routines successfully run
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Controller Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Model Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:02:03 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:02:03 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:02:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:02:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:02:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:02:03 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:02:03 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 17:02:03 --> Final output sent to browser
DEBUG - 2015-12-17 17:02:03 --> Total execution time: 0.1042
DEBUG - 2015-12-17 17:02:03 --> Config Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:02:03 --> URI Class Initialized
DEBUG - 2015-12-17 17:02:03 --> Router Class Initialized
ERROR - 2015-12-17 17:02:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:04:59 --> Config Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:04:59 --> URI Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Router Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Output Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Security Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Input Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:04:59 --> Language Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Loader Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:04:59 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Session Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:04:59 --> Session routines successfully run
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Controller Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:04:59 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:04:59 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:00 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-17 17:05:00 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:00 --> Total execution time: 0.2040
DEBUG - 2015-12-17 17:05:00 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:00 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:00 --> Router Class Initialized
ERROR - 2015-12-17 17:05:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:05:02 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:02 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:02 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:02 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:02 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:02 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:02 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:02 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:02 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:02 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-17 17:05:02 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:02 --> Total execution time: 0.0756
DEBUG - 2015-12-17 17:05:03 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:03 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:03 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:03 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:03 --> Router Class Initialized
ERROR - 2015-12-17 17:05:03 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:05:10 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:10 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:10 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:10 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:10 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:10 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:05:10 --> Helper loaded: pdf_helper
DEBUG - 2015-12-17 17:05:10 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-17 17:05:12 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-17 17:05:13 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-17 17:05:15 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:15 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:15 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:15 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:15 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:15 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:15 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-17 17:05:15 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:15 --> Total execution time: 0.0597
DEBUG - 2015-12-17 17:05:15 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:15 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:15 --> Router Class Initialized
ERROR - 2015-12-17 17:05:15 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:05:19 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:19 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:19 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:19 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:19 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:19 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:19 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:19 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-17 17:05:19 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:19 --> Total execution time: 0.1635
DEBUG - 2015-12-17 17:05:19 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:19 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:19 --> Router Class Initialized
ERROR - 2015-12-17 17:05:19 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:05:23 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:23 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:23 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:23 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:23 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:23 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:23 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:23 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-17 17:05:23 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:23 --> Total execution time: 0.0812
DEBUG - 2015-12-17 17:05:23 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:23 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:23 --> Router Class Initialized
ERROR - 2015-12-17 17:05:23 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:05:44 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:44 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:44 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:44 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:44 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:44 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:44 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:44 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:44 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-17 17:05:44 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:44 --> Total execution time: 0.0916
DEBUG - 2015-12-17 17:05:44 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:44 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:44 --> Router Class Initialized
ERROR - 2015-12-17 17:05:44 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:05:47 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:47 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Router Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Output Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Security Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Input Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:05:47 --> Language Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Loader Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:05:47 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Session Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:05:47 --> Session routines successfully run
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Controller Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:05:47 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:05:47 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:05:47 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:05:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:05:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:05:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:05:47 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:05:47 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-17 17:05:47 --> Final output sent to browser
DEBUG - 2015-12-17 17:05:47 --> Total execution time: 0.0676
DEBUG - 2015-12-17 17:05:48 --> Config Class Initialized
DEBUG - 2015-12-17 17:05:48 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:05:48 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:05:48 --> URI Class Initialized
DEBUG - 2015-12-17 17:05:48 --> Router Class Initialized
ERROR - 2015-12-17 17:05:48 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:06:32 --> Config Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:06:32 --> URI Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Router Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Output Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Security Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Input Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:06:32 --> Language Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Loader Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:06:32 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Session Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:06:32 --> Session routines successfully run
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Controller Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Model Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:06:32 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:06:32 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:06:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:06:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:06:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:06:32 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:06:32 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-17 17:06:32 --> Final output sent to browser
DEBUG - 2015-12-17 17:06:32 --> Total execution time: 0.0896
DEBUG - 2015-12-17 17:06:32 --> Config Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:06:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:06:32 --> URI Class Initialized
DEBUG - 2015-12-17 17:06:32 --> Router Class Initialized
ERROR - 2015-12-17 17:06:32 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:16:08 --> Config Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:16:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:16:08 --> URI Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Router Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Output Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Security Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Input Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:16:08 --> Language Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Loader Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:16:08 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Session Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:16:08 --> Session routines successfully run
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Controller Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:16:08 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:16:08 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:16:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:16:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:16:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:16:08 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:16:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-17 17:16:08 --> Final output sent to browser
DEBUG - 2015-12-17 17:16:08 --> Total execution time: 0.1464
DEBUG - 2015-12-17 17:16:08 --> Config Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:16:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:16:08 --> URI Class Initialized
DEBUG - 2015-12-17 17:16:08 --> Router Class Initialized
ERROR - 2015-12-17 17:16:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:16:11 --> Config Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:16:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:16:11 --> URI Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Router Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Output Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Security Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Input Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:16:11 --> Language Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Loader Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:16:11 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Session Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:16:11 --> Session routines successfully run
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Controller Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:16:11 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:16:11 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:16:11 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:16:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:16:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:16:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:16:11 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:16:11 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-17 17:16:11 --> Final output sent to browser
DEBUG - 2015-12-17 17:16:11 --> Total execution time: 0.0784
DEBUG - 2015-12-17 17:16:12 --> Config Class Initialized
DEBUG - 2015-12-17 17:16:12 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:16:12 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:16:12 --> URI Class Initialized
DEBUG - 2015-12-17 17:16:12 --> Router Class Initialized
ERROR - 2015-12-17 17:16:12 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:16:31 --> Config Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:16:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:16:31 --> URI Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Router Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Output Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Security Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Input Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:16:31 --> Language Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Loader Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:16:31 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Session Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:16:31 --> Session routines successfully run
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Controller Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:16:31 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:16:31 --> Helper loaded: pdf_helper
DEBUG - 2015-12-17 17:16:33 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-17 17:16:33 --> Final output sent to browser
DEBUG - 2015-12-17 17:16:33 --> Total execution time: 1.7792
DEBUG - 2015-12-17 17:42:42 --> Config Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:42:42 --> URI Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Router Class Initialized
DEBUG - 2015-12-17 17:42:42 --> No URI present. Default controller set.
DEBUG - 2015-12-17 17:42:42 --> Output Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Security Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Input Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:42:42 --> Language Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Loader Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:42:42 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Session Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:42:42 --> Session routines successfully run
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Controller Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:42:42 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Config Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:42:42 --> URI Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Router Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Output Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Security Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Input Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:42:42 --> Language Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Loader Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:42:42 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Session Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:42:42 --> Session routines successfully run
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Controller Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:42:42 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:42:42 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:42:42 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:42:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:42:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:42:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:42:42 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:42:42 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-17 17:42:42 --> Final output sent to browser
DEBUG - 2015-12-17 17:42:42 --> Total execution time: 0.0438
DEBUG - 2015-12-17 17:42:43 --> Config Class Initialized
DEBUG - 2015-12-17 17:42:43 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:42:43 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:42:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:42:43 --> URI Class Initialized
DEBUG - 2015-12-17 17:42:43 --> Router Class Initialized
ERROR - 2015-12-17 17:42:43 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:42:44 --> Config Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:42:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:42:44 --> URI Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Router Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Output Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Security Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Input Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:42:44 --> Language Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Loader Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:42:44 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Session Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:42:44 --> Session routines successfully run
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Controller Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:42:44 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Config Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:42:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:42:44 --> URI Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Router Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Output Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Security Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Input Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:42:44 --> Language Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Loader Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:42:44 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Session Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:42:44 --> Session routines successfully run
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Controller Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:42:44 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:42:44 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:42:44 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-17 17:42:44 --> Final output sent to browser
DEBUG - 2015-12-17 17:42:44 --> Total execution time: 0.0396
DEBUG - 2015-12-17 17:42:45 --> Config Class Initialized
DEBUG - 2015-12-17 17:42:45 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:42:45 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:42:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:42:45 --> URI Class Initialized
DEBUG - 2015-12-17 17:42:45 --> Router Class Initialized
ERROR - 2015-12-17 17:42:45 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:43:00 --> Config Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:43:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:43:00 --> URI Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Router Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Output Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Security Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Input Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:43:00 --> Language Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Loader Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:43:00 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Session Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:43:00 --> Session routines successfully run
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Controller Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:43:00 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:43:00 --> Config Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:43:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:43:00 --> URI Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Router Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Output Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Security Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Input Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:43:00 --> Language Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Loader Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:43:00 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Session Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:43:00 --> Session routines successfully run
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Controller Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:43:00 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:43:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:43:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:43:00 --> Config Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:43:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:43:00 --> URI Class Initialized
DEBUG - 2015-12-17 17:43:00 --> Router Class Initialized
ERROR - 2015-12-17 17:43:00 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:45:33 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:33 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Router Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Output Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Security Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Input Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:45:33 --> Language Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Loader Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:45:33 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Session Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:45:33 --> Session routines successfully run
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Controller Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:33 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:45:33 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:45:33 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:45:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:45:33 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-12-17 17:45:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:45:33 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:45:33 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-12-17 17:45:33 --> Final output sent to browser
DEBUG - 2015-12-17 17:45:33 --> Total execution time: 0.0667
DEBUG - 2015-12-17 17:45:34 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:34 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:34 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:34 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:34 --> Router Class Initialized
ERROR - 2015-12-17 17:45:34 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:45:36 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:36 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Router Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Output Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Security Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Input Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:45:36 --> Language Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Loader Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:45:36 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Session Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:45:36 --> Session routines successfully run
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Controller Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:45:36 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:45:36 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:45:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:45:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:45:36 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-12-17 17:45:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:45:36 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:45:36 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-12-17 17:45:36 --> Final output sent to browser
DEBUG - 2015-12-17 17:45:36 --> Total execution time: 0.0610
DEBUG - 2015-12-17 17:45:37 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:37 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:37 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:37 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:37 --> Router Class Initialized
ERROR - 2015-12-17 17:45:37 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:45:40 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:40 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Router Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Output Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Security Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Input Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:45:40 --> Language Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Loader Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:45:40 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Session Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:45:40 --> Session routines successfully run
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Controller Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:45:40 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:40 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:45:40 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:45:40 --> Final output sent to browser
DEBUG - 2015-12-17 17:45:40 --> Total execution time: 0.0514
DEBUG - 2015-12-17 17:45:40 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:40 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:40 --> Router Class Initialized
ERROR - 2015-12-17 17:45:40 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:45:42 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:42 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:42 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:42 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:42 --> Router Class Initialized
ERROR - 2015-12-17 17:45:42 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:45:44 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:44 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Router Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Output Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Security Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Input Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:45:44 --> Language Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Loader Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:45:44 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Session Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:45:44 --> Session routines successfully run
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Controller Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:45:44 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:44 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:45:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:45:44 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-12-17 17:45:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:45:44 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:45:44 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 17:45:44 --> Final output sent to browser
DEBUG - 2015-12-17 17:45:44 --> Total execution time: 0.0686
DEBUG - 2015-12-17 17:45:45 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:45 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:45 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:45 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:45 --> Router Class Initialized
ERROR - 2015-12-17 17:45:45 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:45:56 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:56 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Router Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Output Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Security Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Input Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:45:56 --> Language Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Loader Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:45:56 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Session Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:45:56 --> Session routines successfully run
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Controller Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:45:56 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:56 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Router Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Output Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Security Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Input Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:45:56 --> Language Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Loader Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:45:56 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Session Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:45:56 --> Session routines successfully run
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Controller Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Model Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:45:56 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:45:56 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-17 17:45:56 --> Final output sent to browser
DEBUG - 2015-12-17 17:45:56 --> Total execution time: 0.0441
DEBUG - 2015-12-17 17:45:56 --> Config Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:45:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:45:56 --> URI Class Initialized
DEBUG - 2015-12-17 17:45:56 --> Router Class Initialized
ERROR - 2015-12-17 17:45:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:46:14 --> Config Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:46:14 --> URI Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Router Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Output Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Security Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Input Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:46:14 --> Language Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Loader Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:46:14 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Session Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:46:14 --> Session routines successfully run
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Controller Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:46:14 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:46:14 --> Config Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:46:14 --> URI Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Router Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Output Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Security Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Input Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:46:14 --> Language Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Loader Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:46:14 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Session Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:46:14 --> Session routines successfully run
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Controller Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Model Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:46:14 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:46:14 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:46:14 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:46:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:46:14 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-12-17 17:46:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:46:14 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:46:14 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-12-17 17:46:14 --> Final output sent to browser
DEBUG - 2015-12-17 17:46:14 --> Total execution time: 0.0491
DEBUG - 2015-12-17 17:46:15 --> Config Class Initialized
DEBUG - 2015-12-17 17:46:15 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:46:15 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:46:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:46:15 --> URI Class Initialized
DEBUG - 2015-12-17 17:46:15 --> Router Class Initialized
ERROR - 2015-12-17 17:46:15 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:47:59 --> Config Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:47:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:47:59 --> URI Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Router Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Output Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Security Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Input Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:47:59 --> Language Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Loader Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:47:59 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Session Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:47:59 --> Session routines successfully run
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Controller Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:47:59 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Model Class Initialized
DEBUG - 2015-12-17 17:47:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:47:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:47:59 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-12-17 17:47:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:47:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:47:59 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 17:47:59 --> Final output sent to browser
DEBUG - 2015-12-17 17:47:59 --> Total execution time: 0.0972
DEBUG - 2015-12-17 17:47:59 --> Config Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:47:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:47:59 --> URI Class Initialized
DEBUG - 2015-12-17 17:47:59 --> Router Class Initialized
ERROR - 2015-12-17 17:47:59 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:48:05 --> Config Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:48:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:48:05 --> URI Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Router Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Output Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Security Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Input Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:48:05 --> Language Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Loader Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:48:05 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Session Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:48:05 --> Session routines successfully run
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Controller Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:48:05 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:05 --> Model Class Initialized
ERROR - 2015-12-17 17:48:05 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/models/form_model.php 66
DEBUG - 2015-12-17 17:48:05 --> DB Transaction Failure
ERROR - 2015-12-17 17:48:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'limit 30 offset 0' at line 1
DEBUG - 2015-12-17 17:48:05 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-12-17 17:48:05 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 442
DEBUG - 2015-12-17 17:48:31 --> Config Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:48:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:48:31 --> URI Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Router Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Output Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Security Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Input Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:48:31 --> Language Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Loader Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:48:31 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Session Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:48:31 --> Session routines successfully run
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Controller Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:48:31 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> Model Class Initialized
DEBUG - 2015-12-17 17:48:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:48:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:48:31 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-12-17 17:48:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:48:31 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:48:31 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 17:48:31 --> Final output sent to browser
DEBUG - 2015-12-17 17:48:31 --> Total execution time: 0.0626
DEBUG - 2015-12-17 17:48:32 --> Config Class Initialized
DEBUG - 2015-12-17 17:48:32 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:48:32 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:48:32 --> URI Class Initialized
DEBUG - 2015-12-17 17:48:32 --> Router Class Initialized
ERROR - 2015-12-17 17:48:32 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:51:53 --> Config Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:51:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:51:53 --> URI Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Router Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Output Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Security Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Input Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:51:53 --> Language Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Loader Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:51:53 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Session Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:51:53 --> Session routines successfully run
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Controller Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:51:53 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:51:53 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:51:53 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:51:53 --> Final output sent to browser
DEBUG - 2015-12-17 17:51:53 --> Total execution time: 0.0751
DEBUG - 2015-12-17 17:51:54 --> Config Class Initialized
DEBUG - 2015-12-17 17:51:54 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:51:54 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:51:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:51:54 --> URI Class Initialized
DEBUG - 2015-12-17 17:51:54 --> Router Class Initialized
ERROR - 2015-12-17 17:51:54 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:53:39 --> Config Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:53:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:53:39 --> URI Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Router Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Output Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Security Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Input Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:53:39 --> Language Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Loader Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:53:39 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Session Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:53:39 --> Session routines successfully run
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Controller Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:53:39 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:53:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:53:39 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:53:39 --> Final output sent to browser
DEBUG - 2015-12-17 17:53:39 --> Total execution time: 0.0789
DEBUG - 2015-12-17 17:53:40 --> Config Class Initialized
DEBUG - 2015-12-17 17:53:40 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:53:40 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:53:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:53:40 --> URI Class Initialized
DEBUG - 2015-12-17 17:53:40 --> Router Class Initialized
ERROR - 2015-12-17 17:53:40 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:54:00 --> Config Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:54:00 --> URI Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Router Class Initialized
DEBUG - 2015-12-17 17:54:00 --> No URI present. Default controller set.
DEBUG - 2015-12-17 17:54:00 --> Output Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Security Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Input Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:54:00 --> Language Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Loader Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:54:00 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Session Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:54:00 --> A session cookie was not found.
DEBUG - 2015-12-17 17:54:00 --> Session routines successfully run
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Controller Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:00 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:54:00 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:54:00 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-17 17:54:00 --> Final output sent to browser
DEBUG - 2015-12-17 17:54:00 --> Total execution time: 0.0544
DEBUG - 2015-12-17 17:54:19 --> Config Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:54:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:54:19 --> URI Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Router Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Output Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Security Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Input Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:54:19 --> Language Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Loader Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:54:19 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Session Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:54:19 --> Session routines successfully run
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Controller Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:54:19 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:54:19 --> Config Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:54:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:54:19 --> URI Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Router Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Output Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Security Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Input Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:54:19 --> Language Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Loader Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:54:19 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Session Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:54:19 --> Session routines successfully run
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Controller Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:54:19 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:54:19 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:54:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:54:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:54:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:54:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:54:19 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:54:19 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-17 17:54:19 --> Final output sent to browser
DEBUG - 2015-12-17 17:54:19 --> Total execution time: 0.0457
DEBUG - 2015-12-17 17:54:24 --> Config Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:54:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:54:24 --> URI Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Router Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Output Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Security Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Input Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:54:24 --> Language Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Loader Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:54:24 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Session Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:54:24 --> Session routines successfully run
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Controller Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:54:24 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> Model Class Initialized
DEBUG - 2015-12-17 17:54:24 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:54:24 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:54:24 --> Final output sent to browser
DEBUG - 2015-12-17 17:54:24 --> Total execution time: 0.0599
DEBUG - 2015-12-17 17:55:47 --> Config Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:55:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:55:47 --> URI Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Router Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Output Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Security Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Input Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:55:47 --> Language Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Loader Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:55:47 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Session Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:55:47 --> Session routines successfully run
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Controller Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:55:47 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> Model Class Initialized
DEBUG - 2015-12-17 17:55:47 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-17 17:55:47 --> Email Class Initialized
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fsockopen(): unable to connect to 192.168.0.12:25 (Operation timed out) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1689
DEBUG - 2015-12-17 17:55:52 --> Language file loaded: language/english/email_lang.php
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
DEBUG - 2015-12-17 17:55:52 --> File loaded: application/views/header.php
ERROR - 2015-12-17 17:55:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-12-17 17:55:52 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:55:52 --> Final output sent to browser
DEBUG - 2015-12-17 17:55:52 --> Total execution time: 5.1533
DEBUG - 2015-12-17 17:55:57 --> Config Class Initialized
DEBUG - 2015-12-17 17:55:57 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:55:57 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:55:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:55:57 --> URI Class Initialized
DEBUG - 2015-12-17 17:55:57 --> Router Class Initialized
ERROR - 2015-12-17 17:55:57 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:05 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:05 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:05 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:05 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:05 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:05 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:05 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:56:05 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:56:05 --> Final output sent to browser
DEBUG - 2015-12-17 17:56:05 --> Total execution time: 0.0752
DEBUG - 2015-12-17 17:56:05 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:05 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:05 --> Router Class Initialized
ERROR - 2015-12-17 17:56:05 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:08 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:08 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:08 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:08 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:08 --> Router Class Initialized
ERROR - 2015-12-17 17:56:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:10 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:10 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:10 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:10 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:10 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:10 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:10 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:10 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:56:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:56:10 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-12-17 17:56:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:56:10 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:56:10 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 17:56:10 --> Final output sent to browser
DEBUG - 2015-12-17 17:56:10 --> Total execution time: 0.0546
DEBUG - 2015-12-17 17:56:11 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:11 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:11 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:11 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:11 --> Router Class Initialized
ERROR - 2015-12-17 17:56:11 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:13 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:13 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:13 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:13 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:13 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:13 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:13 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:13 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:13 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:13 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:13 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:13 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-17 17:56:13 --> Final output sent to browser
DEBUG - 2015-12-17 17:56:13 --> Total execution time: 0.0401
DEBUG - 2015-12-17 17:56:13 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:13 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:13 --> Router Class Initialized
ERROR - 2015-12-17 17:56:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:18 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:18 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:18 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:18 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:18 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:18 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:56:18 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:18 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:18 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:18 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:18 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:18 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:56:18 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:56:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:56:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:56:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:56:18 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:56:18 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-17 17:56:18 --> Final output sent to browser
DEBUG - 2015-12-17 17:56:18 --> Total execution time: 0.0463
DEBUG - 2015-12-17 17:56:18 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:18 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:18 --> Router Class Initialized
ERROR - 2015-12-17 17:56:18 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:21 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:21 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:21 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:21 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:21 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:21 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:56:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:56:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:56:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:56:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:56:21 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-17 17:56:21 --> Final output sent to browser
DEBUG - 2015-12-17 17:56:21 --> Total execution time: 0.0733
DEBUG - 2015-12-17 17:56:22 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:22 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:22 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:22 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:22 --> Router Class Initialized
ERROR - 2015-12-17 17:56:22 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:29 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:29 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:29 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:29 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:29 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:29 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:30 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:56:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:56:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:56:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:56:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:56:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:56:30 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-17 17:56:30 --> Final output sent to browser
DEBUG - 2015-12-17 17:56:30 --> Total execution time: 0.0942
DEBUG - 2015-12-17 17:56:30 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:30 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:30 --> Router Class Initialized
ERROR - 2015-12-17 17:56:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:56:53 --> Config Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:56:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:56:53 --> URI Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Router Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Output Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Security Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Input Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:56:53 --> Language Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Loader Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:56:53 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Session Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:56:53 --> Session routines successfully run
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Controller Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Model Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:56:53 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:56:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-17 17:56:53 --> Helper loaded: pdf_helper
DEBUG - 2015-12-17 17:56:53 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-12-17 17:56:56 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2015-12-17 17:56:59 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-12-17 17:57:00 --> Config Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:57:00 --> URI Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Router Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Output Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Security Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Input Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:57:00 --> Language Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Loader Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:57:00 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Session Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:57:00 --> Session routines successfully run
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Controller Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:57:00 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:57:00 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/footer.php
DEBUG - 2015-12-17 17:57:00 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-12-17 17:57:00 --> Final output sent to browser
DEBUG - 2015-12-17 17:57:00 --> Total execution time: 0.0667
DEBUG - 2015-12-17 17:57:01 --> Config Class Initialized
DEBUG - 2015-12-17 17:57:01 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:57:01 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:57:01 --> URI Class Initialized
DEBUG - 2015-12-17 17:57:01 --> Router Class Initialized
ERROR - 2015-12-17 17:57:01 --> 404 Page Not Found --> js
DEBUG - 2015-12-17 17:57:38 --> Config Class Initialized
DEBUG - 2015-12-17 17:57:38 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:57:38 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:57:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:57:38 --> URI Class Initialized
DEBUG - 2015-12-17 17:57:38 --> Router Class Initialized
DEBUG - 2015-12-17 17:57:38 --> Output Class Initialized
DEBUG - 2015-12-17 17:57:38 --> Security Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Input Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-17 17:57:39 --> Language Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Loader Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Helper loaded: url_helper
DEBUG - 2015-12-17 17:57:39 --> Database Driver Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Session Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Helper loaded: string_helper
DEBUG - 2015-12-17 17:57:39 --> Session routines successfully run
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Controller Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Pagination Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Helper loaded: form_helper
DEBUG - 2015-12-17 17:57:39 --> Form Validation Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Model Class Initialized
DEBUG - 2015-12-17 17:57:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-17 17:57:39 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-17 17:57:39 --> Final output sent to browser
DEBUG - 2015-12-17 17:57:39 --> Total execution time: 0.0783
DEBUG - 2015-12-17 17:57:39 --> Config Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Hooks Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Utf8 Class Initialized
DEBUG - 2015-12-17 17:57:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-17 17:57:39 --> URI Class Initialized
DEBUG - 2015-12-17 17:57:39 --> Router Class Initialized
ERROR - 2015-12-17 17:57:39 --> 404 Page Not Found --> js
