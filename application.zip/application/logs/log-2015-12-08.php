<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-08 15:10:23 --> Config Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:10:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:10:23 --> URI Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Router Class Initialized
DEBUG - 2015-12-08 15:10:23 --> No URI present. Default controller set.
DEBUG - 2015-12-08 15:10:23 --> Output Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Security Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Input Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:10:23 --> Language Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Loader Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:10:23 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Session Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:10:23 --> A session cookie was not found.
DEBUG - 2015-12-08 15:10:23 --> Session routines successfully run
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Controller Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:23 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:10:23 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:10:23 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-08 15:10:23 --> Final output sent to browser
DEBUG - 2015-12-08 15:10:23 --> Total execution time: 0.0661
DEBUG - 2015-12-08 15:10:30 --> Config Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:10:30 --> URI Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Router Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Output Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Security Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Input Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:10:30 --> Language Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Loader Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:10:30 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Session Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:10:30 --> Session routines successfully run
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Controller Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:10:30 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-08 15:10:30 --> Config Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:10:30 --> URI Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Router Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Output Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Security Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Input Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:10:30 --> Language Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Loader Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:10:30 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Session Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:10:30 --> Session routines successfully run
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Controller Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:10:30 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:10:30 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:10:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:10:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:10:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:10:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:10:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:10:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-08 15:10:30 --> Final output sent to browser
DEBUG - 2015-12-08 15:10:30 --> Total execution time: 0.0413
DEBUG - 2015-12-08 15:10:34 --> Config Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:10:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:10:34 --> URI Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Router Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Output Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Security Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Input Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:10:34 --> Language Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Loader Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:10:34 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Session Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:10:34 --> Session routines successfully run
DEBUG - 2015-12-08 15:10:34 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Controller Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:34 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:10:34 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Config Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:10:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:10:59 --> URI Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Router Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Output Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Security Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Input Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:10:59 --> Language Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Loader Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:10:59 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Session Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:10:59 --> Session routines successfully run
DEBUG - 2015-12-08 15:10:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Controller Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:10:59 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:10:59 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:10:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:10:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:10:59 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:10:59 --> Final output sent to browser
DEBUG - 2015-12-08 15:10:59 --> Total execution time: 0.0331
DEBUG - 2015-12-08 15:11:48 --> Config Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:11:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:11:48 --> URI Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Router Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Output Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Security Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Input Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:11:48 --> Language Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Loader Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:11:48 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Session Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:11:48 --> Session routines successfully run
DEBUG - 2015-12-08 15:11:48 --> Model Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Model Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Controller Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Model Class Initialized
DEBUG - 2015-12-08 15:11:48 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:11:48 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:11:48 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:11:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:11:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:11:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:11:48 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:11:48 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:11:48 --> Final output sent to browser
DEBUG - 2015-12-08 15:11:48 --> Total execution time: 0.0502
DEBUG - 2015-12-08 15:12:02 --> Config Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:12:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:12:02 --> URI Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Router Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Output Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Security Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Input Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:12:02 --> Language Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Loader Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:12:02 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Session Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:12:02 --> Session routines successfully run
DEBUG - 2015-12-08 15:12:02 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Controller Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:02 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:12:02 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:12:02 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:12:02 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:12:02 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:12:02 --> Final output sent to browser
DEBUG - 2015-12-08 15:12:02 --> Total execution time: 0.0485
DEBUG - 2015-12-08 15:12:11 --> Config Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:12:11 --> URI Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Router Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Output Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Security Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Input Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:12:11 --> Language Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Loader Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:12:11 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Session Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:12:11 --> Session routines successfully run
DEBUG - 2015-12-08 15:12:11 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Controller Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:11 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:12:11 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:12:11 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:12:11 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:12:11 --> Final output sent to browser
DEBUG - 2015-12-08 15:12:11 --> Total execution time: 0.0445
DEBUG - 2015-12-08 15:12:40 --> Config Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:12:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:12:40 --> URI Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Router Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Output Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Security Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Input Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:12:40 --> Language Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Loader Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:12:40 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Session Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:12:40 --> Session routines successfully run
DEBUG - 2015-12-08 15:12:40 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Controller Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:12:40 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:41 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:12:41 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:12:41 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:12:41 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:12:41 --> Final output sent to browser
DEBUG - 2015-12-08 15:12:41 --> Total execution time: 0.0326
DEBUG - 2015-12-08 15:12:59 --> Config Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:12:59 --> URI Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Router Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Output Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Security Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Input Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:12:59 --> Language Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Loader Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:12:59 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Session Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:12:59 --> Session routines successfully run
DEBUG - 2015-12-08 15:12:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Controller Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:12:59 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:12:59 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:12:59 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:12:59 --> Final output sent to browser
DEBUG - 2015-12-08 15:12:59 --> Total execution time: 0.0475
DEBUG - 2015-12-08 15:13:12 --> Config Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:13:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:13:12 --> URI Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Router Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Output Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Security Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Input Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:13:12 --> Language Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Loader Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:13:12 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Session Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:13:12 --> Session routines successfully run
DEBUG - 2015-12-08 15:13:12 --> Model Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Model Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Controller Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Model Class Initialized
DEBUG - 2015-12-08 15:13:12 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:13:12 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:13:12 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:13:12 --> Final output sent to browser
DEBUG - 2015-12-08 15:13:12 --> Total execution time: 0.0385
DEBUG - 2015-12-08 15:13:19 --> Config Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:13:19 --> URI Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Router Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Output Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Security Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Input Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:13:19 --> Language Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Loader Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:13:19 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Session Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:13:19 --> Session routines successfully run
DEBUG - 2015-12-08 15:13:19 --> Model Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Model Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Controller Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Model Class Initialized
DEBUG - 2015-12-08 15:13:19 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:13:19 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:13:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:13:19 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:13:19 --> Final output sent to browser
DEBUG - 2015-12-08 15:13:19 --> Total execution time: 0.0378
DEBUG - 2015-12-08 15:14:13 --> Config Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:14:13 --> URI Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Router Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Output Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Security Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Input Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:14:13 --> Language Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Loader Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:14:13 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Session Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:14:13 --> Session routines successfully run
DEBUG - 2015-12-08 15:14:13 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Controller Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:13 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:14:13 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:14:13 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:14:13 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:14:13 --> Final output sent to browser
DEBUG - 2015-12-08 15:14:13 --> Total execution time: 0.0308
DEBUG - 2015-12-08 15:14:22 --> Config Class Initialized
DEBUG - 2015-12-08 15:14:22 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:14:22 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:14:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:14:22 --> URI Class Initialized
DEBUG - 2015-12-08 15:14:22 --> Router Class Initialized
ERROR - 2015-12-08 15:14:22 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:14:28 --> Config Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:14:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:14:28 --> URI Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Router Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Output Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Security Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Input Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:14:28 --> Language Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Loader Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:14:28 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Session Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:14:28 --> Session routines successfully run
DEBUG - 2015-12-08 15:14:28 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Controller Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:14:28 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:14:28 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:14:28 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:14:28 --> Final output sent to browser
DEBUG - 2015-12-08 15:14:28 --> Total execution time: 0.0408
DEBUG - 2015-12-08 15:14:28 --> Config Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:14:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:14:28 --> URI Class Initialized
DEBUG - 2015-12-08 15:14:28 --> Router Class Initialized
ERROR - 2015-12-08 15:14:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:14:47 --> Config Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:14:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:14:47 --> URI Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Router Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Output Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Security Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Input Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:14:47 --> Language Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Loader Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:14:47 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Session Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:14:47 --> Session routines successfully run
DEBUG - 2015-12-08 15:14:47 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Controller Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Model Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:14:47 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:14:47 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:14:47 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:14:47 --> Final output sent to browser
DEBUG - 2015-12-08 15:14:47 --> Total execution time: 0.0302
DEBUG - 2015-12-08 15:14:47 --> Config Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:14:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:14:47 --> URI Class Initialized
DEBUG - 2015-12-08 15:14:47 --> Router Class Initialized
ERROR - 2015-12-08 15:14:47 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:15:55 --> Config Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:15:55 --> URI Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Router Class Initialized
DEBUG - 2015-12-08 15:15:55 --> No URI present. Default controller set.
DEBUG - 2015-12-08 15:15:55 --> Output Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Security Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Input Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:15:55 --> Language Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Loader Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:15:55 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Session Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:15:55 --> A session cookie was not found.
DEBUG - 2015-12-08 15:15:55 --> Session routines successfully run
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Controller Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:15:55 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:15:55 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:15:55 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-08 15:15:55 --> Final output sent to browser
DEBUG - 2015-12-08 15:15:55 --> Total execution time: 0.0481
DEBUG - 2015-12-08 15:16:09 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:09 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:09 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:09 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:09 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:09 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-08 15:16:09 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:09 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:09 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:09 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:09 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:09 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:09 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:16:09 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:16:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:16:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:16:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:16:09 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:16:09 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-08 15:16:09 --> Final output sent to browser
DEBUG - 2015-12-08 15:16:09 --> Total execution time: 0.0400
DEBUG - 2015-12-08 15:16:19 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:19 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:19 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:19 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:19 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:19 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:19 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:19 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:16:19 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:16:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:16:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:16:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:16:19 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:16:19 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-08 15:16:19 --> Final output sent to browser
DEBUG - 2015-12-08 15:16:19 --> Total execution time: 0.0373
DEBUG - 2015-12-08 15:16:21 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:21 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:21 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:21 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:21 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:21 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:21 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:21 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:16:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:16:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:16:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:16:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:16:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:16:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-08 15:16:21 --> Final output sent to browser
DEBUG - 2015-12-08 15:16:21 --> Total execution time: 0.0405
DEBUG - 2015-12-08 15:16:22 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:22 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:22 --> No URI present. Default controller set.
DEBUG - 2015-12-08 15:16:22 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:22 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:22 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:22 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:23 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:23 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:23 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:23 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:23 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:23 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:23 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-08 15:16:23 --> Final output sent to browser
DEBUG - 2015-12-08 15:16:23 --> Total execution time: 0.0381
DEBUG - 2015-12-08 15:16:23 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:23 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:23 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:23 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:23 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:23 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:23 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:16:23 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:16:23 --> Final output sent to browser
DEBUG - 2015-12-08 15:16:23 --> Total execution time: 0.0310
DEBUG - 2015-12-08 15:16:54 --> Config Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:16:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:16:55 --> URI Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Router Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Output Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Security Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Input Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:16:55 --> Language Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Loader Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:16:55 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Session Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:16:55 --> Session routines successfully run
DEBUG - 2015-12-08 15:16:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Controller Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Model Class Initialized
DEBUG - 2015-12-08 15:16:55 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:16:55 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:16:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:16:55 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:16:55 --> Final output sent to browser
DEBUG - 2015-12-08 15:16:55 --> Total execution time: 0.0455
DEBUG - 2015-12-08 15:17:51 --> Config Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:17:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:17:51 --> URI Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Router Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Output Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Security Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Input Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:17:51 --> Language Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Loader Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:17:51 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Session Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:17:51 --> Session routines successfully run
DEBUG - 2015-12-08 15:17:51 --> Model Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Model Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Controller Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Model Class Initialized
DEBUG - 2015-12-08 15:17:51 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:17:51 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:17:51 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:17:51 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:17:51 --> Final output sent to browser
DEBUG - 2015-12-08 15:17:51 --> Total execution time: 0.0454
DEBUG - 2015-12-08 15:18:21 --> Config Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:18:21 --> URI Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Router Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Output Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Security Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Input Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:18:21 --> Language Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Loader Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:18:21 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Session Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:18:21 --> Session routines successfully run
DEBUG - 2015-12-08 15:18:21 --> Model Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Model Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Controller Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Model Class Initialized
DEBUG - 2015-12-08 15:18:21 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:18:21 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:18:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:18:21 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:18:21 --> Final output sent to browser
DEBUG - 2015-12-08 15:18:21 --> Total execution time: 0.0339
DEBUG - 2015-12-08 15:18:28 --> Config Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:18:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:18:28 --> URI Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Router Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Output Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Security Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Input Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:18:28 --> Language Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Loader Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:18:28 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Session Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:18:28 --> Session routines successfully run
DEBUG - 2015-12-08 15:18:28 --> Model Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Model Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Controller Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Model Class Initialized
DEBUG - 2015-12-08 15:18:28 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:18:28 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:18:28 --> DB Transaction Failure
ERROR - 2015-12-08 15:18:28 --> Query error: Table 'asmc_crm2.forms' doesn't exist
DEBUG - 2015-12-08 15:18:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-08 15:19:00 --> Config Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:19:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:19:00 --> URI Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Router Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Output Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Security Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Input Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:19:00 --> Language Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Loader Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:19:00 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Session Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:19:00 --> Session routines successfully run
DEBUG - 2015-12-08 15:19:00 --> Model Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Model Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Controller Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Model Class Initialized
DEBUG - 2015-12-08 15:19:00 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:19:00 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Config Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:19:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:19:40 --> URI Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Router Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Output Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Security Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Input Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:19:40 --> Language Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Loader Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:19:40 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Session Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:19:40 --> Session routines successfully run
DEBUG - 2015-12-08 15:19:40 --> Model Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Model Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Controller Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Model Class Initialized
DEBUG - 2015-12-08 15:19:40 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:19:40 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:19:40 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-08 15:19:40 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:19:40 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:19:40 --> Final output sent to browser
DEBUG - 2015-12-08 15:19:40 --> Total execution time: 0.0516
DEBUG - 2015-12-08 15:21:11 --> Config Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:21:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:21:11 --> URI Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Router Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Output Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Security Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Input Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:21:11 --> Language Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Loader Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:21:11 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Session Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:21:11 --> Session routines successfully run
DEBUG - 2015-12-08 15:21:11 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Controller Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:11 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:21:11 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:21:11 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:21:11 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:21:11 --> Final output sent to browser
DEBUG - 2015-12-08 15:21:11 --> Total execution time: 0.0432
DEBUG - 2015-12-08 15:21:39 --> Config Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:21:39 --> URI Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Router Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Output Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Security Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Input Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:21:39 --> Language Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Loader Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:21:39 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Session Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:21:39 --> Session routines successfully run
DEBUG - 2015-12-08 15:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Controller Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:39 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:21:39 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:21:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:21:39 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:21:39 --> Final output sent to browser
DEBUG - 2015-12-08 15:21:39 --> Total execution time: 0.0341
DEBUG - 2015-12-08 15:21:48 --> Config Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:21:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:21:48 --> URI Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Router Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Output Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Security Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Input Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:21:48 --> Language Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Loader Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:21:48 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Session Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:21:48 --> Session routines successfully run
DEBUG - 2015-12-08 15:21:48 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Controller Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Model Class Initialized
DEBUG - 2015-12-08 15:21:48 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:21:48 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:21:48 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:21:48 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:21:48 --> Final output sent to browser
DEBUG - 2015-12-08 15:21:48 --> Total execution time: 0.0356
DEBUG - 2015-12-08 15:22:49 --> Config Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:22:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:22:49 --> URI Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Router Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Output Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Security Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Input Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:22:49 --> Language Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Loader Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:22:49 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Session Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:22:49 --> Session routines successfully run
DEBUG - 2015-12-08 15:22:49 --> Model Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Model Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Controller Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Model Class Initialized
DEBUG - 2015-12-08 15:22:49 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:22:49 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:22:49 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:22:49 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:22:49 --> Final output sent to browser
DEBUG - 2015-12-08 15:22:49 --> Total execution time: 0.0472
DEBUG - 2015-12-08 15:23:39 --> Config Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:23:39 --> URI Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Router Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Output Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Security Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Input Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:23:39 --> Language Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Loader Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:23:39 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Session Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:23:39 --> Session routines successfully run
DEBUG - 2015-12-08 15:23:39 --> Model Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Model Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Controller Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Model Class Initialized
DEBUG - 2015-12-08 15:23:39 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:23:39 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:23:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:23:39 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:23:39 --> Final output sent to browser
DEBUG - 2015-12-08 15:23:39 --> Total execution time: 0.0314
DEBUG - 2015-12-08 15:24:00 --> Config Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:24:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:24:00 --> URI Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Router Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Output Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Security Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Input Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:24:00 --> Language Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Loader Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:24:00 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Session Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:24:00 --> Session routines successfully run
DEBUG - 2015-12-08 15:24:00 --> Model Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Model Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Controller Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Model Class Initialized
DEBUG - 2015-12-08 15:24:00 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:24:00 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:24:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:24:00 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:24:00 --> Final output sent to browser
DEBUG - 2015-12-08 15:24:00 --> Total execution time: 0.0366
DEBUG - 2015-12-08 15:25:31 --> Config Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:25:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:25:31 --> URI Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Router Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Output Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Security Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Input Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:25:31 --> Language Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Loader Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:25:31 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Session Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:25:31 --> Session routines successfully run
DEBUG - 2015-12-08 15:25:31 --> Model Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Model Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Controller Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Model Class Initialized
DEBUG - 2015-12-08 15:25:31 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:25:31 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:25:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:25:31 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:25:31 --> Final output sent to browser
DEBUG - 2015-12-08 15:25:31 --> Total execution time: 0.0439
DEBUG - 2015-12-08 15:25:57 --> Config Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:25:57 --> URI Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Router Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Output Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Security Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Input Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:25:57 --> Language Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Loader Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:25:57 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Session Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:25:57 --> Session routines successfully run
DEBUG - 2015-12-08 15:25:57 --> Model Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Model Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Controller Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Model Class Initialized
DEBUG - 2015-12-08 15:25:57 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:25:57 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:25:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:25:57 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:25:57 --> Final output sent to browser
DEBUG - 2015-12-08 15:25:57 --> Total execution time: 0.0375
DEBUG - 2015-12-08 15:25:58 --> Config Class Initialized
DEBUG - 2015-12-08 15:25:58 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:25:58 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:25:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:25:58 --> URI Class Initialized
DEBUG - 2015-12-08 15:25:58 --> Router Class Initialized
ERROR - 2015-12-08 15:25:58 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:26:44 --> Config Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:26:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:26:44 --> URI Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Router Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Output Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Security Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Input Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:26:44 --> Language Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Loader Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:26:44 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Session Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:26:44 --> Session routines successfully run
DEBUG - 2015-12-08 15:26:44 --> Model Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Model Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Controller Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Model Class Initialized
DEBUG - 2015-12-08 15:26:44 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:26:44 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:26:44 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:26:44 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 15:26:44 --> Final output sent to browser
DEBUG - 2015-12-08 15:26:44 --> Total execution time: 0.0504
DEBUG - 2015-12-08 15:26:45 --> Config Class Initialized
DEBUG - 2015-12-08 15:26:45 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:26:45 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:26:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:26:45 --> URI Class Initialized
DEBUG - 2015-12-08 15:26:45 --> Router Class Initialized
ERROR - 2015-12-08 15:26:45 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:29:59 --> Config Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:29:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:29:59 --> URI Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Router Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Output Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Security Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Input Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:29:59 --> Language Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Loader Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:29:59 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Session Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:29:59 --> Session routines successfully run
DEBUG - 2015-12-08 15:29:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Controller Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Model Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:29:59 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:29:59 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:29:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:29:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:29:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:29:59 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:29:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-08 15:29:59 --> Final output sent to browser
DEBUG - 2015-12-08 15:29:59 --> Total execution time: 0.0607
DEBUG - 2015-12-08 15:29:59 --> Config Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:29:59 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:29:59 --> URI Class Initialized
DEBUG - 2015-12-08 15:29:59 --> Router Class Initialized
ERROR - 2015-12-08 15:29:59 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:30:04 --> Config Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:30:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:30:04 --> URI Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Router Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Output Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Security Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Input Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:30:04 --> Language Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Loader Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:30:04 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Session Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:30:04 --> Session routines successfully run
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Controller Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:30:04 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:30:04 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:30:04 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:30:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:30:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:30:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:30:04 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:30:04 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-08 15:30:04 --> Final output sent to browser
DEBUG - 2015-12-08 15:30:04 --> Total execution time: 0.1783
DEBUG - 2015-12-08 15:30:05 --> Config Class Initialized
DEBUG - 2015-12-08 15:30:05 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:30:05 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:30:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:30:05 --> URI Class Initialized
DEBUG - 2015-12-08 15:30:05 --> Router Class Initialized
ERROR - 2015-12-08 15:30:05 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 15:30:07 --> Config Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:30:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:30:07 --> URI Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Router Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Output Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Security Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Input Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 15:30:07 --> Language Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Loader Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Helper loaded: url_helper
DEBUG - 2015-12-08 15:30:07 --> Database Driver Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Session Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Helper loaded: string_helper
DEBUG - 2015-12-08 15:30:07 --> Session routines successfully run
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Controller Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Model Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Helper loaded: form_helper
DEBUG - 2015-12-08 15:30:07 --> Form Validation Class Initialized
DEBUG - 2015-12-08 15:30:07 --> Pagination Class Initialized
DEBUG - 2015-12-08 15:30:07 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 15:30:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 15:30:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 15:30:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 15:30:07 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 15:30:07 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-12-08 15:30:07 --> Final output sent to browser
DEBUG - 2015-12-08 15:30:07 --> Total execution time: 0.0827
DEBUG - 2015-12-08 15:30:08 --> Config Class Initialized
DEBUG - 2015-12-08 15:30:08 --> Hooks Class Initialized
DEBUG - 2015-12-08 15:30:08 --> Utf8 Class Initialized
DEBUG - 2015-12-08 15:30:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 15:30:08 --> URI Class Initialized
DEBUG - 2015-12-08 15:30:08 --> Router Class Initialized
ERROR - 2015-12-08 15:30:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:00:21 --> Config Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:00:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:00:21 --> URI Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Router Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Output Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Security Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Input Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:00:21 --> Language Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Loader Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:00:21 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Session Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:00:21 --> Session routines successfully run
DEBUG - 2015-12-08 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Controller Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:21 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:00:21 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Config Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:00:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:00:55 --> URI Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Router Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Output Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Security Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Input Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:00:55 --> Language Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Loader Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:00:55 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Session Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:00:55 --> Session routines successfully run
DEBUG - 2015-12-08 16:00:55 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Controller Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Model Class Initialized
DEBUG - 2015-12-08 16:00:55 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:00:55 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:00:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:00:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:00:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:00:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:00:55 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:00:55 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:00:55 --> Final output sent to browser
DEBUG - 2015-12-08 16:00:55 --> Total execution time: 0.0734
DEBUG - 2015-12-08 16:00:56 --> Config Class Initialized
DEBUG - 2015-12-08 16:00:56 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:00:56 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:00:56 --> URI Class Initialized
DEBUG - 2015-12-08 16:00:56 --> Router Class Initialized
ERROR - 2015-12-08 16:00:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:01:06 --> Config Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:01:06 --> URI Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Router Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Output Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Security Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Input Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:01:06 --> Language Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Loader Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:01:06 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Session Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:01:06 --> Session routines successfully run
DEBUG - 2015-12-08 16:01:06 --> Model Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Model Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Controller Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Model Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Model Class Initialized
DEBUG - 2015-12-08 16:01:06 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:01:06 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:01:06 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:01:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:01:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:01:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:01:06 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:01:06 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:01:06 --> Final output sent to browser
DEBUG - 2015-12-08 16:01:06 --> Total execution time: 0.0486
DEBUG - 2015-12-08 16:01:07 --> Config Class Initialized
DEBUG - 2015-12-08 16:01:07 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:01:07 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:01:07 --> URI Class Initialized
DEBUG - 2015-12-08 16:01:07 --> Router Class Initialized
ERROR - 2015-12-08 16:01:07 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:03:18 --> Config Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:03:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:03:18 --> URI Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Router Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Output Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Security Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Input Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:03:18 --> Language Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Loader Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:03:18 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Session Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:03:18 --> Session routines successfully run
DEBUG - 2015-12-08 16:03:18 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Controller Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:18 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:03:18 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:03:18 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-08 16:03:18 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:03:18 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 16:03:18 --> Final output sent to browser
DEBUG - 2015-12-08 16:03:18 --> Total execution time: 0.0511
DEBUG - 2015-12-08 16:03:22 --> Config Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:03:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:03:22 --> URI Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Router Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Output Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Security Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Input Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:03:22 --> Language Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Loader Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:03:22 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Session Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:03:22 --> Session routines successfully run
DEBUG - 2015-12-08 16:03:22 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Controller Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:03:22 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:03:22 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:03:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:03:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:03:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:03:22 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:03:22 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:03:22 --> Final output sent to browser
DEBUG - 2015-12-08 16:03:22 --> Total execution time: 0.0413
DEBUG - 2015-12-08 16:03:22 --> Config Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:03:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:03:22 --> URI Class Initialized
DEBUG - 2015-12-08 16:03:22 --> Router Class Initialized
ERROR - 2015-12-08 16:03:22 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:03:43 --> Config Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:03:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:03:43 --> URI Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Router Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Output Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Security Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Input Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:03:43 --> Language Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Loader Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:03:43 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Session Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:03:43 --> Session routines successfully run
DEBUG - 2015-12-08 16:03:43 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Controller Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:03:43 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:03:43 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:03:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:03:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:03:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:03:43 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:03:43 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:03:43 --> Final output sent to browser
DEBUG - 2015-12-08 16:03:43 --> Total execution time: 0.0608
DEBUG - 2015-12-08 16:03:43 --> Config Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:03:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:03:43 --> URI Class Initialized
DEBUG - 2015-12-08 16:03:43 --> Router Class Initialized
ERROR - 2015-12-08 16:03:43 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:03:54 --> Config Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:03:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:03:54 --> URI Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Router Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Output Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Security Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Input Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:03:54 --> Language Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Loader Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:03:54 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Session Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:03:54 --> Session routines successfully run
DEBUG - 2015-12-08 16:03:54 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Controller Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Model Class Initialized
DEBUG - 2015-12-08 16:03:54 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:03:54 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:03:54 --> DB Transaction Failure
ERROR - 2015-12-08 16:03:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'like '%06%'  or  like '%06%'  or  like '%06%'  or  like '%06%'  or  like '%06%' ' at line 1
DEBUG - 2015-12-08 16:03:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-08 16:04:08 --> Config Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:04:08 --> URI Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Router Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Output Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Security Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Input Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:04:08 --> Language Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Loader Class Initialized
DEBUG - 2015-12-08 16:04:08 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:04:09 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Session Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:04:09 --> Session routines successfully run
DEBUG - 2015-12-08 16:04:09 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Controller Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:04:09 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:04:09 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:04:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:04:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:04:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:04:09 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:04:09 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:04:09 --> Final output sent to browser
DEBUG - 2015-12-08 16:04:09 --> Total execution time: 0.0602
DEBUG - 2015-12-08 16:04:09 --> Config Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:04:09 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:04:09 --> URI Class Initialized
DEBUG - 2015-12-08 16:04:09 --> Router Class Initialized
ERROR - 2015-12-08 16:04:09 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:04:12 --> Config Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:04:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:04:12 --> URI Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Router Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Output Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Security Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Input Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:04:12 --> Language Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Loader Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:04:12 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Session Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:04:12 --> Session routines successfully run
DEBUG - 2015-12-08 16:04:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Controller Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:04:12 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:04:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:04:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:04:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:04:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:04:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:04:12 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:04:12 --> Final output sent to browser
DEBUG - 2015-12-08 16:04:12 --> Total execution time: 0.0433
DEBUG - 2015-12-08 16:04:12 --> Config Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:04:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:04:12 --> URI Class Initialized
DEBUG - 2015-12-08 16:04:12 --> Router Class Initialized
ERROR - 2015-12-08 16:04:12 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:04:21 --> Config Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:04:21 --> URI Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Router Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Output Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Security Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Input Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:04:21 --> Language Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Loader Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:04:21 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Session Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:04:21 --> Session routines successfully run
DEBUG - 2015-12-08 16:04:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Controller Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Model Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:04:21 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:04:21 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:04:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:04:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:04:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:04:21 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:04:21 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:04:21 --> Final output sent to browser
DEBUG - 2015-12-08 16:04:21 --> Total execution time: 0.0424
DEBUG - 2015-12-08 16:04:21 --> Config Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:04:21 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:04:21 --> URI Class Initialized
DEBUG - 2015-12-08 16:04:21 --> Router Class Initialized
ERROR - 2015-12-08 16:04:21 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:06:45 --> Config Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:06:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:06:45 --> URI Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Router Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Output Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Security Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Input Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:06:45 --> Language Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Loader Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:06:45 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Session Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:06:45 --> Session routines successfully run
DEBUG - 2015-12-08 16:06:45 --> Model Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Model Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Controller Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Model Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Model Class Initialized
DEBUG - 2015-12-08 16:06:45 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:06:45 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:06:45 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:06:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:06:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:06:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:06:45 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:06:45 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:06:45 --> Final output sent to browser
DEBUG - 2015-12-08 16:06:45 --> Total execution time: 0.0452
DEBUG - 2015-12-08 16:06:46 --> Config Class Initialized
DEBUG - 2015-12-08 16:06:46 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:06:46 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:06:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:06:46 --> URI Class Initialized
DEBUG - 2015-12-08 16:06:46 --> Router Class Initialized
ERROR - 2015-12-08 16:06:46 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:08:32 --> Config Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:08:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:08:32 --> URI Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Router Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Output Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Security Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Input Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:08:32 --> Language Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Loader Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:08:32 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Session Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:08:32 --> Session routines successfully run
DEBUG - 2015-12-08 16:08:32 --> Model Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Model Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Controller Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Model Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Model Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:08:32 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:08:32 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:08:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:08:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:08:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:08:32 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:08:32 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 16:08:32 --> Final output sent to browser
DEBUG - 2015-12-08 16:08:32 --> Total execution time: 0.0475
DEBUG - 2015-12-08 16:08:32 --> Config Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:08:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:08:32 --> URI Class Initialized
DEBUG - 2015-12-08 16:08:32 --> Router Class Initialized
ERROR - 2015-12-08 16:08:32 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:13:50 --> Config Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:13:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:13:50 --> URI Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Router Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Output Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Security Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Input Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:13:50 --> Language Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Loader Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:13:50 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Session Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:13:50 --> Session routines successfully run
DEBUG - 2015-12-08 16:13:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Controller Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:50 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:13:50 --> Form Validation Class Initialized
ERROR - 2015-12-08 16:13:50 --> 404 Page Not Found --> form/editRecord
DEBUG - 2015-12-08 16:13:57 --> Config Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:13:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:13:57 --> URI Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Router Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Output Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Security Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Input Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:13:57 --> Language Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Loader Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:13:57 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Session Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:13:57 --> Session routines successfully run
DEBUG - 2015-12-08 16:13:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Controller Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:13:57 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:13:57 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:13:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:13:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:13:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:13:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:13:57 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:13:57 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:13:57 --> Final output sent to browser
DEBUG - 2015-12-08 16:13:57 --> Total execution time: 0.0401
DEBUG - 2015-12-08 16:13:58 --> Config Class Initialized
DEBUG - 2015-12-08 16:13:58 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:13:58 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:13:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:13:58 --> URI Class Initialized
DEBUG - 2015-12-08 16:13:58 --> Router Class Initialized
ERROR - 2015-12-08 16:13:58 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:14:46 --> Config Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:14:46 --> URI Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Router Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Output Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Security Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Input Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:14:46 --> Language Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Loader Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:14:46 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Session Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:14:46 --> Session routines successfully run
DEBUG - 2015-12-08 16:14:46 --> Model Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Model Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Controller Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Model Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Model Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:14:46 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:14:46 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:14:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:14:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:14:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:14:46 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:14:46 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:14:46 --> Final output sent to browser
DEBUG - 2015-12-08 16:14:46 --> Total execution time: 0.0568
DEBUG - 2015-12-08 16:14:46 --> Config Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:14:46 --> URI Class Initialized
DEBUG - 2015-12-08 16:14:46 --> Router Class Initialized
ERROR - 2015-12-08 16:14:46 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:15:56 --> Config Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:15:56 --> URI Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Router Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Output Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Security Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Input Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:15:56 --> Language Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Loader Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:15:56 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Session Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:15:56 --> Session routines successfully run
DEBUG - 2015-12-08 16:15:56 --> Model Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Model Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Controller Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Model Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Model Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:15:56 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:15:56 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:15:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:15:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:15:56 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-08 16:15:56 --> Severity: Notice  --> Undefined variable: subtitle /Applications/MAMP/htdocs/asmc/crm/application/views/form/editForm.php 57
DEBUG - 2015-12-08 16:15:56 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:15:56 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:15:56 --> Final output sent to browser
DEBUG - 2015-12-08 16:15:56 --> Total execution time: 0.0398
DEBUG - 2015-12-08 16:15:56 --> Config Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:15:56 --> URI Class Initialized
DEBUG - 2015-12-08 16:15:56 --> Router Class Initialized
ERROR - 2015-12-08 16:15:56 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:16:07 --> Config Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:16:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:16:07 --> URI Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Router Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Output Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Security Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Input Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:16:07 --> Language Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Loader Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:16:07 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Session Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:16:07 --> Session routines successfully run
DEBUG - 2015-12-08 16:16:07 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Controller Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:07 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:16:07 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:16:07 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:16:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:16:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:16:07 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-08 16:16:07 --> Severity: Notice  --> Undefined variable: subtitle /Applications/MAMP/htdocs/asmc/crm/application/views/form/editForm.php 57
DEBUG - 2015-12-08 16:16:07 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:16:07 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:16:07 --> Final output sent to browser
DEBUG - 2015-12-08 16:16:07 --> Total execution time: 0.0463
DEBUG - 2015-12-08 16:16:08 --> Config Class Initialized
DEBUG - 2015-12-08 16:16:08 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:16:08 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:16:08 --> URI Class Initialized
DEBUG - 2015-12-08 16:16:08 --> Router Class Initialized
ERROR - 2015-12-08 16:16:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:16:30 --> Config Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:16:30 --> URI Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Router Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Output Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Security Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Input Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:16:30 --> Language Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Loader Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:16:30 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Session Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:16:30 --> Session routines successfully run
DEBUG - 2015-12-08 16:16:30 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Controller Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:16:30 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:16:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:16:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:16:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:16:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:16:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:16:30 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:16:30 --> Final output sent to browser
DEBUG - 2015-12-08 16:16:30 --> Total execution time: 0.0422
DEBUG - 2015-12-08 16:16:30 --> Config Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:16:30 --> URI Class Initialized
DEBUG - 2015-12-08 16:16:30 --> Router Class Initialized
ERROR - 2015-12-08 16:16:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:16:42 --> Config Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:16:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:16:42 --> URI Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Router Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Output Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Security Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Input Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:16:42 --> Language Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Loader Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:16:42 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Session Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:16:42 --> Session routines successfully run
DEBUG - 2015-12-08 16:16:42 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Controller Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Model Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:16:42 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:16:42 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:16:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:16:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:16:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:16:42 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:16:42 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:16:42 --> Final output sent to browser
DEBUG - 2015-12-08 16:16:42 --> Total execution time: 0.0401
DEBUG - 2015-12-08 16:16:42 --> Config Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:16:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:16:42 --> URI Class Initialized
DEBUG - 2015-12-08 16:16:42 --> Router Class Initialized
ERROR - 2015-12-08 16:16:42 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:18:33 --> Config Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:18:33 --> URI Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Router Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Output Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Security Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Input Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:18:33 --> Language Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Loader Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:18:33 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Session Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:18:33 --> Session routines successfully run
DEBUG - 2015-12-08 16:18:33 --> Model Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Model Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Controller Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Model Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Model Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:18:33 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:18:33 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:18:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:18:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:18:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:18:33 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:18:33 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:18:33 --> Final output sent to browser
DEBUG - 2015-12-08 16:18:33 --> Total execution time: 0.0497
DEBUG - 2015-12-08 16:18:33 --> Config Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:18:33 --> URI Class Initialized
DEBUG - 2015-12-08 16:18:33 --> Router Class Initialized
ERROR - 2015-12-08 16:18:33 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:19:12 --> Config Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:19:12 --> URI Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Router Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Output Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Security Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Input Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:19:12 --> Language Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Loader Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:19:12 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Session Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:19:12 --> Session routines successfully run
DEBUG - 2015-12-08 16:19:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Controller Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Model Class Initialized
DEBUG - 2015-12-08 16:19:12 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:19:12 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:19:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:19:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:19:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:19:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:19:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:19:12 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:19:12 --> Final output sent to browser
DEBUG - 2015-12-08 16:19:12 --> Total execution time: 0.0434
DEBUG - 2015-12-08 16:19:13 --> Config Class Initialized
DEBUG - 2015-12-08 16:19:13 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:19:13 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:19:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:19:13 --> URI Class Initialized
DEBUG - 2015-12-08 16:19:13 --> Router Class Initialized
ERROR - 2015-12-08 16:19:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:23:57 --> Config Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:23:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:23:57 --> URI Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Router Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Output Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Security Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Input Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:23:57 --> Language Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Loader Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:23:57 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Session Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:23:57 --> Session routines successfully run
DEBUG - 2015-12-08 16:23:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Controller Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Model Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:23:57 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:23:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:23:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:23:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:23:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:23:57 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:23:57 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:23:57 --> Final output sent to browser
DEBUG - 2015-12-08 16:23:57 --> Total execution time: 0.0593
DEBUG - 2015-12-08 16:23:57 --> Config Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:23:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:23:57 --> URI Class Initialized
DEBUG - 2015-12-08 16:23:57 --> Router Class Initialized
ERROR - 2015-12-08 16:23:57 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:24:44 --> Config Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:24:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:24:44 --> URI Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Router Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Output Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Security Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Input Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:24:44 --> Language Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Loader Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:24:44 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Session Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:24:44 --> Session routines successfully run
DEBUG - 2015-12-08 16:24:44 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Controller Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:44 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:24:44 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Config Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:24:50 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:24:50 --> URI Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Router Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Output Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Security Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Input Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:24:50 --> Language Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Loader Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:24:50 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Session Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:24:50 --> Session routines successfully run
DEBUG - 2015-12-08 16:24:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Controller Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Model Class Initialized
DEBUG - 2015-12-08 16:24:50 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:24:50 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:24:50 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:24:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:24:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:24:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:24:50 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:24:50 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:24:50 --> Final output sent to browser
DEBUG - 2015-12-08 16:24:50 --> Total execution time: 0.0407
DEBUG - 2015-12-08 16:24:51 --> Config Class Initialized
DEBUG - 2015-12-08 16:24:51 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:24:51 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:24:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:24:51 --> URI Class Initialized
DEBUG - 2015-12-08 16:24:51 --> Router Class Initialized
ERROR - 2015-12-08 16:24:51 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 16:25:34 --> Config Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:25:34 --> URI Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Router Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Output Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Security Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Input Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 16:25:34 --> Language Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Loader Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Helper loaded: url_helper
DEBUG - 2015-12-08 16:25:34 --> Database Driver Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Session Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Helper loaded: string_helper
DEBUG - 2015-12-08 16:25:34 --> Session routines successfully run
DEBUG - 2015-12-08 16:25:34 --> Model Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Model Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Controller Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Pagination Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Model Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Model Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Helper loaded: form_helper
DEBUG - 2015-12-08 16:25:34 --> Form Validation Class Initialized
DEBUG - 2015-12-08 16:25:34 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 16:25:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 16:25:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 16:25:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 16:25:34 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 16:25:34 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 16:25:34 --> Final output sent to browser
DEBUG - 2015-12-08 16:25:34 --> Total execution time: 0.0592
DEBUG - 2015-12-08 16:25:34 --> Config Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Hooks Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Utf8 Class Initialized
DEBUG - 2015-12-08 16:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 16:25:34 --> URI Class Initialized
DEBUG - 2015-12-08 16:25:34 --> Router Class Initialized
ERROR - 2015-12-08 16:25:34 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:21:39 --> Config Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:21:39 --> URI Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Router Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Output Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Security Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Input Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:21:39 --> Language Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Loader Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:21:39 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Session Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:21:39 --> Session routines successfully run
DEBUG - 2015-12-08 17:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Controller Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Model Class Initialized
DEBUG - 2015-12-08 17:21:39 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:21:39 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:21:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:21:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:21:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:21:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:21:39 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:21:39 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 17:21:39 --> Final output sent to browser
DEBUG - 2015-12-08 17:21:39 --> Total execution time: 0.0620
DEBUG - 2015-12-08 17:21:40 --> Config Class Initialized
DEBUG - 2015-12-08 17:21:40 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:21:40 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:21:40 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:21:40 --> URI Class Initialized
DEBUG - 2015-12-08 17:21:40 --> Router Class Initialized
ERROR - 2015-12-08 17:21:40 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:25:00 --> Config Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:25:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:25:00 --> URI Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Router Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Output Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Security Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Input Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:25:00 --> Language Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Loader Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:25:00 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Session Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:25:00 --> Session routines successfully run
DEBUG - 2015-12-08 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Controller Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Model Class Initialized
DEBUG - 2015-12-08 17:25:00 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:25:00 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:25:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:25:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:25:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:25:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:25:00 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:25:00 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 17:25:00 --> Final output sent to browser
DEBUG - 2015-12-08 17:25:00 --> Total execution time: 0.0666
DEBUG - 2015-12-08 17:25:01 --> Config Class Initialized
DEBUG - 2015-12-08 17:25:01 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:25:01 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:25:01 --> URI Class Initialized
DEBUG - 2015-12-08 17:25:01 --> Router Class Initialized
ERROR - 2015-12-08 17:25:01 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:26:01 --> Config Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:26:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:26:01 --> URI Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Router Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Output Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Security Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Input Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:26:01 --> Language Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Loader Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:26:01 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Session Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:26:01 --> Session routines successfully run
DEBUG - 2015-12-08 17:26:01 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Controller Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:26:01 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:02 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:02 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:26:02 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:26:02 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:26:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:26:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:26:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:26:02 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:26:02 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 17:26:02 --> Final output sent to browser
DEBUG - 2015-12-08 17:26:02 --> Total execution time: 0.0643
DEBUG - 2015-12-08 17:26:02 --> Config Class Initialized
DEBUG - 2015-12-08 17:26:02 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:26:02 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:26:02 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:26:02 --> URI Class Initialized
DEBUG - 2015-12-08 17:26:02 --> Router Class Initialized
ERROR - 2015-12-08 17:26:02 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:26:17 --> Config Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:26:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:26:17 --> URI Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Router Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Output Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Security Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Input Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:26:17 --> Language Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Loader Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:26:17 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Session Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:26:17 --> Session routines successfully run
DEBUG - 2015-12-08 17:26:17 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Controller Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:26:17 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:26:17 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:26:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:26:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:26:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:26:17 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:26:17 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 17:26:17 --> Final output sent to browser
DEBUG - 2015-12-08 17:26:17 --> Total execution time: 0.0490
DEBUG - 2015-12-08 17:26:17 --> Config Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:26:17 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:26:17 --> URI Class Initialized
DEBUG - 2015-12-08 17:26:17 --> Router Class Initialized
ERROR - 2015-12-08 17:26:17 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:26:37 --> Config Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:26:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:26:37 --> URI Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Router Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Output Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Security Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Input Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:26:37 --> Language Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Loader Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:26:37 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Session Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:26:37 --> Session routines successfully run
DEBUG - 2015-12-08 17:26:37 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Controller Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Model Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:26:37 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:26:37 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:26:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:26:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:26:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:26:37 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:26:37 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 17:26:37 --> Final output sent to browser
DEBUG - 2015-12-08 17:26:37 --> Total execution time: 0.0656
DEBUG - 2015-12-08 17:26:37 --> Config Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:26:37 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:26:37 --> URI Class Initialized
DEBUG - 2015-12-08 17:26:37 --> Router Class Initialized
ERROR - 2015-12-08 17:26:37 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:50:04 --> Config Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:50:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:50:04 --> URI Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Router Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Output Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Security Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Input Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:50:04 --> Language Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Loader Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:50:04 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Session Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:50:04 --> Session routines successfully run
DEBUG - 2015-12-08 17:50:04 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Controller Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:04 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:50:04 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:50:04 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-08 17:50:04 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:50:04 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-08 17:50:04 --> Final output sent to browser
DEBUG - 2015-12-08 17:50:04 --> Total execution time: 0.0624
DEBUG - 2015-12-08 17:50:13 --> Config Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:50:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:50:13 --> URI Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Router Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Output Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Security Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Input Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:50:13 --> Language Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Loader Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:50:13 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Session Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:50:13 --> Session routines successfully run
DEBUG - 2015-12-08 17:50:13 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Controller Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:13 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:50:13 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:50:13 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:50:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:50:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:50:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:50:13 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:50:13 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-08 17:50:13 --> Final output sent to browser
DEBUG - 2015-12-08 17:50:13 --> Total execution time: 0.0459
DEBUG - 2015-12-08 17:50:14 --> Config Class Initialized
DEBUG - 2015-12-08 17:50:14 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:50:14 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:50:14 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:50:14 --> URI Class Initialized
DEBUG - 2015-12-08 17:50:14 --> Router Class Initialized
ERROR - 2015-12-08 17:50:14 --> 404 Page Not Found --> js
DEBUG - 2015-12-08 17:50:18 --> Config Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:50:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:50:18 --> URI Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Router Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Output Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Security Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Input Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-08 17:50:18 --> Language Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Loader Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Helper loaded: url_helper
DEBUG - 2015-12-08 17:50:18 --> Database Driver Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Session Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Helper loaded: string_helper
DEBUG - 2015-12-08 17:50:18 --> Session routines successfully run
DEBUG - 2015-12-08 17:50:18 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Controller Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Pagination Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Model Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Helper loaded: form_helper
DEBUG - 2015-12-08 17:50:18 --> Form Validation Class Initialized
DEBUG - 2015-12-08 17:50:18 --> File loaded: application/views/header.php
DEBUG - 2015-12-08 17:50:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-08 17:50:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-08 17:50:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-08 17:50:18 --> File loaded: application/views/footer.php
DEBUG - 2015-12-08 17:50:18 --> File loaded: application/views/form/editForm.php
DEBUG - 2015-12-08 17:50:18 --> Final output sent to browser
DEBUG - 2015-12-08 17:50:18 --> Total execution time: 0.0408
DEBUG - 2015-12-08 17:50:18 --> Config Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Hooks Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Utf8 Class Initialized
DEBUG - 2015-12-08 17:50:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-08 17:50:18 --> URI Class Initialized
DEBUG - 2015-12-08 17:50:18 --> Router Class Initialized
ERROR - 2015-12-08 17:50:18 --> 404 Page Not Found --> js
