<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-10-20 11:37:16 --> Config Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:37:16 --> URI Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Router Class Initialized
DEBUG - 2015-10-20 11:37:16 --> No URI present. Default controller set.
DEBUG - 2015-10-20 11:37:16 --> Output Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Security Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Input Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:37:16 --> Language Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Loader Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:37:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Session Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:37:16 --> A session cookie was not found.
DEBUG - 2015-10-20 11:37:16 --> Session routines successfully run
DEBUG - 2015-10-20 11:37:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Controller Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:37:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:37:16 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 11:37:16 --> Final output sent to browser
DEBUG - 2015-10-20 11:37:16 --> Total execution time: 0.0610
DEBUG - 2015-10-20 11:37:21 --> Config Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:37:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:37:21 --> URI Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Router Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Output Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Security Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Input Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:37:21 --> Language Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Loader Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:37:21 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Session Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:37:21 --> Session routines successfully run
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Controller Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:37:21 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 11:37:21 --> Config Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:37:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:37:21 --> URI Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Router Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Output Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Security Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Input Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:37:21 --> Language Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Loader Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:37:21 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Session Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:37:21 --> Session routines successfully run
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Controller Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:37:21 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:37:21 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:37:21 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:37:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:37:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:37:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:37:21 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:37:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-10-20 11:37:21 --> Final output sent to browser
DEBUG - 2015-10-20 11:37:21 --> Total execution time: 0.0447
DEBUG - 2015-10-20 11:37:29 --> Config Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:37:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:37:29 --> URI Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Router Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Output Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Security Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Input Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:37:29 --> Language Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Loader Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:37:29 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Session Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:37:29 --> Session routines successfully run
DEBUG - 2015-10-20 11:37:29 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Controller Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:37:29 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:37:29 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:37:29 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:37:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:37:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:37:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:37:29 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:37:29 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 11:37:29 --> Final output sent to browser
DEBUG - 2015-10-20 11:37:29 --> Total execution time: 0.0611
DEBUG - 2015-10-20 11:37:30 --> Config Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:37:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:37:30 --> URI Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Router Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Output Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Security Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Input Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:37:30 --> Language Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Loader Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:37:30 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Session Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:37:30 --> Session routines successfully run
DEBUG - 2015-10-20 11:37:30 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Controller Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:30 --> Model Class Initialized
DEBUG - 2015-10-20 11:37:31 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:37:31 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:37:31 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:37:31 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:37:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:37:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:37:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:37:31 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:37:31 --> File loaded: application/views/agent/editAgentView.php
DEBUG - 2015-10-20 11:37:31 --> Final output sent to browser
DEBUG - 2015-10-20 11:37:31 --> Total execution time: 0.0765
DEBUG - 2015-10-20 11:43:54 --> Config Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:43:54 --> URI Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Router Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Output Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Security Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Input Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:43:54 --> Language Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Loader Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:43:54 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Session Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:43:54 --> Session routines successfully run
DEBUG - 2015-10-20 11:43:54 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Controller Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:43:54 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:43:54 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:43:54 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:43:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:43:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:43:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:43:54 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:43:54 --> File loaded: application/views/agent/editAgentView.php
DEBUG - 2015-10-20 11:43:54 --> Final output sent to browser
DEBUG - 2015-10-20 11:43:54 --> Total execution time: 0.0524
DEBUG - 2015-10-20 11:43:57 --> Config Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:43:57 --> URI Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Router Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Output Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Security Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Input Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:43:57 --> Language Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Loader Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:43:57 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Session Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:43:57 --> Session routines successfully run
DEBUG - 2015-10-20 11:43:57 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Controller Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Model Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:43:57 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:43:57 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:43:57 --> DB Transaction Failure
ERROR - 2015-10-20 11:43:57 --> Query error: Unknown column 'active' in 'where clause'
DEBUG - 2015-10-20 11:43:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-20 11:44:16 --> Config Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:44:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:44:16 --> URI Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Router Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Output Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Security Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Input Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:44:16 --> Language Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Loader Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:44:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Session Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:44:16 --> Session routines successfully run
DEBUG - 2015-10-20 11:44:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Controller Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:44:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:44:16 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Config Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:44:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:44:55 --> URI Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Router Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Output Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Security Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Input Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:44:55 --> Language Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Loader Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:44:55 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Session Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:44:55 --> Session routines successfully run
DEBUG - 2015-10-20 11:44:55 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Controller Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:44:55 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:44:55 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:44:55 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:44:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:44:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:44:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:44:55 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:44:55 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:44:55 --> Final output sent to browser
DEBUG - 2015-10-20 11:44:55 --> Total execution time: 0.0436
DEBUG - 2015-10-20 11:44:59 --> Config Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:44:59 --> URI Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Router Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Output Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Security Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Input Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:44:59 --> Language Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Loader Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:44:59 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Session Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:44:59 --> Session routines successfully run
DEBUG - 2015-10-20 11:44:59 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Controller Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Model Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:44:59 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:44:59 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:44:59 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:44:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:44:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:44:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:46:46 --> Config Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:46:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:46:46 --> URI Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Router Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Output Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Security Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Input Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:46:46 --> Language Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Loader Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:46:46 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Session Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:46:46 --> Session routines successfully run
DEBUG - 2015-10-20 11:46:46 --> Model Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Model Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Controller Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Model Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:46:46 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:46:46 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:46:46 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:46:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:46:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:46:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:46:52 --> Config Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:46:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:46:52 --> URI Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Router Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Output Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Security Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Input Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:46:52 --> Language Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Loader Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:46:52 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Session Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:46:52 --> Session routines successfully run
DEBUG - 2015-10-20 11:46:52 --> Model Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Model Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Controller Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Model Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:46:52 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:46:52 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:46:52 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:46:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:46:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:46:52 --> File loaded: application/views/sidebar.php
ERROR - 2015-10-20 11:46:52 --> Severity: Notice  --> Undefined variable: dr_name /Applications/MAMP/htdocs/asmc/crm/application/views/director/addDirectorView.php 44
ERROR - 2015-10-20 11:46:52 --> Severity: Notice  --> Undefined variable: dr_email /Applications/MAMP/htdocs/asmc/crm/application/views/director/addDirectorView.php 51
ERROR - 2015-10-20 11:46:52 --> Severity: Notice  --> Undefined variable: dr_pass /Applications/MAMP/htdocs/asmc/crm/application/views/director/addDirectorView.php 58
ERROR - 2015-10-20 11:46:52 --> Severity: Notice  --> Undefined variable: dr_code /Applications/MAMP/htdocs/asmc/crm/application/views/director/addDirectorView.php 65
DEBUG - 2015-10-20 11:46:52 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:46:52 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2015-10-20 11:46:52 --> Final output sent to browser
DEBUG - 2015-10-20 11:46:52 --> Total execution time: 0.0506
DEBUG - 2015-10-20 11:48:37 --> Config Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:48:37 --> URI Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Router Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Output Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Security Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Input Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:48:37 --> Language Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Loader Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:48:37 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Session Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:48:37 --> Session routines successfully run
DEBUG - 2015-10-20 11:48:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Controller Class Initialized
DEBUG - 2015-10-20 11:48:37 --> Model Class Initialized
ERROR - 2015-10-20 11:48:37 --> Unable to load the requested class: fordr_validation
DEBUG - 2015-10-20 11:48:50 --> Config Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:48:50 --> URI Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Router Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Output Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Security Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Input Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:48:50 --> Language Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Loader Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:48:50 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Session Class Initialized
DEBUG - 2015-10-20 11:48:50 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:48:50 --> Session routines successfully run
DEBUG - 2015-10-20 11:48:50 --> Model Class Initialized
DEBUG - 2015-10-20 11:48:51 --> Model Class Initialized
DEBUG - 2015-10-20 11:48:51 --> Controller Class Initialized
DEBUG - 2015-10-20 11:48:51 --> Model Class Initialized
DEBUG - 2015-10-20 11:48:51 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:48:51 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:48:51 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:48:51 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:48:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:48:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:48:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:48:51 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:48:51 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2015-10-20 11:48:51 --> Final output sent to browser
DEBUG - 2015-10-20 11:48:51 --> Total execution time: 0.0437
DEBUG - 2015-10-20 11:49:08 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:08 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:08 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:08 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:08 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:08 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 11:49:08 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:08 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:08 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:08 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:09 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:09 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:09 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:09 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:09 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:09 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:09 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:09 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:09 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:09 --> Total execution time: 0.0388
DEBUG - 2015-10-20 11:49:12 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:12 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:12 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:12 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:12 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:12 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:12 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:12 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:12 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:12 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:12 --> File loaded: application/views/director/editDirectorView.php
DEBUG - 2015-10-20 11:49:12 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:12 --> Total execution time: 0.0445
DEBUG - 2015-10-20 11:49:16 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:16 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:16 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:16 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 11:49:16 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:16 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:16 --> File loaded: application/views/director/editDirectorView.php
DEBUG - 2015-10-20 11:49:16 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:16 --> Total execution time: 0.0440
DEBUG - 2015-10-20 11:49:17 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:17 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:17 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:17 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:17 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:17 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:17 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:17 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:17 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:17 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:17 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:17 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:17 --> Total execution time: 0.0474
DEBUG - 2015-10-20 11:49:22 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:22 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:22 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:22 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:22 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:22 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:22 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:22 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:22 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:22 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:22 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:22 --> Total execution time: 0.0425
DEBUG - 2015-10-20 11:49:24 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:24 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:24 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:24 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:24 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:24 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:24 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:24 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:24 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:24 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:24 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:24 --> Total execution time: 0.0416
DEBUG - 2015-10-20 11:49:25 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:25 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:25 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:25 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:25 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:25 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:25 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:25 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:25 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:25 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:25 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:25 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:25 --> Total execution time: 0.0372
DEBUG - 2015-10-20 11:49:26 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:26 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:26 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:26 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:26 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:26 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:26 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:26 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:26 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:26 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:26 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:26 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:26 --> Total execution time: 0.0374
DEBUG - 2015-10-20 11:49:28 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:28 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:28 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:28 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:28 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:28 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:28 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:28 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:28 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:28 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 11:49:28 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:28 --> Total execution time: 0.0386
DEBUG - 2015-10-20 11:49:37 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:37 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:37 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:37 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:37 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:37 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:37 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:37 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:37 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:37 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 11:49:37 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:37 --> Total execution time: 0.0510
DEBUG - 2015-10-20 11:49:40 --> Config Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:49:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:49:40 --> URI Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Router Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Output Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Security Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Input Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:49:40 --> Language Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Loader Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:49:40 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Session Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:49:40 --> Session routines successfully run
DEBUG - 2015-10-20 11:49:40 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Controller Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Model Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:49:40 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:49:40 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:49:40 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:49:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:49:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:49:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:49:40 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:49:40 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2015-10-20 11:49:40 --> Final output sent to browser
DEBUG - 2015-10-20 11:49:40 --> Total execution time: 0.0670
DEBUG - 2015-10-20 11:53:16 --> Config Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:53:16 --> URI Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Router Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Output Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Security Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Input Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:53:16 --> Language Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Loader Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:53:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Session Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:53:16 --> Session routines successfully run
DEBUG - 2015-10-20 11:53:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Controller Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:53:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:53:16 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:53:16 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:53:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:53:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:53:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:53:16 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:53:16 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2015-10-20 11:53:16 --> Final output sent to browser
DEBUG - 2015-10-20 11:53:16 --> Total execution time: 0.0428
DEBUG - 2015-10-20 11:53:20 --> Config Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:53:20 --> URI Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Router Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Output Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Security Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Input Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:53:20 --> Language Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Loader Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:53:20 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Session Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:53:20 --> Session routines successfully run
DEBUG - 2015-10-20 11:53:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Controller Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:53:20 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:53:20 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:53:20 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:53:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:53:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:53:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:53:20 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:53:20 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2015-10-20 11:53:20 --> Final output sent to browser
DEBUG - 2015-10-20 11:53:20 --> Total execution time: 0.0428
DEBUG - 2015-10-20 11:53:43 --> Config Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:53:43 --> URI Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Router Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Output Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Security Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Input Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:53:43 --> Language Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Loader Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:53:43 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Session Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:53:43 --> Session routines successfully run
DEBUG - 2015-10-20 11:53:43 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Controller Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Model Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:53:43 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:53:43 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:53:43 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:53:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:53:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:53:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:53:43 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:53:43 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2015-10-20 11:53:43 --> Final output sent to browser
DEBUG - 2015-10-20 11:53:43 --> Total execution time: 0.0373
DEBUG - 2015-10-20 11:54:08 --> Config Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:54:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:54:08 --> URI Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Router Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Output Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Security Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Input Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:54:08 --> Language Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Loader Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:54:08 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Session Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:54:08 --> Session routines successfully run
DEBUG - 2015-10-20 11:54:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Controller Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:54:08 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:54:08 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:54:08 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:54:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:54:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:54:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:54:08 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:54:08 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2015-10-20 11:54:08 --> Final output sent to browser
DEBUG - 2015-10-20 11:54:08 --> Total execution time: 0.0440
DEBUG - 2015-10-20 11:54:20 --> Config Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:54:20 --> URI Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Router Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Output Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Security Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Input Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:54:20 --> Language Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Loader Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:54:20 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Session Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:54:20 --> Session routines successfully run
DEBUG - 2015-10-20 11:54:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Controller Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:54:20 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:54:20 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:54:20 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:54:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:54:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:54:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:54:20 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:54:20 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 11:54:20 --> Final output sent to browser
DEBUG - 2015-10-20 11:54:20 --> Total execution time: 0.0527
DEBUG - 2015-10-20 11:54:22 --> Config Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:54:22 --> URI Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Router Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Output Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Security Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Input Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:54:22 --> Language Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Loader Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:54:22 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Session Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:54:22 --> Session routines successfully run
DEBUG - 2015-10-20 11:54:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Controller Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:54:22 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:54:22 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:54:22 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:54:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:54:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:54:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:54:22 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:54:22 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 11:54:22 --> Final output sent to browser
DEBUG - 2015-10-20 11:54:22 --> Total execution time: 0.0560
DEBUG - 2015-10-20 11:54:35 --> Config Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:54:35 --> URI Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Router Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Output Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Security Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Input Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:54:35 --> Language Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Loader Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:54:35 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Session Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:54:35 --> Session routines successfully run
DEBUG - 2015-10-20 11:54:35 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Controller Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:54:35 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:54:35 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:54:35 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:54:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:54:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:54:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:54:35 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:54:35 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 11:54:35 --> Final output sent to browser
DEBUG - 2015-10-20 11:54:35 --> Total execution time: 0.0425
DEBUG - 2015-10-20 11:54:37 --> Config Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:54:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:54:37 --> URI Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Router Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Output Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Security Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Input Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:54:37 --> Language Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Loader Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:54:37 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Session Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:54:37 --> Session routines successfully run
DEBUG - 2015-10-20 11:54:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Controller Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Model Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:54:37 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:54:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 11:54:37 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:54:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:54:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:54:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:54:37 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:54:37 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 11:54:37 --> Final output sent to browser
DEBUG - 2015-10-20 11:54:37 --> Total execution time: 0.0493
DEBUG - 2015-10-20 11:56:17 --> Config Class Initialized
DEBUG - 2015-10-20 11:56:17 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:56:17 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:56:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:56:18 --> URI Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Router Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Output Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Security Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Input Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:56:18 --> Language Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Loader Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:56:18 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Session Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:56:18 --> Session routines successfully run
DEBUG - 2015-10-20 11:56:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Controller Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:56:18 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:56:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 11:56:18 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:56:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:56:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:56:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:56:18 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:56:18 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 11:56:18 --> Final output sent to browser
DEBUG - 2015-10-20 11:56:18 --> Total execution time: 0.0478
DEBUG - 2015-10-20 11:56:21 --> Config Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:56:21 --> URI Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Router Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Output Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Security Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Input Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:56:21 --> Language Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Loader Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:56:21 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Session Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:56:21 --> Session routines successfully run
DEBUG - 2015-10-20 11:56:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Controller Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Model Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:56:21 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:56:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 11:56:21 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:56:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:56:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:56:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:56:21 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:56:21 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 11:56:21 --> Final output sent to browser
DEBUG - 2015-10-20 11:56:21 --> Total execution time: 0.0489
DEBUG - 2015-10-20 11:57:18 --> Config Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:57:18 --> URI Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Router Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Output Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Security Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Input Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:57:18 --> Language Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Loader Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:57:18 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Session Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:57:18 --> Session routines successfully run
DEBUG - 2015-10-20 11:57:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Controller Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:57:18 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:57:18 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:57:18 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:57:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:57:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:57:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:57:18 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:57:18 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 11:57:18 --> Final output sent to browser
DEBUG - 2015-10-20 11:57:18 --> Total execution time: 0.0765
DEBUG - 2015-10-20 11:57:22 --> Config Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:57:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:57:22 --> URI Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Router Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Output Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Security Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Input Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:57:22 --> Language Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Loader Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:57:22 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Session Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:57:22 --> Session routines successfully run
DEBUG - 2015-10-20 11:57:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Controller Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:57:22 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:57:22 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:57:22 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:57:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:57:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:57:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:57:22 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:57:22 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 11:57:22 --> Final output sent to browser
DEBUG - 2015-10-20 11:57:22 --> Total execution time: 0.0604
DEBUG - 2015-10-20 11:57:24 --> Config Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:57:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:57:24 --> URI Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Router Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Output Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Security Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Input Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:57:24 --> Language Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Loader Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:57:24 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Session Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:57:24 --> Session routines successfully run
DEBUG - 2015-10-20 11:57:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Controller Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Model Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:57:24 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:57:24 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:57:24 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:57:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:57:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:57:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:57:24 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:57:24 --> File loaded: application/views/agent/editAgentView.php
DEBUG - 2015-10-20 11:57:24 --> Final output sent to browser
DEBUG - 2015-10-20 11:57:24 --> Total execution time: 0.0528
DEBUG - 2015-10-20 11:58:27 --> Config Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:58:27 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:58:27 --> URI Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Router Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Output Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Security Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Input Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:58:27 --> Language Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Loader Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:58:27 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Session Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:58:27 --> Session routines successfully run
DEBUG - 2015-10-20 11:58:27 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Controller Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:58:27 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:58:27 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:58:27 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:58:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:58:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:58:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:58:27 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:58:27 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 11:58:27 --> Final output sent to browser
DEBUG - 2015-10-20 11:58:27 --> Total execution time: 0.0567
DEBUG - 2015-10-20 11:58:28 --> Config Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Hooks Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Utf8 Class Initialized
DEBUG - 2015-10-20 11:58:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 11:58:28 --> URI Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Router Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Output Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Security Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Input Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 11:58:28 --> Language Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Loader Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Helper loaded: url_helper
DEBUG - 2015-10-20 11:58:28 --> Database Driver Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Session Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Helper loaded: string_helper
DEBUG - 2015-10-20 11:58:28 --> Session routines successfully run
DEBUG - 2015-10-20 11:58:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Controller Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Model Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Helper loaded: form_helper
DEBUG - 2015-10-20 11:58:28 --> Form Validation Class Initialized
DEBUG - 2015-10-20 11:58:28 --> Pagination Class Initialized
DEBUG - 2015-10-20 11:58:28 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 11:58:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 11:58:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 11:58:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 11:58:28 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 11:58:28 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 11:58:28 --> Final output sent to browser
DEBUG - 2015-10-20 11:58:28 --> Total execution time: 0.0602
DEBUG - 2015-10-20 12:00:18 --> Config Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:00:18 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:00:18 --> URI Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Router Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Output Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Security Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Input Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:00:18 --> Language Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Loader Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:00:18 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Session Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:00:18 --> Session routines successfully run
DEBUG - 2015-10-20 12:00:18 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Controller Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:00:18 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:00:18 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:00:18 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:00:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:00:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:00:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:00:18 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:00:18 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 12:00:18 --> Final output sent to browser
DEBUG - 2015-10-20 12:00:18 --> Total execution time: 0.0535
DEBUG - 2015-10-20 12:00:20 --> Config Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:00:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:00:20 --> URI Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Router Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Output Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Security Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Input Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:00:20 --> Language Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Loader Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:00:20 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Session Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:00:20 --> Session routines successfully run
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Controller Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:00:20 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Config Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:00:20 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:00:20 --> URI Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Router Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Output Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Security Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Input Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:00:20 --> Language Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Loader Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:00:20 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Session Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:00:20 --> Session routines successfully run
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Controller Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:20 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:00:20 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:00:20 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 12:00:20 --> Final output sent to browser
DEBUG - 2015-10-20 12:00:20 --> Total execution time: 0.0345
DEBUG - 2015-10-20 12:00:42 --> Config Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:00:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:00:42 --> URI Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Router Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Output Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Security Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Input Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:00:42 --> Language Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Loader Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:00:42 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Session Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:00:42 --> Session routines successfully run
DEBUG - 2015-10-20 12:00:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Controller Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:00:42 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:00:42 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-10-20 12:00:42 --> Severity: Notice  --> Undefined property: Login::$Director_model /Applications/MAMP/htdocs/asmc/crm/application/controllers/login.php 107
DEBUG - 2015-10-20 12:00:58 --> Config Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:00:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:00:58 --> URI Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Router Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Output Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Security Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Input Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:00:58 --> Language Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Loader Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:00:58 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Session Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:00:58 --> Session routines successfully run
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Controller Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:00:58 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:00:58 --> Config Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:00:58 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:00:58 --> URI Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Router Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Output Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Security Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Input Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:00:58 --> Language Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Loader Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:00:58 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Session Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:00:58 --> Session routines successfully run
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Model Class Initialized
DEBUG - 2015-10-20 12:00:58 --> Controller Class Initialized
DEBUG - 2015-10-20 12:01:01 --> Config Class Initialized
DEBUG - 2015-10-20 12:01:01 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:01:01 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:01:01 --> URI Class Initialized
DEBUG - 2015-10-20 12:01:01 --> Router Class Initialized
ERROR - 2015-10-20 12:01:01 --> 404 Page Not Found --> managers
DEBUG - 2015-10-20 12:01:15 --> Config Class Initialized
DEBUG - 2015-10-20 12:01:15 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:01:15 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:01:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:01:15 --> URI Class Initialized
DEBUG - 2015-10-20 12:01:15 --> Router Class Initialized
ERROR - 2015-10-20 12:01:15 --> 404 Page Not Found --> managers
DEBUG - 2015-10-20 12:01:17 --> Config Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:01:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:01:17 --> URI Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Router Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Output Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Security Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Input Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:01:17 --> Language Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Loader Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:01:17 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Session Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:01:17 --> Session routines successfully run
DEBUG - 2015-10-20 12:01:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Controller Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:01:17 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:01:17 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:01:17 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:01:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:01:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:01:17 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:01:17 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:01:17 --> Final output sent to browser
DEBUG - 2015-10-20 12:01:17 --> Total execution time: 0.0470
DEBUG - 2015-10-20 12:01:51 --> Config Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:01:51 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:01:51 --> URI Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Router Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Output Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Security Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Input Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:01:51 --> Language Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Loader Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:01:51 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Session Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:01:51 --> Session routines successfully run
DEBUG - 2015-10-20 12:01:51 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Controller Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Model Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:01:51 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:01:51 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:01:51 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:01:51 --> File loaded: application/views/navbar.php
ERROR - 2015-10-20 12:01:51 --> Severity: Notice  --> Undefined variable: id /Applications/MAMP/htdocs/asmc/crm/application/views/sidebar_director.php 68
DEBUG - 2015-10-20 12:01:51 --> DB Transaction Failure
ERROR - 2015-10-20 12:01:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'and msg_read = 0  order by msg_sent_date desc' at line 1
DEBUG - 2015-10-20 12:01:51 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-10-20 12:02:39 --> Config Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:02:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:02:39 --> URI Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Router Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Output Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Security Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Input Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:02:39 --> Language Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Loader Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:02:39 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Session Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:02:39 --> Session routines successfully run
DEBUG - 2015-10-20 12:02:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Controller Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:02:39 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:02:39 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:02:39 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:02:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:02:39 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:02:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:02:39 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:02:39 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:02:39 --> Final output sent to browser
DEBUG - 2015-10-20 12:02:39 --> Total execution time: 0.0427
DEBUG - 2015-10-20 12:02:44 --> Config Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:02:44 --> URI Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Router Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Output Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Security Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Input Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:02:44 --> Language Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Loader Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:02:44 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Session Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:02:44 --> Session routines successfully run
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Controller Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:02:44 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:02:44 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:02:44 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:02:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:02:44 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:02:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:02:44 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:02:44 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 12:02:44 --> Final output sent to browser
DEBUG - 2015-10-20 12:02:44 --> Total execution time: 0.1415
DEBUG - 2015-10-20 12:02:53 --> Config Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:02:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:02:53 --> URI Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Router Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Output Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Security Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Input Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:02:53 --> Language Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Loader Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:02:53 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Session Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:02:53 --> Session routines successfully run
DEBUG - 2015-10-20 12:02:53 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Controller Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:53 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:02:53 --> Form Validation Class Initialized
ERROR - 2015-10-20 12:02:53 --> Severity: Notice  --> Undefined variable: id /Applications/MAMP/htdocs/asmc/crm/application/controllers/message.php 71
DEBUG - 2015-10-20 12:02:53 --> DB Transaction Failure
ERROR - 2015-10-20 12:02:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by msg_sent_date desc' at line 1
DEBUG - 2015-10-20 12:02:53 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-10-20 12:02:53 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 442
DEBUG - 2015-10-20 12:02:56 --> Config Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:02:56 --> URI Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Router Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Output Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Security Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Input Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:02:56 --> Language Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Loader Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:02:56 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Session Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:02:56 --> Session routines successfully run
DEBUG - 2015-10-20 12:02:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Controller Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:02:56 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:02:56 --> Form Validation Class Initialized
ERROR - 2015-10-20 12:02:56 --> Severity: Notice  --> Undefined variable: id /Applications/MAMP/htdocs/asmc/crm/application/controllers/message.php 51
DEBUG - 2015-10-20 12:02:56 --> DB Transaction Failure
ERROR - 2015-10-20 12:02:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by msg_sent_date desc' at line 1
DEBUG - 2015-10-20 12:02:56 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-10-20 12:02:56 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 442
DEBUG - 2015-10-20 12:07:13 --> Config Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:07:13 --> URI Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Router Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Output Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Security Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Input Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:07:13 --> Language Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Loader Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:07:13 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Session Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:07:13 --> Session routines successfully run
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Controller Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:07:13 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:07:13 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:07:13 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:07:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:07:13 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:07:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:07:13 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:07:13 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 12:07:13 --> Final output sent to browser
DEBUG - 2015-10-20 12:07:13 --> Total execution time: 0.1003
DEBUG - 2015-10-20 12:09:34 --> Config Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:09:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:09:34 --> URI Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Router Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Output Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Security Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Input Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:09:34 --> Language Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Loader Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:09:34 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Session Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:09:34 --> Session routines successfully run
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Controller Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:34 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:09:34 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:09:34 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:09:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:09:34 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:09:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:09:34 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:09:34 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:09:34 --> Final output sent to browser
DEBUG - 2015-10-20 12:09:34 --> Total execution time: 0.0687
DEBUG - 2015-10-20 12:09:37 --> Config Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:09:37 --> URI Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Router Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Output Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Security Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Input Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:09:37 --> Language Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Loader Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:09:37 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Session Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:09:37 --> Session routines successfully run
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Controller Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:37 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:09:37 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:09:37 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:09:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:09:37 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:09:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:09:37 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:09:37 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:09:37 --> Final output sent to browser
DEBUG - 2015-10-20 12:09:37 --> Total execution time: 0.0479
DEBUG - 2015-10-20 12:09:38 --> Config Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:09:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:09:38 --> URI Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Router Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Output Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Security Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Input Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:09:38 --> Language Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Loader Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:09:38 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Session Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:09:38 --> Session routines successfully run
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Controller Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:38 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:09:38 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:09:38 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:09:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:09:38 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:09:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:09:38 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:09:38 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:09:38 --> Final output sent to browser
DEBUG - 2015-10-20 12:09:38 --> Total execution time: 0.0428
DEBUG - 2015-10-20 12:09:39 --> Config Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:09:39 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:09:39 --> URI Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Router Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Output Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Security Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Input Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:09:39 --> Language Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Loader Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:09:39 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Session Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:09:39 --> Session routines successfully run
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Controller Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:39 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:09:39 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:09:39 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:09:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:09:39 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:09:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:09:39 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:09:39 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-10-20 12:09:39 --> Final output sent to browser
DEBUG - 2015-10-20 12:09:39 --> Total execution time: 0.0534
DEBUG - 2015-10-20 12:09:50 --> Config Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:09:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:09:50 --> URI Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Router Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Output Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Security Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Input Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:09:50 --> Language Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Loader Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:09:50 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Session Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:09:50 --> Session routines successfully run
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Controller Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:09:50 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:09:50 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:09:50 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:09:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:09:50 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:09:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:09:50 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:09:50 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:09:50 --> Final output sent to browser
DEBUG - 2015-10-20 12:09:50 --> Total execution time: 0.0544
DEBUG - 2015-10-20 12:10:30 --> Config Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:10:30 --> URI Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Router Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Output Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Security Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Input Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:10:30 --> Language Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Loader Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:10:30 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Session Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:10:30 --> Session routines successfully run
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Controller Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:10:30 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:10:30 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:10:30 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:10:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:10:30 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:10:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:10:30 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:10:30 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:10:30 --> Final output sent to browser
DEBUG - 2015-10-20 12:10:30 --> Total execution time: 0.0515
DEBUG - 2015-10-20 12:11:08 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:08 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:08 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:08 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:08 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:08 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:08 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:11:08 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:11:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:11:08 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:11:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:11:08 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:11:08 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:11:08 --> Final output sent to browser
DEBUG - 2015-10-20 12:11:08 --> Total execution time: 0.0406
DEBUG - 2015-10-20 12:11:13 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:13 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:13 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:13 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:13 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:13 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:11:13 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:13 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:13 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:13 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:13 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:13 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:13 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:11:13 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:11:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:11:13 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:11:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:11:13 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:11:13 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:11:13 --> Final output sent to browser
DEBUG - 2015-10-20 12:11:13 --> Total execution time: 0.0386
DEBUG - 2015-10-20 12:11:15 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:15 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:15 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:15 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:15 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:15 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:15 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:11:15 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:11:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:11:15 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:11:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:11:15 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:11:15 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:11:15 --> Final output sent to browser
DEBUG - 2015-10-20 12:11:15 --> Total execution time: 0.0534
DEBUG - 2015-10-20 12:11:16 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:16 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:16 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:16 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:11:16 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:11:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:11:16 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:11:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:11:16 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:11:16 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-10-20 12:11:16 --> Final output sent to browser
DEBUG - 2015-10-20 12:11:16 --> Total execution time: 0.0464
DEBUG - 2015-10-20 12:11:17 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:17 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:17 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:17 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:17 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:17 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:17 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:17 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:11:17 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:11:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:11:17 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:11:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:11:17 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:11:17 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-10-20 12:11:17 --> Final output sent to browser
DEBUG - 2015-10-20 12:11:17 --> Total execution time: 0.0509
DEBUG - 2015-10-20 12:11:56 --> Config Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:11:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:11:56 --> URI Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Router Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Output Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Security Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Input Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:11:56 --> Language Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Loader Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:11:56 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Session Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:11:56 --> Session routines successfully run
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Controller Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:11:56 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:11:56 --> Form Validation Class Initialized
ERROR - 2015-10-20 12:11:56 --> Severity: Notice  --> Undefined variable: sender /Applications/MAMP/htdocs/asmc/crm/application/models/message_model.php 130
DEBUG - 2015-10-20 12:11:56 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:11:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:11:56 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:11:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:11:56 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:11:56 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:11:56 --> Final output sent to browser
DEBUG - 2015-10-20 12:11:56 --> Total execution time: 0.0565
DEBUG - 2015-10-20 12:14:19 --> Config Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:14:19 --> URI Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Router Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Output Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Security Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Input Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:14:19 --> Language Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Loader Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:14:19 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Session Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:14:19 --> Session routines successfully run
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Controller Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:14:19 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:14:19 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:14:19 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:14:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:14:19 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:14:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:14:19 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:14:19 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:14:19 --> Final output sent to browser
DEBUG - 2015-10-20 12:14:19 --> Total execution time: 0.0513
DEBUG - 2015-10-20 12:15:00 --> Config Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:15:00 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:15:00 --> URI Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Router Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Output Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Security Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Input Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:15:00 --> Language Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Loader Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:15:00 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Session Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:15:00 --> Session routines successfully run
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Controller Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:00 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:15:00 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:15:00 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:15:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:15:00 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:15:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:15:00 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:15:00 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:15:00 --> Final output sent to browser
DEBUG - 2015-10-20 12:15:00 --> Total execution time: 0.0503
DEBUG - 2015-10-20 12:15:24 --> Config Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:15:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:15:24 --> URI Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Router Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Output Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Security Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Input Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:15:24 --> Language Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Loader Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:15:24 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Session Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:15:24 --> Session routines successfully run
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Controller Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:15:24 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:15:24 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:15:24 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:15:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:15:24 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:15:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:15:24 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:15:24 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:15:24 --> Final output sent to browser
DEBUG - 2015-10-20 12:15:24 --> Total execution time: 0.0445
DEBUG - 2015-10-20 12:16:04 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:04 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:04 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:04 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:04 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:04 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:04 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:04 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:04 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:04 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:04 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:04 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:04 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 12:16:04 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:04 --> Total execution time: 0.0367
DEBUG - 2015-10-20 12:16:09 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:09 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:09 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:09 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:09 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:09 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:16:09 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:09 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:09 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:09 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:09 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:09 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:09 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:16:09 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:16:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:16:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:16:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:16:09 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:16:09 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-10-20 12:16:09 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:09 --> Total execution time: 0.0451
DEBUG - 2015-10-20 12:16:11 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:11 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:11 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:11 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:11 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:11 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:11 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:11 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:11 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:16:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:16:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:16:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:16:11 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:16:11 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:16:11 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:11 --> Total execution time: 0.0575
DEBUG - 2015-10-20 12:16:13 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:13 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:13 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:13 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:13 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:13 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:13 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:13 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:13 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:16:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:16:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:16:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:16:13 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:16:13 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:16:13 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:13 --> Total execution time: 0.0459
DEBUG - 2015-10-20 12:16:16 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:16 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:16 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:16 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:16 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:16:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:16:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:16:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:16:16 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:16:16 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:16:16 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:16 --> Total execution time: 0.0457
DEBUG - 2015-10-20 12:16:42 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:42 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:42 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:42 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:42 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:42 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:42 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:42 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:16:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:16:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:16:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:16:42 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:16:42 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:16:42 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:42 --> Total execution time: 0.0382
DEBUG - 2015-10-20 12:16:49 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:49 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:49 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:49 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:49 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:49 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:49 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:49 --> Total execution time: 0.0424
DEBUG - 2015-10-20 12:16:56 --> Config Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:16:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:16:56 --> URI Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Router Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Output Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Security Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Input Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:16:56 --> Language Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Loader Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:16:56 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Session Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:16:56 --> Session routines successfully run
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Controller Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:16:56 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:16:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:16:56 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:16:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:16:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:16:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:16:56 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:16:56 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:16:56 --> Final output sent to browser
DEBUG - 2015-10-20 12:16:56 --> Total execution time: 0.0515
DEBUG - 2015-10-20 12:17:05 --> Config Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:17:05 --> URI Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Router Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Output Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Security Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Input Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:17:05 --> Language Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Loader Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:17:05 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Session Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:17:05 --> Session routines successfully run
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Controller Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:17:05 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:17:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:17:05 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:17:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:17:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:17:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:17:05 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:17:05 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:17:05 --> Final output sent to browser
DEBUG - 2015-10-20 12:17:05 --> Total execution time: 0.0463
DEBUG - 2015-10-20 12:17:09 --> Config Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:17:09 --> URI Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Router Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Output Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Security Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Input Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:17:09 --> Language Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Loader Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:17:09 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Session Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:17:09 --> Session routines successfully run
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Controller Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:17:09 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:17:09 --> Final output sent to browser
DEBUG - 2015-10-20 12:17:09 --> Total execution time: 0.0381
DEBUG - 2015-10-20 12:17:12 --> Config Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:17:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:17:12 --> URI Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Router Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Output Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Security Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Input Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:17:12 --> Language Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Loader Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:17:12 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Session Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:17:12 --> Session routines successfully run
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Controller Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:17:12 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:17:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:17:12 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:17:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:17:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:17:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:17:12 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:17:12 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:17:12 --> Final output sent to browser
DEBUG - 2015-10-20 12:17:12 --> Total execution time: 0.0423
DEBUG - 2015-10-20 12:18:09 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:09 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:09 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:09 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:09 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:09 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:09 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:09 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:09 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:09 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:18:09 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:09 --> Total execution time: 0.0560
DEBUG - 2015-10-20 12:18:16 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:16 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:16 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:16 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:18:28 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:28 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:28 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:28 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:28 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:28 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:18:28 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:28 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:28 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:28 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:28 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:28 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:28 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:28 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:28 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:28 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:18:28 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:28 --> Total execution time: 0.0380
DEBUG - 2015-10-20 12:18:33 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:33 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:33 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:33 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:33 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:33 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:33 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:33 --> Total execution time: 0.0367
DEBUG - 2015-10-20 12:18:40 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:40 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:40 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:40 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:40 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:40 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:18:40 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:40 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:40 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:40 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:40 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:40 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:40 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:40 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:40 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:40 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2015-10-20 12:18:40 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:40 --> Total execution time: 0.0539
DEBUG - 2015-10-20 12:18:43 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:43 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:43 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:43 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:43 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:43 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:43 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:43 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:43 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:43 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-10-20 12:18:43 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:43 --> Total execution time: 0.0546
DEBUG - 2015-10-20 12:18:44 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:44 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:44 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:44 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:44 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:44 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:44 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:44 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:44 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:44 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:18:44 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:44 --> Total execution time: 0.0583
DEBUG - 2015-10-20 12:18:45 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:45 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:45 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:45 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:45 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:45 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:45 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:45 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:45 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:45 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:45 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:18:45 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:45 --> Total execution time: 0.0508
DEBUG - 2015-10-20 12:18:49 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:49 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:49 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:49 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:49 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:49 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:18:49 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:49 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:49 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:49 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:49 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:49 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:49 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:49 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:49 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:18:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:18:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:18:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:18:49 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:18:49 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:18:49 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:49 --> Total execution time: 0.0501
DEBUG - 2015-10-20 12:18:52 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:52 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:52 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:52 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:52 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:52 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Config Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:18:52 --> URI Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Router Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Output Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Security Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Input Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:18:52 --> Language Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Loader Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:18:52 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Session Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:18:52 --> Session routines successfully run
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Controller Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:18:52 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:18:52 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:18:52 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 12:18:52 --> Final output sent to browser
DEBUG - 2015-10-20 12:18:52 --> Total execution time: 0.0323
DEBUG - 2015-10-20 12:19:04 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:04 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:04 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:04 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:04 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:04 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:19:04 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:04 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:04 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:04 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:04 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:04 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:04 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:19:04 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:19:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:19:04 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:19:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:19:04 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:19:04 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:19:04 --> Final output sent to browser
DEBUG - 2015-10-20 12:19:04 --> Total execution time: 0.0458
DEBUG - 2015-10-20 12:19:06 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:06 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:06 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:06 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:06 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:06 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:06 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:06 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:19:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:19:06 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:19:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:19:06 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:19:06 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:19:06 --> Final output sent to browser
DEBUG - 2015-10-20 12:19:06 --> Total execution time: 0.0485
DEBUG - 2015-10-20 12:19:12 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:12 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:12 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:12 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:12 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:12 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:12 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:12 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:19:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:19:12 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:19:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:19:12 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:19:12 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-10-20 12:19:12 --> Final output sent to browser
DEBUG - 2015-10-20 12:19:12 --> Total execution time: 0.0545
DEBUG - 2015-10-20 12:19:14 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:14 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:14 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:14 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:14 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:14 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:14 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:14 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:19:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:19:14 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:19:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:19:14 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:19:14 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-10-20 12:19:14 --> Final output sent to browser
DEBUG - 2015-10-20 12:19:14 --> Total execution time: 0.0516
DEBUG - 2015-10-20 12:19:16 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:16 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:16 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:16 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:16 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:16 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:16 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:16 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:16 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:19:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:19:16 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:19:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:19:16 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:19:16 --> File loaded: application/views/message/readView.php
DEBUG - 2015-10-20 12:19:16 --> Final output sent to browser
DEBUG - 2015-10-20 12:19:16 --> Total execution time: 0.0481
DEBUG - 2015-10-20 12:19:31 --> Config Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:19:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:19:31 --> URI Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Router Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Output Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Security Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Input Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:19:31 --> Language Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Loader Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:19:31 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Session Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:19:31 --> Session routines successfully run
DEBUG - 2015-10-20 12:19:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Controller Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:19:31 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:19:31 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:19:31 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:19:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:19:31 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:19:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:19:31 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:19:31 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:19:31 --> Final output sent to browser
DEBUG - 2015-10-20 12:19:31 --> Total execution time: 0.0743
DEBUG - 2015-10-20 12:23:57 --> Config Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:23:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:23:57 --> URI Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Router Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Output Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Security Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Input Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:23:57 --> Language Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Loader Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:23:57 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Session Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:23:57 --> Session routines successfully run
DEBUG - 2015-10-20 12:23:57 --> Model Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Model Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Controller Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Model Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Model Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:23:57 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:23:57 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:23:57 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:23:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:23:57 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:23:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:23:57 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:23:57 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:23:57 --> Final output sent to browser
DEBUG - 2015-10-20 12:23:57 --> Total execution time: 0.0453
DEBUG - 2015-10-20 12:24:04 --> Config Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:24:04 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:24:04 --> URI Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Router Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Output Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Security Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Input Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:24:04 --> Language Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Loader Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:24:04 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Session Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:24:04 --> Session routines successfully run
DEBUG - 2015-10-20 12:24:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Controller Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Model Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:24:04 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:24:04 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:24:04 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:24:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:24:04 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:24:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:24:04 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:24:04 --> File loaded: application/views/manager/editManagerView.php
DEBUG - 2015-10-20 12:24:04 --> Final output sent to browser
DEBUG - 2015-10-20 12:24:04 --> Total execution time: 0.0382
DEBUG - 2015-10-20 12:24:10 --> Config Class Initialized
DEBUG - 2015-10-20 12:24:10 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:24:10 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:24:11 --> URI Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Router Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Output Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Security Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Input Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:24:11 --> Language Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Loader Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:24:11 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Session Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:24:11 --> Session routines successfully run
DEBUG - 2015-10-20 12:24:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Model Class Initialized
DEBUG - 2015-10-20 12:24:11 --> Controller Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Config Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:24:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:24:44 --> URI Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Router Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Output Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Security Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Input Class Initialized
DEBUG - 2015-10-20 12:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:24:44 --> Language Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Config Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:25:01 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:25:01 --> URI Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Router Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Output Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Security Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Input Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:25:01 --> Language Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Loader Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:25:01 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Session Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:25:01 --> Session routines successfully run
DEBUG - 2015-10-20 12:25:01 --> Model Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Model Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Controller Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Model Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Model Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:25:01 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:25:01 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:25:01 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:25:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:25:01 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:25:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:25:01 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:25:01 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:25:01 --> Final output sent to browser
DEBUG - 2015-10-20 12:25:01 --> Total execution time: 0.0738
DEBUG - 2015-10-20 12:26:09 --> Config Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:26:09 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:26:09 --> URI Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Router Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Output Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Security Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Input Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:26:09 --> Language Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Loader Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:26:09 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Session Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:26:09 --> Session routines successfully run
DEBUG - 2015-10-20 12:26:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Controller Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:26:09 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:26:09 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:26:09 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:26:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:26:09 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:26:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:26:09 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:26:09 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:26:09 --> Final output sent to browser
DEBUG - 2015-10-20 12:26:09 --> Total execution time: 0.0811
DEBUG - 2015-10-20 12:26:15 --> Config Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:26:15 --> URI Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Router Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Output Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Security Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Input Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:26:15 --> Language Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Loader Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:26:15 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Session Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:26:15 --> Session routines successfully run
DEBUG - 2015-10-20 12:26:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Controller Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Model Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:26:15 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:26:15 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:26:15 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:26:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:26:15 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:26:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:26:15 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:26:15 --> File loaded: application/views/changePass.php
DEBUG - 2015-10-20 12:26:15 --> Final output sent to browser
DEBUG - 2015-10-20 12:26:15 --> Total execution time: 0.0706
DEBUG - 2015-10-20 12:31:26 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:26 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:26 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:26 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:26 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:26 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:26 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:26 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:26 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:26 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:26 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:26 --> File loaded: application/views/changePass.php
DEBUG - 2015-10-20 12:31:26 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:26 --> Total execution time: 0.0503
DEBUG - 2015-10-20 12:31:29 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:29 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:29 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:29 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:29 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:29 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:29 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:29 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:29 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:29 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:29 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:29 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:31:29 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:29 --> Total execution time: 0.0523
DEBUG - 2015-10-20 12:31:40 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:40 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:40 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:40 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:40 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:40 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:40 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:40 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:40 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:40 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:40 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:31:40 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:40 --> Total execution time: 0.0532
DEBUG - 2015-10-20 12:31:47 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:47 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:47 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:47 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:47 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:48 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:48 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:48 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:48 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:48 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:48 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:48 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:48 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:31:48 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:48 --> Total execution time: 0.0586
DEBUG - 2015-10-20 12:31:50 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:50 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:50 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:50 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:50 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:50 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:50 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:50 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:50 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:50 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:50 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:31:50 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:50 --> Total execution time: 0.0499
DEBUG - 2015-10-20 12:31:52 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:52 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:52 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:52 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:52 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:52 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:52 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:52 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:52 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:52 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:52 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:52 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:31:52 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:52 --> Total execution time: 0.0587
DEBUG - 2015-10-20 12:31:56 --> Config Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:31:56 --> URI Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Router Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Output Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Security Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Input Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:31:56 --> Language Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Loader Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:31:56 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Session Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:31:56 --> Session routines successfully run
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Controller Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Model Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:31:56 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:31:56 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:31:56 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:31:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:31:56 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 12:31:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:31:56 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:31:56 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 12:31:56 --> Final output sent to browser
DEBUG - 2015-10-20 12:31:56 --> Total execution time: 0.1008
DEBUG - 2015-10-20 12:32:14 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:14 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:14 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:14 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:14 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:14 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:14 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:14 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:14 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:14 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:14 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:14 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:14 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 12:32:14 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:14 --> Total execution time: 0.0388
DEBUG - 2015-10-20 12:32:24 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:24 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:24 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:24 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:24 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:24 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:32:24 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:24 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:24 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:24 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:24 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:24 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:24 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:32:24 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:32:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:32:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:32:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:32:24 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:32:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-10-20 12:32:24 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:24 --> Total execution time: 0.0404
DEBUG - 2015-10-20 12:32:28 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:28 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:28 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:28 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:28 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:28 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:28 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:28 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:32:28 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:32:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:32:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:32:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:32:28 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:32:28 --> File loaded: application/views/director/directorListView.php
DEBUG - 2015-10-20 12:32:28 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:28 --> Total execution time: 0.0428
DEBUG - 2015-10-20 12:32:30 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:30 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:30 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:30 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:30 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:30 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:30 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:30 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:32:30 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:32:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:32:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:32:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:32:30 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:32:30 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 12:32:30 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:30 --> Total execution time: 0.0754
DEBUG - 2015-10-20 12:32:31 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:31 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:31 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:31 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:31 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:31 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:31 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:31 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:32:31 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:32:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:32:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:32:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:32:31 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:32:31 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:32:31 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:31 --> Total execution time: 0.0553
DEBUG - 2015-10-20 12:32:34 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:34 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:34 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:34 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:34 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:34 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:34 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:32:34 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:32:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:32:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 12:32:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:32:34 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:32:34 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 12:32:34 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:34 --> Total execution time: 0.0953
DEBUG - 2015-10-20 12:32:41 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:41 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:41 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:41 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:41 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:41 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Config Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:32:41 --> URI Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Router Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Output Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Security Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Input Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:32:41 --> Language Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Loader Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:32:41 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Session Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:32:41 --> Session routines successfully run
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Controller Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Model Class Initialized
DEBUG - 2015-10-20 12:32:41 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:32:41 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:32:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 12:32:41 --> Final output sent to browser
DEBUG - 2015-10-20 12:32:41 --> Total execution time: 0.0335
DEBUG - 2015-10-20 12:33:02 --> Config Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:33:02 --> URI Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Router Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Output Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Security Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Input Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:33:02 --> Language Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Loader Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:33:02 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Session Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:33:02 --> Session routines successfully run
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Controller Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:33:02 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 12:33:02 --> Config Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:33:02 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:33:02 --> URI Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Router Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Output Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Security Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Input Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:33:02 --> Language Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Loader Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:33:02 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Session Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:33:02 --> Session routines successfully run
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Controller Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:33:02 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:33:02 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:33:02 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:33:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:33:02 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-10-20 12:33:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:33:02 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:33:02 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-10-20 12:33:02 --> Final output sent to browser
DEBUG - 2015-10-20 12:33:02 --> Total execution time: 0.0364
DEBUG - 2015-10-20 12:33:06 --> Config Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:33:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:33:06 --> URI Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Router Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Output Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Security Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Input Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:33:06 --> Language Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Loader Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:33:06 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Session Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:33:06 --> Session routines successfully run
DEBUG - 2015-10-20 12:33:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Controller Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:06 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:07 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:07 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:07 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:33:07 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:33:07 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:33:07 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:33:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:33:07 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-10-20 12:33:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:33:07 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:33:07 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 12:33:07 --> Final output sent to browser
DEBUG - 2015-10-20 12:33:07 --> Total execution time: 0.0704
DEBUG - 2015-10-20 12:33:19 --> Config Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:33:19 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:33:19 --> URI Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Router Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Output Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Security Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Input Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:33:19 --> Language Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Loader Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:33:19 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Session Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:33:19 --> Session routines successfully run
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Controller Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:33:19 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:33:19 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:33:19 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:33:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:33:19 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-10-20 12:33:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:33:19 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:33:19 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-10-20 12:33:19 --> Final output sent to browser
DEBUG - 2015-10-20 12:33:19 --> Total execution time: 0.0770
DEBUG - 2015-10-20 12:33:21 --> Config Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:33:21 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:33:21 --> URI Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Router Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Output Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Security Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Input Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:33:21 --> Language Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Loader Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:33:21 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Session Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:33:21 --> Session routines successfully run
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Controller Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:33:21 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:33:21 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:33:21 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:33:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:33:21 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-10-20 12:33:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:33:21 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:33:21 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 12:33:21 --> Final output sent to browser
DEBUG - 2015-10-20 12:33:21 --> Total execution time: 0.0656
DEBUG - 2015-10-20 12:33:22 --> Config Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Hooks Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Utf8 Class Initialized
DEBUG - 2015-10-20 12:33:22 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 12:33:22 --> URI Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Router Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Output Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Security Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Input Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 12:33:22 --> Language Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Loader Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Helper loaded: url_helper
DEBUG - 2015-10-20 12:33:22 --> Database Driver Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Session Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Helper loaded: string_helper
DEBUG - 2015-10-20 12:33:22 --> Session routines successfully run
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Controller Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Model Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Helper loaded: form_helper
DEBUG - 2015-10-20 12:33:22 --> Form Validation Class Initialized
DEBUG - 2015-10-20 12:33:22 --> Pagination Class Initialized
DEBUG - 2015-10-20 12:33:22 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 12:33:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 12:33:22 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-10-20 12:33:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 12:33:22 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 12:33:22 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-10-20 12:33:22 --> Final output sent to browser
DEBUG - 2015-10-20 12:33:22 --> Total execution time: 0.0616
DEBUG - 2015-10-20 13:04:32 --> Config Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:04:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:04:32 --> URI Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Router Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Output Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Security Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Input Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:04:32 --> Language Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Loader Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:04:32 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Session Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:04:32 --> Session routines successfully run
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Controller Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:04:32 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Config Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:04:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:04:32 --> URI Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Router Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Output Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Security Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Input Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:04:32 --> Language Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Loader Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:04:32 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Session Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:04:32 --> Session routines successfully run
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Controller Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:32 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:04:32 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:04:32 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 13:04:32 --> Final output sent to browser
DEBUG - 2015-10-20 13:04:32 --> Total execution time: 0.0435
DEBUG - 2015-10-20 13:04:41 --> Config Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:04:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:04:41 --> URI Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Router Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Output Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Security Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Input Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:04:41 --> Language Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Loader Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:04:41 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Session Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:04:41 --> Session routines successfully run
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Controller Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:04:41 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 13:04:41 --> Config Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:04:41 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:04:41 --> URI Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Router Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Output Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Security Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Input Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:04:41 --> Language Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Loader Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:04:41 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Session Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:04:41 --> Session routines successfully run
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Controller Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:04:41 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:04:41 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:04:41 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:04:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:04:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:04:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:04:41 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:04:41 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-10-20 13:04:41 --> Final output sent to browser
DEBUG - 2015-10-20 13:04:41 --> Total execution time: 0.0420
DEBUG - 2015-10-20 13:04:44 --> Config Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:04:44 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:04:44 --> URI Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Router Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Output Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Security Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Input Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:04:44 --> Language Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Loader Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:04:44 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Session Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:04:44 --> Session routines successfully run
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Controller Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Model Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:04:44 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:04:44 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:04:44 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:04:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:04:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:04:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:04:44 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:04:44 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-10-20 13:04:44 --> Final output sent to browser
DEBUG - 2015-10-20 13:04:44 --> Total execution time: 0.0792
DEBUG - 2015-10-20 13:14:57 --> Config Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:14:57 --> URI Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Router Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Output Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Security Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Input Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:14:57 --> Language Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Loader Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:14:57 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Session Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:14:57 --> Session routines successfully run
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Controller Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:14:57 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:14:57 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Config Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:15:15 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:15:15 --> URI Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Router Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Output Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Security Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Input Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:15:15 --> Language Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Loader Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:15:15 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Session Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:15:15 --> Session routines successfully run
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Controller Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:15:15 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:15:15 --> Pagination Class Initialized
ERROR - 2015-10-20 13:15:15 --> Severity: Notice  --> Undefined property: Invoice::$Director_model /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 691
DEBUG - 2015-10-20 13:15:29 --> Config Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:15:29 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:15:29 --> URI Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Router Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Output Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Security Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Input Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:15:29 --> Language Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Loader Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:15:29 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Session Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:15:29 --> Session routines successfully run
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Controller Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:15:29 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:15:29 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:15:29 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:15:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:15:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:15:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:15:29 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:15:29 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-10-20 13:15:29 --> Final output sent to browser
DEBUG - 2015-10-20 13:15:29 --> Total execution time: 0.0583
DEBUG - 2015-10-20 13:15:59 --> Config Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:15:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:15:59 --> URI Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Router Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Output Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Security Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Input Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:15:59 --> Language Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Loader Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:15:59 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Session Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:15:59 --> Session routines successfully run
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Controller Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:15:59 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 13:15:59 --> Config Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:15:59 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:15:59 --> URI Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Router Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Output Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Security Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Input Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:15:59 --> Language Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Loader Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:15:59 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Session Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:15:59 --> Session routines successfully run
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Controller Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Model Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:15:59 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:15:59 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:15:59 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:15:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:15:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:15:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:15:59 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:15:59 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-20 13:15:59 --> Final output sent to browser
DEBUG - 2015-10-20 13:15:59 --> Total execution time: 0.0656
DEBUG - 2015-10-20 13:16:05 --> Config Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:16:05 --> URI Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Router Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Output Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Security Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Input Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:16:05 --> Language Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Loader Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:16:05 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Session Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:16:05 --> Session routines successfully run
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Controller Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Model Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:16:05 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:16:05 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:16:05 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:16:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:16:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:16:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:16:05 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:16:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-10-20 13:16:05 --> Final output sent to browser
DEBUG - 2015-10-20 13:16:05 --> Total execution time: 0.0732
DEBUG - 2015-10-20 13:17:38 --> Config Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:17:38 --> URI Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Router Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Output Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Security Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Input Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:17:38 --> Language Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Loader Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:17:38 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Session Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:17:38 --> Session routines successfully run
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Controller Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:17:38 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:17:38 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:17:38 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:17:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:17:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:17:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:17:38 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:17:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 13:17:38 --> Final output sent to browser
DEBUG - 2015-10-20 13:17:38 --> Total execution time: 0.1161
DEBUG - 2015-10-20 13:17:46 --> Config Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:17:46 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:17:46 --> URI Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Router Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Output Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Security Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Input Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:17:46 --> Language Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Loader Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:17:46 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Session Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:17:46 --> Session routines successfully run
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Controller Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:17:46 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:17:46 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:17:46 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:17:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:17:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:17:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:17:46 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:17:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 13:17:46 --> Final output sent to browser
DEBUG - 2015-10-20 13:17:46 --> Total execution time: 0.0857
DEBUG - 2015-10-20 13:17:53 --> Config Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:17:53 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:17:53 --> URI Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Router Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Output Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Security Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Input Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:17:53 --> Language Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Loader Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:17:53 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Session Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:17:53 --> Session routines successfully run
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Controller Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Model Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:17:53 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:17:53 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:17:53 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:17:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:17:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:17:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:17:53 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:17:53 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-20 13:17:53 --> Final output sent to browser
DEBUG - 2015-10-20 13:17:53 --> Total execution time: 0.0649
DEBUG - 2015-10-20 13:19:47 --> Config Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:19:47 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:19:47 --> URI Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Router Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Output Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Security Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Input Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:19:47 --> Language Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Loader Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:19:47 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Session Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:19:47 --> Session routines successfully run
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Controller Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:19:47 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:19:47 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:19:47 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:19:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:19:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:19:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:19:47 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:19:47 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-20 13:19:47 --> Final output sent to browser
DEBUG - 2015-10-20 13:19:47 --> Total execution time: 0.0768
DEBUG - 2015-10-20 13:19:50 --> Config Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:19:50 --> URI Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Router Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Output Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Security Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Input Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:19:50 --> Language Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Loader Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:19:50 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Session Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:19:50 --> Session routines successfully run
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Controller Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:19:50 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:19:50 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:19:50 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:19:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:19:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:19:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:19:50 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:19:50 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-10-20 13:19:50 --> Final output sent to browser
DEBUG - 2015-10-20 13:19:50 --> Total execution time: 0.0645
DEBUG - 2015-10-20 13:19:57 --> Config Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:19:57 --> URI Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Router Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Output Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Security Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Input Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:19:57 --> Language Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Loader Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:19:57 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Session Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:19:57 --> Session routines successfully run
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Controller Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:19:57 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 13:19:57 --> Config Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:19:57 --> URI Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Router Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Output Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Security Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Input Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:19:57 --> Language Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Loader Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:19:57 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Session Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:19:57 --> Session routines successfully run
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Controller Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:19:57 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:19:57 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:19:57 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:19:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:19:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:19:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:19:57 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:19:57 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-20 13:19:57 --> Final output sent to browser
DEBUG - 2015-10-20 13:19:57 --> Total execution time: 0.0618
DEBUG - 2015-10-20 13:21:06 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:06 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:06 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:06 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:06 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:06 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:06 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:06 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:34 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:34 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:34 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:34 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:34 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:34 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:34 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:21:34 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:21:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:21:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-10-20 13:21:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:21:34 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:21:34 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-10-20 13:21:34 --> Final output sent to browser
DEBUG - 2015-10-20 13:21:34 --> Total execution time: 0.0809
DEBUG - 2015-10-20 13:21:43 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:43 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:43 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:43 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:43 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:43 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:43 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:43 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:43 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:43 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:43 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:43 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:43 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:43 --> File loaded: application/views/loginView.php
DEBUG - 2015-10-20 13:21:43 --> Final output sent to browser
DEBUG - 2015-10-20 13:21:43 --> Total execution time: 0.0339
DEBUG - 2015-10-20 13:21:55 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:55 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:55 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:55 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:55 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:55 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-10-20 13:21:55 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:55 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:55 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:55 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:55 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:55 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:55 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:55 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:21:55 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:21:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:21:55 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 13:21:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:21:55 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:21:55 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-10-20 13:21:55 --> Final output sent to browser
DEBUG - 2015-10-20 13:21:55 --> Total execution time: 0.0366
DEBUG - 2015-10-20 13:21:57 --> Config Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:21:57 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:21:57 --> URI Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Router Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Output Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Security Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Input Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:21:57 --> Language Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Loader Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:21:57 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Session Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:21:57 --> Session routines successfully run
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Controller Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Model Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:21:57 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:21:57 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:21:57 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:21:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:21:57 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 13:21:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:21:57 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:21:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 13:21:57 --> Final output sent to browser
DEBUG - 2015-10-20 13:21:57 --> Total execution time: 0.1429
DEBUG - 2015-10-20 13:22:32 --> Config Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Hooks Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Utf8 Class Initialized
DEBUG - 2015-10-20 13:22:32 --> UTF-8 Support Enabled
DEBUG - 2015-10-20 13:22:32 --> URI Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Router Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Output Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Security Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Input Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-10-20 13:22:32 --> Language Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Loader Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Helper loaded: url_helper
DEBUG - 2015-10-20 13:22:32 --> Database Driver Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Session Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Helper loaded: string_helper
DEBUG - 2015-10-20 13:22:32 --> Session routines successfully run
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Controller Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:32 --> Model Class Initialized
DEBUG - 2015-10-20 13:22:33 --> Helper loaded: form_helper
DEBUG - 2015-10-20 13:22:33 --> Form Validation Class Initialized
DEBUG - 2015-10-20 13:22:33 --> Pagination Class Initialized
DEBUG - 2015-10-20 13:22:33 --> File loaded: application/views/header.php
DEBUG - 2015-10-20 13:22:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-10-20 13:22:33 --> File loaded: application/views/sidebar_director.php
DEBUG - 2015-10-20 13:22:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-10-20 13:22:33 --> File loaded: application/views/footer.php
DEBUG - 2015-10-20 13:22:33 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-10-20 13:22:33 --> Final output sent to browser
DEBUG - 2015-10-20 13:22:33 --> Total execution time: 0.0598
