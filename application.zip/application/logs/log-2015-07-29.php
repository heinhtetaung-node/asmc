<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-07-29 09:20:41 --> Config Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:20:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:20:41 --> URI Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Router Class Initialized
DEBUG - 2015-07-29 09:20:41 --> No URI present. Default controller set.
DEBUG - 2015-07-29 09:20:41 --> Output Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Security Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Input Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:20:41 --> Language Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Loader Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:20:41 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Session Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:20:41 --> A session cookie was not found.
DEBUG - 2015-07-29 09:20:41 --> Session routines successfully run
DEBUG - 2015-07-29 09:20:41 --> Model Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Model Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Controller Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Model Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Model Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Model Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Model Class Initialized
DEBUG - 2015-07-29 09:20:41 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:20:41 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:20:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-29 09:20:41 --> Final output sent to browser
DEBUG - 2015-07-29 09:20:41 --> Total execution time: 0.0769
DEBUG - 2015-07-29 09:21:13 --> Config Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:21:13 --> URI Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Router Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Output Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Security Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Input Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:21:13 --> Language Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Loader Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:21:13 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Session Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:21:13 --> Session routines successfully run
DEBUG - 2015-07-29 09:21:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Controller Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:21:13 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:21:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:21:13 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-29 09:21:13 --> Final output sent to browser
DEBUG - 2015-07-29 09:21:13 --> Total execution time: 0.0425
DEBUG - 2015-07-29 09:21:52 --> Config Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:21:52 --> URI Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Router Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Output Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Security Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Input Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:21:52 --> Language Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Loader Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:21:52 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Session Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:21:52 --> Session routines successfully run
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Controller Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:21:52 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:21:52 --> Config Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:21:52 --> URI Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Router Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Output Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Security Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Input Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:21:52 --> Language Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Loader Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:21:52 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Session Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:21:52 --> Session routines successfully run
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Controller Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:52 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:21:52 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:21:52 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:21:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:21:52 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:21:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:21:52 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:21:52 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-07-29 09:21:52 --> Final output sent to browser
DEBUG - 2015-07-29 09:21:52 --> Total execution time: 0.0361
DEBUG - 2015-07-29 09:21:54 --> Config Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:21:54 --> URI Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Router Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Output Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Security Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Input Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:21:54 --> Language Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Loader Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:21:54 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Session Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:21:54 --> Session routines successfully run
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Controller Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:21:54 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:21:54 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:21:54 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:21:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:21:54 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:21:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:21:54 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:21:54 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:21:54 --> Final output sent to browser
DEBUG - 2015-07-29 09:21:54 --> Total execution time: 0.0533
DEBUG - 2015-07-29 09:21:55 --> Config Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:21:55 --> URI Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Router Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Output Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Security Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Input Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:21:55 --> Language Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Loader Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:21:55 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Session Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:21:55 --> Session routines successfully run
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Controller Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Model Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:21:55 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:21:55 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:21:55 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:21:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:21:55 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:21:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:21:55 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:21:55 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-07-29 09:21:55 --> Final output sent to browser
DEBUG - 2015-07-29 09:21:55 --> Total execution time: 0.0506
DEBUG - 2015-07-29 09:22:06 --> Config Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:22:06 --> URI Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Router Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Output Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Security Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Input Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:22:06 --> Language Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Loader Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:22:06 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Session Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:22:06 --> Session routines successfully run
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Controller Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:22:06 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Config Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:22:06 --> URI Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Router Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Output Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Security Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Input Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:22:06 --> Language Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Loader Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:22:06 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Session Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:22:06 --> Session routines successfully run
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Controller Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:06 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:22:06 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:22:06 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-29 09:22:06 --> Final output sent to browser
DEBUG - 2015-07-29 09:22:06 --> Total execution time: 0.0303
DEBUG - 2015-07-29 09:22:17 --> Config Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:22:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:22:17 --> URI Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Router Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Output Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Security Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Input Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:22:17 --> Language Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Loader Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:22:17 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Session Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:22:17 --> Session routines successfully run
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Controller Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:22:17 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:22:17 --> Config Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:22:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:22:17 --> URI Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Router Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Output Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Security Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Input Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:22:17 --> Language Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Loader Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:22:17 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Session Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:22:17 --> Session routines successfully run
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Controller Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:17 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:22:17 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:22:17 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:22:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:22:17 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:22:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:22:17 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:22:17 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-07-29 09:22:17 --> Final output sent to browser
DEBUG - 2015-07-29 09:22:17 --> Total execution time: 0.0373
DEBUG - 2015-07-29 09:22:18 --> Config Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:22:18 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:22:18 --> URI Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Router Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Output Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Security Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Input Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:22:18 --> Language Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Loader Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:22:18 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Session Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:22:18 --> Session routines successfully run
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Controller Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:22:18 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:22:18 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:22:18 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:22:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:22:18 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:22:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:22:18 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:22:18 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-07-29 09:22:18 --> Final output sent to browser
DEBUG - 2015-07-29 09:22:18 --> Total execution time: 0.0839
DEBUG - 2015-07-29 09:25:20 --> Config Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:25:20 --> URI Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Router Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Output Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Security Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Input Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:25:20 --> Language Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Loader Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:25:20 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Session Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:25:20 --> Session routines successfully run
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Controller Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:25:20 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:25:20 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:25:20 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:25:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:25:20 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:25:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:25:20 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:25:20 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-07-29 09:25:20 --> Final output sent to browser
DEBUG - 2015-07-29 09:25:20 --> Total execution time: 0.0671
DEBUG - 2015-07-29 09:32:01 --> Config Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:32:01 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:32:01 --> URI Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Router Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Output Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Security Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Input Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:32:01 --> Language Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Loader Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:32:01 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Session Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:32:01 --> Session routines successfully run
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Controller Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:32:01 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:32:01 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:32:01 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:32:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:32:01 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:32:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:32:01 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:32:01 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:32:01 --> Final output sent to browser
DEBUG - 2015-07-29 09:32:01 --> Total execution time: 0.0775
DEBUG - 2015-07-29 09:32:05 --> Config Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:32:05 --> URI Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Router Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Output Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Security Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Input Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:32:05 --> Language Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Loader Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:32:05 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Session Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:32:05 --> Session routines successfully run
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Controller Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Model Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:32:05 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:32:05 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:32:05 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:32:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:32:05 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:32:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:32:05 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:32:05 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:32:05 --> Final output sent to browser
DEBUG - 2015-07-29 09:32:05 --> Total execution time: 0.0548
DEBUG - 2015-07-29 09:35:00 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:00 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:00 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:00 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:00 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:00 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:00 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:35:00 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:35:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:35:00 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:35:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:35:00 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:35:00 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:35:00 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:00 --> Total execution time: 0.0561
DEBUG - 2015-07-29 09:35:02 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:02 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:02 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:02 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:02 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:02 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:02 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:35:02 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:35:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:35:02 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-07-29 09:35:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:35:02 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:35:02 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-07-29 09:35:02 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:02 --> Total execution time: 0.0728
DEBUG - 2015-07-29 09:35:04 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:04 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:04 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:04 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:04 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:04 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:04 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:04 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:04 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:04 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:04 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:04 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:04 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-29 09:35:04 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:04 --> Total execution time: 0.0328
DEBUG - 2015-07-29 09:35:19 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:19 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:19 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:19 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:19 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:19 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:19 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:35:19 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-29 09:35:19 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:19 --> Total execution time: 0.0376
DEBUG - 2015-07-29 09:35:25 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:25 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:25 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:25 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:25 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:25 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:35:25 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:25 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:25 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:25 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:25 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:25 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:25 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:35:25 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:35:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:35:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:35:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:35:25 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:35:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-07-29 09:35:25 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:25 --> Total execution time: 0.0387
DEBUG - 2015-07-29 09:35:29 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:29 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:29 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:29 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:29 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:29 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:29 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:35:30 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:35:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:35:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:35:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:35:30 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:35:30 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:35:30 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:30 --> Total execution time: 0.1345
DEBUG - 2015-07-29 09:35:31 --> Config Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:35:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:35:31 --> URI Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Router Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Output Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Security Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Input Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:35:31 --> Language Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Loader Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:35:31 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Session Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:35:31 --> Session routines successfully run
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Controller Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Model Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:35:31 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:35:31 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:35:31 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:35:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:35:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:35:31 --> File loaded: application/views/sidebar.php
ERROR - 2015-07-29 09:35:31 --> Severity: Notice  --> Undefined variable: project_name /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/addInvoiceView.php 44
DEBUG - 2015-07-29 09:35:31 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:35:31 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-07-29 09:35:31 --> Final output sent to browser
DEBUG - 2015-07-29 09:35:31 --> Total execution time: 0.0518
DEBUG - 2015-07-29 09:36:03 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:03 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:03 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:03 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:03 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:03 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:03 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:03 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:36:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:36:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:36:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:36:03 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:36:03 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-07-29 09:36:03 --> Final output sent to browser
DEBUG - 2015-07-29 09:36:03 --> Total execution time: 0.0479
DEBUG - 2015-07-29 09:36:44 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:44 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:44 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:44 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:44 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:44 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:44 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:36:45 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:45 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:45 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:45 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:45 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:45 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:45 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:45 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:36:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:36:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:36:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:36:45 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:36:45 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:36:45 --> Final output sent to browser
DEBUG - 2015-07-29 09:36:45 --> Total execution time: 0.0583
DEBUG - 2015-07-29 09:36:49 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:49 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:49 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:49 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:49 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:49 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:49 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:49 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:36:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:36:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:36:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:36:49 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:36:49 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:36:49 --> Final output sent to browser
DEBUG - 2015-07-29 09:36:49 --> Total execution time: 0.1019
DEBUG - 2015-07-29 09:36:53 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:53 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:53 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:53 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:53 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:53 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:53 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:53 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:36:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:36:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:36:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:36:53 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:36:53 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:36:53 --> Final output sent to browser
DEBUG - 2015-07-29 09:36:53 --> Total execution time: 0.0932
DEBUG - 2015-07-29 09:36:56 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:56 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:56 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:56 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:56 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:56 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:56 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:56 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:56 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:36:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:36:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:36:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:36:56 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:36:56 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:36:56 --> Final output sent to browser
DEBUG - 2015-07-29 09:36:56 --> Total execution time: 0.0438
DEBUG - 2015-07-29 09:36:58 --> Config Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:36:58 --> URI Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Router Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Output Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Security Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Input Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:36:58 --> Language Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Loader Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:36:58 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Session Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:36:58 --> Session routines successfully run
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Controller Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Model Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:36:58 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:36:58 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:36:58 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:36:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:36:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:36:58 --> File loaded: application/views/sidebar.php
ERROR - 2015-07-29 09:36:58 --> Severity: Notice  --> Undefined variable: project_name /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/editInvoiceView.php 51
DEBUG - 2015-07-29 09:36:58 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:36:58 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-29 09:36:58 --> Final output sent to browser
DEBUG - 2015-07-29 09:36:58 --> Total execution time: 0.0633
DEBUG - 2015-07-29 09:37:13 --> Config Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:37:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:37:13 --> URI Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Router Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Output Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Security Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Input Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:37:13 --> Language Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Loader Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:37:13 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Session Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:37:13 --> Session routines successfully run
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Controller Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:37:13 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:37:13 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:37:13 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:37:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:37:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:37:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:37:13 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:37:13 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-29 09:37:13 --> Final output sent to browser
DEBUG - 2015-07-29 09:37:13 --> Total execution time: 0.0577
DEBUG - 2015-07-29 09:37:20 --> Config Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:37:20 --> URI Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Router Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Output Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Security Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Input Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:37:20 --> Language Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Loader Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:37:20 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Session Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:37:20 --> Session routines successfully run
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Controller Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:37:20 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:37:20 --> Config Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:37:20 --> URI Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Router Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Output Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Security Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Input Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:37:20 --> Language Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Loader Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:37:20 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Session Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:37:20 --> Session routines successfully run
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Controller Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Model Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:37:20 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:37:20 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:37:20 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:37:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:37:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:37:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:37:20 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:37:20 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:37:20 --> Final output sent to browser
DEBUG - 2015-07-29 09:37:20 --> Total execution time: 0.0543
DEBUG - 2015-07-29 09:44:12 --> Config Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:44:12 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:44:12 --> URI Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Router Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Output Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Security Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Input Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:44:12 --> Language Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Loader Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:44:12 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Session Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:44:12 --> Session routines successfully run
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Controller Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:44:12 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:44:12 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:44:12 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:44:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:44:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:44:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:44:12 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:44:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-29 09:44:12 --> Final output sent to browser
DEBUG - 2015-07-29 09:44:12 --> Total execution time: 0.1062
DEBUG - 2015-07-29 09:44:14 --> Config Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:44:14 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:44:14 --> URI Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Router Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Output Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Security Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Input Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:44:14 --> Language Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Loader Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:44:14 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Session Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:44:14 --> Session routines successfully run
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Controller Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Model Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:44:14 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:44:14 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:44:14 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:44:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:44:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:44:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:44:14 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:44:14 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:44:14 --> Final output sent to browser
DEBUG - 2015-07-29 09:44:14 --> Total execution time: 0.0543
DEBUG - 2015-07-29 09:45:29 --> Config Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:45:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:45:29 --> URI Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Router Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Output Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Security Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Input Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:45:29 --> Language Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Loader Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:45:29 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Session Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:45:29 --> Session routines successfully run
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Controller Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Model Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:45:29 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:45:29 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:45:29 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:45:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:45:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:45:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:45:29 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:45:29 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-29 09:45:29 --> Final output sent to browser
DEBUG - 2015-07-29 09:45:29 --> Total execution time: 0.0634
DEBUG - 2015-07-29 09:46:24 --> Config Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:46:24 --> URI Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Router Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Output Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Security Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Input Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:46:24 --> Language Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Loader Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:46:24 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Session Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:46:24 --> Session routines successfully run
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Controller Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:46:24 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:46:24 --> Config Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:46:24 --> URI Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Router Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Output Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Security Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Input Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:46:24 --> Language Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Loader Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:46:24 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Session Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:46:24 --> Session routines successfully run
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Controller Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Model Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:46:24 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:46:24 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:46:24 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:46:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:46:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:46:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:46:24 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:46:24 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:46:24 --> Final output sent to browser
DEBUG - 2015-07-29 09:46:24 --> Total execution time: 0.0555
DEBUG - 2015-07-29 09:55:40 --> Config Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:55:40 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:55:40 --> URI Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Router Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Output Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Security Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Input Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:55:40 --> Language Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Loader Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:55:40 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Session Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:55:40 --> Session routines successfully run
DEBUG - 2015-07-29 09:55:40 --> Model Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Model Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Controller Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Model Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Model Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Model Class Initialized
DEBUG - 2015-07-29 09:55:40 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Config Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:56:03 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:56:03 --> URI Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Router Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Output Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Security Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Input Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:56:03 --> Language Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Loader Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:56:03 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Session Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:56:03 --> Session routines successfully run
DEBUG - 2015-07-29 09:56:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Controller Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:03 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Config Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:56:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:56:17 --> URI Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Router Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Output Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Security Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Input Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:56:17 --> Language Class Initialized
DEBUG - 2015-07-29 09:56:17 --> Loader Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:56:18 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Session Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:56:18 --> Session routines successfully run
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Controller Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:56:18 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:56:18 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:56:18 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:56:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:56:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:56:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:56:18 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:56:18 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-29 09:56:18 --> Final output sent to browser
DEBUG - 2015-07-29 09:56:18 --> Total execution time: 0.0631
DEBUG - 2015-07-29 09:56:28 --> Config Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:56:28 --> URI Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Router Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Output Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Security Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Input Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:56:28 --> Language Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Loader Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:56:28 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Session Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:56:28 --> Session routines successfully run
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Controller Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:56:28 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-29 09:56:28 --> Config Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Hooks Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Utf8 Class Initialized
DEBUG - 2015-07-29 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 09:56:28 --> URI Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Router Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Output Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Security Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Input Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 09:56:28 --> Language Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Loader Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Helper loaded: url_helper
DEBUG - 2015-07-29 09:56:28 --> Database Driver Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Session Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Helper loaded: string_helper
DEBUG - 2015-07-29 09:56:28 --> Session routines successfully run
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Controller Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Model Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Helper loaded: form_helper
DEBUG - 2015-07-29 09:56:28 --> Form Validation Class Initialized
DEBUG - 2015-07-29 09:56:28 --> Pagination Class Initialized
DEBUG - 2015-07-29 09:56:28 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 09:56:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 09:56:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 09:56:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 09:56:28 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 09:56:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 09:56:28 --> Final output sent to browser
DEBUG - 2015-07-29 09:56:28 --> Total execution time: 0.0554
DEBUG - 2015-07-29 10:00:05 --> Config Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Hooks Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Utf8 Class Initialized
DEBUG - 2015-07-29 10:00:05 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 10:00:05 --> URI Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Router Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Output Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Security Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Input Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 10:00:05 --> Language Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Loader Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Helper loaded: url_helper
DEBUG - 2015-07-29 10:00:05 --> Database Driver Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Session Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Helper loaded: string_helper
DEBUG - 2015-07-29 10:00:05 --> Session routines successfully run
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Controller Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Helper loaded: form_helper
DEBUG - 2015-07-29 10:00:05 --> Form Validation Class Initialized
DEBUG - 2015-07-29 10:00:05 --> Pagination Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Config Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Hooks Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Utf8 Class Initialized
DEBUG - 2015-07-29 10:00:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 10:00:20 --> URI Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Router Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Output Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Security Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Input Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 10:00:20 --> Language Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Loader Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Helper loaded: url_helper
DEBUG - 2015-07-29 10:00:20 --> Database Driver Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Session Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Helper loaded: string_helper
DEBUG - 2015-07-29 10:00:20 --> Session routines successfully run
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Controller Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Helper loaded: form_helper
DEBUG - 2015-07-29 10:00:20 --> Form Validation Class Initialized
DEBUG - 2015-07-29 10:00:20 --> Pagination Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Config Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Hooks Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Utf8 Class Initialized
DEBUG - 2015-07-29 10:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-07-29 10:00:56 --> URI Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Router Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Output Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Security Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Input Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-29 10:00:56 --> Language Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Loader Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Helper loaded: url_helper
DEBUG - 2015-07-29 10:00:56 --> Database Driver Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Session Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Helper loaded: string_helper
DEBUG - 2015-07-29 10:00:56 --> Session routines successfully run
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Controller Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Model Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Helper loaded: form_helper
DEBUG - 2015-07-29 10:00:56 --> Form Validation Class Initialized
DEBUG - 2015-07-29 10:00:56 --> Pagination Class Initialized
DEBUG - 2015-07-29 10:00:56 --> File loaded: application/views/header.php
DEBUG - 2015-07-29 10:00:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-29 10:00:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-29 10:00:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-29 10:00:56 --> File loaded: application/views/footer.php
DEBUG - 2015-07-29 10:00:56 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-29 10:00:56 --> Final output sent to browser
DEBUG - 2015-07-29 10:00:56 --> Total execution time: 0.0587
