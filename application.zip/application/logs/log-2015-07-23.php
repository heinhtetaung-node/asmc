<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-07-23 12:10:23 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:23 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Router Class Initialized
DEBUG - 2015-07-23 12:10:23 --> No URI present. Default controller set.
DEBUG - 2015-07-23 12:10:23 --> Output Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Security Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Input Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:10:23 --> Language Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Loader Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:10:23 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Session Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:10:23 --> A session cookie was not found.
DEBUG - 2015-07-23 12:10:23 --> Session routines successfully run
DEBUG - 2015-07-23 12:10:23 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Controller Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:10:23 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:10:23 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-23 12:10:23 --> Final output sent to browser
DEBUG - 2015-07-23 12:10:23 --> Total execution time: 0.0902
DEBUG - 2015-07-23 12:10:23 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:23 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:23 --> Router Class Initialized
ERROR - 2015-07-23 12:10:23 --> 404 Page Not Found --> js
DEBUG - 2015-07-23 12:10:32 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:32 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:32 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Router Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Output Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Security Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Input Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:10:32 --> Language Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Loader Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:10:32 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Session Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:10:32 --> Session routines successfully run
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Controller Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:10:32 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-23 12:10:32 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:32 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:32 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Router Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Output Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Security Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Input Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:10:32 --> Language Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Loader Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:10:32 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Session Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:10:32 --> Session routines successfully run
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Controller Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:10:32 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:10:32 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:10:32 --> File loaded: application/views/header.php
DEBUG - 2015-07-23 12:10:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-23 12:10:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-23 12:10:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-23 12:10:32 --> File loaded: application/views/footer.php
DEBUG - 2015-07-23 12:10:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-07-23 12:10:32 --> Final output sent to browser
DEBUG - 2015-07-23 12:10:32 --> Total execution time: 0.0552
DEBUG - 2015-07-23 12:10:34 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:34 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:34 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:34 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:34 --> Router Class Initialized
ERROR - 2015-07-23 12:10:34 --> 404 Page Not Found --> js
DEBUG - 2015-07-23 12:10:39 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:39 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:39 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Router Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Output Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Security Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Input Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:10:39 --> Language Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Loader Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:10:39 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Session Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:10:39 --> Session routines successfully run
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Controller Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:10:39 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:10:39 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:10:40 --> File loaded: application/views/header.php
DEBUG - 2015-07-23 12:10:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-23 12:10:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-23 12:10:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-23 12:10:40 --> File loaded: application/views/footer.php
DEBUG - 2015-07-23 12:10:40 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-23 12:10:40 --> Final output sent to browser
DEBUG - 2015-07-23 12:10:40 --> Total execution time: 0.2949
DEBUG - 2015-07-23 12:10:41 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:41 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:41 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:41 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:41 --> Router Class Initialized
ERROR - 2015-07-23 12:10:41 --> 404 Page Not Found --> js
DEBUG - 2015-07-23 12:10:47 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:47 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Router Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Output Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Security Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Input Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:10:47 --> Language Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Loader Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:10:47 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Session Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:10:47 --> Session routines successfully run
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Controller Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Model Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:10:47 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:10:47 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:10:47 --> File loaded: application/views/header.php
DEBUG - 2015-07-23 12:10:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-23 12:10:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-23 12:10:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-23 12:10:47 --> File loaded: application/views/footer.php
DEBUG - 2015-07-23 12:10:47 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-23 12:10:47 --> Final output sent to browser
DEBUG - 2015-07-23 12:10:47 --> Total execution time: 0.0966
DEBUG - 2015-07-23 12:10:48 --> Config Class Initialized
DEBUG - 2015-07-23 12:10:48 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:10:48 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:10:48 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:10:48 --> URI Class Initialized
DEBUG - 2015-07-23 12:10:48 --> Router Class Initialized
ERROR - 2015-07-23 12:10:48 --> 404 Page Not Found --> js
DEBUG - 2015-07-23 12:11:40 --> Config Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:11:40 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:11:40 --> URI Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Router Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Output Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Security Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Input Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:11:40 --> Language Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Loader Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:11:40 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Session Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:11:40 --> Session routines successfully run
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Controller Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:11:40 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-23 12:11:40 --> Config Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:11:40 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:11:40 --> URI Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Router Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Output Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Security Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Input Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:11:40 --> Language Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Loader Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:11:40 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Session Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:11:40 --> Session routines successfully run
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Controller Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:11:40 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:11:40 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:11:40 --> File loaded: application/views/header.php
DEBUG - 2015-07-23 12:11:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-23 12:11:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-23 12:11:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-23 12:11:40 --> File loaded: application/views/footer.php
DEBUG - 2015-07-23 12:11:40 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-23 12:11:40 --> Final output sent to browser
DEBUG - 2015-07-23 12:11:40 --> Total execution time: 0.0741
DEBUG - 2015-07-23 12:11:41 --> Config Class Initialized
DEBUG - 2015-07-23 12:11:41 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:11:41 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:11:41 --> URI Class Initialized
DEBUG - 2015-07-23 12:11:41 --> Router Class Initialized
ERROR - 2015-07-23 12:11:41 --> 404 Page Not Found --> js
DEBUG - 2015-07-23 12:11:58 --> Config Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:11:58 --> URI Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Router Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Output Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Security Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Input Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:11:58 --> Language Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Loader Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:11:58 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Session Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:11:58 --> Session routines successfully run
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Controller Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Model Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:11:58 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:11:58 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:11:58 --> File loaded: application/views/header.php
DEBUG - 2015-07-23 12:11:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-23 12:11:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-23 12:11:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-23 12:11:58 --> File loaded: application/views/footer.php
DEBUG - 2015-07-23 12:11:58 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-23 12:11:58 --> Final output sent to browser
DEBUG - 2015-07-23 12:11:58 --> Total execution time: 0.0968
DEBUG - 2015-07-23 12:12:00 --> Config Class Initialized
DEBUG - 2015-07-23 12:12:00 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:12:00 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:12:00 --> URI Class Initialized
DEBUG - 2015-07-23 12:12:00 --> Router Class Initialized
ERROR - 2015-07-23 12:12:00 --> 404 Page Not Found --> js
DEBUG - 2015-07-23 12:12:16 --> Config Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:12:16 --> URI Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Router Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Output Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Security Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Input Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:12:16 --> Language Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Loader Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:12:16 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Session Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:12:16 --> Session routines successfully run
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Controller Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:12:16 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-23 12:12:16 --> Config Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:12:16 --> URI Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Router Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Output Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Security Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Input Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-23 12:12:16 --> Language Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Loader Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Helper loaded: url_helper
DEBUG - 2015-07-23 12:12:16 --> Database Driver Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Session Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Helper loaded: string_helper
DEBUG - 2015-07-23 12:12:16 --> Session routines successfully run
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Controller Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Model Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Helper loaded: form_helper
DEBUG - 2015-07-23 12:12:16 --> Form Validation Class Initialized
DEBUG - 2015-07-23 12:12:16 --> Pagination Class Initialized
DEBUG - 2015-07-23 12:12:16 --> File loaded: application/views/header.php
DEBUG - 2015-07-23 12:12:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-23 12:12:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-23 12:12:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-23 12:12:16 --> File loaded: application/views/footer.php
DEBUG - 2015-07-23 12:12:16 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-23 12:12:16 --> Final output sent to browser
DEBUG - 2015-07-23 12:12:16 --> Total execution time: 0.0661
DEBUG - 2015-07-23 12:12:17 --> Config Class Initialized
DEBUG - 2015-07-23 12:12:17 --> Hooks Class Initialized
DEBUG - 2015-07-23 12:12:17 --> Utf8 Class Initialized
DEBUG - 2015-07-23 12:12:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-23 12:12:17 --> URI Class Initialized
DEBUG - 2015-07-23 12:12:17 --> Router Class Initialized
ERROR - 2015-07-23 12:12:17 --> 404 Page Not Found --> js
