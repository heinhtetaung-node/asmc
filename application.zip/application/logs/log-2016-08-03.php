<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-03 10:31:01 --> Config Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:31:01 --> URI Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Router Class Initialized
DEBUG - 2016-08-03 10:31:01 --> No URI present. Default controller set.
DEBUG - 2016-08-03 10:31:01 --> Output Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Security Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Input Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:31:01 --> Language Class Initialized
DEBUG - 2016-08-03 10:31:01 --> Loader Class Initialized
DEBUG - 2016-08-03 10:31:02 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:31:02 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:31:02 --> Session Class Initialized
DEBUG - 2016-08-03 10:31:02 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:31:02 --> A session cookie was not found.
DEBUG - 2016-08-03 10:31:02 --> Session routines successfully run
DEBUG - 2016-08-03 10:31:02 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Controller Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:31:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:31:03 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 10:31:03 --> Final output sent to browser
DEBUG - 2016-08-03 10:31:03 --> Total execution time: 2.5105
DEBUG - 2016-08-03 10:31:10 --> Config Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:31:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:31:10 --> URI Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Router Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Output Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Security Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Input Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:31:10 --> Language Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Loader Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:31:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Session Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:31:10 --> Session routines successfully run
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Controller Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:31:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:31:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 10:31:10 --> Config Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:31:11 --> URI Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Router Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Output Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Security Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Input Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:31:11 --> Language Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Loader Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:31:11 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Session Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:31:11 --> Session routines successfully run
DEBUG - 2016-08-03 10:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Controller Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:31:11 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:31:11 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:31:11 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 10:31:11 --> Final output sent to browser
DEBUG - 2016-08-03 10:31:11 --> Total execution time: 0.5928
DEBUG - 2016-08-03 10:31:32 --> Config Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:31:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:31:32 --> URI Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Router Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Output Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Security Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Input Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:31:32 --> Language Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Loader Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:31:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Session Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:31:32 --> Session routines successfully run
DEBUG - 2016-08-03 10:31:32 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Controller Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Model Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:31:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:31:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:31:32 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 10:31:32 --> Final output sent to browser
DEBUG - 2016-08-03 10:31:32 --> Total execution time: 0.2580
DEBUG - 2016-08-03 10:32:40 --> Config Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:32:40 --> URI Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Router Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Output Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Security Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Input Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:32:40 --> Language Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Loader Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:32:40 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Session Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:32:40 --> Session routines successfully run
DEBUG - 2016-08-03 10:32:40 --> Model Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Model Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Controller Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Model Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:32:40 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:32:40 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:32:40 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 10:32:40 --> Final output sent to browser
DEBUG - 2016-08-03 10:32:40 --> Total execution time: 0.0946
DEBUG - 2016-08-03 10:33:00 --> Config Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:33:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:33:00 --> URI Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Router Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Output Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Security Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Input Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:33:00 --> Language Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Loader Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:33:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Session Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:33:00 --> Session routines successfully run
DEBUG - 2016-08-03 10:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Controller Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:33:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:33:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:33:00 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 10:33:00 --> Final output sent to browser
DEBUG - 2016-08-03 10:33:00 --> Total execution time: 0.1638
DEBUG - 2016-08-03 10:33:18 --> Config Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:33:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:33:18 --> URI Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Router Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Output Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Security Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Input Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:33:18 --> Language Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Loader Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:33:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Session Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:33:18 --> Session routines successfully run
DEBUG - 2016-08-03 10:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Controller Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:33:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:33:18 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:33:18 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 10:33:18 --> Final output sent to browser
DEBUG - 2016-08-03 10:33:18 --> Total execution time: 0.1806
DEBUG - 2016-08-03 10:33:36 --> Config Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:33:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:33:36 --> URI Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Router Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Output Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Security Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Input Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:33:36 --> Language Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Loader Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:33:36 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Session Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:33:36 --> Session routines successfully run
DEBUG - 2016-08-03 10:33:36 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Controller Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:33:36 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:33:36 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:33:36 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:33:36 --> Final output sent to browser
DEBUG - 2016-08-03 10:33:36 --> Total execution time: 0.1843
DEBUG - 2016-08-03 10:33:57 --> Config Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:33:57 --> URI Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Router Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Output Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Security Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Input Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:33:57 --> Language Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Loader Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:33:57 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Session Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:33:57 --> Session routines successfully run
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Controller Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:57 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:33:57 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:33:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:33:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:33:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:33:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:33:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:33:57 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-03 10:33:57 --> Final output sent to browser
DEBUG - 2016-08-03 10:33:57 --> Total execution time: 0.2645
DEBUG - 2016-08-03 10:33:59 --> Config Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:33:59 --> URI Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Router Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Output Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Security Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Input Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:33:59 --> Language Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Loader Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:33:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Session Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:33:59 --> Session routines successfully run
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Controller Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:33:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:33:59 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:34:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 10:34:00 --> Final output sent to browser
DEBUG - 2016-08-03 10:34:00 --> Total execution time: 0.8102
DEBUG - 2016-08-03 10:37:56 --> Config Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:37:56 --> URI Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Router Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Output Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Security Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Input Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:37:56 --> Language Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Loader Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:37:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Session Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:37:56 --> Session routines successfully run
DEBUG - 2016-08-03 10:37:56 --> Model Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Model Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Controller Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Model Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:37:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:37:56 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:37:56 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:37:56 --> Final output sent to browser
DEBUG - 2016-08-03 10:37:56 --> Total execution time: 0.1299
DEBUG - 2016-08-03 10:37:58 --> Config Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:37:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:37:58 --> URI Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Router Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Output Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Security Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Input Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:37:58 --> Language Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Loader Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:37:58 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Session Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:37:58 --> Session routines successfully run
DEBUG - 2016-08-03 10:37:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Controller Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:37:58 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:37:58 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:37:59 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:37:59 --> Final output sent to browser
DEBUG - 2016-08-03 10:37:59 --> Total execution time: 0.1264
DEBUG - 2016-08-03 10:38:24 --> Config Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:38:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:38:24 --> URI Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Router Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Output Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Security Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Input Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:38:24 --> Language Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Loader Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:38:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Session Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:38:24 --> Session routines successfully run
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Controller Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:38:24 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:38:24 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:38:24 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 10:38:24 --> Final output sent to browser
DEBUG - 2016-08-03 10:38:24 --> Total execution time: 0.3691
DEBUG - 2016-08-03 10:41:23 --> Config Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:41:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:41:23 --> URI Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Router Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Output Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Security Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Input Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:41:23 --> Language Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Loader Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:41:23 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Session Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:41:23 --> Session routines successfully run
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Controller Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:41:23 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:41:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:41:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:41:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:41:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:41:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:41:58 --> Config Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:41:58 --> URI Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Router Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Output Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Security Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Input Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:41:58 --> Language Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Loader Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:41:58 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Session Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:41:58 --> Session routines successfully run
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Controller Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Model Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:41:58 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:41:58 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:41:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:41:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:41:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:41:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:42:30 --> Config Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:42:30 --> URI Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Router Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Output Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Security Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Input Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:42:30 --> Language Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Loader Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:42:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Session Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:42:30 --> Session routines successfully run
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Controller Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:42:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:42:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:42:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:42:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:42:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:42:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:42:38 --> Config Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:42:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:42:38 --> URI Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Router Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Output Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Security Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Input Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:42:38 --> Language Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Loader Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:42:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Session Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:42:38 --> Session routines successfully run
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Controller Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Model Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:42:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:42:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:42:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:42:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:42:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:42:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:44:57 --> Config Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:44:57 --> URI Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Router Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Output Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Security Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Input Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:44:57 --> Language Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Loader Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:44:57 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Session Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:44:57 --> Session routines successfully run
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Controller Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Model Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:44:57 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:44:57 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:44:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 10:44:57 --> Final output sent to browser
DEBUG - 2016-08-03 10:44:58 --> Total execution time: 0.3314
DEBUG - 2016-08-03 10:45:00 --> Config Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:45:00 --> URI Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Router Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Output Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Security Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Input Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:45:00 --> Language Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Loader Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:45:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Session Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:45:00 --> Session routines successfully run
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Controller Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:45:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:45:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:45:01 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 10:45:01 --> Final output sent to browser
DEBUG - 2016-08-03 10:45:01 --> Total execution time: 0.3486
DEBUG - 2016-08-03 10:45:11 --> Config Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:45:11 --> URI Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Router Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Output Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Security Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Input Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:45:11 --> Language Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Loader Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:45:11 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Session Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:45:11 --> Session routines successfully run
DEBUG - 2016-08-03 10:45:11 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Controller Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:45:11 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:45:11 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Config Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:45:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:45:30 --> URI Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Router Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Output Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Security Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Input Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:45:30 --> Language Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Loader Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:45:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Session Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:45:30 --> Session routines successfully run
DEBUG - 2016-08-03 10:45:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Controller Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Model Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:45:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:45:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:45:30 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:45:30 --> Final output sent to browser
DEBUG - 2016-08-03 10:45:30 --> Total execution time: 0.1292
DEBUG - 2016-08-03 10:46:19 --> Config Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:46:19 --> URI Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Router Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Output Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Security Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Input Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:46:19 --> Language Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Loader Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:46:19 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Session Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:46:19 --> Session routines successfully run
DEBUG - 2016-08-03 10:46:19 --> Model Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Model Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Controller Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Model Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:46:19 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:46:19 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:46:19 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:46:19 --> Final output sent to browser
DEBUG - 2016-08-03 10:46:19 --> Total execution time: 0.1378
DEBUG - 2016-08-03 10:49:13 --> Config Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:49:13 --> URI Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Router Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Output Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Security Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Input Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:49:13 --> Language Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Loader Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:49:13 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Session Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:49:13 --> Session routines successfully run
DEBUG - 2016-08-03 10:49:13 --> Model Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Model Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Controller Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Model Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:49:13 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:49:13 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:49:13 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:49:13 --> Final output sent to browser
DEBUG - 2016-08-03 10:49:13 --> Total execution time: 0.1456
DEBUG - 2016-08-03 10:58:21 --> Config Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:58:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:58:21 --> URI Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Router Class Initialized
DEBUG - 2016-08-03 10:58:21 --> No URI present. Default controller set.
DEBUG - 2016-08-03 10:58:21 --> Output Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Security Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Input Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:58:21 --> Language Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Loader Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:58:21 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Session Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:58:21 --> Session routines successfully run
DEBUG - 2016-08-03 10:58:21 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Controller Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:21 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:58:22 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Config Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:58:22 --> URI Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Router Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Output Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Security Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Input Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:58:22 --> Language Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Loader Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:58:22 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Session Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:58:22 --> Session routines successfully run
DEBUG - 2016-08-03 10:58:22 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Controller Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:58:22 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:58:22 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:58:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 10:58:22 --> Final output sent to browser
DEBUG - 2016-08-03 10:58:22 --> Total execution time: 0.1192
DEBUG - 2016-08-03 10:58:24 --> Config Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:58:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:58:24 --> URI Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Router Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Output Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Security Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Input Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:58:24 --> Language Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Loader Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:58:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Session Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:58:24 --> Session routines successfully run
DEBUG - 2016-08-03 10:58:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Controller Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:58:24 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:58:24 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:58:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 10:58:24 --> Final output sent to browser
DEBUG - 2016-08-03 10:58:24 --> Total execution time: 0.1338
DEBUG - 2016-08-03 10:58:27 --> Config Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:58:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:58:27 --> URI Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Router Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Output Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Security Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Input Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:58:27 --> Language Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Loader Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:58:27 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Session Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:58:27 --> Session routines successfully run
DEBUG - 2016-08-03 10:58:27 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Controller Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:58:27 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:58:27 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:58:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:58:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:58:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:58:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:58:27 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:58:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:58:28 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:58:28 --> Final output sent to browser
DEBUG - 2016-08-03 10:58:28 --> Total execution time: 0.1482
DEBUG - 2016-08-03 10:58:39 --> Config Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:58:39 --> URI Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Router Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Output Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Security Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Input Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:58:39 --> Language Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Loader Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:58:39 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Session Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:58:39 --> Session routines successfully run
DEBUG - 2016-08-03 10:58:39 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Controller Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:58:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:58:39 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:58:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 10:58:39 --> Final output sent to browser
DEBUG - 2016-08-03 10:58:39 --> Total execution time: 0.1294
DEBUG - 2016-08-03 10:58:46 --> Config Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:58:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:58:46 --> URI Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Router Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Output Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Security Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Input Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:58:46 --> Language Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Loader Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:58:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Session Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:58:46 --> Session routines successfully run
DEBUG - 2016-08-03 10:58:46 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Controller Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Model Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:58:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:58:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:58:46 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 10:58:46 --> Final output sent to browser
DEBUG - 2016-08-03 10:58:46 --> Total execution time: 0.1463
DEBUG - 2016-08-03 10:59:12 --> Config Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:59:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:59:12 --> URI Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Router Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Output Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Security Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Input Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:59:12 --> Language Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Loader Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:59:12 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Session Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:59:12 --> Session routines successfully run
DEBUG - 2016-08-03 10:59:12 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Controller Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:59:12 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:59:12 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:59:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 10:59:12 --> Final output sent to browser
DEBUG - 2016-08-03 10:59:12 --> Total execution time: 0.1357
DEBUG - 2016-08-03 10:59:40 --> Config Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:59:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:59:40 --> URI Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Router Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Output Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Security Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Input Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:59:40 --> Language Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Loader Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:59:40 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Session Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:59:40 --> Session routines successfully run
DEBUG - 2016-08-03 10:59:40 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Controller Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:59:40 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:59:40 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:59:40 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 10:59:40 --> Final output sent to browser
DEBUG - 2016-08-03 10:59:40 --> Total execution time: 0.1766
DEBUG - 2016-08-03 10:59:59 --> Config Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 10:59:59 --> URI Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Router Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Output Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Security Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Input Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 10:59:59 --> Language Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Loader Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 10:59:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Session Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 10:59:59 --> Session routines successfully run
DEBUG - 2016-08-03 10:59:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Controller Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Model Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 10:59:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 10:59:59 --> Pagination Class Initialized
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 10:59:59 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 10:59:59 --> Final output sent to browser
DEBUG - 2016-08-03 10:59:59 --> Total execution time: 0.1424
DEBUG - 2016-08-03 11:00:08 --> Config Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:00:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:00:08 --> URI Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Router Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Output Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Security Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Input Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:00:08 --> Language Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Loader Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:00:08 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Session Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:00:08 --> Session routines successfully run
DEBUG - 2016-08-03 11:00:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Controller Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:00:08 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:00:08 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:00:08 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 11:00:08 --> Final output sent to browser
DEBUG - 2016-08-03 11:00:08 --> Total execution time: 0.1484
DEBUG - 2016-08-03 11:00:17 --> Config Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:00:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:00:17 --> URI Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Router Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Output Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Security Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Input Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:00:17 --> Language Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Loader Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:00:17 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Session Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:00:17 --> Session routines successfully run
DEBUG - 2016-08-03 11:00:17 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Controller Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:00:17 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:00:17 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:00:17 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 11:00:17 --> Final output sent to browser
DEBUG - 2016-08-03 11:00:17 --> Total execution time: 0.1570
DEBUG - 2016-08-03 11:00:54 --> Config Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:00:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:00:54 --> URI Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Router Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Output Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Security Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Input Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:00:54 --> Language Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Loader Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:00:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Session Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:00:54 --> Session routines successfully run
DEBUG - 2016-08-03 11:00:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Controller Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:00:55 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:00:55 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:00:55 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:00:55 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 11:00:55 --> Final output sent to browser
DEBUG - 2016-08-03 11:00:55 --> Total execution time: 0.1607
DEBUG - 2016-08-03 11:01:03 --> Config Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:01:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:01:03 --> URI Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Router Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Output Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Security Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Input Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:01:03 --> Language Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Loader Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:01:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Session Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:01:03 --> Session routines successfully run
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Controller Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:01:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:01:03 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:01:03 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:01:03 --> Final output sent to browser
DEBUG - 2016-08-03 11:01:03 --> Total execution time: 0.3986
DEBUG - 2016-08-03 11:01:54 --> Config Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:01:54 --> URI Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Router Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Output Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Security Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Input Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:01:54 --> Language Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Loader Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:01:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Session Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:01:54 --> Session routines successfully run
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Controller Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Model Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:01:54 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:01:54 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:01:55 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:01:55 --> Final output sent to browser
DEBUG - 2016-08-03 11:01:55 --> Total execution time: 0.3723
DEBUG - 2016-08-03 11:02:03 --> Config Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:02:03 --> URI Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Router Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Output Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Security Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Input Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:02:03 --> Language Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Loader Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:02:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Session Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:02:03 --> Session routines successfully run
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Controller Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:02:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:02:03 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:02:03 --> Final output sent to browser
DEBUG - 2016-08-03 11:02:03 --> Total execution time: 0.2894
DEBUG - 2016-08-03 11:03:03 --> Config Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:03:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:03:03 --> URI Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Router Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Output Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Security Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Input Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:03:03 --> Language Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Loader Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:03:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Session Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:03:03 --> Session routines successfully run
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Controller Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:03:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:03:03 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:03:03 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:03:03 --> Final output sent to browser
DEBUG - 2016-08-03 11:03:03 --> Total execution time: 0.3572
DEBUG - 2016-08-03 11:03:05 --> Config Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:03:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:03:05 --> URI Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Router Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Output Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Security Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Input Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:03:05 --> Language Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Loader Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:03:05 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Session Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:03:05 --> Session routines successfully run
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Controller Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:03:05 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:03:05 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:03:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:03:05 --> Final output sent to browser
DEBUG - 2016-08-03 11:03:06 --> Total execution time: 0.3693
DEBUG - 2016-08-03 11:03:52 --> Config Class Initialized
DEBUG - 2016-08-03 11:03:52 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:03:52 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:03:52 --> URI Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Router Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Output Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Security Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Input Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:03:53 --> Language Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Loader Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:03:53 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Session Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:03:53 --> Session routines successfully run
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Controller Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:03:53 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:03:53 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:03:53 --> Final output sent to browser
DEBUG - 2016-08-03 11:03:53 --> Total execution time: 0.1615
DEBUG - 2016-08-03 11:03:57 --> Config Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:03:57 --> URI Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Router Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Output Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Security Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Input Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:03:57 --> Language Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Loader Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:03:57 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Session Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:03:57 --> Session routines successfully run
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Controller Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:03:57 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:03:57 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:03:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:03:57 --> Final output sent to browser
DEBUG - 2016-08-03 11:03:57 --> Total execution time: 0.3585
DEBUG - 2016-08-03 11:10:08 --> Config Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:10:08 --> URI Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Router Class Initialized
DEBUG - 2016-08-03 11:10:08 --> No URI present. Default controller set.
DEBUG - 2016-08-03 11:10:08 --> Output Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Security Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Input Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:10:08 --> Language Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Loader Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:10:08 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Session Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:10:08 --> Session routines successfully run
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Controller Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:10:08 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Config Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:10:08 --> URI Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Router Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Output Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Security Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Input Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:10:08 --> Language Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Loader Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:10:08 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Session Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:10:08 --> Session routines successfully run
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Controller Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Model Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:10:08 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:10:08 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:10:08 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:10:08 --> Final output sent to browser
DEBUG - 2016-08-03 11:10:08 --> Total execution time: 0.1308
DEBUG - 2016-08-03 11:11:44 --> Config Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:11:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:11:44 --> URI Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Router Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Output Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Security Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Input Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:11:44 --> Language Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Loader Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:11:44 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Session Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:11:44 --> Session routines successfully run
DEBUG - 2016-08-03 11:11:44 --> Model Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Model Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Controller Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Model Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:11:44 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:11:44 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:11:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:11:44 --> Final output sent to browser
DEBUG - 2016-08-03 11:11:44 --> Total execution time: 0.1611
DEBUG - 2016-08-03 11:11:45 --> Config Class Initialized
DEBUG - 2016-08-03 11:11:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:11:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:11:45 --> URI Class Initialized
DEBUG - 2016-08-03 11:11:45 --> Router Class Initialized
ERROR - 2016-08-03 11:11:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-03 11:11:45 --> Config Class Initialized
DEBUG - 2016-08-03 11:11:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:11:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:11:45 --> URI Class Initialized
DEBUG - 2016-08-03 11:11:45 --> Router Class Initialized
ERROR - 2016-08-03 11:11:45 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-03 11:11:59 --> Config Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:11:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:11:59 --> URI Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Router Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Output Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Security Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Input Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:11:59 --> Language Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Loader Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:11:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Session Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:11:59 --> Session routines successfully run
DEBUG - 2016-08-03 11:11:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Controller Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:11:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:11:59 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:11:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:11:59 --> Final output sent to browser
DEBUG - 2016-08-03 11:11:59 --> Total execution time: 0.1807
DEBUG - 2016-08-03 11:12:00 --> Config Class Initialized
DEBUG - 2016-08-03 11:12:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:12:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:12:00 --> URI Class Initialized
DEBUG - 2016-08-03 11:12:00 --> Router Class Initialized
ERROR - 2016-08-03 11:12:00 --> 404 Page Not Found --> js
DEBUG - 2016-08-03 11:12:00 --> Config Class Initialized
DEBUG - 2016-08-03 11:12:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:12:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:12:00 --> URI Class Initialized
DEBUG - 2016-08-03 11:12:00 --> Router Class Initialized
ERROR - 2016-08-03 11:12:00 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-03 11:12:30 --> Config Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:12:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:12:30 --> URI Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Router Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Output Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Security Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Input Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:12:30 --> Language Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Loader Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:12:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Session Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:12:30 --> Session routines successfully run
DEBUG - 2016-08-03 11:12:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Controller Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:12:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:12:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:12:30 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 11:12:30 --> Final output sent to browser
DEBUG - 2016-08-03 11:12:30 --> Total execution time: 0.1493
DEBUG - 2016-08-03 11:12:34 --> Config Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:12:34 --> URI Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Router Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Output Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Security Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Input Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:12:34 --> Language Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Loader Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:12:34 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Session Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:12:34 --> Session routines successfully run
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Controller Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:12:34 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:12:34 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:12:35 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:12:35 --> Final output sent to browser
DEBUG - 2016-08-03 11:12:35 --> Total execution time: 0.4135
DEBUG - 2016-08-03 11:13:36 --> Config Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:13:36 --> URI Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Router Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Output Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Security Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Input Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:13:36 --> Language Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Loader Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:13:36 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Session Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:13:36 --> Session routines successfully run
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Controller Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Model Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:13:36 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:13:36 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:13:36 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:13:36 --> Final output sent to browser
DEBUG - 2016-08-03 11:13:36 --> Total execution time: 0.3669
DEBUG - 2016-08-03 11:14:00 --> Config Class Initialized
DEBUG - 2016-08-03 11:14:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:14:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:14:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:14:00 --> URI Class Initialized
DEBUG - 2016-08-03 11:14:00 --> Router Class Initialized
DEBUG - 2016-08-03 11:14:00 --> Output Class Initialized
DEBUG - 2016-08-03 11:14:00 --> Security Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Input Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:14:01 --> Language Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Loader Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:14:01 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Session Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:14:01 --> Session routines successfully run
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Controller Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:14:01 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:14:01 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:14:01 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:14:01 --> Final output sent to browser
DEBUG - 2016-08-03 11:14:01 --> Total execution time: 0.4368
DEBUG - 2016-08-03 11:14:29 --> Config Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:14:29 --> URI Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Router Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Output Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Security Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Input Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:14:29 --> Language Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Loader Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:14:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Session Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:14:29 --> Session routines successfully run
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Controller Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:14:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> Model Class Initialized
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:14:29 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:14:29 --> Final output sent to browser
DEBUG - 2016-08-03 11:14:29 --> Total execution time: 0.2160
DEBUG - 2016-08-03 11:17:42 --> Config Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:17:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:17:42 --> URI Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Router Class Initialized
DEBUG - 2016-08-03 11:17:42 --> No URI present. Default controller set.
DEBUG - 2016-08-03 11:17:42 --> Output Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Security Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Input Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:17:42 --> Language Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Loader Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:17:42 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Session Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:17:42 --> Session routines successfully run
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Controller Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:17:42 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Config Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:17:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:17:42 --> URI Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Router Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Output Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Security Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Input Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:17:42 --> Language Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Loader Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:17:42 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Session Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:17:42 --> Session routines successfully run
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Controller Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:17:42 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:17:42 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:17:42 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:17:42 --> Final output sent to browser
DEBUG - 2016-08-03 11:17:42 --> Total execution time: 0.1502
DEBUG - 2016-08-03 11:17:46 --> Config Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:17:46 --> URI Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Router Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Output Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Security Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Input Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:17:46 --> Language Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Loader Class Initialized
DEBUG - 2016-08-03 11:17:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:17:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Session Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:17:47 --> Session routines successfully run
DEBUG - 2016-08-03 11:17:47 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Controller Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:17:47 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:17:47 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:17:47 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 11:17:47 --> Final output sent to browser
DEBUG - 2016-08-03 11:17:47 --> Total execution time: 0.1528
DEBUG - 2016-08-03 11:17:49 --> Config Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:17:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:17:49 --> URI Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Router Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Output Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Security Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Input Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:17:49 --> Language Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Loader Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:17:49 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Session Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:17:49 --> Session routines successfully run
DEBUG - 2016-08-03 11:17:49 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Controller Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:17:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:17:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:17:49 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 11:17:49 --> Final output sent to browser
DEBUG - 2016-08-03 11:17:49 --> Total execution time: 0.1664
DEBUG - 2016-08-03 11:17:52 --> Config Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:17:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:17:52 --> URI Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Router Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Output Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Security Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Input Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:17:52 --> Language Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Loader Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:17:52 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Session Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:17:52 --> Session routines successfully run
DEBUG - 2016-08-03 11:17:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Controller Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:17:52 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:17:52 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:17:52 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 11:17:52 --> Final output sent to browser
DEBUG - 2016-08-03 11:17:52 --> Total execution time: 0.1779
DEBUG - 2016-08-03 11:18:01 --> Config Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:18:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:18:01 --> URI Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Router Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Output Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Security Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Input Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:18:01 --> Language Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Loader Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:18:01 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Session Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:18:01 --> Session routines successfully run
DEBUG - 2016-08-03 11:18:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Controller Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:18:01 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:18:01 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:18:01 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 11:18:01 --> Final output sent to browser
DEBUG - 2016-08-03 11:18:01 --> Total execution time: 0.1839
DEBUG - 2016-08-03 11:18:09 --> Config Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:18:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:18:09 --> URI Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Router Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Output Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Security Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Input Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:18:09 --> Language Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Loader Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:18:09 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Session Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:18:09 --> Session routines successfully run
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Controller Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:18:09 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:18:09 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:18:09 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:18:09 --> Final output sent to browser
DEBUG - 2016-08-03 11:18:09 --> Total execution time: 0.4212
DEBUG - 2016-08-03 11:18:23 --> Config Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:18:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:18:23 --> URI Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Router Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Output Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Security Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Input Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:18:23 --> Language Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Loader Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:18:23 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Session Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:18:23 --> Session routines successfully run
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Controller Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:18:23 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:18:23 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:18:23 --> Final output sent to browser
DEBUG - 2016-08-03 11:18:23 --> Total execution time: 0.2118
DEBUG - 2016-08-03 11:19:30 --> Config Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:19:30 --> URI Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Router Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Output Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Security Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Input Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:19:30 --> Language Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Loader Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:19:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Session Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:19:30 --> Session routines successfully run
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Controller Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:19:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:19:30 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:19:30 --> Final output sent to browser
DEBUG - 2016-08-03 11:19:30 --> Total execution time: 0.2025
DEBUG - 2016-08-03 11:19:37 --> Config Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:19:37 --> URI Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Router Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Output Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Security Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Input Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:19:37 --> Language Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Loader Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:19:37 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Session Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:19:37 --> Session routines successfully run
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Controller Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Model Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:19:37 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:19:37 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:19:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:19:38 --> Final output sent to browser
DEBUG - 2016-08-03 11:19:38 --> Total execution time: 0.4303
DEBUG - 2016-08-03 11:20:19 --> Config Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:20:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:20:19 --> URI Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Router Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Output Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Security Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Input Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:20:19 --> Language Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Loader Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:20:19 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Session Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:20:19 --> Session routines successfully run
DEBUG - 2016-08-03 11:20:19 --> Model Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Model Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Controller Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Model Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:20:19 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:20:19 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:20:19 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 11:20:19 --> Final output sent to browser
DEBUG - 2016-08-03 11:20:19 --> Total execution time: 0.1876
DEBUG - 2016-08-03 11:21:02 --> Config Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:21:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:21:02 --> URI Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Router Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Output Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Security Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Input Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:21:02 --> Language Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Loader Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:21:02 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Session Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:21:02 --> Session routines successfully run
DEBUG - 2016-08-03 11:21:02 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Controller Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:21:02 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:21:02 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:21:02 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 11:21:02 --> Final output sent to browser
DEBUG - 2016-08-03 11:21:02 --> Total execution time: 0.1873
DEBUG - 2016-08-03 11:21:10 --> Config Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:21:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:21:10 --> URI Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Router Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Output Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Security Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Input Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:21:10 --> Language Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Loader Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:21:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Session Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:21:10 --> Session routines successfully run
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Controller Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:21:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:21:10 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:21:10 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:21:10 --> Final output sent to browser
DEBUG - 2016-08-03 11:21:10 --> Total execution time: 0.4395
DEBUG - 2016-08-03 11:21:16 --> Config Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:21:16 --> URI Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Router Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Output Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Security Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Input Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:21:16 --> Language Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Loader Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:21:16 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Session Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:21:16 --> Session routines successfully run
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Controller Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:21:16 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:21:16 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:21:16 --> Final output sent to browser
DEBUG - 2016-08-03 11:21:16 --> Total execution time: 0.2234
DEBUG - 2016-08-03 11:21:20 --> Config Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:21:20 --> URI Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Router Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Output Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Security Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Input Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:21:20 --> Language Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Loader Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:21:20 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Session Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:21:20 --> Session routines successfully run
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Controller Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:21:20 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:21:20 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:21:20 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:21:20 --> Final output sent to browser
DEBUG - 2016-08-03 11:21:20 --> Total execution time: 0.3895
DEBUG - 2016-08-03 11:22:11 --> Config Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:22:11 --> URI Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Router Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Output Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Security Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Input Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:22:11 --> Language Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Loader Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:22:11 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Session Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:22:11 --> Session routines successfully run
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Controller Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:22:11 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:22:11 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:22:11 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:22:11 --> Final output sent to browser
DEBUG - 2016-08-03 11:22:11 --> Total execution time: 0.3752
DEBUG - 2016-08-03 11:22:18 --> Config Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:22:18 --> URI Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Router Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Output Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Security Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Input Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:22:18 --> Language Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Loader Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:22:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Session Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:22:18 --> Session routines successfully run
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Controller Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:22:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:22:18 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:22:18 --> Final output sent to browser
DEBUG - 2016-08-03 11:22:18 --> Total execution time: 0.2166
DEBUG - 2016-08-03 11:22:23 --> Config Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:22:23 --> URI Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Router Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Output Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Security Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Input Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:22:23 --> Language Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Loader Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:22:23 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Session Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:22:23 --> Session routines successfully run
DEBUG - 2016-08-03 11:22:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Controller Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:22:23 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:22:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:22:23 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:22:23 --> Final output sent to browser
DEBUG - 2016-08-03 11:22:23 --> Total execution time: 0.1802
DEBUG - 2016-08-03 11:24:14 --> Config Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:24:14 --> URI Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Router Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Output Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Security Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Input Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:24:14 --> Language Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Loader Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:24:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Session Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:24:14 --> Session routines successfully run
DEBUG - 2016-08-03 11:24:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Controller Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:24:15 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:24:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:24:15 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:24:15 --> Final output sent to browser
DEBUG - 2016-08-03 11:24:15 --> Total execution time: 0.2437
DEBUG - 2016-08-03 11:26:00 --> Config Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:26:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:26:00 --> URI Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Router Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Output Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Security Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Input Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:26:00 --> Language Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Loader Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:26:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Session Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:26:00 --> Session routines successfully run
DEBUG - 2016-08-03 11:26:00 --> Model Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Model Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Controller Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Model Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:26:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:26:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:26:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:26:00 --> Final output sent to browser
DEBUG - 2016-08-03 11:26:00 --> Total execution time: 0.1746
DEBUG - 2016-08-03 11:26:04 --> Config Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:26:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:26:04 --> URI Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Router Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Output Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Security Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Input Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:26:04 --> Language Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Loader Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:26:04 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Session Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:26:04 --> Session routines successfully run
DEBUG - 2016-08-03 11:26:04 --> Model Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Model Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Controller Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Model Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:26:04 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:26:04 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:26:04 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 11:26:04 --> Final output sent to browser
DEBUG - 2016-08-03 11:26:04 --> Total execution time: 0.1790
DEBUG - 2016-08-03 11:41:59 --> Config Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:41:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:41:59 --> URI Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Router Class Initialized
DEBUG - 2016-08-03 11:41:59 --> No URI present. Default controller set.
DEBUG - 2016-08-03 11:41:59 --> Output Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Security Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Input Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:41:59 --> Language Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Loader Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:41:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Session Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:41:59 --> A session cookie was not found.
DEBUG - 2016-08-03 11:41:59 --> Session routines successfully run
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Controller Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Model Class Initialized
DEBUG - 2016-08-03 11:41:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:41:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:41:59 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 11:41:59 --> Final output sent to browser
DEBUG - 2016-08-03 11:41:59 --> Total execution time: 0.2836
DEBUG - 2016-08-03 11:42:10 --> Config Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:42:10 --> URI Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Router Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Output Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Security Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Input Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:42:10 --> Language Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Loader Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:42:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Session Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:42:10 --> Session routines successfully run
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Controller Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:42:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 11:42:10 --> Config Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:42:10 --> URI Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Router Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Output Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Security Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Input Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:42:10 --> Language Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Loader Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:42:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Session Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:42:10 --> Session routines successfully run
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Controller Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:42:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:42:10 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:42:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:42:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:42:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:42:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:42:11 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:42:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:42:11 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:42:11 --> Final output sent to browser
DEBUG - 2016-08-03 11:42:11 --> Total execution time: 0.3394
DEBUG - 2016-08-03 11:42:15 --> Config Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:42:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:42:15 --> URI Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Router Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Output Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Security Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Input Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:42:15 --> Language Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Loader Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:42:15 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Session Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:42:15 --> Session routines successfully run
DEBUG - 2016-08-03 11:42:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Controller Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Model Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:42:15 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:42:15 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:42:15 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:42:15 --> Final output sent to browser
DEBUG - 2016-08-03 11:42:15 --> Total execution time: 0.2000
DEBUG - 2016-08-03 11:43:43 --> Config Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:43:43 --> URI Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Router Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Output Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Security Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Input Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:43:43 --> Language Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Loader Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:43:43 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Session Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:43:43 --> Session routines successfully run
DEBUG - 2016-08-03 11:43:43 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Controller Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:43:43 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:43:43 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:43:43 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 11:43:43 --> Final output sent to browser
DEBUG - 2016-08-03 11:43:43 --> Total execution time: 0.2898
DEBUG - 2016-08-03 11:43:46 --> Config Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:43:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:43:46 --> URI Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Router Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Output Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Security Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Input Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:43:46 --> Language Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Loader Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:43:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Session Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:43:46 --> Session routines successfully run
DEBUG - 2016-08-03 11:43:46 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Controller Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:43:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:43:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:43:46 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 11:43:46 --> Final output sent to browser
DEBUG - 2016-08-03 11:43:46 --> Total execution time: 0.2339
DEBUG - 2016-08-03 11:43:56 --> Config Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:43:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:43:56 --> URI Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Router Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Output Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Security Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Input Class Initialized
DEBUG - 2016-08-03 11:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:43:57 --> Language Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Loader Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:43:57 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Session Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:43:57 --> Session routines successfully run
DEBUG - 2016-08-03 11:43:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Controller Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Model Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:43:57 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:43:57 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:43:57 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 11:43:57 --> Final output sent to browser
DEBUG - 2016-08-03 11:43:57 --> Total execution time: 0.2782
DEBUG - 2016-08-03 11:44:23 --> Config Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:44:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:44:23 --> URI Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Router Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Output Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Security Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Input Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:44:23 --> Language Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Loader Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:44:23 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Session Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:44:23 --> Session routines successfully run
DEBUG - 2016-08-03 11:44:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Controller Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:44:23 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:44:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:44:23 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 11:44:23 --> Final output sent to browser
DEBUG - 2016-08-03 11:44:23 --> Total execution time: 0.1982
DEBUG - 2016-08-03 11:44:34 --> Config Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:44:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:44:34 --> URI Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Router Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Output Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Security Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Input Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:44:34 --> Language Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Loader Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:44:34 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Session Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:44:34 --> Session routines successfully run
DEBUG - 2016-08-03 11:44:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Controller Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:44:34 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:44:34 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:44:34 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 11:44:34 --> Final output sent to browser
DEBUG - 2016-08-03 11:44:34 --> Total execution time: 0.2051
DEBUG - 2016-08-03 11:44:45 --> Config Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:44:45 --> URI Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Router Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Output Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Security Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Input Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:44:45 --> Language Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Loader Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:44:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Session Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:44:45 --> Session routines successfully run
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Controller Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:45 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:46 --> Model Class Initialized
DEBUG - 2016-08-03 11:44:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:44:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:44:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:44:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:44:46 --> Final output sent to browser
DEBUG - 2016-08-03 11:44:46 --> Total execution time: 0.5606
DEBUG - 2016-08-03 11:45:00 --> Config Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:45:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:45:00 --> URI Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Router Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Output Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Security Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Input Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:45:00 --> Language Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Loader Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:45:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Session Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:45:00 --> Session routines successfully run
DEBUG - 2016-08-03 11:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Controller Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:45:00 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:01 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:45:01 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:45:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:01 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:45:01 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:45:01 --> Final output sent to browser
DEBUG - 2016-08-03 11:45:01 --> Total execution time: 0.2437
DEBUG - 2016-08-03 11:45:20 --> Config Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:45:20 --> URI Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Router Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Output Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Security Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Input Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:45:20 --> Language Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Loader Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:45:20 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Session Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:45:20 --> Session routines successfully run
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Controller Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Model Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:45:20 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:45:20 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:45:20 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 11:45:20 --> Final output sent to browser
DEBUG - 2016-08-03 11:45:20 --> Total execution time: 0.4063
DEBUG - 2016-08-03 11:46:05 --> Config Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:46:05 --> URI Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Router Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Output Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Security Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Input Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:46:05 --> Language Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Loader Class Initialized
DEBUG - 2016-08-03 11:46:05 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:46:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Session Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:46:06 --> Session routines successfully run
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Controller Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:46:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:46:06 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:46:06 --> Final output sent to browser
DEBUG - 2016-08-03 11:46:06 --> Total execution time: 0.2298
DEBUG - 2016-08-03 11:46:51 --> Config Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:46:51 --> URI Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Router Class Initialized
DEBUG - 2016-08-03 11:46:51 --> No URI present. Default controller set.
DEBUG - 2016-08-03 11:46:51 --> Output Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Security Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Input Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:46:51 --> Language Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Loader Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:46:51 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Session Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:46:51 --> Session routines successfully run
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Controller Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:46:51 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Config Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:46:51 --> URI Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Router Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Output Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Security Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Input Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:46:51 --> Language Class Initialized
DEBUG - 2016-08-03 11:46:51 --> Loader Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:46:52 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Session Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:46:52 --> Session routines successfully run
DEBUG - 2016-08-03 11:46:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Controller Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:46:52 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:46:52 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:46:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 11:46:52 --> Final output sent to browser
DEBUG - 2016-08-03 11:46:52 --> Total execution time: 0.1651
DEBUG - 2016-08-03 11:46:54 --> Config Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:46:54 --> URI Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Router Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Output Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Security Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Input Class Initialized
DEBUG - 2016-08-03 11:46:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:46:55 --> Language Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Loader Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:46:55 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Session Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:46:55 --> Session routines successfully run
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Controller Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Pagination Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:46:55 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> Model Class Initialized
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 11:46:55 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 11:46:55 --> Final output sent to browser
DEBUG - 2016-08-03 11:46:55 --> Total execution time: 0.2470
DEBUG - 2016-08-03 11:47:14 --> Config Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:47:14 --> URI Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Router Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Output Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Security Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Input Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:47:14 --> Language Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Loader Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:47:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Session Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:47:14 --> Session routines successfully run
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Controller Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:47:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Config Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 11:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 11:47:14 --> URI Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Router Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Output Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Security Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Input Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 11:47:14 --> Language Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Loader Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 11:47:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Session Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 11:47:14 --> Session routines successfully run
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Controller Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Model Class Initialized
DEBUG - 2016-08-03 11:47:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 11:47:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 11:47:14 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 11:47:14 --> Final output sent to browser
DEBUG - 2016-08-03 11:47:14 --> Total execution time: 0.1545
DEBUG - 2016-08-03 14:19:53 --> Config Class Initialized
DEBUG - 2016-08-03 14:19:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:19:53 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:19:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:19:53 --> URI Class Initialized
DEBUG - 2016-08-03 14:19:53 --> Router Class Initialized
DEBUG - 2016-08-03 14:19:54 --> No URI present. Default controller set.
DEBUG - 2016-08-03 14:19:54 --> Output Class Initialized
DEBUG - 2016-08-03 14:19:54 --> Security Class Initialized
DEBUG - 2016-08-03 14:19:54 --> Input Class Initialized
DEBUG - 2016-08-03 14:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:19:54 --> Language Class Initialized
DEBUG - 2016-08-03 14:19:54 --> Loader Class Initialized
DEBUG - 2016-08-03 14:19:55 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:19:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:19:56 --> Session Class Initialized
DEBUG - 2016-08-03 14:19:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:19:57 --> A session cookie was not found.
DEBUG - 2016-08-03 14:19:57 --> Session routines successfully run
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Controller Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:19:58 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:19:58 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:19:58 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 14:19:58 --> Final output sent to browser
DEBUG - 2016-08-03 14:19:58 --> Total execution time: 5.6720
DEBUG - 2016-08-03 14:20:55 --> Config Class Initialized
DEBUG - 2016-08-03 14:20:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:20:55 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:20:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:20:55 --> URI Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Router Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Output Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Security Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Input Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:20:56 --> Language Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Loader Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:20:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Session Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:20:56 --> Session routines successfully run
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Controller Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:20:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:20:56 --> Config Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:20:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:20:56 --> URI Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Router Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Output Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Security Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Input Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:20:56 --> Language Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Loader Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:20:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Session Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:20:56 --> Session routines successfully run
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Controller Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:20:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:20:56 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:20:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 14:20:56 --> Final output sent to browser
DEBUG - 2016-08-03 14:20:56 --> Total execution time: 0.3549
DEBUG - 2016-08-03 14:21:12 --> Config Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:21:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:21:12 --> URI Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Router Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Output Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Security Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Input Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:21:12 --> Language Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Loader Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:21:12 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Session Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:21:12 --> Session routines successfully run
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Controller Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:21:12 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:21:12 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:21:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:21:12 --> Final output sent to browser
DEBUG - 2016-08-03 14:21:12 --> Total execution time: 0.7995
DEBUG - 2016-08-03 14:21:30 --> Config Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:21:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:21:30 --> URI Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Router Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Output Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Security Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Input Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:21:30 --> Language Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Loader Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:21:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Session Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:21:30 --> Session routines successfully run
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Controller Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:21:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:21:30 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:21:30 --> Final output sent to browser
DEBUG - 2016-08-03 14:21:30 --> Total execution time: 0.2859
DEBUG - 2016-08-03 14:21:38 --> Config Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:21:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:21:38 --> URI Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Router Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Output Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Security Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Input Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:21:38 --> Language Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Loader Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:21:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Session Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:21:38 --> Session routines successfully run
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Controller Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:21:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:21:39 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:21:39 --> Final output sent to browser
DEBUG - 2016-08-03 14:21:39 --> Total execution time: 0.1952
DEBUG - 2016-08-03 14:21:42 --> Config Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:21:42 --> URI Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Router Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Output Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Security Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Input Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:21:42 --> Language Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Loader Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:21:42 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Session Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:21:42 --> Session routines successfully run
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Controller Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:21:42 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:21:42 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:21:42 --> Final output sent to browser
DEBUG - 2016-08-03 14:21:42 --> Total execution time: 0.2823
DEBUG - 2016-08-03 14:21:45 --> Config Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:21:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:21:45 --> URI Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Router Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Output Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Security Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Input Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:21:45 --> Language Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Loader Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:21:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Session Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:21:45 --> Session routines successfully run
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Controller Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:21:45 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:21:45 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:21:45 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:21:45 --> Final output sent to browser
DEBUG - 2016-08-03 14:21:45 --> Total execution time: 0.3920
DEBUG - 2016-08-03 14:24:13 --> Config Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:24:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:24:13 --> URI Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Router Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Output Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Security Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Input Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:24:13 --> Language Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Loader Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:24:13 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Session Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:24:13 --> Session routines successfully run
DEBUG - 2016-08-03 14:24:13 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Controller Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:24:13 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:24:13 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:24:13 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 14:24:13 --> Final output sent to browser
DEBUG - 2016-08-03 14:24:13 --> Total execution time: 0.1909
DEBUG - 2016-08-03 14:24:20 --> Config Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:24:20 --> URI Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Router Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Output Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Security Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Input Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:24:20 --> Language Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Loader Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:24:20 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Session Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:24:20 --> Session routines successfully run
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Controller Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:24:20 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:24:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:24:20 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:24:20 --> Final output sent to browser
DEBUG - 2016-08-03 14:24:20 --> Total execution time: 0.2144
DEBUG - 2016-08-03 14:29:33 --> Config Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:29:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:29:33 --> URI Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Router Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Output Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Security Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Input Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:29:33 --> Language Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Loader Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:29:33 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Session Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:29:33 --> Session routines successfully run
DEBUG - 2016-08-03 14:29:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Controller Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:29:33 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:29:33 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:29:33 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 14:29:33 --> Final output sent to browser
DEBUG - 2016-08-03 14:29:33 --> Total execution time: 0.1858
DEBUG - 2016-08-03 14:29:37 --> Config Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:29:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:29:37 --> URI Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Router Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Output Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Security Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Input Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:29:37 --> Language Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Loader Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:29:37 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Session Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:29:37 --> Session routines successfully run
DEBUG - 2016-08-03 14:29:37 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:37 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:38 --> Controller Class Initialized
DEBUG - 2016-08-03 14:29:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:29:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:29:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:29:38 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 14:29:38 --> Final output sent to browser
DEBUG - 2016-08-03 14:29:38 --> Total execution time: 0.1860
DEBUG - 2016-08-03 14:29:44 --> Config Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:29:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:29:44 --> URI Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Router Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Output Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Security Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Input Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:29:44 --> Language Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Loader Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:29:44 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Session Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:29:44 --> Session routines successfully run
DEBUG - 2016-08-03 14:29:44 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Controller Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Model Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:29:44 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:29:44 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:29:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:29:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:29:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:29:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:29:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:29:44 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-08-03 14:29:44 --> Final output sent to browser
DEBUG - 2016-08-03 14:29:44 --> Total execution time: 0.2359
DEBUG - 2016-08-03 14:30:01 --> Config Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:30:01 --> URI Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Router Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Output Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Security Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Input Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:30:01 --> Language Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Loader Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:30:01 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Session Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:30:01 --> Session routines successfully run
DEBUG - 2016-08-03 14:30:01 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Controller Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:30:01 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:30:01 --> Config Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:30:01 --> URI Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Router Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Output Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Security Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Input Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:30:01 --> Language Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Loader Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:30:01 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Session Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:30:01 --> Session routines successfully run
DEBUG - 2016-08-03 14:30:01 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:01 --> Controller Class Initialized
DEBUG - 2016-08-03 14:30:02 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:02 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:30:02 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:30:02 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:30:02 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 14:30:02 --> Final output sent to browser
DEBUG - 2016-08-03 14:30:02 --> Total execution time: 0.2083
DEBUG - 2016-08-03 14:30:07 --> Config Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:30:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:30:07 --> URI Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Router Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Output Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Security Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Input Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:30:07 --> Language Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Loader Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:30:07 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Session Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:30:07 --> Session routines successfully run
DEBUG - 2016-08-03 14:30:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Controller Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:30:07 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:30:07 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:30:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:30:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:30:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:30:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:30:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:30:07 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-08-03 14:30:07 --> Final output sent to browser
DEBUG - 2016-08-03 14:30:07 --> Total execution time: 0.2066
DEBUG - 2016-08-03 14:30:30 --> Config Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:30:30 --> URI Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Router Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Output Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Security Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Input Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:30:30 --> Language Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Loader Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:30:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Session Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:30:30 --> Session routines successfully run
DEBUG - 2016-08-03 14:30:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Controller Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:30:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:30:30 --> Config Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:30:30 --> URI Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Router Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Output Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Security Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Input Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:30:30 --> Language Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Loader Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:30:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Session Class Initialized
DEBUG - 2016-08-03 14:30:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:30:31 --> Session routines successfully run
DEBUG - 2016-08-03 14:30:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:31 --> Controller Class Initialized
DEBUG - 2016-08-03 14:30:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:31 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:30:31 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:30:31 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:30:31 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 14:30:31 --> Final output sent to browser
DEBUG - 2016-08-03 14:30:31 --> Total execution time: 0.1916
DEBUG - 2016-08-03 14:30:39 --> Config Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:30:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:30:39 --> URI Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Router Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Output Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Security Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Input Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:30:39 --> Language Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Loader Class Initialized
DEBUG - 2016-08-03 14:30:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:30:40 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Session Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:30:40 --> Session routines successfully run
DEBUG - 2016-08-03 14:30:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Controller Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:30:40 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:30:40 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:30:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:30:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:30:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:30:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:30:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:30:40 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2016-08-03 14:30:40 --> Final output sent to browser
DEBUG - 2016-08-03 14:30:40 --> Total execution time: 0.2427
DEBUG - 2016-08-03 14:31:03 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:03 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:03 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:03 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:31:04 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:04 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:04 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:04 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:04 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:04 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:04 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:31:04 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 14:31:04 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:04 --> Total execution time: 0.2167
DEBUG - 2016-08-03 14:31:08 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:08 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:08 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:08 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:08 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:08 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:08 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:31:08 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 14:31:08 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:08 --> Total execution time: 0.1959
DEBUG - 2016-08-03 14:31:10 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:10 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:10 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:10 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:10 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:31:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:31:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:31:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:31:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:31:10 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2016-08-03 14:31:10 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:10 --> Total execution time: 0.2760
DEBUG - 2016-08-03 14:31:36 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:36 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:36 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:36 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:36 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:36 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:31:36 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:36 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:36 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:36 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:36 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:36 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:36 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:31:36 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 14:31:36 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:36 --> Total execution time: 0.2268
DEBUG - 2016-08-03 14:31:41 --> Config Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:31:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:31:41 --> URI Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Router Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Output Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Security Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Input Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:31:41 --> Language Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Loader Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:31:41 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Session Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:31:41 --> Session routines successfully run
DEBUG - 2016-08-03 14:31:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Controller Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:31:41 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:31:41 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:31:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:31:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:31:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:31:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:31:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:31:41 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-08-03 14:31:41 --> Final output sent to browser
DEBUG - 2016-08-03 14:31:41 --> Total execution time: 0.2544
DEBUG - 2016-08-03 14:33:00 --> Config Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:33:00 --> URI Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Router Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Output Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Security Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Input Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:33:00 --> Language Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Loader Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:33:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Session Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:33:00 --> Session routines successfully run
DEBUG - 2016-08-03 14:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Controller Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Model Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:33:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:33:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:33:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:33:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:33:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:33:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:33:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:33:00 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-08-03 14:33:00 --> Final output sent to browser
DEBUG - 2016-08-03 14:33:00 --> Total execution time: 0.1812
DEBUG - 2016-08-03 14:33:55 --> Config Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:33:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:33:55 --> URI Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Router Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Output Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Security Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Input Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:33:55 --> Language Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Loader Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:33:55 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Session Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:33:55 --> Session routines successfully run
DEBUG - 2016-08-03 14:33:55 --> Model Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Model Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Controller Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Model Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:33:55 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:33:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:33:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:33:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:33:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:33:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:33:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:33:55 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-08-03 14:33:55 --> Final output sent to browser
DEBUG - 2016-08-03 14:33:55 --> Total execution time: 0.1935
DEBUG - 2016-08-03 14:34:31 --> Config Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:34:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:34:31 --> URI Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Router Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Output Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Security Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Input Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:34:31 --> Language Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Loader Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:34:31 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Session Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:34:31 --> Session routines successfully run
DEBUG - 2016-08-03 14:34:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Controller Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:34:31 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:34:31 --> Config Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:34:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:34:31 --> URI Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Router Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Output Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Security Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Input Class Initialized
DEBUG - 2016-08-03 14:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:34:32 --> Language Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Loader Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:34:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Session Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:34:32 --> Session routines successfully run
DEBUG - 2016-08-03 14:34:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Controller Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:34:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:34:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:34:32 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:34:32 --> Final output sent to browser
DEBUG - 2016-08-03 14:34:32 --> Total execution time: 0.2226
DEBUG - 2016-08-03 14:34:43 --> Config Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:34:43 --> URI Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Router Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Output Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Security Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Input Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:34:43 --> Language Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Loader Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:34:43 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Session Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:34:43 --> Session routines successfully run
DEBUG - 2016-08-03 14:34:43 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Controller Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:34:43 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:34:43 --> Pagination Class Initialized
ERROR - 2016-08-03 14:34:43 --> 404 Page Not Found --> admin/editCustomer
DEBUG - 2016-08-03 14:34:49 --> Config Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:34:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:34:49 --> URI Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Router Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Output Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Security Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Input Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:34:49 --> Language Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Loader Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:34:49 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Session Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:34:49 --> Session routines successfully run
DEBUG - 2016-08-03 14:34:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Controller Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:34:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:34:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:34:49 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:34:49 --> Final output sent to browser
DEBUG - 2016-08-03 14:34:49 --> Total execution time: 0.1901
DEBUG - 2016-08-03 14:35:29 --> Config Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:35:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:35:29 --> URI Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Router Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Output Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Security Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Input Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:35:29 --> Language Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Loader Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:35:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Session Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:35:29 --> Session routines successfully run
DEBUG - 2016-08-03 14:35:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Controller Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:35:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:35:29 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:35:29 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:35:29 --> Final output sent to browser
DEBUG - 2016-08-03 14:35:29 --> Total execution time: 0.2017
DEBUG - 2016-08-03 14:35:32 --> Config Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:35:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:35:32 --> URI Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Router Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Output Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Security Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Input Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:35:32 --> Language Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Loader Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:35:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Session Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:35:32 --> Session routines successfully run
DEBUG - 2016-08-03 14:35:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Controller Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:35:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:35:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:35:32 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:35:32 --> Final output sent to browser
DEBUG - 2016-08-03 14:35:32 --> Total execution time: 0.2144
DEBUG - 2016-08-03 14:35:44 --> Config Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:35:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:35:44 --> URI Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Router Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Output Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Security Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Input Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:35:44 --> Language Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Loader Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:35:44 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Session Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:35:44 --> Session routines successfully run
DEBUG - 2016-08-03 14:35:44 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Controller Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:35:44 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:35:44 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:35:44 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:35:44 --> Final output sent to browser
DEBUG - 2016-08-03 14:35:44 --> Total execution time: 0.2311
DEBUG - 2016-08-03 14:35:59 --> Config Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:35:59 --> URI Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Router Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Output Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Security Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Input Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:35:59 --> Language Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Loader Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:35:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Session Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:35:59 --> Session routines successfully run
DEBUG - 2016-08-03 14:35:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Controller Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:35:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:35:59 --> Pagination Class Initialized
ERROR - 2016-08-03 14:35:59 --> 404 Page Not Found --> admin/deleteCustomer
DEBUG - 2016-08-03 14:36:41 --> Config Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:36:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:36:41 --> URI Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Router Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Output Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Security Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Input Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:36:41 --> Language Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Loader Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:36:41 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Session Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:36:41 --> Session routines successfully run
DEBUG - 2016-08-03 14:36:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Controller Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:36:41 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:36:41 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:36:41 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:36:41 --> Final output sent to browser
DEBUG - 2016-08-03 14:36:41 --> Total execution time: 0.2198
DEBUG - 2016-08-03 14:36:45 --> Config Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:36:45 --> URI Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Router Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Output Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Security Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Input Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:36:45 --> Language Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Loader Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:36:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Session Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:36:45 --> Session routines successfully run
DEBUG - 2016-08-03 14:36:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Controller Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:36:45 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Config Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:36:45 --> URI Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Router Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Output Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Security Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Input Class Initialized
DEBUG - 2016-08-03 14:36:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:36:46 --> Language Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Loader Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:36:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Session Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:36:46 --> Session routines successfully run
DEBUG - 2016-08-03 14:36:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Controller Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:36:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:36:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:36:46 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:36:46 --> Final output sent to browser
DEBUG - 2016-08-03 14:36:46 --> Total execution time: 0.2563
DEBUG - 2016-08-03 14:37:00 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:00 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:00 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:00 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:00 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:00 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:00 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:00 --> Total execution time: 0.2128
DEBUG - 2016-08-03 14:37:07 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:07 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:08 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:08 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:08 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:08 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:08 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:08 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:08 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:08 --> Total execution time: 0.2164
DEBUG - 2016-08-03 14:37:15 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:15 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:15 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:15 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:15 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:15 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:15 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:15 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:15 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:15 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:15 --> Total execution time: 0.2202
DEBUG - 2016-08-03 14:37:31 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:31 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:31 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:31 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:31 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:31 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:31 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:31 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:31 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:31 --> Total execution time: 0.2138
DEBUG - 2016-08-03 14:37:35 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:35 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:35 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:35 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:35 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:35 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:35 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:35 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:35 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:35 --> Total execution time: 0.2086
DEBUG - 2016-08-03 14:37:41 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:41 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:41 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:41 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:41 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:41 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:41 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:41 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:41 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:41 --> Total execution time: 0.2083
DEBUG - 2016-08-03 14:37:46 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:46 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:46 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:46 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:46 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:46 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:46 --> Total execution time: 0.2197
DEBUG - 2016-08-03 14:37:48 --> Config Class Initialized
DEBUG - 2016-08-03 14:37:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:37:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:37:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:37:49 --> URI Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Router Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Output Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Security Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Input Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:37:49 --> Language Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Loader Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:37:49 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Session Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:37:49 --> Session routines successfully run
DEBUG - 2016-08-03 14:37:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Controller Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:37:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:37:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:37:49 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:37:49 --> Final output sent to browser
DEBUG - 2016-08-03 14:37:49 --> Total execution time: 0.2146
DEBUG - 2016-08-03 14:38:10 --> Config Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:38:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:38:10 --> URI Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Router Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Output Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Security Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Input Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:38:10 --> Language Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Loader Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:38:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Session Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:38:10 --> Session routines successfully run
DEBUG - 2016-08-03 14:38:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Controller Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:38:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:38:10 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:38:10 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:38:10 --> Final output sent to browser
DEBUG - 2016-08-03 14:38:10 --> Total execution time: 0.2120
DEBUG - 2016-08-03 14:39:32 --> Config Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:39:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:39:32 --> URI Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Router Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Output Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Security Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Input Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:39:32 --> Language Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Loader Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:39:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Session Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:39:32 --> Session routines successfully run
DEBUG - 2016-08-03 14:39:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Controller Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Model Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:39:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:39:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:39:33 --> DB Transaction Failure
ERROR - 2016-08-03 14:39:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by customer_id desc' at line 1
DEBUG - 2016-08-03 14:39:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-08-03 14:40:21 --> Config Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:40:21 --> URI Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Router Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Output Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Security Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Input Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:40:21 --> Language Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Loader Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:40:21 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Session Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:40:21 --> Session routines successfully run
DEBUG - 2016-08-03 14:40:21 --> Model Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Model Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Controller Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Model Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:40:21 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:40:21 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:40:21 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:40:21 --> Final output sent to browser
DEBUG - 2016-08-03 14:40:21 --> Total execution time: 0.2113
DEBUG - 2016-08-03 14:40:53 --> Config Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:40:53 --> URI Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Router Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Output Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Security Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Input Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:40:53 --> Language Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Loader Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:40:53 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Session Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:40:53 --> Session routines successfully run
DEBUG - 2016-08-03 14:40:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Controller Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:40:53 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:40:53 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:40:53 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:40:53 --> Final output sent to browser
DEBUG - 2016-08-03 14:40:53 --> Total execution time: 0.2191
DEBUG - 2016-08-03 14:41:07 --> Config Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:41:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:41:07 --> URI Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Router Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Output Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Security Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Input Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:41:07 --> Language Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Loader Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:41:07 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Session Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:41:07 --> Session routines successfully run
DEBUG - 2016-08-03 14:41:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Controller Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:41:07 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:41:07 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:41:07 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 14:41:07 --> Final output sent to browser
DEBUG - 2016-08-03 14:41:07 --> Total execution time: 0.2413
DEBUG - 2016-08-03 14:41:10 --> Config Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:41:10 --> URI Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Router Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Output Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Security Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Input Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:41:10 --> Language Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Loader Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:41:10 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Session Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:41:10 --> Session routines successfully run
DEBUG - 2016-08-03 14:41:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Controller Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:41:10 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:41:10 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:41:10 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-03 14:41:10 --> Final output sent to browser
DEBUG - 2016-08-03 14:41:10 --> Total execution time: 0.2170
DEBUG - 2016-08-03 14:41:12 --> Config Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:41:12 --> URI Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Router Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Output Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Security Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Input Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:41:12 --> Language Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Loader Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:41:12 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Session Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:41:12 --> Session routines successfully run
DEBUG - 2016-08-03 14:41:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Controller Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:41:12 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:41:12 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:41:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 14:41:12 --> Final output sent to browser
DEBUG - 2016-08-03 14:41:12 --> Total execution time: 0.2183
DEBUG - 2016-08-03 14:41:16 --> Config Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:41:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:41:16 --> URI Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Router Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Output Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Security Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Input Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:41:16 --> Language Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Loader Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:41:16 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Session Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:41:16 --> Session routines successfully run
DEBUG - 2016-08-03 14:41:16 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Controller Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:41:16 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:41:16 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:41:16 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 14:41:16 --> Final output sent to browser
DEBUG - 2016-08-03 14:41:16 --> Total execution time: 0.2272
DEBUG - 2016-08-03 14:41:18 --> Config Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:41:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:41:18 --> URI Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Router Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Output Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Security Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Input Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:41:18 --> Language Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Loader Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:41:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Session Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:41:18 --> Session routines successfully run
DEBUG - 2016-08-03 14:41:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Controller Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:41:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:41:19 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:41:19 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:41:19 --> Final output sent to browser
DEBUG - 2016-08-03 14:41:19 --> Total execution time: 0.2327
DEBUG - 2016-08-03 14:41:38 --> Config Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:41:38 --> URI Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Router Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Output Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Security Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Input Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:41:38 --> Language Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Loader Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:41:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Session Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:41:38 --> Session routines successfully run
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Controller Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:41:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:41:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:41:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:41:38 --> Final output sent to browser
DEBUG - 2016-08-03 14:41:38 --> Total execution time: 0.5643
DEBUG - 2016-08-03 14:42:03 --> Config Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:42:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:42:03 --> URI Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Router Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Output Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Security Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Input Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:42:03 --> Language Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Loader Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:42:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Session Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:42:03 --> Session routines successfully run
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Controller Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:42:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Config Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:42:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:42:03 --> URI Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Router Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Output Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Security Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Input Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:42:03 --> Language Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Loader Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:42:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Session Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:42:03 --> Session routines successfully run
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Controller Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:42:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:42:03 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 14:42:03 --> Final output sent to browser
DEBUG - 2016-08-03 14:42:03 --> Total execution time: 0.2040
DEBUG - 2016-08-03 14:42:14 --> Config Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:42:14 --> URI Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Router Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Output Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Security Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Input Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:42:14 --> Language Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Loader Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:42:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Session Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:42:14 --> Session routines successfully run
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Controller Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:42:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:42:14 --> Config Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:42:14 --> URI Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Router Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Output Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Security Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Input Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:42:14 --> Language Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Loader Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:42:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Session Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:42:14 --> Session routines successfully run
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Controller Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:42:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:42:14 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:42:14 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 14:42:14 --> Final output sent to browser
DEBUG - 2016-08-03 14:42:14 --> Total execution time: 0.3087
DEBUG - 2016-08-03 14:42:18 --> Config Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:42:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:42:18 --> URI Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Router Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Output Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Security Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Input Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:42:18 --> Language Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Loader Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:42:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Session Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:42:18 --> Session routines successfully run
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Controller Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:42:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> Model Class Initialized
DEBUG - 2016-08-03 14:42:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:42:18 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:42:18 --> Final output sent to browser
DEBUG - 2016-08-03 14:42:18 --> Total execution time: 0.2386
DEBUG - 2016-08-03 14:47:29 --> Config Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:47:29 --> URI Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Router Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Output Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Security Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Input Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:47:29 --> Language Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Loader Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:47:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Session Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:47:29 --> Session routines successfully run
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Controller Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:47:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:47:29 --> Model Class Initialized
ERROR - 2016-08-03 14:47:29 --> Severity: Notice  --> Undefined variable: crm D:\xampp\htdocs\asmc\application\views\form\email.php 130
ERROR - 2016-08-03 14:47:29 --> Severity: Notice  --> Undefined variable: sm D:\xampp\htdocs\asmc\application\views\form\email.php 132
DEBUG - 2016-08-03 14:47:29 --> File loaded: application/views/form/email.php
DEBUG - 2016-08-03 14:47:29 --> Email Class Initialized
DEBUG - 2016-08-03 14:47:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:47:29 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:47:29 --> Final output sent to browser
DEBUG - 2016-08-03 14:47:29 --> Total execution time: 0.4433
DEBUG - 2016-08-03 14:48:25 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:25 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:25 --> No URI present. Default controller set.
DEBUG - 2016-08-03 14:48:25 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:25 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:25 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:25 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:25 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:25 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:26 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:26 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:26 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:26 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:26 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:26 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:26 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:48:26 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 14:48:26 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:26 --> Total execution time: 0.2210
DEBUG - 2016-08-03 14:48:31 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:31 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:31 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:31 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:31 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:31 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:31 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:48:31 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 14:48:31 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:31 --> Total execution time: 0.2450
DEBUG - 2016-08-03 14:48:34 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:34 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:34 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:34 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:34 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:34 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:34 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:48:34 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 14:48:34 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:34 --> Total execution time: 0.2323
DEBUG - 2016-08-03 14:48:35 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:35 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:35 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:35 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:35 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:35 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:35 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:48:35 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:48:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:48:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:48:35 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2016-08-03 14:48:35 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:35 --> Total execution time: 0.2267
DEBUG - 2016-08-03 14:48:38 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:38 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:38 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:38 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:38 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:38 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:39 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:39 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:39 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:39 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:48:39 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 14:48:39 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:39 --> Total execution time: 0.2362
DEBUG - 2016-08-03 14:48:45 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:45 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:45 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:45 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:45 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:45 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:48:45 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:48:45 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:45 --> Total execution time: 0.2817
DEBUG - 2016-08-03 14:48:56 --> Config Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:48:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:48:56 --> URI Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Router Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Output Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Security Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Input Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:48:56 --> Language Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Loader Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:48:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Session Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:48:56 --> Session routines successfully run
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Controller Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:48:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> Model Class Initialized
DEBUG - 2016-08-03 14:48:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:48:56 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:48:56 --> Final output sent to browser
DEBUG - 2016-08-03 14:48:56 --> Total execution time: 0.2523
DEBUG - 2016-08-03 14:49:19 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:19 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:19 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:19 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:19 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:19 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:19 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:49:19 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:19 --> Total execution time: 0.2471
DEBUG - 2016-08-03 14:49:24 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:24 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:24 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:24 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:24 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:24 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:49:25 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:49:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:49:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:49:25 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-08-03 14:49:25 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:25 --> Total execution time: 0.3642
DEBUG - 2016-08-03 14:49:29 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:29 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:29 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:29 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:29 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:30 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:49:30 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:30 --> Total execution time: 0.2451
DEBUG - 2016-08-03 14:49:34 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:34 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:34 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:34 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:34 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:34 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:34 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:49:34 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:49:34 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:34 --> Total execution time: 0.2885
DEBUG - 2016-08-03 14:49:38 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:38 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:38 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:38 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:49:38 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:49:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:49:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:49:38 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-08-03 14:49:38 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:38 --> Total execution time: 0.2598
DEBUG - 2016-08-03 14:49:40 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:40 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:40 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:40 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:40 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:40 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:40 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:49:40 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:49:40 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:40 --> Total execution time: 0.2898
DEBUG - 2016-08-03 14:49:41 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:41 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:41 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:41 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:42 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:42 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:42 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:42 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:49:42 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:42 --> Total execution time: 0.2450
DEBUG - 2016-08-03 14:49:48 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:48 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:48 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:48 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:48 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:48 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:48 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:48 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:48 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:48 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:48 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:48 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:48 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 14:49:48 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:48 --> Total execution time: 0.2137
DEBUG - 2016-08-03 14:49:53 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:53 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:53 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:53 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:53 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:53 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:49:53 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 14:49:53 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:53 --> Total execution time: 0.2271
DEBUG - 2016-08-03 14:49:59 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:59 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:59 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:59 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:49:59 --> Config Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:49:59 --> URI Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Router Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Output Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Security Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Input Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:49:59 --> Language Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Loader Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:49:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Session Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:49:59 --> Session routines successfully run
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Controller Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Model Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:49:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:49:59 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:49:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 14:49:59 --> Final output sent to browser
DEBUG - 2016-08-03 14:49:59 --> Total execution time: 0.2756
DEBUG - 2016-08-03 14:50:06 --> Config Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:50:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:50:06 --> URI Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Router Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Output Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Security Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Input Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:50:06 --> Language Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Loader Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:50:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Session Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:50:06 --> Session routines successfully run
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Controller Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:50:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:50:06 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:50:06 --> Final output sent to browser
DEBUG - 2016-08-03 14:50:06 --> Total execution time: 0.3516
DEBUG - 2016-08-03 14:50:14 --> Config Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:50:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:50:14 --> URI Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Router Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Output Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Security Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Input Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:50:14 --> Language Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Loader Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:50:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Session Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:50:14 --> Session routines successfully run
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Controller Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:50:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:50:14 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:50:14 --> Final output sent to browser
DEBUG - 2016-08-03 14:50:14 --> Total execution time: 0.2487
DEBUG - 2016-08-03 14:50:48 --> Config Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:50:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:50:48 --> URI Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Router Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Output Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Security Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Input Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:50:48 --> Language Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Loader Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:50:48 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Session Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:50:48 --> Session routines successfully run
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Controller Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Model Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:50:48 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:50:48 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:50:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:50:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:50:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:50:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:50:48 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:50:48 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:50:48 --> Final output sent to browser
DEBUG - 2016-08-03 14:50:48 --> Total execution time: 0.3447
DEBUG - 2016-08-03 14:51:06 --> Config Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:51:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:51:06 --> URI Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Router Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Output Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Security Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Input Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:51:06 --> Language Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Loader Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:51:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Session Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:51:06 --> Session routines successfully run
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Controller Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:51:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:51:06 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:51:06 --> Final output sent to browser
DEBUG - 2016-08-03 14:51:06 --> Total execution time: 0.3042
DEBUG - 2016-08-03 14:51:39 --> Config Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:51:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:51:39 --> URI Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Router Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Output Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Security Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Input Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:51:39 --> Language Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Loader Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:51:39 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Session Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:51:39 --> Session routines successfully run
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Controller Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Model Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:51:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:51:39 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:51:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:51:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:51:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:51:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:51:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:51:39 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:51:39 --> Final output sent to browser
DEBUG - 2016-08-03 14:51:39 --> Total execution time: 0.3179
DEBUG - 2016-08-03 14:52:05 --> Config Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:52:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:52:05 --> URI Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Router Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Output Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Security Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Input Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:52:05 --> Language Class Initialized
DEBUG - 2016-08-03 14:52:05 --> Loader Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:52:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Session Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:52:06 --> Session routines successfully run
DEBUG - 2016-08-03 14:52:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Controller Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:52:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:52:06 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:52:06 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 14:52:06 --> Final output sent to browser
DEBUG - 2016-08-03 14:52:06 --> Total execution time: 0.2644
DEBUG - 2016-08-03 14:52:25 --> Config Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:52:25 --> URI Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Router Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Output Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Security Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Input Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:52:25 --> Language Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Loader Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:52:25 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Session Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:52:25 --> Session routines successfully run
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Controller Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:52:25 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:52:25 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:52:26 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:52:26 --> Final output sent to browser
DEBUG - 2016-08-03 14:52:26 --> Total execution time: 0.5434
DEBUG - 2016-08-03 14:52:30 --> Config Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:52:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:52:30 --> URI Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Router Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Output Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Security Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Input Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:52:30 --> Language Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Loader Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:52:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Session Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:52:30 --> Session routines successfully run
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Controller Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:52:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:52:30 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:52:30 --> Final output sent to browser
DEBUG - 2016-08-03 14:52:30 --> Total execution time: 0.2893
DEBUG - 2016-08-03 14:52:33 --> Config Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:52:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:52:33 --> URI Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Router Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Output Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Security Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Input Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:52:33 --> Language Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Loader Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:52:33 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Session Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:52:33 --> Session routines successfully run
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Controller Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:52:33 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:52:33 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:52:33 --> Final output sent to browser
DEBUG - 2016-08-03 14:52:33 --> Total execution time: 0.3197
DEBUG - 2016-08-03 14:52:38 --> Config Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:52:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:52:38 --> URI Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Router Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Output Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Security Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Input Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:52:38 --> Language Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Loader Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:52:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Session Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:52:38 --> Session routines successfully run
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Controller Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:52:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:52:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:52:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:52:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:52:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:52:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:52:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:52:38 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:52:38 --> Final output sent to browser
DEBUG - 2016-08-03 14:52:38 --> Total execution time: 0.3037
DEBUG - 2016-08-03 14:53:19 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:19 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:19 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:19 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:19 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:19 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:19 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:19 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:53:19 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:19 --> Total execution time: 0.4680
DEBUG - 2016-08-03 14:53:22 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:22 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:22 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:22 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:22 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:22 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:22 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:23 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:53:23 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:23 --> Total execution time: 0.3114
DEBUG - 2016-08-03 14:53:30 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:30 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:30 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:30 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:30 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:30 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:53:30 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:30 --> Total execution time: 0.3223
DEBUG - 2016-08-03 14:53:34 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:34 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:34 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:34 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:34 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:34 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:34 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:34 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:53:34 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:34 --> Total execution time: 0.2941
DEBUG - 2016-08-03 14:53:38 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:38 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:38 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:38 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:38 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 14:53:39 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:39 --> Total execution time: 0.4640
DEBUG - 2016-08-03 14:53:45 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:45 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:45 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:45 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:45 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:46 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:46 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:53:46 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:46 --> Total execution time: 0.3074
DEBUG - 2016-08-03 14:53:48 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:49 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:49 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:49 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:49 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:49 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:53:49 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:49 --> Total execution time: 0.3005
DEBUG - 2016-08-03 14:53:52 --> Config Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:53:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:53:52 --> URI Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Router Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Output Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Security Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Input Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:53:52 --> Language Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Loader Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:53:52 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Session Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:53:52 --> Session routines successfully run
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Controller Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Model Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:53:52 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:53:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:53:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:53:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:53:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:53:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:53:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:53:52 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:53:52 --> Final output sent to browser
DEBUG - 2016-08-03 14:53:52 --> Total execution time: 0.3102
DEBUG - 2016-08-03 14:54:24 --> Config Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:54:24 --> URI Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Router Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Output Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Security Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Input Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:54:24 --> Language Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Loader Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:54:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Session Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:54:24 --> Session routines successfully run
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Controller Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:54:24 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:54:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:54:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:54:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:54:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:54:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:54:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:54:24 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:54:24 --> Final output sent to browser
DEBUG - 2016-08-03 14:54:24 --> Total execution time: 0.2941
DEBUG - 2016-08-03 14:54:57 --> Config Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:54:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:54:57 --> URI Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Router Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Output Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Security Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Input Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:54:57 --> Language Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Loader Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:54:57 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Session Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:54:57 --> Session routines successfully run
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Controller Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Model Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:54:57 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:54:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 14:54:58 --> Helper loaded: pdf_helper
ERROR - 2016-08-03 14:54:59 --> Severity: Warning  --> getimagesize(/home/sgdatacrm//public_html/asmc/images/logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\asmc\application\helpers\tcpdf\tcpdf.php 6850
ERROR - 2016-08-03 14:54:59 --> Severity: Warning  --> file_get_contents(/home/sgdatacrm//public_html/asmc/images/logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\asmc\application\helpers\tcpdf\include\tcpdf_static.php 2495
ERROR - 2016-08-03 14:54:59 --> Severity: Warning  --> file_get_contents(D:/xampp/htdocs/home/sgdatacrm//public_html/asmc/images/logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\asmc\application\helpers\tcpdf\include\tcpdf_static.php 2495
DEBUG - 2016-08-03 14:55:14 --> Config Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:55:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:55:14 --> URI Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Router Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Output Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Security Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Input Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:55:14 --> Language Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Loader Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:55:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Session Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:55:14 --> Session routines successfully run
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Controller Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:55:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:55:14 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:55:14 --> Final output sent to browser
DEBUG - 2016-08-03 14:55:14 --> Total execution time: 0.2936
DEBUG - 2016-08-03 14:55:20 --> Config Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:55:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:55:20 --> URI Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Router Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Output Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Security Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Input Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:55:20 --> Language Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Loader Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:55:20 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Session Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:55:20 --> Session routines successfully run
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Controller Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:55:20 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:55:20 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 14:55:20 --> Final output sent to browser
DEBUG - 2016-08-03 14:55:20 --> Total execution time: 0.2530
DEBUG - 2016-08-03 14:55:24 --> Config Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:55:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:55:24 --> URI Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Router Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Output Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Security Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Input Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:55:24 --> Language Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Loader Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:55:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Session Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:55:24 --> Session routines successfully run
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Controller Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:55:24 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:24 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:25 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:55:25 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 14:55:25 --> Final output sent to browser
DEBUG - 2016-08-03 14:55:25 --> Total execution time: 0.3849
DEBUG - 2016-08-03 14:55:28 --> Config Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Hooks Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Utf8 Class Initialized
DEBUG - 2016-08-03 14:55:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 14:55:28 --> URI Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Router Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Output Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Security Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Input Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 14:55:28 --> Language Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Loader Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Helper loaded: url_helper
DEBUG - 2016-08-03 14:55:28 --> Database Driver Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Session Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Helper loaded: string_helper
DEBUG - 2016-08-03 14:55:28 --> Session routines successfully run
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Controller Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Model Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Helper loaded: form_helper
DEBUG - 2016-08-03 14:55:28 --> Form Validation Class Initialized
DEBUG - 2016-08-03 14:55:28 --> Pagination Class Initialized
DEBUG - 2016-08-03 14:55:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 14:55:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 14:55:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 14:55:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 14:55:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 14:55:28 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 14:55:28 --> Final output sent to browser
DEBUG - 2016-08-03 14:55:28 --> Total execution time: 0.3106
DEBUG - 2016-08-03 15:02:11 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:12 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:12 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:02:12 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:12 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:12 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:12 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:12 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:12 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:12 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:12 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:12 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:12 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:12 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:02:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 15:02:12 --> Final output sent to browser
DEBUG - 2016-08-03 15:02:12 --> Total execution time: 0.3290
DEBUG - 2016-08-03 15:02:15 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:15 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:15 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:15 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:15 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:15 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:02:15 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:02:15 --> Final output sent to browser
DEBUG - 2016-08-03 15:02:15 --> Total execution time: 0.3669
DEBUG - 2016-08-03 15:02:39 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:39 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:39 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:39 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:39 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:39 --> Model Class Initialized
ERROR - 2016-08-03 15:02:39 --> Severity: Notice  --> Undefined variable: crm D:\xampp\htdocs\asmc\application\views\form\email.php 130
ERROR - 2016-08-03 15:02:39 --> Severity: Notice  --> Undefined variable: sm D:\xampp\htdocs\asmc\application\views\form\email.php 132
DEBUG - 2016-08-03 15:02:39 --> File loaded: application/views/form/email.php
DEBUG - 2016-08-03 15:02:39 --> Email Class Initialized
DEBUG - 2016-08-03 15:02:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:02:39 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:02:39 --> Final output sent to browser
DEBUG - 2016-08-03 15:02:39 --> Total execution time: 0.4448
DEBUG - 2016-08-03 15:02:46 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:46 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:46 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:02:46 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:46 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:46 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:46 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:46 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:46 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:02:46 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 15:02:46 --> Final output sent to browser
DEBUG - 2016-08-03 15:02:46 --> Total execution time: 0.2986
DEBUG - 2016-08-03 15:02:48 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:48 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:48 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:48 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:48 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:48 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:02:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:02:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:02:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:02:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:02:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:02:49 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:02:49 --> Final output sent to browser
DEBUG - 2016-08-03 15:02:49 --> Total execution time: 0.4386
DEBUG - 2016-08-03 15:02:56 --> Config Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:02:56 --> URI Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Router Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Output Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Security Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Input Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:02:56 --> Language Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Loader Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:02:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Session Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:02:56 --> Session routines successfully run
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Controller Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:02:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:02:56 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:02:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:02:57 --> Final output sent to browser
DEBUG - 2016-08-03 15:02:57 --> Total execution time: 0.6000
DEBUG - 2016-08-03 15:03:45 --> Config Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:03:45 --> URI Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Router Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Output Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Security Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Input Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:03:45 --> Language Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Loader Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:03:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Session Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:03:45 --> Session routines successfully run
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Controller Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:03:45 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:03:45 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:03:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:03:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:03:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:03:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:03:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:03:45 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:03:45 --> Final output sent to browser
DEBUG - 2016-08-03 15:03:45 --> Total execution time: 0.3563
DEBUG - 2016-08-03 15:04:04 --> Config Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:04:04 --> URI Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Router Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Output Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Security Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Input Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:04:04 --> Language Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Loader Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:04:04 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Session Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:04:04 --> Session routines successfully run
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Controller Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:04:04 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:04:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-03 15:04:04 --> Severity: Warning  --> Missing argument 7 for Invoice_model::addSalesPayout(), called in D:\xampp\htdocs\asmc\application\controllers\invoice.php on line 902 and defined D:\xampp\htdocs\asmc\application\models\invoice_model.php 394
ERROR - 2016-08-03 15:04:04 --> Severity: Warning  --> Missing argument 8 for Invoice_model::addSalesPayout(), called in D:\xampp\htdocs\asmc\application\controllers\invoice.php on line 902 and defined D:\xampp\htdocs\asmc\application\models\invoice_model.php 394
DEBUG - 2016-08-03 15:04:04 --> Helper loaded: pdf_helper
ERROR - 2016-08-03 15:04:05 --> Severity: Warning  --> getimagesize(/home/sgdatacrm//public_html/asmc/images/logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\asmc\application\helpers\tcpdf\tcpdf.php 6850
ERROR - 2016-08-03 15:04:05 --> Severity: Warning  --> file_get_contents(/home/sgdatacrm//public_html/asmc/images/logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\asmc\application\helpers\tcpdf\include\tcpdf_static.php 2495
ERROR - 2016-08-03 15:04:05 --> Severity: Warning  --> file_get_contents(D:/xampp/htdocs/home/sgdatacrm//public_html/asmc/images/logo.png): failed to open stream: No such file or directory D:\xampp\htdocs\asmc\application\helpers\tcpdf\include\tcpdf_static.php 2495
DEBUG - 2016-08-03 15:05:01 --> Config Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:05:01 --> URI Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Router Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Output Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Security Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Input Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:05:01 --> Language Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Loader Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:05:01 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Session Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:05:01 --> Session routines successfully run
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Controller Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:05:01 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:05:01 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:05:01 --> Final output sent to browser
DEBUG - 2016-08-03 15:05:01 --> Total execution time: 0.3591
DEBUG - 2016-08-03 15:05:06 --> Config Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:05:06 --> URI Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Router Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Output Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Security Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Input Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:05:06 --> Language Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Loader Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:05:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Session Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:05:06 --> Session routines successfully run
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Controller Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:05:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:05:06 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:05:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:05:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:05:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:05:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:05:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:05:06 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:05:06 --> Final output sent to browser
DEBUG - 2016-08-03 15:05:06 --> Total execution time: 0.3361
DEBUG - 2016-08-03 15:05:16 --> Config Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:05:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:05:16 --> URI Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Router Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Output Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Security Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Input Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:05:16 --> Language Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Loader Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:05:16 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Session Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:05:16 --> Session routines successfully run
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Controller Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:05:16 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:05:16 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:05:17 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:05:17 --> Final output sent to browser
DEBUG - 2016-08-03 15:05:17 --> Total execution time: 0.5844
DEBUG - 2016-08-03 15:05:29 --> Config Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:05:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:05:29 --> URI Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Router Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Output Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Security Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Input Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:05:29 --> Language Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Loader Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:05:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Session Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:05:29 --> Session routines successfully run
DEBUG - 2016-08-03 15:05:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Controller Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:05:30 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:05:30 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:05:30 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:05:30 --> Final output sent to browser
DEBUG - 2016-08-03 15:05:30 --> Total execution time: 0.4673
DEBUG - 2016-08-03 15:05:53 --> Config Class Initialized
DEBUG - 2016-08-03 15:05:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:05:53 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:05:53 --> URI Class Initialized
DEBUG - 2016-08-03 15:05:53 --> Router Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Output Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Security Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Input Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:05:54 --> Language Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Loader Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:05:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Session Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:05:54 --> Session routines successfully run
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Controller Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:05:54 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:05:54 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:05:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:05:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:05:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:05:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:05:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:05:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-08-03 15:05:54 --> Final output sent to browser
DEBUG - 2016-08-03 15:05:54 --> Total execution time: 0.4927
DEBUG - 2016-08-03 15:06:34 --> Config Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:06:34 --> URI Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Router Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Output Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Security Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Input Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:06:34 --> Language Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Loader Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:06:34 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Session Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:06:34 --> Session routines successfully run
DEBUG - 2016-08-03 15:06:34 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Controller Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:34 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:35 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:06:35 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:06:35 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:06:35 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:06:35 --> Final output sent to browser
DEBUG - 2016-08-03 15:06:35 --> Total execution time: 0.5100
DEBUG - 2016-08-03 15:06:54 --> Config Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:06:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:06:54 --> URI Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Router Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Output Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Security Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Input Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:06:54 --> Language Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Loader Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:06:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Session Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:06:54 --> Session routines successfully run
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Controller Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:06:54 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:06:54 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:06:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:06:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:06:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:06:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:06:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:06:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-08-03 15:06:54 --> Final output sent to browser
DEBUG - 2016-08-03 15:06:54 --> Total execution time: 0.3771
DEBUG - 2016-08-03 15:07:28 --> Config Class Initialized
DEBUG - 2016-08-03 15:07:28 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:07:28 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:07:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:07:28 --> URI Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Router Class Initialized
DEBUG - 2016-08-03 15:07:29 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:07:29 --> Output Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Security Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Input Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:07:29 --> Language Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Loader Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:07:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Session Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:07:29 --> Session routines successfully run
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Controller Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:07:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Config Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:07:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:07:29 --> URI Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Router Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Output Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Security Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Input Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:07:29 --> Language Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Loader Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:07:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Session Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:07:29 --> Session routines successfully run
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Controller Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:07:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:07:29 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:07:29 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 15:07:29 --> Final output sent to browser
DEBUG - 2016-08-03 15:07:29 --> Total execution time: 0.3003
DEBUG - 2016-08-03 15:07:35 --> Config Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:07:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:07:35 --> URI Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Router Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Output Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Security Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Input Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:07:35 --> Language Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Loader Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:07:35 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Session Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:07:35 --> Session routines successfully run
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Controller Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:07:35 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:07:35 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:07:36 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:07:36 --> Final output sent to browser
DEBUG - 2016-08-03 15:07:36 --> Total execution time: 0.6000
DEBUG - 2016-08-03 15:07:48 --> Config Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:07:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:07:48 --> URI Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Router Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Output Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Security Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Input Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:07:48 --> Language Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Loader Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:07:48 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Session Class Initialized
DEBUG - 2016-08-03 15:07:48 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:07:49 --> Session routines successfully run
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Controller Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:07:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:07:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:07:49 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:07:49 --> Final output sent to browser
DEBUG - 2016-08-03 15:07:49 --> Total execution time: 0.3089
DEBUG - 2016-08-03 15:09:47 --> Config Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:09:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:09:47 --> URI Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Router Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Output Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Security Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Input Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:09:47 --> Language Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Loader Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:09:47 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Session Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:09:47 --> Session routines successfully run
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Controller Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:09:47 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Config Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:09:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:09:47 --> URI Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Router Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Output Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Security Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Input Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:09:47 --> Language Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Loader Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:09:47 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Session Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:09:47 --> Session routines successfully run
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Controller Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Model Class Initialized
DEBUG - 2016-08-03 15:09:48 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:09:48 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:09:48 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 15:09:48 --> Final output sent to browser
DEBUG - 2016-08-03 15:09:48 --> Total execution time: 0.2699
DEBUG - 2016-08-03 15:10:13 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:13 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:13 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:13 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:13 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:13 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 15:10:13 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:13 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:13 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:13 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:13 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:13 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:13 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:10:13 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:10:13 --> Final output sent to browser
DEBUG - 2016-08-03 15:10:13 --> Total execution time: 0.3645
DEBUG - 2016-08-03 15:10:17 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:17 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:17 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:17 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:17 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:17 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:17 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:10:17 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:10:17 --> Final output sent to browser
DEBUG - 2016-08-03 15:10:17 --> Total execution time: 0.3705
DEBUG - 2016-08-03 15:10:23 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:23 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:23 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:23 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:23 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:23 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:10:23 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:10:23 --> Final output sent to browser
DEBUG - 2016-08-03 15:10:23 --> Total execution time: 0.2955
DEBUG - 2016-08-03 15:10:31 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:31 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:31 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:31 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:31 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:32 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:10:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:10:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:10:32 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:10:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:10:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:10:32 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-08-03 15:10:32 --> Final output sent to browser
DEBUG - 2016-08-03 15:10:32 --> Total execution time: 0.3482
DEBUG - 2016-08-03 15:10:54 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:54 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:54 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:54 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:54 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:54 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:54 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:54 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:54 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Config Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:10:54 --> URI Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Router Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Output Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Security Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Input Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:10:54 --> Language Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Loader Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:10:54 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Session Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:10:54 --> Session routines successfully run
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Controller Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Model Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:10:54 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:10:54 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:10:54 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:10:54 --> Final output sent to browser
DEBUG - 2016-08-03 15:10:54 --> Total execution time: 0.2969
DEBUG - 2016-08-03 15:11:03 --> Config Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:11:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:11:03 --> URI Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Router Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Output Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Security Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Input Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:11:03 --> Language Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Loader Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:11:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Session Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:11:03 --> Session routines successfully run
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Controller Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:11:03 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:11:03 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:11:03 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:11:03 --> Final output sent to browser
DEBUG - 2016-08-03 15:11:03 --> Total execution time: 0.3927
DEBUG - 2016-08-03 15:11:06 --> Config Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:11:06 --> URI Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Router Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Output Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Security Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Input Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:11:06 --> Language Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Loader Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:11:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Session Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:11:06 --> Session routines successfully run
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Controller Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:11:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Config Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:11:06 --> URI Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Router Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Output Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Security Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Input Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:11:06 --> Language Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Loader Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:11:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Session Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:11:06 --> Session routines successfully run
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Controller Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:11:06 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Config Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:11:06 --> URI Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Router Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Output Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Security Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Input Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:11:06 --> Language Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Loader Class Initialized
DEBUG - 2016-08-03 15:11:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:11:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Session Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:11:07 --> Session routines successfully run
DEBUG - 2016-08-03 15:11:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Controller Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:11:07 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:11:07 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:11:07 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:11:07 --> Final output sent to browser
DEBUG - 2016-08-03 15:11:07 --> Total execution time: 0.3102
DEBUG - 2016-08-03 15:11:09 --> Config Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:11:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:11:09 --> URI Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Router Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Output Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Security Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Input Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:11:09 --> Language Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Loader Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:11:09 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Session Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:11:09 --> Session routines successfully run
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Controller Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:11:09 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:11:09 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:11:09 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:11:09 --> Final output sent to browser
DEBUG - 2016-08-03 15:11:09 --> Total execution time: 0.3928
DEBUG - 2016-08-03 15:11:17 --> Config Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:11:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:11:17 --> URI Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Router Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Output Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Security Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Input Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:11:17 --> Language Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Loader Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:11:17 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Session Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:11:17 --> Session routines successfully run
DEBUG - 2016-08-03 15:11:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Controller Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:11:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:11:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:11:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:11:18 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:11:18 --> Final output sent to browser
DEBUG - 2016-08-03 15:11:18 --> Total execution time: 0.3156
DEBUG - 2016-08-03 15:19:13 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:14 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:14 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:14 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:14 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:14 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:14 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:14 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 15:19:14 --> Final output sent to browser
DEBUG - 2016-08-03 15:19:14 --> Total execution time: 0.2640
DEBUG - 2016-08-03 15:19:20 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:20 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:20 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:20 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:20 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:20 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 15:19:20 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:20 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:20 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:20 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:20 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:20 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:20 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:19:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 15:19:20 --> Final output sent to browser
DEBUG - 2016-08-03 15:19:20 --> Total execution time: 0.3764
DEBUG - 2016-08-03 15:19:24 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:24 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:24 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:24 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:24 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:19:24 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:19:24 --> Final output sent to browser
DEBUG - 2016-08-03 15:19:24 --> Total execution time: 0.4007
DEBUG - 2016-08-03 15:19:55 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:55 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:55 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:19:55 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:55 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:55 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:55 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:55 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Config Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:19:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:19:56 --> URI Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Router Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Output Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Security Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Input Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:19:56 --> Language Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Loader Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:19:56 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Session Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:19:56 --> Session routines successfully run
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Controller Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Model Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:19:56 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:19:56 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:19:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 15:19:56 --> Final output sent to browser
DEBUG - 2016-08-03 15:19:56 --> Total execution time: 0.2934
DEBUG - 2016-08-03 15:20:00 --> Config Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:20:00 --> URI Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Router Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Output Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Security Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Input Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:20:00 --> Language Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Loader Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:20:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Session Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:20:00 --> Session routines successfully run
DEBUG - 2016-08-03 15:20:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Controller Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:20:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:20:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:20:00 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 15:20:00 --> Final output sent to browser
DEBUG - 2016-08-03 15:20:00 --> Total execution time: 0.3387
DEBUG - 2016-08-03 15:20:18 --> Config Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:20:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:20:18 --> URI Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Router Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Output Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Security Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Input Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:20:18 --> Language Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Loader Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:20:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Session Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:20:18 --> Session routines successfully run
DEBUG - 2016-08-03 15:20:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Controller Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:20:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:20:18 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:20:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:20:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:20:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:20:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:20:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:20:18 --> File loaded: application/views/customer/editCustomerView.php
DEBUG - 2016-08-03 15:20:18 --> Final output sent to browser
DEBUG - 2016-08-03 15:20:18 --> Total execution time: 0.3311
DEBUG - 2016-08-03 15:23:59 --> Config Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:23:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:23:59 --> URI Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Router Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Output Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Security Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Input Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:23:59 --> Language Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Loader Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:23:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Session Class Initialized
DEBUG - 2016-08-03 15:23:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:23:59 --> Session routines successfully run
DEBUG - 2016-08-03 15:23:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:00 --> File loaded: application/views/form/email.php
DEBUG - 2016-08-03 15:24:00 --> Email Class Initialized
DEBUG - 2016-08-03 15:24:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:24:00 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:24:00 --> Final output sent to browser
DEBUG - 2016-08-03 15:24:00 --> Total execution time: 0.4903
DEBUG - 2016-08-03 15:24:05 --> Config Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:24:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:24:05 --> URI Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Router Class Initialized
DEBUG - 2016-08-03 15:24:05 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:24:05 --> Output Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Security Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Input Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:24:05 --> Language Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Loader Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:24:05 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Session Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:24:05 --> Session routines successfully run
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:05 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Config Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:24:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:24:05 --> URI Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Router Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Output Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Security Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Input Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:24:05 --> Language Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Loader Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:24:05 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Session Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:24:05 --> Session routines successfully run
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:05 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:05 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:24:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:24:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:24:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:24:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:24:05 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:24:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:24:06 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-03 15:24:06 --> Final output sent to browser
DEBUG - 2016-08-03 15:24:06 --> Total execution time: 0.3130
DEBUG - 2016-08-03 15:24:11 --> Config Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:24:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:24:11 --> URI Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Router Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Output Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Security Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Input Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:24:11 --> Language Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Loader Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:24:11 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Session Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:24:11 --> Session routines successfully run
DEBUG - 2016-08-03 15:24:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:11 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:11 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:24:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:24:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:24:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:24:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:24:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:24:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:24:12 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-03 15:24:12 --> Final output sent to browser
DEBUG - 2016-08-03 15:24:12 --> Total execution time: 0.3280
DEBUG - 2016-08-03 15:24:21 --> Config Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:24:21 --> URI Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Router Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Output Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Security Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Input Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:24:21 --> Language Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Loader Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:24:21 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Session Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:24:21 --> Session routines successfully run
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:21 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:21 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:24:21 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:24:21 --> Final output sent to browser
DEBUG - 2016-08-03 15:24:21 --> Total execution time: 0.6858
DEBUG - 2016-08-03 15:24:32 --> Config Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:24:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:24:32 --> URI Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Router Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Output Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Security Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Input Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:24:32 --> Language Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Loader Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:24:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Session Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:24:32 --> Session routines successfully run
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:24:32 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:24:32 --> Final output sent to browser
DEBUG - 2016-08-03 15:24:32 --> Total execution time: 0.3845
DEBUG - 2016-08-03 15:24:44 --> Config Class Initialized
DEBUG - 2016-08-03 15:24:44 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:24:44 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:24:45 --> URI Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Router Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Output Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Security Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Input Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:24:45 --> Language Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Loader Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:24:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Session Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:24:45 --> Session routines successfully run
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Controller Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:24:45 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:24:45 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:24:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:24:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:24:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:24:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:24:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:24:45 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:24:45 --> Final output sent to browser
DEBUG - 2016-08-03 15:24:45 --> Total execution time: 0.4081
DEBUG - 2016-08-03 15:25:17 --> Config Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:25:17 --> URI Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Router Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Output Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Security Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Input Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:25:17 --> Language Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Loader Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:25:17 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Session Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:25:17 --> Session routines successfully run
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Controller Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:25:17 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:25:17 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:25:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:25:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:25:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:25:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:25:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:25:18 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:25:18 --> Final output sent to browser
DEBUG - 2016-08-03 15:25:18 --> Total execution time: 0.3464
DEBUG - 2016-08-03 15:25:24 --> Config Class Initialized
DEBUG - 2016-08-03 15:25:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:25:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:25:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:25:24 --> URI Class Initialized
DEBUG - 2016-08-03 15:25:24 --> Router Class Initialized
DEBUG - 2016-08-03 15:25:24 --> Output Class Initialized
DEBUG - 2016-08-03 15:25:24 --> Security Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Input Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:25:25 --> Language Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Loader Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:25:25 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Session Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:25:25 --> Session routines successfully run
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Controller Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:25:25 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:25:25 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:25:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:25:25 --> Final output sent to browser
DEBUG - 2016-08-03 15:25:25 --> Total execution time: 0.5431
DEBUG - 2016-08-03 15:25:41 --> Config Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:25:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:25:41 --> URI Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Router Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Output Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Security Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Input Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:25:41 --> Language Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Loader Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:25:41 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Session Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:25:41 --> Session routines successfully run
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Controller Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:25:41 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:25:41 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:25:41 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:25:41 --> Final output sent to browser
DEBUG - 2016-08-03 15:25:41 --> Total execution time: 0.4830
DEBUG - 2016-08-03 15:25:51 --> Config Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:25:51 --> URI Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Router Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Output Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Security Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Input Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:25:51 --> Language Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Loader Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:25:51 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Session Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:25:51 --> Session routines successfully run
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Controller Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:25:51 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:25:51 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:25:51 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:25:51 --> Final output sent to browser
DEBUG - 2016-08-03 15:25:51 --> Total execution time: 0.5487
DEBUG - 2016-08-03 15:25:59 --> Config Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:25:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:25:59 --> URI Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Router Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Output Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Security Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Input Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:25:59 --> Language Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Loader Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:25:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Session Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:25:59 --> Session routines successfully run
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Controller Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:25:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:25:59 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:25:59 --> Final output sent to browser
DEBUG - 2016-08-03 15:25:59 --> Total execution time: 0.4000
DEBUG - 2016-08-03 15:26:02 --> Config Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:26:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:26:02 --> URI Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Router Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Output Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Security Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Input Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:26:02 --> Language Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Loader Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:26:02 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Session Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:26:02 --> Session routines successfully run
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Controller Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:26:02 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:26:02 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:26:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:26:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:26:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:26:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:26:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:26:02 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:26:02 --> Final output sent to browser
DEBUG - 2016-08-03 15:26:02 --> Total execution time: 0.3485
DEBUG - 2016-08-03 15:26:28 --> Config Class Initialized
DEBUG - 2016-08-03 15:26:28 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:26:28 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:26:28 --> URI Class Initialized
DEBUG - 2016-08-03 15:26:28 --> Router Class Initialized
DEBUG - 2016-08-03 15:26:28 --> Output Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Security Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Input Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:26:29 --> Language Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Loader Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:26:29 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Session Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:26:29 --> Session routines successfully run
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Controller Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:26:29 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:26:29 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:26:29 --> Final output sent to browser
DEBUG - 2016-08-03 15:26:29 --> Total execution time: 0.3304
DEBUG - 2016-08-03 15:26:32 --> Config Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:26:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:26:32 --> URI Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Router Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Output Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Security Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Input Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:26:32 --> Language Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Loader Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:26:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Session Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:26:32 --> Session routines successfully run
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Controller Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:26:32 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:26:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:26:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:26:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:26:33 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:26:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:26:33 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:26:33 --> Final output sent to browser
DEBUG - 2016-08-03 15:26:33 --> Total execution time: 0.3760
DEBUG - 2016-08-03 15:26:36 --> Config Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:26:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:26:36 --> URI Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Router Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Output Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Security Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Input Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:26:36 --> Language Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Loader Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:26:36 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Session Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:26:36 --> Session routines successfully run
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Controller Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:26:36 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:26:36 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:26:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:26:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:26:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:26:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:26:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:26:36 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:26:36 --> Final output sent to browser
DEBUG - 2016-08-03 15:26:36 --> Total execution time: 0.3567
DEBUG - 2016-08-03 15:27:26 --> Config Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:27:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:27:26 --> URI Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Router Class Initialized
DEBUG - 2016-08-03 15:27:26 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:27:26 --> Output Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Security Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Input Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:27:26 --> Language Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Loader Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:27:26 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Session Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:27:26 --> A session cookie was not found.
DEBUG - 2016-08-03 15:27:26 --> Session routines successfully run
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Controller Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:26 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:27:26 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:27:26 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 15:27:26 --> Final output sent to browser
DEBUG - 2016-08-03 15:27:26 --> Total execution time: 0.3434
DEBUG - 2016-08-03 15:27:40 --> Config Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:27:40 --> URI Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Router Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Output Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Security Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Input Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:27:40 --> Language Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Loader Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:27:40 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Session Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:27:40 --> Session routines successfully run
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Controller Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:27:40 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:27:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 15:27:40 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-03 15:27:40 --> Final output sent to browser
DEBUG - 2016-08-03 15:27:40 --> Total execution time: 0.2847
DEBUG - 2016-08-03 15:27:46 --> Config Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:27:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:27:46 --> URI Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Router Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Output Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Security Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Input Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:27:46 --> Language Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Loader Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:27:46 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Session Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:27:46 --> Session routines successfully run
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Controller Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:27:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-03 15:27:47 --> Config Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:27:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:27:47 --> URI Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Router Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Output Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Security Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Input Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:27:47 --> Language Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Loader Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:27:47 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Session Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:27:47 --> Session routines successfully run
DEBUG - 2016-08-03 15:27:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Controller Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:27:47 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:27:47 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:27:47 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:27:47 --> Final output sent to browser
DEBUG - 2016-08-03 15:27:47 --> Total execution time: 0.3760
DEBUG - 2016-08-03 15:27:55 --> Config Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:27:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:27:55 --> URI Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Router Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Output Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Security Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Input Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:27:55 --> Language Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Loader Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:27:55 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Session Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:27:55 --> Session routines successfully run
DEBUG - 2016-08-03 15:27:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Controller Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:27:55 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:27:55 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:27:55 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:27:55 --> Final output sent to browser
DEBUG - 2016-08-03 15:27:55 --> Total execution time: 0.3564
DEBUG - 2016-08-03 15:27:59 --> Config Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:27:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:27:59 --> URI Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Router Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Output Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Security Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Input Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:27:59 --> Language Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Loader Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:27:59 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Session Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:27:59 --> Session routines successfully run
DEBUG - 2016-08-03 15:27:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Controller Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Model Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:27:59 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:27:59 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:27:59 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:27:59 --> Final output sent to browser
DEBUG - 2016-08-03 15:27:59 --> Total execution time: 0.3376
DEBUG - 2016-08-03 15:28:02 --> Config Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:28:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:28:02 --> URI Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Router Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Output Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Security Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Input Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:28:02 --> Language Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Loader Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:28:02 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Session Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:28:02 --> Session routines successfully run
DEBUG - 2016-08-03 15:28:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Controller Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:28:02 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:28:02 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:28:02 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:28:02 --> Final output sent to browser
DEBUG - 2016-08-03 15:28:02 --> Total execution time: 0.3428
DEBUG - 2016-08-03 15:28:05 --> Config Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:28:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:28:05 --> URI Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Router Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Output Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Security Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Input Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:28:05 --> Language Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Loader Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:28:05 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Session Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:28:05 --> Session routines successfully run
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Controller Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:28:05 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:28:05 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:28:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:28:05 --> Final output sent to browser
DEBUG - 2016-08-03 15:28:05 --> Total execution time: 0.4401
DEBUG - 2016-08-03 15:28:08 --> Config Class Initialized
DEBUG - 2016-08-03 15:28:08 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:28:08 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:28:08 --> URI Class Initialized
DEBUG - 2016-08-03 15:28:08 --> Router Class Initialized
DEBUG - 2016-08-03 15:28:08 --> Output Class Initialized
DEBUG - 2016-08-03 15:28:08 --> Security Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Input Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:28:09 --> Language Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Loader Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:28:09 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Session Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:28:09 --> Session routines successfully run
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Controller Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:28:09 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:28:09 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:28:09 --> Final output sent to browser
DEBUG - 2016-08-03 15:28:09 --> Total execution time: 0.3471
DEBUG - 2016-08-03 15:28:17 --> Config Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:28:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:28:17 --> URI Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Router Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Output Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Security Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Input Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:28:17 --> Language Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Loader Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:28:17 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Session Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:28:17 --> Session routines successfully run
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Controller Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:28:17 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:28:17 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:28:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:28:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:28:17 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:28:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:28:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:28:17 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-08-03 15:28:17 --> Final output sent to browser
DEBUG - 2016-08-03 15:28:17 --> Total execution time: 0.4845
DEBUG - 2016-08-03 15:28:38 --> Config Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:28:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:28:38 --> URI Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Router Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Output Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Security Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Input Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:28:38 --> Language Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Loader Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:28:38 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Session Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:28:38 --> Session routines successfully run
DEBUG - 2016-08-03 15:28:38 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Controller Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:28:38 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:28:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:28:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:28:39 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:28:39 --> Final output sent to browser
DEBUG - 2016-08-03 15:28:39 --> Total execution time: 0.4342
DEBUG - 2016-08-03 15:29:22 --> Config Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:29:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:29:22 --> URI Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Router Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Output Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Security Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Input Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:29:22 --> Language Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Loader Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:29:22 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Session Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:29:22 --> Session routines successfully run
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Controller Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:29:22 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:29:22 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:29:22 --> Final output sent to browser
DEBUG - 2016-08-03 15:29:22 --> Total execution time: 0.3703
DEBUG - 2016-08-03 15:29:39 --> Config Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:29:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:29:39 --> URI Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Router Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Output Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Security Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Input Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:29:39 --> Language Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Loader Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:29:39 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Session Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:29:39 --> Session routines successfully run
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Controller Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:29:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:29:39 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:29:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:29:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:29:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:29:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:29:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:29:39 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:29:39 --> Final output sent to browser
DEBUG - 2016-08-03 15:29:39 --> Total execution time: 0.3903
DEBUG - 2016-08-03 15:30:55 --> Config Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:30:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:30:55 --> URI Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Router Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Output Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Security Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Input Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:30:55 --> Language Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Loader Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:30:55 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Session Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:30:55 --> Session routines successfully run
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Controller Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:30:55 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> Model Class Initialized
DEBUG - 2016-08-03 15:30:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:30:55 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:30:55 --> Final output sent to browser
DEBUG - 2016-08-03 15:30:55 --> Total execution time: 0.3540
DEBUG - 2016-08-03 15:31:01 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:01 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:01 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:01 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:01 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:01 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:02 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:02 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:02 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:02 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-08-03 15:31:02 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:02 --> Total execution time: 0.3665
DEBUG - 2016-08-03 15:31:03 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:03 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:03 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:03 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:03 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:03 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:04 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:04 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:04 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:04 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-03 15:31:04 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:04 --> Total execution time: 0.3781
DEBUG - 2016-08-03 15:31:06 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:06 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:06 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:07 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:07 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:07 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:07 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:07 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:07 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:31:07 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:07 --> Total execution time: 0.3460
DEBUG - 2016-08-03 15:31:10 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:10 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:10 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:10 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:10 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:10 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:11 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:11 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:11 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:11 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:11 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:11 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:31:11 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:11 --> Total execution time: 0.3579
DEBUG - 2016-08-03 15:31:14 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:15 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:15 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:15 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:15 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:15 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:15 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:15 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:31:15 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:15 --> Total execution time: 0.4867
DEBUG - 2016-08-03 15:31:18 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:18 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:18 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:18 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:18 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:18 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:31:18 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:18 --> Total execution time: 0.3568
DEBUG - 2016-08-03 15:31:27 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:27 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:27 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:27 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:27 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:27 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:27 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:27 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:27 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:31:27 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:27 --> Total execution time: 0.3565
DEBUG - 2016-08-03 15:31:44 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:44 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:44 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:44 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:44 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:44 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:44 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:44 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:31:44 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:44 --> Total execution time: 0.4302
DEBUG - 2016-08-03 15:31:48 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:48 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Router Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Output Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Security Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Input Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:31:48 --> Language Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Loader Class Initialized
DEBUG - 2016-08-03 15:31:48 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:31:48 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Session Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:31:49 --> Session routines successfully run
DEBUG - 2016-08-03 15:31:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Controller Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:31:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:31:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:31:49 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:31:49 --> Final output sent to browser
DEBUG - 2016-08-03 15:31:49 --> Total execution time: 0.3562
DEBUG - 2016-08-03 15:31:54 --> Config Class Initialized
DEBUG - 2016-08-03 15:31:54 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:31:54 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:31:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:31:54 --> URI Class Initialized
DEBUG - 2016-08-03 15:31:54 --> Router Class Initialized
ERROR - 2016-08-03 15:31:54 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-03 15:32:13 --> Config Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:32:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:32:13 --> URI Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Router Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Output Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Security Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Input Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:32:13 --> Language Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Loader Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:32:13 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Session Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:32:13 --> Session routines successfully run
DEBUG - 2016-08-03 15:32:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Controller Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:32:13 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:32:13 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:32:13 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:32:13 --> Final output sent to browser
DEBUG - 2016-08-03 15:32:13 --> Total execution time: 0.5555
DEBUG - 2016-08-03 15:32:19 --> Config Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:32:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:32:19 --> URI Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Router Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Output Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Security Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Input Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:32:19 --> Language Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Loader Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:32:19 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Session Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:32:19 --> Session routines successfully run
DEBUG - 2016-08-03 15:32:19 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Controller Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:32:19 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:32:19 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:32:19 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:32:19 --> Final output sent to browser
DEBUG - 2016-08-03 15:32:19 --> Total execution time: 0.3547
DEBUG - 2016-08-03 15:32:24 --> Config Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:32:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:32:24 --> URI Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Router Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Output Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Security Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Input Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:32:24 --> Language Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Loader Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:32:24 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Session Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:32:24 --> Session routines successfully run
DEBUG - 2016-08-03 15:32:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:24 --> Controller Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Config Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:32:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:32:33 --> URI Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Router Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Output Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Security Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Input Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:32:33 --> Language Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Loader Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:32:33 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Session Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:32:33 --> Session routines successfully run
DEBUG - 2016-08-03 15:32:33 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Controller Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:32:33 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:32:33 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Config Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:32:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:32:44 --> URI Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Router Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Output Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Security Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Input Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:32:44 --> Language Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Loader Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:32:44 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Session Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:32:44 --> Session routines successfully run
DEBUG - 2016-08-03 15:32:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Controller Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Model Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:32:44 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:32:44 --> Pagination Class Initialized
ERROR - 2016-08-03 15:32:44 --> 404 Page Not Found --> admin/editAgent
DEBUG - 2016-08-03 15:33:14 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:14 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:14 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:14 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:14 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:14 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:14 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:33:14 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:33:14 --> Final output sent to browser
DEBUG - 2016-08-03 15:33:14 --> Total execution time: 0.3606
DEBUG - 2016-08-03 15:33:17 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:17 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:17 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:17 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:17 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:17 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:18 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:18 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:18 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:18 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:18 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:33:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:33:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:33:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:33:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:33:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:33:18 --> File loaded: application/views/agent/editAgentView.php
DEBUG - 2016-08-03 15:33:18 --> Final output sent to browser
DEBUG - 2016-08-03 15:33:18 --> Total execution time: 0.3665
DEBUG - 2016-08-03 15:33:23 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:23 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:23 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:23 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:23 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:23 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:23 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:33:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:33:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:33:23 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:33:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:33:24 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:33:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:33:24 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:33:24 --> Final output sent to browser
DEBUG - 2016-08-03 15:33:24 --> Total execution time: 0.3736
DEBUG - 2016-08-03 15:33:28 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:28 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:28 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:28 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:28 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:28 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:28 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:28 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:32 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:32 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:32 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:32 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:32 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:33 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:33 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:33:33 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-03 15:33:33 --> Final output sent to browser
DEBUG - 2016-08-03 15:33:33 --> Total execution time: 0.3516
DEBUG - 2016-08-03 15:33:35 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:35 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:35 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:35 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:35 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:35 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:35 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:33:35 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:33:35 --> Final output sent to browser
DEBUG - 2016-08-03 15:33:35 --> Total execution time: 0.3568
DEBUG - 2016-08-03 15:33:37 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:37 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:37 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:37 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:37 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:37 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:37 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:33:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:33:57 --> URI Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Router Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Output Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Security Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Input Class Initialized
DEBUG - 2016-08-03 15:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:33:57 --> Language Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Loader Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:33:58 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Session Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:33:58 --> Session routines successfully run
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Controller Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Model Class Initialized
DEBUG - 2016-08-03 15:33:58 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:33:58 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:33:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:33:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:33:58 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:33:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:33:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:33:58 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-03 15:33:58 --> Final output sent to browser
DEBUG - 2016-08-03 15:33:58 --> Total execution time: 0.3869
DEBUG - 2016-08-03 15:33:59 --> Config Class Initialized
DEBUG - 2016-08-03 15:33:59 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:33:59 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:34:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:34:00 --> URI Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Router Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Output Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Security Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Input Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:34:00 --> Language Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Loader Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:34:00 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Session Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:34:00 --> Session routines successfully run
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Controller Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:34:00 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:34:00 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:34:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:34:00 --> Final output sent to browser
DEBUG - 2016-08-03 15:34:00 --> Total execution time: 0.4368
DEBUG - 2016-08-03 15:34:02 --> Config Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:34:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:34:02 --> URI Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Router Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Output Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Security Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Input Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:34:02 --> Language Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Loader Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:34:02 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Session Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:34:02 --> Session routines successfully run
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Controller Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:34:02 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:34:02 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:34:02 --> Final output sent to browser
DEBUG - 2016-08-03 15:34:02 --> Total execution time: 0.3564
DEBUG - 2016-08-03 15:34:06 --> Config Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:34:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:34:06 --> URI Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Router Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Output Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Security Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Input Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:34:06 --> Language Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Loader Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:34:06 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Session Class Initialized
DEBUG - 2016-08-03 15:34:06 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:34:06 --> Session routines successfully run
DEBUG - 2016-08-03 15:34:06 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Controller Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:34:07 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:34:07 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:34:07 --> Final output sent to browser
DEBUG - 2016-08-03 15:34:07 --> Total execution time: 0.3736
DEBUG - 2016-08-03 15:34:11 --> Config Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:34:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:34:11 --> URI Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Router Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Output Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Security Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Input Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:34:11 --> Language Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Loader Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:34:11 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Session Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:34:11 --> Session routines successfully run
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Controller Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:34:11 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:34:11 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-03 15:34:11 --> Final output sent to browser
DEBUG - 2016-08-03 15:34:11 --> Total execution time: 0.4158
DEBUG - 2016-08-03 15:34:39 --> Config Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:34:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:34:39 --> URI Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Router Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Output Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Security Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Input Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:34:39 --> Language Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Loader Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:34:39 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Session Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:34:39 --> Session routines successfully run
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Controller Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:34:39 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:39 --> Model Class Initialized
DEBUG - 2016-08-03 15:34:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:34:40 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:34:40 --> Final output sent to browser
DEBUG - 2016-08-03 15:34:40 --> Total execution time: 0.3671
DEBUG - 2016-08-03 15:41:36 --> Config Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:41:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:41:36 --> URI Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Router Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Output Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Security Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Input Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:41:36 --> Language Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Loader Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:41:36 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Session Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:41:36 --> Session routines successfully run
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Controller Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:41:36 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:41:36 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:41:36 --> Final output sent to browser
DEBUG - 2016-08-03 15:41:36 --> Total execution time: 0.3581
DEBUG - 2016-08-03 15:41:45 --> Config Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:41:45 --> URI Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Router Class Initialized
DEBUG - 2016-08-03 15:41:45 --> No URI present. Default controller set.
DEBUG - 2016-08-03 15:41:45 --> Output Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Security Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Input Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:41:45 --> Language Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Loader Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:41:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Session Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:41:45 --> Session routines successfully run
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Controller Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:41:45 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Config Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:41:45 --> URI Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Router Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Output Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Security Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Input Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:41:45 --> Language Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Loader Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:41:45 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Session Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:41:45 --> Session routines successfully run
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Controller Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:45 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:46 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:41:46 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:41:46 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:41:46 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-03 15:41:46 --> Final output sent to browser
DEBUG - 2016-08-03 15:41:46 --> Total execution time: 0.3697
DEBUG - 2016-08-03 15:41:49 --> Config Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:41:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:41:49 --> URI Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Router Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Output Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Security Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Input Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:41:49 --> Language Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Loader Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:41:49 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Session Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:41:49 --> Session routines successfully run
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Controller Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:41:49 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:41:49 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/sidebar_director.php
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:41:49 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-03 15:41:49 --> Final output sent to browser
DEBUG - 2016-08-03 15:41:49 --> Total execution time: 0.4645
DEBUG - 2016-08-03 15:41:53 --> Config Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:41:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:41:53 --> URI Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Router Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Output Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Security Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Input Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:41:53 --> Language Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Loader Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:41:53 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Session Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:41:53 --> Session routines successfully run
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Controller Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:41:53 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> Model Class Initialized
DEBUG - 2016-08-03 15:41:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:41:53 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-03 15:41:53 --> Final output sent to browser
DEBUG - 2016-08-03 15:41:53 --> Total execution time: 0.3826
DEBUG - 2016-08-03 15:42:01 --> Config Class Initialized
DEBUG - 2016-08-03 15:42:01 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:42:01 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:42:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:42:01 --> URI Class Initialized
DEBUG - 2016-08-03 15:42:01 --> Router Class Initialized
ERROR - 2016-08-03 15:42:01 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-03 15:44:43 --> Config Class Initialized
DEBUG - 2016-08-03 15:44:43 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:44:43 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:44:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:44:43 --> URI Class Initialized
DEBUG - 2016-08-03 15:44:43 --> Router Class Initialized
ERROR - 2016-08-03 15:44:43 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-03 15:45:15 --> Config Class Initialized
DEBUG - 2016-08-03 15:45:15 --> Hooks Class Initialized
DEBUG - 2016-08-03 15:45:15 --> Utf8 Class Initialized
DEBUG - 2016-08-03 15:45:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-03 15:45:15 --> URI Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Router Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Output Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Security Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Input Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-03 15:45:16 --> Language Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Loader Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Helper loaded: url_helper
DEBUG - 2016-08-03 15:45:16 --> Database Driver Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Session Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Helper loaded: string_helper
DEBUG - 2016-08-03 15:45:16 --> Session routines successfully run
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Controller Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Model Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Helper loaded: form_helper
DEBUG - 2016-08-03 15:45:16 --> Form Validation Class Initialized
DEBUG - 2016-08-03 15:45:16 --> Pagination Class Initialized
DEBUG - 2016-08-03 15:45:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-03 15:45:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-03 15:45:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-03 15:45:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-03 15:45:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-03 15:45:16 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-03 15:45:16 --> Final output sent to browser
DEBUG - 2016-08-03 15:45:16 --> Total execution time: 0.6458
