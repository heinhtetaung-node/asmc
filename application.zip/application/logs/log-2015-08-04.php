<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-08-04 12:40:03 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:03 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Router Class Initialized
DEBUG - 2015-08-04 12:40:03 --> No URI present. Default controller set.
DEBUG - 2015-08-04 12:40:03 --> Output Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Security Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Input Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:40:03 --> Language Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Loader Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:40:03 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Session Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:40:03 --> A session cookie was not found.
DEBUG - 2015-08-04 12:40:03 --> Session routines successfully run
DEBUG - 2015-08-04 12:40:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Controller Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:03 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:40:03 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:40:03 --> File loaded: application/views/loginView.php
DEBUG - 2015-08-04 12:40:03 --> Final output sent to browser
DEBUG - 2015-08-04 12:40:03 --> Total execution time: 0.0663
DEBUG - 2015-08-04 12:40:04 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:04 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:04 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:04 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:04 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:04 --> Router Class Initialized
ERROR - 2015-08-04 12:40:04 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:40:18 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:18 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Router Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Output Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Security Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Input Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:40:18 --> Language Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Loader Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:40:18 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Session Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:40:18 --> Session routines successfully run
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Controller Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:40:18 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-04 12:40:18 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:18 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Router Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Output Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Security Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Input Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:40:18 --> Language Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Loader Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:40:18 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Session Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:40:18 --> Session routines successfully run
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Controller Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:40:18 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:40:18 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:40:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:40:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:40:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:40:18 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:40:18 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-08-04 12:40:18 --> Final output sent to browser
DEBUG - 2015-08-04 12:40:18 --> Total execution time: 0.0611
DEBUG - 2015-08-04 12:40:18 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:18 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:18 --> Router Class Initialized
ERROR - 2015-08-04 12:40:18 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:40:21 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:21 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Router Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Output Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Security Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Input Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:40:21 --> Language Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Loader Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:40:21 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Session Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:40:21 --> Session routines successfully run
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Controller Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:40:21 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:40:21 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:40:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:40:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:40:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:40:21 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:40:21 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-04 12:40:21 --> Final output sent to browser
DEBUG - 2015-08-04 12:40:21 --> Total execution time: 0.2243
DEBUG - 2015-08-04 12:40:21 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:21 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:21 --> Router Class Initialized
ERROR - 2015-08-04 12:40:21 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:40:25 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:25 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:25 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Router Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Output Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Security Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Input Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:40:25 --> Language Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Loader Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:40:25 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Session Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:40:25 --> Session routines successfully run
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Controller Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Model Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:40:25 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:40:25 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:40:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:40:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:40:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:40:25 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:40:25 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-04 12:40:25 --> Final output sent to browser
DEBUG - 2015-08-04 12:40:25 --> Total execution time: 0.0999
DEBUG - 2015-08-04 12:40:25 --> Config Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:40:25 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:40:25 --> URI Class Initialized
DEBUG - 2015-08-04 12:40:25 --> Router Class Initialized
ERROR - 2015-08-04 12:40:25 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:43:03 --> Config Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:43:03 --> URI Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Router Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Output Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Security Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Input Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:43:03 --> Language Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Loader Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:43:03 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Session Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:43:03 --> Session routines successfully run
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Controller Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:43:03 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:43:03 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:43:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:43:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:43:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:43:03 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:43:03 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-04 12:43:03 --> Final output sent to browser
DEBUG - 2015-08-04 12:43:03 --> Total execution time: 0.0974
DEBUG - 2015-08-04 12:43:03 --> Config Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:43:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:43:03 --> URI Class Initialized
DEBUG - 2015-08-04 12:43:03 --> Router Class Initialized
ERROR - 2015-08-04 12:43:03 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:43:12 --> Config Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:43:12 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:43:12 --> URI Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Router Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Output Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Security Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Input Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:43:12 --> Language Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Loader Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:43:12 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Session Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:43:12 --> Session routines successfully run
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Controller Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:43:12 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:43:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-04 12:43:13 --> Config Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:43:13 --> URI Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Router Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Output Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Security Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Input Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:43:13 --> Language Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Loader Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:43:13 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Session Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:43:13 --> Session routines successfully run
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Controller Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Model Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:43:13 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:43:13 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:43:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:43:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:43:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:43:13 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:43:13 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:43:13 --> Final output sent to browser
DEBUG - 2015-08-04 12:43:13 --> Total execution time: 0.0635
DEBUG - 2015-08-04 12:43:13 --> Config Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:43:13 --> URI Class Initialized
DEBUG - 2015-08-04 12:43:13 --> Router Class Initialized
ERROR - 2015-08-04 12:43:13 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:44:15 --> Config Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:44:15 --> URI Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Router Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Output Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Security Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Input Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:44:15 --> Language Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Loader Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:44:15 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Session Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:44:15 --> Session routines successfully run
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Controller Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:44:15 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:44:15 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:44:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:44:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:44:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:44:15 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:44:15 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-04 12:44:15 --> Final output sent to browser
DEBUG - 2015-08-04 12:44:15 --> Total execution time: 0.1049
DEBUG - 2015-08-04 12:44:15 --> Config Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:44:15 --> URI Class Initialized
DEBUG - 2015-08-04 12:44:15 --> Router Class Initialized
ERROR - 2015-08-04 12:44:15 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:44:24 --> Config Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:44:24 --> URI Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Router Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Output Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Security Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Input Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:44:24 --> Language Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Loader Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:44:24 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Session Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:44:24 --> Session routines successfully run
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Controller Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Model Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:44:24 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:44:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-08-04 12:44:24 --> Severity: Notice  --> Undefined index: comfort_letter /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 625
DEBUG - 2015-08-04 12:45:22 --> Config Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:45:22 --> URI Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Router Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Output Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Security Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Input Class Initialized
DEBUG - 2015-08-04 12:45:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:45:22 --> Language Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Loader Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:45:23 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Session Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:45:23 --> Session routines successfully run
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Controller Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:45:23 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:45:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-04 12:45:32 --> Config Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:45:32 --> URI Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Router Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Output Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Security Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Input Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:45:32 --> Language Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Loader Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:45:32 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Session Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:45:32 --> Session routines successfully run
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Controller Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Model Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:45:32 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:45:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-04 12:46:38 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:38 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Router Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Output Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Security Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Input Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:46:38 --> Language Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Loader Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:46:38 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Session Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:46:38 --> Session routines successfully run
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Controller Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:46:38 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:46:38 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:46:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:46:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:46:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:46:38 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:46:38 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-04 12:46:38 --> Final output sent to browser
DEBUG - 2015-08-04 12:46:38 --> Total execution time: 0.0856
DEBUG - 2015-08-04 12:46:38 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:38 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:38 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:38 --> Router Class Initialized
ERROR - 2015-08-04 12:46:38 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:46:40 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:40 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Router Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Output Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Security Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Input Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:46:40 --> Language Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Loader Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:46:40 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Session Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:46:40 --> Session routines successfully run
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Controller Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:46:40 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:46:40 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:46:41 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:46:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:46:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:46:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:46:41 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:46:41 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-04 12:46:41 --> Final output sent to browser
DEBUG - 2015-08-04 12:46:41 --> Total execution time: 0.1097
DEBUG - 2015-08-04 12:46:41 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:41 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:41 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:41 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:41 --> Router Class Initialized
ERROR - 2015-08-04 12:46:41 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:46:47 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:47 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:47 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Router Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Output Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Security Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Input Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:46:47 --> Language Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Loader Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:46:47 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Session Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:46:47 --> Session routines successfully run
DEBUG - 2015-08-04 12:46:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Controller Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:46:47 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:46:47 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:46:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:46:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:46:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:46:47 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:46:47 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-08-04 12:46:47 --> Final output sent to browser
DEBUG - 2015-08-04 12:46:47 --> Total execution time: 0.0577
DEBUG - 2015-08-04 12:46:47 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:47 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:47 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:47 --> Router Class Initialized
ERROR - 2015-08-04 12:46:47 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:46:50 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:50 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:50 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Router Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Output Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Security Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Input Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:46:50 --> Language Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Loader Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:46:50 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Session Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:46:50 --> Session routines successfully run
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Controller Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:46:50 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:46:50 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:46:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:46:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:46:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:46:50 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:46:50 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-04 12:46:50 --> Final output sent to browser
DEBUG - 2015-08-04 12:46:50 --> Total execution time: 0.1281
DEBUG - 2015-08-04 12:46:50 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:50 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:50 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:50 --> Router Class Initialized
ERROR - 2015-08-04 12:46:50 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:46:53 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:53 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Router Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Output Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Security Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Input Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:46:53 --> Language Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Loader Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:46:53 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Session Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:46:53 --> Session routines successfully run
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Controller Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Model Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:46:53 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:46:53 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:46:53 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:46:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:46:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:46:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:46:53 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:46:53 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:46:53 --> Final output sent to browser
DEBUG - 2015-08-04 12:46:53 --> Total execution time: 0.0625
DEBUG - 2015-08-04 12:46:54 --> Config Class Initialized
DEBUG - 2015-08-04 12:46:54 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:46:54 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:46:54 --> URI Class Initialized
DEBUG - 2015-08-04 12:46:54 --> Router Class Initialized
ERROR - 2015-08-04 12:46:54 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:47:41 --> Config Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:47:41 --> URI Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Router Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Output Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Security Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Input Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:47:41 --> Language Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Loader Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:47:41 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Session Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:47:41 --> Session routines successfully run
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Controller Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:47:41 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:47:41 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:47:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:47:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:47:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:47:41 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:47:41 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-04 12:47:41 --> Final output sent to browser
DEBUG - 2015-08-04 12:47:41 --> Total execution time: 0.1452
DEBUG - 2015-08-04 12:47:41 --> Config Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:47:41 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:47:41 --> URI Class Initialized
DEBUG - 2015-08-04 12:47:41 --> Router Class Initialized
ERROR - 2015-08-04 12:47:41 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:47:47 --> Config Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:47:47 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:47:47 --> URI Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Router Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Output Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Security Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Input Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:47:47 --> Language Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Loader Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:47:47 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Session Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:47:47 --> Session routines successfully run
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Controller Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Model Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:47:47 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:47:47 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:47:47 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:47:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:47:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:47:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:47:47 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:47:47 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-04 12:47:47 --> Final output sent to browser
DEBUG - 2015-08-04 12:47:47 --> Total execution time: 0.0648
DEBUG - 2015-08-04 12:47:48 --> Config Class Initialized
DEBUG - 2015-08-04 12:47:48 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:47:48 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:47:48 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:47:48 --> URI Class Initialized
DEBUG - 2015-08-04 12:47:48 --> Router Class Initialized
ERROR - 2015-08-04 12:47:48 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:50:42 --> Config Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:50:42 --> URI Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Router Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Output Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Security Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Input Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:50:42 --> Language Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Loader Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:50:42 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Session Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:50:42 --> Session routines successfully run
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Controller Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:50:42 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:50:42 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:50:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:50:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:50:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:50:42 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:50:42 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-04 12:50:42 --> Final output sent to browser
DEBUG - 2015-08-04 12:50:42 --> Total execution time: 0.1721
DEBUG - 2015-08-04 12:50:42 --> Config Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:50:42 --> URI Class Initialized
DEBUG - 2015-08-04 12:50:42 --> Router Class Initialized
ERROR - 2015-08-04 12:50:42 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:50:45 --> Config Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:50:45 --> URI Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Router Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Output Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Security Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Input Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:50:45 --> Language Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Loader Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:50:45 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Session Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:50:45 --> Session routines successfully run
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Controller Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Model Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:50:45 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:50:45 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:50:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:50:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:50:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:50:45 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:50:45 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:50:45 --> Final output sent to browser
DEBUG - 2015-08-04 12:50:45 --> Total execution time: 0.0715
DEBUG - 2015-08-04 12:50:45 --> Config Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:50:45 --> URI Class Initialized
DEBUG - 2015-08-04 12:50:45 --> Router Class Initialized
ERROR - 2015-08-04 12:50:45 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:51:31 --> Config Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:51:31 --> URI Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Router Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Output Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Security Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Input Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:51:31 --> Language Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Loader Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:51:31 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Session Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:51:31 --> Session routines successfully run
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Controller Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:51:31 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:51:31 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:51:31 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:51:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:51:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:51:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:51:31 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:51:31 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-04 12:51:31 --> Final output sent to browser
DEBUG - 2015-08-04 12:51:31 --> Total execution time: 0.1370
DEBUG - 2015-08-04 12:51:32 --> Config Class Initialized
DEBUG - 2015-08-04 12:51:32 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:51:32 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:51:32 --> URI Class Initialized
DEBUG - 2015-08-04 12:51:32 --> Router Class Initialized
ERROR - 2015-08-04 12:51:32 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:51:34 --> Config Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:51:34 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:51:34 --> URI Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Router Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Output Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Security Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Input Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:51:34 --> Language Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Loader Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:51:34 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Session Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:51:34 --> Session routines successfully run
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Controller Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Model Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:51:34 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:51:34 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:51:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:51:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:51:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:51:34 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:51:34 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:51:34 --> Final output sent to browser
DEBUG - 2015-08-04 12:51:34 --> Total execution time: 0.0768
DEBUG - 2015-08-04 12:51:34 --> Config Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:51:34 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:51:34 --> URI Class Initialized
DEBUG - 2015-08-04 12:51:34 --> Router Class Initialized
ERROR - 2015-08-04 12:51:34 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:52:56 --> Config Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:52:56 --> URI Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Router Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Output Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Security Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Input Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:52:56 --> Language Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Loader Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:52:56 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Session Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:52:56 --> Session routines successfully run
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Controller Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Model Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:52:56 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:52:56 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:52:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:52:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:52:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:52:56 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:52:56 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:52:56 --> Final output sent to browser
DEBUG - 2015-08-04 12:52:56 --> Total execution time: 0.0737
DEBUG - 2015-08-04 12:52:56 --> Config Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:52:56 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:52:56 --> URI Class Initialized
DEBUG - 2015-08-04 12:52:56 --> Router Class Initialized
ERROR - 2015-08-04 12:52:56 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:55:49 --> Config Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:55:49 --> URI Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Router Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Output Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Security Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Input Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:55:49 --> Language Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Loader Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:55:49 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Session Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:55:49 --> Session routines successfully run
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Controller Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Model Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:55:49 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:55:49 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:55:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:55:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:55:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:55:49 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:55:49 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:55:49 --> Final output sent to browser
DEBUG - 2015-08-04 12:55:49 --> Total execution time: 0.0767
DEBUG - 2015-08-04 12:55:49 --> Config Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:55:49 --> URI Class Initialized
DEBUG - 2015-08-04 12:55:49 --> Router Class Initialized
ERROR - 2015-08-04 12:55:49 --> 404 Page Not Found --> js
DEBUG - 2015-08-04 12:56:54 --> Config Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:56:54 --> URI Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Router Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Output Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Security Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Input Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-04 12:56:54 --> Language Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Loader Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Helper loaded: url_helper
DEBUG - 2015-08-04 12:56:54 --> Database Driver Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Session Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Helper loaded: string_helper
DEBUG - 2015-08-04 12:56:54 --> Session routines successfully run
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Controller Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Model Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Helper loaded: form_helper
DEBUG - 2015-08-04 12:56:54 --> Form Validation Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Pagination Class Initialized
DEBUG - 2015-08-04 12:56:54 --> File loaded: application/views/header.php
DEBUG - 2015-08-04 12:56:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-04 12:56:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-04 12:56:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-04 12:56:54 --> File loaded: application/views/footer.php
DEBUG - 2015-08-04 12:56:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-04 12:56:54 --> Final output sent to browser
DEBUG - 2015-08-04 12:56:54 --> Total execution time: 0.0920
DEBUG - 2015-08-04 12:56:54 --> Config Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Hooks Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Utf8 Class Initialized
DEBUG - 2015-08-04 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2015-08-04 12:56:54 --> URI Class Initialized
DEBUG - 2015-08-04 12:56:54 --> Router Class Initialized
ERROR - 2015-08-04 12:56:54 --> 404 Page Not Found --> js
