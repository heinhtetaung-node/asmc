<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-21 16:37:50 --> Config Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:37:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:37:50 --> URI Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Router Class Initialized
DEBUG - 2016-02-21 16:37:50 --> No URI present. Default controller set.
DEBUG - 2016-02-21 16:37:50 --> Output Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Security Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Input Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 16:37:50 --> Language Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Loader Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Helper loaded: url_helper
DEBUG - 2016-02-21 16:37:50 --> Database Driver Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Session Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Helper loaded: string_helper
DEBUG - 2016-02-21 16:37:50 --> A session cookie was not found.
DEBUG - 2016-02-21 16:37:50 --> Session routines successfully run
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Controller Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Model Class Initialized
DEBUG - 2016-02-21 16:37:50 --> Helper loaded: form_helper
DEBUG - 2016-02-21 16:37:50 --> Form Validation Class Initialized
DEBUG - 2016-02-21 16:37:50 --> File loaded: application/views/loginView.php
DEBUG - 2016-02-21 16:37:50 --> Final output sent to browser
DEBUG - 2016-02-21 16:37:50 --> Total execution time: 0.0580
DEBUG - 2016-02-21 16:37:51 --> Config Class Initialized
DEBUG - 2016-02-21 16:37:51 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:37:51 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:37:51 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:37:51 --> URI Class Initialized
DEBUG - 2016-02-21 16:37:51 --> Router Class Initialized
ERROR - 2016-02-21 16:37:51 --> 404 Page Not Found --> js
DEBUG - 2016-02-21 16:38:01 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:01 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Router Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Output Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Security Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Input Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 16:38:01 --> Language Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Loader Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Helper loaded: url_helper
DEBUG - 2016-02-21 16:38:01 --> Database Driver Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Session Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Helper loaded: string_helper
DEBUG - 2016-02-21 16:38:01 --> Session routines successfully run
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Controller Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Helper loaded: form_helper
DEBUG - 2016-02-21 16:38:01 --> Form Validation Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-21 16:38:01 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:01 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Router Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Output Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Security Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Input Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 16:38:01 --> Language Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Loader Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Helper loaded: url_helper
DEBUG - 2016-02-21 16:38:01 --> Database Driver Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Session Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Helper loaded: string_helper
DEBUG - 2016-02-21 16:38:01 --> Session routines successfully run
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Controller Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Helper loaded: form_helper
DEBUG - 2016-02-21 16:38:01 --> Form Validation Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Pagination Class Initialized
DEBUG - 2016-02-21 16:38:01 --> File loaded: application/views/header.php
DEBUG - 2016-02-21 16:38:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-21 16:38:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-21 16:38:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-21 16:38:01 --> File loaded: application/views/footer.php
DEBUG - 2016-02-21 16:38:01 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-02-21 16:38:01 --> Final output sent to browser
DEBUG - 2016-02-21 16:38:01 --> Total execution time: 0.0435
DEBUG - 2016-02-21 16:38:01 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:01 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:01 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:01 --> Router Class Initialized
ERROR - 2016-02-21 16:38:01 --> 404 Page Not Found --> js
DEBUG - 2016-02-21 16:38:07 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:07 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:07 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Router Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Output Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Security Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Input Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 16:38:07 --> Language Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Loader Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Helper loaded: url_helper
DEBUG - 2016-02-21 16:38:07 --> Database Driver Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Session Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Helper loaded: string_helper
DEBUG - 2016-02-21 16:38:07 --> Session routines successfully run
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Controller Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Helper loaded: form_helper
DEBUG - 2016-02-21 16:38:07 --> Form Validation Class Initialized
DEBUG - 2016-02-21 16:38:07 --> Pagination Class Initialized
DEBUG - 2016-02-21 16:38:07 --> File loaded: application/views/header.php
DEBUG - 2016-02-21 16:38:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-21 16:38:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-21 16:38:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-21 16:38:07 --> File loaded: application/views/footer.php
DEBUG - 2016-02-21 16:38:07 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-02-21 16:38:07 --> Final output sent to browser
DEBUG - 2016-02-21 16:38:07 --> Total execution time: 0.0575
DEBUG - 2016-02-21 16:38:08 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:08 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:08 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:08 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:08 --> Router Class Initialized
ERROR - 2016-02-21 16:38:08 --> 404 Page Not Found --> js
DEBUG - 2016-02-21 16:38:10 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:10 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Router Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Output Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Security Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Input Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-21 16:38:10 --> Language Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Loader Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Helper loaded: url_helper
DEBUG - 2016-02-21 16:38:10 --> Database Driver Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Session Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Helper loaded: string_helper
DEBUG - 2016-02-21 16:38:10 --> Session routines successfully run
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Controller Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Model Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Helper loaded: form_helper
DEBUG - 2016-02-21 16:38:10 --> Form Validation Class Initialized
DEBUG - 2016-02-21 16:38:10 --> Pagination Class Initialized
DEBUG - 2016-02-21 16:38:10 --> File loaded: application/views/header.php
DEBUG - 2016-02-21 16:38:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-21 16:38:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-21 16:38:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-21 16:38:10 --> File loaded: application/views/footer.php
DEBUG - 2016-02-21 16:38:10 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-21 16:38:10 --> Final output sent to browser
DEBUG - 2016-02-21 16:38:10 --> Total execution time: 0.0651
DEBUG - 2016-02-21 16:38:11 --> Config Class Initialized
DEBUG - 2016-02-21 16:38:11 --> Hooks Class Initialized
DEBUG - 2016-02-21 16:38:11 --> Utf8 Class Initialized
DEBUG - 2016-02-21 16:38:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-21 16:38:11 --> URI Class Initialized
DEBUG - 2016-02-21 16:38:11 --> Router Class Initialized
ERROR - 2016-02-21 16:38:11 --> 404 Page Not Found --> js
