<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-07-10 13:44:10 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:10 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:10 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Router Class Initialized
DEBUG - 2015-07-10 13:44:10 --> No URI present. Default controller set.
DEBUG - 2015-07-10 13:44:10 --> Output Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Security Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Input Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:44:10 --> Language Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Loader Class Initialized
DEBUG - 2015-07-10 13:44:10 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:44:10 --> Database Driver Class Initialized
ERROR - 2015-07-10 13:44:10 --> Severity: Warning  --> mysqli_connect(): (28000/1045): Access denied for user 'root'@'localhost' (using password: YES) /Applications/MAMP/htdocs/asmc/crm/system/database/drivers/mysqli/mysqli_driver.php 76
ERROR - 2015-07-10 13:44:10 --> Unable to connect to the database
DEBUG - 2015-07-10 13:44:10 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-07-10 13:44:41 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:41 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Router Class Initialized
DEBUG - 2015-07-10 13:44:41 --> No URI present. Default controller set.
DEBUG - 2015-07-10 13:44:41 --> Output Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Security Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Input Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:44:41 --> Language Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Loader Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:44:41 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Session Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:44:41 --> A session cookie was not found.
DEBUG - 2015-07-10 13:44:41 --> Session routines successfully run
DEBUG - 2015-07-10 13:44:41 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Controller Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:44:41 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:44:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-10 13:44:41 --> Final output sent to browser
DEBUG - 2015-07-10 13:44:41 --> Total execution time: 0.0422
DEBUG - 2015-07-10 13:44:41 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:41 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:41 --> Router Class Initialized
ERROR - 2015-07-10 13:44:41 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:44:46 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:46 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Router Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Output Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Security Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Input Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:44:46 --> Language Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Loader Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:44:46 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Session Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:44:46 --> Session routines successfully run
DEBUG - 2015-07-10 13:44:46 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Controller Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:44:46 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:44:46 --> File loaded: application/views/loginView.php
DEBUG - 2015-07-10 13:44:46 --> Final output sent to browser
DEBUG - 2015-07-10 13:44:46 --> Total execution time: 0.0384
DEBUG - 2015-07-10 13:44:46 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:46 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:46 --> Router Class Initialized
ERROR - 2015-07-10 13:44:46 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:44:54 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:54 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Router Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Output Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Security Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Input Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:44:54 --> Language Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Loader Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:44:54 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Session Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:44:54 --> Session routines successfully run
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Controller Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:44:54 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:44:54 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:54 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Router Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Output Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Security Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Input Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:44:54 --> Language Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Loader Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:44:54 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Session Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:44:54 --> Session routines successfully run
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Controller Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:44:54 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:44:54 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:44:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:44:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:44:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:44:54 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:44:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-07-10 13:44:54 --> Final output sent to browser
DEBUG - 2015-07-10 13:44:54 --> Total execution time: 0.0474
DEBUG - 2015-07-10 13:44:54 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:54 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:54 --> Router Class Initialized
ERROR - 2015-07-10 13:44:54 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:44:57 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:57 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Router Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Output Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Security Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Input Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:44:57 --> Language Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Loader Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:44:57 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Session Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:44:57 --> Session routines successfully run
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Controller Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Model Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:44:57 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:44:57 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:44:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:44:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:44:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:44:57 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:44:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-10 13:44:57 --> Final output sent to browser
DEBUG - 2015-07-10 13:44:57 --> Total execution time: 0.1418
DEBUG - 2015-07-10 13:44:57 --> Config Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:44:57 --> URI Class Initialized
DEBUG - 2015-07-10 13:44:57 --> Router Class Initialized
ERROR - 2015-07-10 13:44:57 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:45:00 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:00 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Router Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Output Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Security Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Input Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:45:00 --> Language Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Loader Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:45:00 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Session Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:45:00 --> Session routines successfully run
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Controller Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:45:00 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:45:00 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:45:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:45:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:45:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:45:00 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:45:00 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-10 13:45:00 --> Final output sent to browser
DEBUG - 2015-07-10 13:45:00 --> Total execution time: 0.0834
DEBUG - 2015-07-10 13:45:00 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:00 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:00 --> Router Class Initialized
ERROR - 2015-07-10 13:45:00 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:45:44 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:44 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Router Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Output Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Security Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Input Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:45:44 --> Language Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Loader Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:45:44 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Session Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:45:44 --> Session routines successfully run
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Controller Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:45:44 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:45:44 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:44 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Router Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Output Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Security Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Input Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:45:44 --> Language Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Loader Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:45:44 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Session Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:45:44 --> Session routines successfully run
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Controller Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:45:44 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:45:44 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:45:44 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:45:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:45:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:45:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:45:44 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:45:44 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-10 13:45:44 --> Final output sent to browser
DEBUG - 2015-07-10 13:45:44 --> Total execution time: 0.0567
DEBUG - 2015-07-10 13:45:45 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:45 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:45 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:45 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:45 --> Router Class Initialized
ERROR - 2015-07-10 13:45:45 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:45:50 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:50 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:50 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Router Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Output Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Security Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Input Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:45:50 --> Language Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Loader Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:45:50 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Session Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:45:50 --> Session routines successfully run
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Controller Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:45:50 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:45:50 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:45:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:45:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:45:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:45:50 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:45:50 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-10 13:45:50 --> Final output sent to browser
DEBUG - 2015-07-10 13:45:50 --> Total execution time: 0.1020
DEBUG - 2015-07-10 13:45:50 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:50 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:50 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:50 --> Router Class Initialized
ERROR - 2015-07-10 13:45:50 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:45:53 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:53 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Router Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Output Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Security Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Input Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:45:53 --> Language Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Loader Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:45:53 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Session Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:45:53 --> Session routines successfully run
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Controller Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Model Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:45:53 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:45:53 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:45:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:45:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:45:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:45:53 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:45:53 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-10 13:45:53 --> Final output sent to browser
DEBUG - 2015-07-10 13:45:53 --> Total execution time: 0.0546
DEBUG - 2015-07-10 13:45:53 --> Config Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:45:53 --> URI Class Initialized
DEBUG - 2015-07-10 13:45:53 --> Router Class Initialized
ERROR - 2015-07-10 13:45:53 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:00 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:00 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:00 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:00 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:00 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:00 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:46:00 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:00 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:00 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:00 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:00 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:00 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:00 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:00 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:00 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-10 13:46:00 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:00 --> Total execution time: 0.0540
DEBUG - 2015-07-10 13:46:00 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:00 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:00 --> Router Class Initialized
ERROR - 2015-07-10 13:46:00 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:02 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:02 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:02 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:02 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:02 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:02 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:02 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:02 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:02 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-07-10 13:46:02 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:02 --> Total execution time: 0.0962
DEBUG - 2015-07-10 13:46:02 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:02 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:02 --> Router Class Initialized
ERROR - 2015-07-10 13:46:02 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:04 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:04 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:04 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:04 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:04 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:04 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:04 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:04 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:04 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-07-10 13:46:04 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:04 --> Total execution time: 0.0557
DEBUG - 2015-07-10 13:46:04 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:04 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:04 --> Router Class Initialized
ERROR - 2015-07-10 13:46:04 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:11 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:11 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:11 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:11 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:11 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:11 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:46:11 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:11 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:11 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:11 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:11 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:11 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:11 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:11 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:11 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-10 13:46:11 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:11 --> Total execution time: 0.0527
DEBUG - 2015-07-10 13:46:11 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:11 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:11 --> Router Class Initialized
ERROR - 2015-07-10 13:46:11 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:14 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:14 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:14 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:14 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:14 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:14 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:14 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:14 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:15 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:15 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-07-10 13:46:15 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:15 --> Total execution time: 0.0464
DEBUG - 2015-07-10 13:46:15 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:15 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:15 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:15 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:15 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:15 --> Router Class Initialized
ERROR - 2015-07-10 13:46:15 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:40 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:40 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:40 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:40 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:40 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:40 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:46:40 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:40 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:40 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:40 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:40 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:40 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:40 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:40 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:40 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:40 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-10 13:46:40 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:40 --> Total execution time: 0.0561
DEBUG - 2015-07-10 13:46:41 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:41 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:41 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:41 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:41 --> Router Class Initialized
ERROR - 2015-07-10 13:46:41 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:46:43 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:43 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Router Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Output Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Security Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Input Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:46:43 --> Language Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Loader Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:46:43 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Session Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:46:43 --> Session routines successfully run
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Controller Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Model Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:46:43 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:46:43 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:46:43 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:46:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:46:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:46:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:46:43 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:46:43 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-07-10 13:46:43 --> Final output sent to browser
DEBUG - 2015-07-10 13:46:43 --> Total execution time: 0.0455
DEBUG - 2015-07-10 13:46:44 --> Config Class Initialized
DEBUG - 2015-07-10 13:46:44 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:46:44 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:46:44 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:46:44 --> URI Class Initialized
DEBUG - 2015-07-10 13:46:44 --> Router Class Initialized
ERROR - 2015-07-10 13:46:44 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:47:02 --> Config Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:47:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:47:02 --> URI Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Router Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Output Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Security Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Input Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:47:02 --> Language Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Loader Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:47:02 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Session Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:47:02 --> Session routines successfully run
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Controller Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Model Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:47:02 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:47:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:47:02 --> DB Transaction Failure
ERROR - 2015-07-10 13:47:02 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`asmc_crm2`.`additional_agent`, CONSTRAINT `additional_agent_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`agent_id`) ON DELETE CASCADE ON UPDATE NO ACTION)
DEBUG - 2015-07-10 13:47:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-07-10 13:48:36 --> Config Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:48:36 --> URI Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Router Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Output Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Security Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Input Class Initialized
DEBUG - 2015-07-10 13:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:48:36 --> Language Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:06 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Router Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Output Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Security Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Input Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:49:06 --> Language Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Loader Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:49:06 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Session Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:49:06 --> Session routines successfully run
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Controller Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:49:06 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:49:06 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:06 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Router Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Output Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Security Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Input Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:49:06 --> Language Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Loader Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:49:06 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Session Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:49:06 --> Session routines successfully run
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Controller Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:49:06 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:49:06 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:49:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:49:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:49:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:49:06 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:49:06 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-10 13:49:06 --> Final output sent to browser
DEBUG - 2015-07-10 13:49:06 --> Total execution time: 0.0526
DEBUG - 2015-07-10 13:49:06 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:06 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:06 --> Router Class Initialized
ERROR - 2015-07-10 13:49:06 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:49:08 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:08 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Router Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Output Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Security Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Input Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:49:08 --> Language Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Loader Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:49:08 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Session Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:49:08 --> Session routines successfully run
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Controller Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:49:08 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:49:08 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:49:08 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:49:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:49:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:49:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:49:08 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:49:08 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-07-10 13:49:08 --> Final output sent to browser
DEBUG - 2015-07-10 13:49:08 --> Total execution time: 0.0457
DEBUG - 2015-07-10 13:49:09 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:09 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:09 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:09 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:09 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:09 --> Router Class Initialized
ERROR - 2015-07-10 13:49:09 --> 404 Page Not Found --> js
DEBUG - 2015-07-10 13:49:21 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:21 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Router Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Output Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Security Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Input Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:49:21 --> Language Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Loader Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:49:21 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Session Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:49:21 --> Session routines successfully run
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Controller Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:49:21 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-07-10 13:49:21 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:21 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Router Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Output Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Security Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Input Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-07-10 13:49:21 --> Language Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Loader Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Helper loaded: url_helper
DEBUG - 2015-07-10 13:49:21 --> Database Driver Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Session Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Helper loaded: string_helper
DEBUG - 2015-07-10 13:49:21 --> Session routines successfully run
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Controller Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Model Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Helper loaded: form_helper
DEBUG - 2015-07-10 13:49:21 --> Form Validation Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Pagination Class Initialized
DEBUG - 2015-07-10 13:49:21 --> File loaded: application/views/header.php
DEBUG - 2015-07-10 13:49:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-07-10 13:49:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-07-10 13:49:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-07-10 13:49:21 --> File loaded: application/views/footer.php
DEBUG - 2015-07-10 13:49:21 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-07-10 13:49:21 --> Final output sent to browser
DEBUG - 2015-07-10 13:49:21 --> Total execution time: 0.0557
DEBUG - 2015-07-10 13:49:21 --> Config Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Hooks Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Utf8 Class Initialized
DEBUG - 2015-07-10 13:49:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-10 13:49:21 --> URI Class Initialized
DEBUG - 2015-07-10 13:49:21 --> Router Class Initialized
ERROR - 2015-07-10 13:49:21 --> 404 Page Not Found --> js
