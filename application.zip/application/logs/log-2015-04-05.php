<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-05 18:04:53 --> Config Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Hooks Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Utf8 Class Initialized
DEBUG - 2015-04-05 18:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-05 18:04:53 --> URI Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Router Class Initialized
DEBUG - 2015-04-05 18:04:53 --> No URI present. Default controller set.
DEBUG - 2015-04-05 18:04:53 --> Output Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Security Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Input Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-05 18:04:53 --> Language Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Loader Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Helper loaded: url_helper
DEBUG - 2015-04-05 18:04:53 --> Database Driver Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Session Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Helper loaded: string_helper
DEBUG - 2015-04-05 18:04:53 --> A session cookie was not found.
DEBUG - 2015-04-05 18:04:53 --> Session routines successfully run
DEBUG - 2015-04-05 18:04:53 --> Model Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Model Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Controller Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Model Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Model Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Model Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Model Class Initialized
DEBUG - 2015-04-05 18:04:53 --> Helper loaded: form_helper
DEBUG - 2015-04-05 18:04:53 --> Form Validation Class Initialized
DEBUG - 2015-04-05 18:04:53 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-05 18:04:53 --> Final output sent to browser
DEBUG - 2015-04-05 18:04:53 --> Total execution time: 0.1062
DEBUG - 2015-04-05 18:05:42 --> Config Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Hooks Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Utf8 Class Initialized
DEBUG - 2015-04-05 18:05:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-05 18:05:42 --> URI Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Router Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Output Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Security Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Input Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-05 18:05:42 --> Language Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Loader Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Helper loaded: url_helper
DEBUG - 2015-04-05 18:05:42 --> Database Driver Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Session Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Helper loaded: string_helper
DEBUG - 2015-04-05 18:05:42 --> Session routines successfully run
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Controller Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Helper loaded: form_helper
DEBUG - 2015-04-05 18:05:42 --> Form Validation Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-05 18:05:42 --> Config Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Hooks Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Utf8 Class Initialized
DEBUG - 2015-04-05 18:05:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-05 18:05:42 --> URI Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Router Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Output Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Security Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Input Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-05 18:05:42 --> Language Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Loader Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Helper loaded: url_helper
DEBUG - 2015-04-05 18:05:42 --> Database Driver Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Session Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Helper loaded: string_helper
DEBUG - 2015-04-05 18:05:42 --> Session routines successfully run
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Controller Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Helper loaded: form_helper
DEBUG - 2015-04-05 18:05:42 --> Form Validation Class Initialized
DEBUG - 2015-04-05 18:05:42 --> Pagination Class Initialized
DEBUG - 2015-04-05 18:05:42 --> File loaded: application/views/header.php
DEBUG - 2015-04-05 18:05:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-05 18:05:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-05 18:05:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-05 18:05:42 --> File loaded: application/views/footer.php
DEBUG - 2015-04-05 18:05:42 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-05 18:05:42 --> Final output sent to browser
DEBUG - 2015-04-05 18:05:42 --> Total execution time: 0.0500
DEBUG - 2015-04-05 18:05:49 --> Config Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Hooks Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Utf8 Class Initialized
DEBUG - 2015-04-05 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-05 18:05:49 --> URI Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Router Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Output Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Security Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Input Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-05 18:05:49 --> Language Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Loader Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Helper loaded: url_helper
DEBUG - 2015-04-05 18:05:49 --> Database Driver Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Session Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Helper loaded: string_helper
DEBUG - 2015-04-05 18:05:49 --> Session routines successfully run
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Controller Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Helper loaded: form_helper
DEBUG - 2015-04-05 18:05:49 --> Form Validation Class Initialized
DEBUG - 2015-04-05 18:05:49 --> Pagination Class Initialized
DEBUG - 2015-04-05 18:05:49 --> File loaded: application/views/header.php
DEBUG - 2015-04-05 18:05:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-05 18:05:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-05 18:05:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-05 18:05:49 --> File loaded: application/views/footer.php
DEBUG - 2015-04-05 18:05:49 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-05 18:05:49 --> Final output sent to browser
DEBUG - 2015-04-05 18:05:49 --> Total execution time: 0.0945
DEBUG - 2015-04-05 18:05:51 --> Config Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Hooks Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Utf8 Class Initialized
DEBUG - 2015-04-05 18:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-05 18:05:51 --> URI Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Router Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Output Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Security Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Input Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-05 18:05:51 --> Language Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Loader Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Helper loaded: url_helper
DEBUG - 2015-04-05 18:05:51 --> Database Driver Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Session Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Helper loaded: string_helper
DEBUG - 2015-04-05 18:05:51 --> Session routines successfully run
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Controller Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Model Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Helper loaded: form_helper
DEBUG - 2015-04-05 18:05:51 --> Form Validation Class Initialized
DEBUG - 2015-04-05 18:05:51 --> Pagination Class Initialized
DEBUG - 2015-04-05 18:05:51 --> File loaded: application/views/header.php
DEBUG - 2015-04-05 18:05:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-05 18:05:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-05 18:05:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-05 18:05:51 --> File loaded: application/views/footer.php
DEBUG - 2015-04-05 18:05:51 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-05 18:05:51 --> Final output sent to browser
DEBUG - 2015-04-05 18:05:51 --> Total execution time: 0.0689
