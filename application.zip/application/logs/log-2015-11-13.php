<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-11-13 16:45:45 --> Config Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:45:45 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:45:45 --> URI Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Router Class Initialized
DEBUG - 2015-11-13 16:45:45 --> No URI present. Default controller set.
DEBUG - 2015-11-13 16:45:45 --> Output Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Security Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Input Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:45:45 --> Language Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Loader Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:45:45 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Session Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:45:45 --> A session cookie was not found.
DEBUG - 2015-11-13 16:45:45 --> Session routines successfully run
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Controller Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:45 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:45:45 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:45:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-11-13 16:45:45 --> Final output sent to browser
DEBUG - 2015-11-13 16:45:45 --> Total execution time: 0.1174
DEBUG - 2015-11-13 16:45:46 --> Config Class Initialized
DEBUG - 2015-11-13 16:45:46 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:45:46 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:45:46 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:45:46 --> URI Class Initialized
DEBUG - 2015-11-13 16:45:46 --> Router Class Initialized
ERROR - 2015-11-13 16:45:46 --> 404 Page Not Found --> js
DEBUG - 2015-11-13 16:45:53 --> Config Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:45:53 --> URI Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Router Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Output Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Security Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Input Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:45:53 --> Language Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Loader Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:45:53 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Session Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:45:53 --> Session routines successfully run
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Controller Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:45:53 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-11-13 16:45:53 --> Config Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:45:53 --> URI Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Router Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Output Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Security Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Input Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:45:53 --> Language Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Loader Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:45:53 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Session Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:45:53 --> Session routines successfully run
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Controller Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Model Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:45:53 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:45:53 --> Pagination Class Initialized
DEBUG - 2015-11-13 16:45:53 --> File loaded: application/views/header.php
DEBUG - 2015-11-13 16:45:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-11-13 16:45:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-11-13 16:45:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-11-13 16:45:53 --> File loaded: application/views/footer.php
DEBUG - 2015-11-13 16:45:53 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-11-13 16:45:53 --> Final output sent to browser
DEBUG - 2015-11-13 16:45:53 --> Total execution time: 0.0527
DEBUG - 2015-11-13 16:45:54 --> Config Class Initialized
DEBUG - 2015-11-13 16:45:54 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:45:54 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:45:54 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:45:54 --> URI Class Initialized
DEBUG - 2015-11-13 16:45:54 --> Router Class Initialized
ERROR - 2015-11-13 16:45:54 --> 404 Page Not Found --> js
DEBUG - 2015-11-13 16:46:17 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:17 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Router Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Output Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Security Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Input Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:46:17 --> Language Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Loader Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:46:17 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Session Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:46:17 --> Session routines successfully run
DEBUG - 2015-11-13 16:46:17 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Controller Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:46:17 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Pagination Class Initialized
DEBUG - 2015-11-13 16:46:17 --> File loaded: application/views/header.php
DEBUG - 2015-11-13 16:46:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-11-13 16:46:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-11-13 16:46:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-11-13 16:46:17 --> File loaded: application/views/footer.php
DEBUG - 2015-11-13 16:46:17 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-11-13 16:46:17 --> Final output sent to browser
DEBUG - 2015-11-13 16:46:17 --> Total execution time: 0.0735
DEBUG - 2015-11-13 16:46:17 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:17 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:17 --> Router Class Initialized
ERROR - 2015-11-13 16:46:17 --> 404 Page Not Found --> js
DEBUG - 2015-11-13 16:46:22 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:22 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Router Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Output Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Security Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Input Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:46:22 --> Language Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Loader Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:46:22 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Session Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:46:22 --> Session routines successfully run
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Controller Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:46:22 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Pagination Class Initialized
DEBUG - 2015-11-13 16:46:22 --> File loaded: application/views/header.php
DEBUG - 2015-11-13 16:46:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-11-13 16:46:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-11-13 16:46:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-11-13 16:46:22 --> File loaded: application/views/footer.php
DEBUG - 2015-11-13 16:46:22 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-11-13 16:46:22 --> Final output sent to browser
DEBUG - 2015-11-13 16:46:22 --> Total execution time: 0.2738
DEBUG - 2015-11-13 16:46:22 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:22 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:22 --> Router Class Initialized
ERROR - 2015-11-13 16:46:22 --> 404 Page Not Found --> js
DEBUG - 2015-11-13 16:46:24 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:24 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Router Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Output Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Security Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Input Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:46:24 --> Language Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Loader Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:46:24 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Session Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:46:24 --> Session routines successfully run
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Controller Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:46:24 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Pagination Class Initialized
DEBUG - 2015-11-13 16:46:24 --> File loaded: application/views/header.php
DEBUG - 2015-11-13 16:46:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-11-13 16:46:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-11-13 16:46:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-11-13 16:46:24 --> File loaded: application/views/footer.php
DEBUG - 2015-11-13 16:46:24 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-11-13 16:46:24 --> Final output sent to browser
DEBUG - 2015-11-13 16:46:24 --> Total execution time: 0.0872
DEBUG - 2015-11-13 16:46:24 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:24 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:24 --> Router Class Initialized
ERROR - 2015-11-13 16:46:24 --> 404 Page Not Found --> js
DEBUG - 2015-11-13 16:46:32 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:32 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Router Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Output Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Security Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Input Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:46:32 --> Language Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Loader Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:46:32 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Session Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:46:32 --> Session routines successfully run
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Controller Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:46:32 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:46:32 --> Pagination Class Initialized
DEBUG - 2015-11-13 16:46:32 --> File loaded: application/views/header.php
DEBUG - 2015-11-13 16:46:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-11-13 16:46:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-11-13 16:46:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-11-13 16:46:32 --> File loaded: application/views/footer.php
DEBUG - 2015-11-13 16:46:32 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-11-13 16:46:32 --> Final output sent to browser
DEBUG - 2015-11-13 16:46:32 --> Total execution time: 0.0963
DEBUG - 2015-11-13 16:46:33 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:33 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:33 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:33 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:33 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:33 --> Router Class Initialized
ERROR - 2015-11-13 16:46:33 --> 404 Page Not Found --> js
DEBUG - 2015-11-13 16:46:36 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:36 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Router Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Output Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Security Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Input Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-11-13 16:46:36 --> Language Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Loader Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Helper loaded: url_helper
DEBUG - 2015-11-13 16:46:36 --> Database Driver Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Session Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Helper loaded: string_helper
DEBUG - 2015-11-13 16:46:36 --> Session routines successfully run
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Controller Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Model Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Helper loaded: form_helper
DEBUG - 2015-11-13 16:46:36 --> Form Validation Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Pagination Class Initialized
DEBUG - 2015-11-13 16:46:36 --> File loaded: application/views/header.php
DEBUG - 2015-11-13 16:46:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-11-13 16:46:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-11-13 16:46:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-11-13 16:46:36 --> File loaded: application/views/footer.php
DEBUG - 2015-11-13 16:46:36 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-11-13 16:46:36 --> Final output sent to browser
DEBUG - 2015-11-13 16:46:36 --> Total execution time: 0.1005
DEBUG - 2015-11-13 16:46:36 --> Config Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Hooks Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Utf8 Class Initialized
DEBUG - 2015-11-13 16:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-11-13 16:46:36 --> URI Class Initialized
DEBUG - 2015-11-13 16:46:36 --> Router Class Initialized
ERROR - 2015-11-13 16:46:36 --> 404 Page Not Found --> js
