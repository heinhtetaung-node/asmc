<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-01-13 17:42:14 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:14 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:14 --> No URI present. Default controller set.
DEBUG - 2016-01-13 17:42:14 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:14 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:14 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:14 --> A session cookie was not found.
DEBUG - 2016-01-13 17:42:14 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:14 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:14 --> File loaded: application/views/loginView.php
DEBUG - 2016-01-13 17:42:14 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:14 --> Total execution time: 0.0743
DEBUG - 2016-01-13 17:42:14 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:14 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:14 --> Router Class Initialized
ERROR - 2016-01-13 17:42:14 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 17:42:20 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:20 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:20 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:20 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:20 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:20 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-13 17:42:20 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:20 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:20 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:20 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:20 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:20 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:42:20 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 17:42:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 17:42:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 17:42:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 17:42:20 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 17:42:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-01-13 17:42:20 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:20 --> Total execution time: 0.0416
DEBUG - 2016-01-13 17:42:20 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:20 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:20 --> Router Class Initialized
ERROR - 2016-01-13 17:42:20 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 17:42:23 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:23 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:23 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:23 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:23 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:23 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:23 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:23 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:42:23 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 17:42:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 17:42:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 17:42:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 17:42:23 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 17:42:23 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-01-13 17:42:23 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:23 --> Total execution time: 0.2267
DEBUG - 2016-01-13 17:42:24 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:24 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:24 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:24 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:24 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:24 --> Router Class Initialized
ERROR - 2016-01-13 17:42:24 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 17:42:26 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:26 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:26 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:26 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:26 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:26 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:42:26 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 17:42:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 17:42:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 17:42:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 17:42:26 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 17:42:26 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 17:42:26 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:26 --> Total execution time: 0.0845
DEBUG - 2016-01-13 17:42:26 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:26 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:26 --> Router Class Initialized
ERROR - 2016-01-13 17:42:26 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 17:42:38 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:38 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:38 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:38 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:38 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:38 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:42:38 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:42:39 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 17:42:39 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:39 --> Total execution time: 1.2973
DEBUG - 2016-01-13 17:42:46 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:46 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:46 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:46 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:46 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:46 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:42:46 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:42:47 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 17:42:47 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:47 --> Total execution time: 1.2631
DEBUG - 2016-01-13 17:42:57 --> Config Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:42:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:42:57 --> URI Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Router Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Output Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Security Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Input Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:42:57 --> Language Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Loader Class Initialized
DEBUG - 2016-01-13 17:42:57 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:42:58 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Session Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:42:58 --> Session routines successfully run
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Controller Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Model Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:42:58 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:42:58 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:42:59 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 17:42:59 --> Final output sent to browser
DEBUG - 2016-01-13 17:42:59 --> Total execution time: 1.2492
DEBUG - 2016-01-13 17:43:16 --> Config Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:43:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:43:16 --> URI Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Router Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Output Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Security Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Input Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:43:16 --> Language Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Loader Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:43:16 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Session Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:43:16 --> Session routines successfully run
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Controller Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:43:16 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:43:16 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:43:18 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 17:43:18 --> Final output sent to browser
DEBUG - 2016-01-13 17:43:18 --> Total execution time: 1.2556
DEBUG - 2016-01-13 17:43:27 --> Config Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:43:27 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:43:27 --> URI Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Router Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Output Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Security Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Input Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:43:27 --> Language Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Loader Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:43:27 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Session Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:43:27 --> Session routines successfully run
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Controller Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Model Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:43:27 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:43:27 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:43:28 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 17:43:28 --> Final output sent to browser
DEBUG - 2016-01-13 17:43:28 --> Total execution time: 1.2511
DEBUG - 2016-01-13 17:44:07 --> Config Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:44:07 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:44:07 --> URI Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Router Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Output Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Security Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Input Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:44:07 --> Language Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Loader Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:44:07 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Session Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:44:07 --> Session routines successfully run
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Controller Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:44:07 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:44:07 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:44:08 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 17:44:08 --> Final output sent to browser
DEBUG - 2016-01-13 17:44:08 --> Total execution time: 1.2591
DEBUG - 2016-01-13 17:44:50 --> Config Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:44:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:44:50 --> URI Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Router Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Output Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Security Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Input Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 17:44:50 --> Language Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Loader Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Helper loaded: url_helper
DEBUG - 2016-01-13 17:44:50 --> Database Driver Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Session Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Helper loaded: string_helper
DEBUG - 2016-01-13 17:44:50 --> Session routines successfully run
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Controller Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Model Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Helper loaded: form_helper
DEBUG - 2016-01-13 17:44:50 --> Form Validation Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Pagination Class Initialized
DEBUG - 2016-01-13 17:44:50 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 17:44:52 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-01-13 17:44:52 --> Final output sent to browser
DEBUG - 2016-01-13 17:44:52 --> Total execution time: 1.8221
DEBUG - 2016-01-13 17:51:06 --> Config Class Initialized
DEBUG - 2016-01-13 17:51:06 --> Hooks Class Initialized
DEBUG - 2016-01-13 17:51:06 --> Utf8 Class Initialized
DEBUG - 2016-01-13 17:51:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 17:51:06 --> URI Class Initialized
DEBUG - 2016-01-13 17:51:06 --> Router Class Initialized
ERROR - 2016-01-13 17:51:06 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:00:52 --> Config Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:00:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:00:52 --> URI Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Router Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Output Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Security Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Input Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:00:52 --> Language Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Loader Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:00:52 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Session Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:00:52 --> Session routines successfully run
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Controller Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:00:52 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:00:52 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:00:52 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:00:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:00:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:00:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:00:52 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:00:52 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-01-13 18:00:52 --> Final output sent to browser
DEBUG - 2016-01-13 18:00:52 --> Total execution time: 0.1255
DEBUG - 2016-01-13 18:00:53 --> Config Class Initialized
DEBUG - 2016-01-13 18:00:53 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:00:53 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:00:53 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:00:53 --> URI Class Initialized
DEBUG - 2016-01-13 18:00:53 --> Router Class Initialized
ERROR - 2016-01-13 18:00:53 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:01:00 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:00 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Router Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Output Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Security Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Input Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:01:00 --> Language Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Loader Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:01:00 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Session Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:01:00 --> Session routines successfully run
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Controller Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:01:00 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:01:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-13 18:01:00 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 18:01:00 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-01-13 18:01:02 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-01-13 18:01:03 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-01-13 18:01:04 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:04 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Router Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Output Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Security Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Input Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:01:04 --> Language Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Loader Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:01:04 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Session Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:01:04 --> Session routines successfully run
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Controller Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:01:04 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:01:04 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:01:04 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:01:04 --> Final output sent to browser
DEBUG - 2016-01-13 18:01:04 --> Total execution time: 0.0602
DEBUG - 2016-01-13 18:01:05 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:05 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:05 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:05 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:05 --> Router Class Initialized
ERROR - 2016-01-13 18:01:05 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:01:36 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:36 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Router Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Output Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Security Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Input Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:01:36 --> Language Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Loader Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:01:36 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Session Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:01:36 --> Session routines successfully run
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Controller Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:01:36 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:01:36 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:01:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:01:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:01:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:01:36 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:01:36 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-01-13 18:01:36 --> Final output sent to browser
DEBUG - 2016-01-13 18:01:36 --> Total execution time: 0.1024
DEBUG - 2016-01-13 18:01:36 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:36 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:36 --> Router Class Initialized
ERROR - 2016-01-13 18:01:36 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:01:39 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:39 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:39 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:39 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:39 --> Router Class Initialized
ERROR - 2016-01-13 18:01:39 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:01:41 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:41 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:41 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:41 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:41 --> Router Class Initialized
ERROR - 2016-01-13 18:01:41 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:01:52 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:52 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Router Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Output Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Security Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Input Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:01:52 --> Language Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Loader Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:01:52 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Session Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:01:52 --> Session routines successfully run
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Controller Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:01:52 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:01:52 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:01:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:01:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:01:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:01:52 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:01:52 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:01:52 --> Final output sent to browser
DEBUG - 2016-01-13 18:01:52 --> Total execution time: 0.0888
DEBUG - 2016-01-13 18:01:52 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:52 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:52 --> Router Class Initialized
ERROR - 2016-01-13 18:01:52 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:01:58 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:58 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Router Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Output Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Security Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Input Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:01:58 --> Language Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Loader Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:01:58 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Session Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:01:58 --> Session routines successfully run
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Controller Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Model Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:01:58 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:01:58 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:01:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:01:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:01:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:01:58 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:01:58 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-01-13 18:01:58 --> Final output sent to browser
DEBUG - 2016-01-13 18:01:58 --> Total execution time: 0.0900
DEBUG - 2016-01-13 18:01:58 --> Config Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:01:58 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:01:58 --> URI Class Initialized
DEBUG - 2016-01-13 18:01:58 --> Router Class Initialized
ERROR - 2016-01-13 18:01:58 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:02:04 --> Config Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:02:04 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:02:04 --> URI Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Router Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Output Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Security Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Input Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:02:04 --> Language Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Loader Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:02:04 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Session Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:02:04 --> Session routines successfully run
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Controller Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:02:04 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:02:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-13 18:02:04 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 18:02:04 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-01-13 18:02:06 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-01-13 18:02:07 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-01-13 18:02:08 --> Config Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:02:08 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:02:08 --> URI Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Router Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Output Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Security Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Input Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:02:08 --> Language Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Loader Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:02:08 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Session Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:02:08 --> Session routines successfully run
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Controller Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Model Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:02:08 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:02:08 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:02:08 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:02:08 --> Final output sent to browser
DEBUG - 2016-01-13 18:02:08 --> Total execution time: 0.0602
DEBUG - 2016-01-13 18:02:09 --> Config Class Initialized
DEBUG - 2016-01-13 18:02:09 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:02:09 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:02:09 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:02:09 --> URI Class Initialized
DEBUG - 2016-01-13 18:02:09 --> Router Class Initialized
ERROR - 2016-01-13 18:02:09 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:22:34 --> Config Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:22:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:22:34 --> URI Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Router Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Output Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Security Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Input Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:22:34 --> Language Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Loader Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:22:34 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Session Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:22:34 --> Session routines successfully run
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Controller Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:22:34 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:34 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:22:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:22:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:22:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:22:34 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:22:34 --> File loaded: application/views/form/list.php
DEBUG - 2016-01-13 18:22:34 --> Final output sent to browser
DEBUG - 2016-01-13 18:22:34 --> Total execution time: 0.1066
DEBUG - 2016-01-13 18:22:34 --> Config Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:22:34 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:22:34 --> URI Class Initialized
DEBUG - 2016-01-13 18:22:34 --> Router Class Initialized
ERROR - 2016-01-13 18:22:34 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:22:37 --> Config Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:22:37 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:22:37 --> URI Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Router Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Output Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Security Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Input Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:22:37 --> Language Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Loader Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:22:37 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Session Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:22:37 --> Session routines successfully run
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Controller Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Model Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:22:37 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:22:37 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:22:37 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:22:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:22:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:22:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:22:37 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:22:37 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:22:37 --> Final output sent to browser
DEBUG - 2016-01-13 18:22:37 --> Total execution time: 0.0690
DEBUG - 2016-01-13 18:22:38 --> Config Class Initialized
DEBUG - 2016-01-13 18:22:38 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:22:38 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:22:38 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:22:38 --> URI Class Initialized
DEBUG - 2016-01-13 18:22:38 --> Router Class Initialized
ERROR - 2016-01-13 18:22:38 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:24:00 --> Config Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:24:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:24:00 --> URI Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Router Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Output Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Security Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Input Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:24:00 --> Language Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Loader Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:24:00 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Session Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:24:00 --> Session routines successfully run
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Controller Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:24:00 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Pagination Class Initialized
ERROR - 2016-01-13 18:24:00 --> Severity: Notice  --> Undefined property: stdClass::$inv_total /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 285
DEBUG - 2016-01-13 18:24:00 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:24:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:24:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:24:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:24:00 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:24:00 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:24:00 --> Final output sent to browser
DEBUG - 2016-01-13 18:24:00 --> Total execution time: 0.0881
DEBUG - 2016-01-13 18:24:00 --> Config Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:24:00 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:24:00 --> URI Class Initialized
DEBUG - 2016-01-13 18:24:00 --> Router Class Initialized
ERROR - 2016-01-13 18:24:00 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:24:32 --> Config Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:24:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:24:32 --> URI Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Router Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Output Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Security Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Input Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:24:32 --> Language Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Loader Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:24:32 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Session Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:24:32 --> Session routines successfully run
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Controller Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:24:32 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:24:32 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:24:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:24:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:24:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:24:32 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:24:32 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:24:32 --> Final output sent to browser
DEBUG - 2016-01-13 18:24:32 --> Total execution time: 0.1152
DEBUG - 2016-01-13 18:24:32 --> Config Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:24:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:24:32 --> URI Class Initialized
DEBUG - 2016-01-13 18:24:32 --> Router Class Initialized
ERROR - 2016-01-13 18:24:32 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:25:20 --> Config Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:25:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:25:20 --> URI Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Router Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Output Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Security Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Input Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:25:20 --> Language Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Loader Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:25:20 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Session Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:25:20 --> Session routines successfully run
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Controller Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:25:20 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:25:20 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:25:20 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:25:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:25:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:25:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:25:20 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:25:20 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:25:20 --> Final output sent to browser
DEBUG - 2016-01-13 18:25:20 --> Total execution time: 0.0774
DEBUG - 2016-01-13 18:25:21 --> Config Class Initialized
DEBUG - 2016-01-13 18:25:21 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:25:21 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:25:21 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:25:21 --> URI Class Initialized
DEBUG - 2016-01-13 18:25:21 --> Router Class Initialized
ERROR - 2016-01-13 18:25:21 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:26:06 --> Config Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:26:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:26:06 --> URI Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Router Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Output Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Security Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Input Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:26:06 --> Language Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Loader Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:26:06 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Session Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:26:06 --> Session routines successfully run
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Controller Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Model Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:26:06 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:26:06 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:26:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:26:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:26:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:26:06 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:26:06 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:26:06 --> Final output sent to browser
DEBUG - 2016-01-13 18:26:06 --> Total execution time: 0.0646
DEBUG - 2016-01-13 18:26:06 --> Config Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:26:06 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:26:06 --> URI Class Initialized
DEBUG - 2016-01-13 18:26:06 --> Router Class Initialized
ERROR - 2016-01-13 18:26:06 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:29:02 --> Config Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:29:02 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:29:02 --> URI Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Router Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Output Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Security Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Input Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:29:02 --> Language Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Loader Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:29:02 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Session Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:29:02 --> Session routines successfully run
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Controller Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:02 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:29:03 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:29:03 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:29:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:29:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:29:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:29:03 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:29:03 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:29:03 --> Final output sent to browser
DEBUG - 2016-01-13 18:29:03 --> Total execution time: 0.0711
DEBUG - 2016-01-13 18:29:03 --> Config Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:29:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:29:03 --> URI Class Initialized
DEBUG - 2016-01-13 18:29:03 --> Router Class Initialized
ERROR - 2016-01-13 18:29:03 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:31:43 --> Config Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:31:43 --> URI Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Router Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Output Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Security Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Input Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:31:43 --> Language Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Loader Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:31:43 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Session Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:31:43 --> Session routines successfully run
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Controller Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:31:43 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:31:43 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:31:43 --> File loaded: application/views/form/index.php
DEBUG - 2016-01-13 18:31:43 --> Final output sent to browser
DEBUG - 2016-01-13 18:31:43 --> Total execution time: 0.1020
DEBUG - 2016-01-13 18:31:43 --> Config Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:31:43 --> URI Class Initialized
DEBUG - 2016-01-13 18:31:43 --> Router Class Initialized
ERROR - 2016-01-13 18:31:43 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:32:52 --> Config Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:32:52 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:32:52 --> URI Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Router Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Output Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Security Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Input Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:32:52 --> Language Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Loader Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:32:52 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Session Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:32:52 --> Session routines successfully run
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Controller Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:32:52 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> Model Class Initialized
DEBUG - 2016-01-13 18:32:52 --> File loaded: application/views/form/email.php
DEBUG - 2016-01-13 18:32:52 --> Email Class Initialized
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fsockopen(): unable to connect to 192.168.0.12:25 (Operation timed out) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1689
DEBUG - 2016-01-13 18:32:57 --> Language file loaded: language/english/email_lang.php
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fwrite() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1846
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> fgets() expects parameter 1 to be resource, boolean given /Applications/MAMP/htdocs/asmc/crm/system/libraries/Email.php 1869
DEBUG - 2016-01-13 18:32:57 --> File loaded: application/views/header.php
ERROR - 2016-01-13 18:32:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2016-01-13 18:32:57 --> File loaded: application/views/form/index.php
DEBUG - 2016-01-13 18:32:57 --> Final output sent to browser
DEBUG - 2016-01-13 18:32:57 --> Total execution time: 5.1224
DEBUG - 2016-01-13 18:32:57 --> Config Class Initialized
DEBUG - 2016-01-13 18:32:57 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:32:57 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:32:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:32:57 --> URI Class Initialized
DEBUG - 2016-01-13 18:32:57 --> Router Class Initialized
ERROR - 2016-01-13 18:32:57 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:33:12 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:12 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:12 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Router Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Output Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Security Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Input Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:33:12 --> Language Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Loader Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:33:12 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Session Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:33:12 --> Session routines successfully run
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Controller Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:33:12 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:12 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:33:12 --> File loaded: application/views/form/index.php
DEBUG - 2016-01-13 18:33:12 --> Final output sent to browser
DEBUG - 2016-01-13 18:33:12 --> Total execution time: 0.0749
DEBUG - 2016-01-13 18:33:13 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:13 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:13 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:13 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:13 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:13 --> Router Class Initialized
ERROR - 2016-01-13 18:33:13 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:33:14 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:14 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:14 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:14 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:14 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:14 --> Router Class Initialized
ERROR - 2016-01-13 18:33:14 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:33:16 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:16 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Router Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Output Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Security Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Input Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:33:16 --> Language Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Loader Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:33:16 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Session Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:33:16 --> Session routines successfully run
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Controller Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:33:16 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:16 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:33:16 --> File loaded: application/views/form/index.php
DEBUG - 2016-01-13 18:33:16 --> Final output sent to browser
DEBUG - 2016-01-13 18:33:16 --> Total execution time: 0.0523
DEBUG - 2016-01-13 18:33:16 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:16 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:16 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:16 --> Router Class Initialized
ERROR - 2016-01-13 18:33:16 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:33:18 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:18 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:18 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:18 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:18 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:18 --> Router Class Initialized
ERROR - 2016-01-13 18:33:18 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:33:20 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:20 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Router Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Output Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Security Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Input Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:33:20 --> Language Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Loader Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:33:20 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Session Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:33:20 --> Session routines successfully run
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Controller Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:33:20 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Model Class Initialized
DEBUG - 2016-01-13 18:33:20 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:33:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:33:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:33:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:33:20 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:33:20 --> File loaded: application/views/form/list.php
DEBUG - 2016-01-13 18:33:20 --> Final output sent to browser
DEBUG - 2016-01-13 18:33:20 --> Total execution time: 0.0524
DEBUG - 2016-01-13 18:33:20 --> Config Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:33:20 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:33:20 --> URI Class Initialized
DEBUG - 2016-01-13 18:33:20 --> Router Class Initialized
ERROR - 2016-01-13 18:33:20 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:34:22 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:22 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Router Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Output Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Security Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Input Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:34:22 --> Language Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Loader Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:34:22 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Session Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:34:22 --> Session routines successfully run
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Controller Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:34:22 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:34:22 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:34:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:34:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:34:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:34:22 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:34:22 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-01-13 18:34:22 --> Final output sent to browser
DEBUG - 2016-01-13 18:34:22 --> Total execution time: 0.0913
DEBUG - 2016-01-13 18:34:22 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:22 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:22 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:22 --> Router Class Initialized
ERROR - 2016-01-13 18:34:22 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:34:29 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:29 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:29 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Router Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Output Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Security Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Input Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:34:29 --> Language Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Loader Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:34:29 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Session Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:34:29 --> Session routines successfully run
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Controller Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:34:29 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:34:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-13 18:34:29 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 18:34:29 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-01-13 18:34:32 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-01-13 18:34:34 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 18:34:35 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-01-13 18:34:36 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:36 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Router Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Output Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Security Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Input Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:34:36 --> Language Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Loader Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:34:36 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Session Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:34:36 --> Session routines successfully run
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Controller Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:34:36 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:34:36 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:34:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:34:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:34:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:34:36 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:34:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:34:36 --> Final output sent to browser
DEBUG - 2016-01-13 18:34:36 --> Total execution time: 0.0678
DEBUG - 2016-01-13 18:34:36 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:36 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:36 --> Router Class Initialized
ERROR - 2016-01-13 18:34:36 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:34:39 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:39 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:39 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Router Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Output Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Security Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Input Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:34:39 --> Language Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Loader Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:34:39 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Session Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:34:39 --> Session routines successfully run
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Controller Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:34:39 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:34:39 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:34:39 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:34:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:34:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:34:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:34:39 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:34:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-01-13 18:34:39 --> Final output sent to browser
DEBUG - 2016-01-13 18:34:39 --> Total execution time: 0.1364
DEBUG - 2016-01-13 18:34:40 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:40 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:40 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:40 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:40 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:40 --> Router Class Initialized
ERROR - 2016-01-13 18:34:40 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:34:45 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:45 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Router Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Output Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Security Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Input Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:34:45 --> Language Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Loader Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:34:45 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Session Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:34:45 --> Session routines successfully run
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Controller Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:34:45 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:34:45 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:34:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:34:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:34:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:34:45 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:34:45 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-01-13 18:34:45 --> Final output sent to browser
DEBUG - 2016-01-13 18:34:45 --> Total execution time: 0.0694
DEBUG - 2016-01-13 18:34:45 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:45 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:45 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:45 --> Router Class Initialized
ERROR - 2016-01-13 18:34:45 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:34:50 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:50 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Router Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Output Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Security Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Input Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:34:50 --> Language Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Loader Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:34:50 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Session Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:34:50 --> Session routines successfully run
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Controller Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Model Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:34:50 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:34:50 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:34:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:34:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:34:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:34:50 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:34:50 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:34:50 --> Final output sent to browser
DEBUG - 2016-01-13 18:34:50 --> Total execution time: 0.0751
DEBUG - 2016-01-13 18:34:50 --> Config Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:34:50 --> URI Class Initialized
DEBUG - 2016-01-13 18:34:50 --> Router Class Initialized
ERROR - 2016-01-13 18:34:50 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:36:32 --> Config Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:36:32 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:36:32 --> URI Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Router Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Output Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Security Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Input Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:36:32 --> Language Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Loader Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:36:32 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Session Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:36:32 --> Session routines successfully run
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Controller Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:36:32 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:36:32 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:36:32 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:36:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:36:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:36:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:36:32 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:36:32 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-01-13 18:36:32 --> Final output sent to browser
DEBUG - 2016-01-13 18:36:32 --> Total execution time: 0.0922
DEBUG - 2016-01-13 18:36:33 --> Config Class Initialized
DEBUG - 2016-01-13 18:36:33 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:36:33 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:36:33 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:36:33 --> URI Class Initialized
DEBUG - 2016-01-13 18:36:33 --> Router Class Initialized
ERROR - 2016-01-13 18:36:33 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:36:36 --> Config Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:36:36 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:36:36 --> URI Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Router Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Output Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Security Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Input Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:36:36 --> Language Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Loader Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:36:36 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Session Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:36:36 --> Session routines successfully run
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Controller Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:36:36 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:36:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-13 18:36:36 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 18:36:37 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-01-13 18:36:39 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-01-13 18:36:42 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-01-13 18:36:43 --> Config Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:36:43 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:36:43 --> URI Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Router Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Output Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Security Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Input Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:36:43 --> Language Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Loader Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:36:43 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Session Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:36:43 --> Session routines successfully run
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Controller Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Model Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:36:43 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:36:43 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:36:43 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:36:43 --> Final output sent to browser
DEBUG - 2016-01-13 18:36:43 --> Total execution time: 0.0911
DEBUG - 2016-01-13 18:36:44 --> Config Class Initialized
DEBUG - 2016-01-13 18:36:44 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:36:44 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:36:44 --> URI Class Initialized
DEBUG - 2016-01-13 18:36:44 --> Router Class Initialized
ERROR - 2016-01-13 18:36:44 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:47:56 --> Config Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:47:56 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:47:56 --> URI Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Router Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Output Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Security Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Input Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:47:56 --> Language Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Loader Class Initialized
DEBUG - 2016-01-13 18:47:56 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:47:57 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Session Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:47:57 --> Session routines successfully run
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Controller Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Model Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:47:57 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:47:57 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:47:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:47:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:47:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:47:57 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:47:57 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-01-13 18:47:57 --> Final output sent to browser
DEBUG - 2016-01-13 18:47:57 --> Total execution time: 0.1067
DEBUG - 2016-01-13 18:47:57 --> Config Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:47:57 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:47:57 --> URI Class Initialized
DEBUG - 2016-01-13 18:47:57 --> Router Class Initialized
ERROR - 2016-01-13 18:47:57 --> 404 Page Not Found --> js
DEBUG - 2016-01-13 18:48:03 --> Config Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:48:03 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:48:03 --> URI Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Router Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Output Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Security Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Input Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:48:03 --> Language Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Loader Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:48:03 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Session Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:48:03 --> Session routines successfully run
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Controller Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:48:03 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:48:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-01-13 18:48:03 --> Helper loaded: pdf_helper
DEBUG - 2016-01-13 18:48:03 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-01-13 18:48:06 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-01-13 18:48:08 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-01-13 18:48:10 --> Config Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:48:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:48:10 --> URI Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Router Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Output Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Security Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Input Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-01-13 18:48:10 --> Language Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Loader Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Helper loaded: url_helper
DEBUG - 2016-01-13 18:48:10 --> Database Driver Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Session Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Helper loaded: string_helper
DEBUG - 2016-01-13 18:48:10 --> Session routines successfully run
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Controller Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Model Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Helper loaded: form_helper
DEBUG - 2016-01-13 18:48:10 --> Form Validation Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Pagination Class Initialized
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/header.php
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/footer.php
DEBUG - 2016-01-13 18:48:10 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-01-13 18:48:10 --> Final output sent to browser
DEBUG - 2016-01-13 18:48:10 --> Total execution time: 0.0783
DEBUG - 2016-01-13 18:48:10 --> Config Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Hooks Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Utf8 Class Initialized
DEBUG - 2016-01-13 18:48:10 --> UTF-8 Support Enabled
DEBUG - 2016-01-13 18:48:10 --> URI Class Initialized
DEBUG - 2016-01-13 18:48:10 --> Router Class Initialized
ERROR - 2016-01-13 18:48:10 --> 404 Page Not Found --> js
