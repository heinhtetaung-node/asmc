<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-01 12:13:37 --> Config Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Hooks Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Utf8 Class Initialized
DEBUG - 2016-08-01 12:13:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 12:13:37 --> URI Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Router Class Initialized
DEBUG - 2016-08-01 12:13:37 --> No URI present. Default controller set.
DEBUG - 2016-08-01 12:13:37 --> Output Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Security Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Input Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 12:13:37 --> Language Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Loader Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Helper loaded: url_helper
DEBUG - 2016-08-01 12:13:37 --> Database Driver Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Session Class Initialized
DEBUG - 2016-08-01 12:13:37 --> Helper loaded: string_helper
DEBUG - 2016-08-01 12:13:37 --> A session cookie was not found.
DEBUG - 2016-08-01 12:13:37 --> Session routines successfully run
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Controller Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Model Class Initialized
DEBUG - 2016-08-01 12:13:38 --> Helper loaded: form_helper
DEBUG - 2016-08-01 12:13:38 --> Form Validation Class Initialized
DEBUG - 2016-08-01 12:13:38 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-01 12:13:38 --> Final output sent to browser
DEBUG - 2016-08-01 12:13:38 --> Total execution time: 0.9321
DEBUG - 2016-08-01 19:40:16 --> Config Class Initialized
DEBUG - 2016-08-01 19:40:16 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:40:16 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:40:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:40:16 --> URI Class Initialized
DEBUG - 2016-08-01 19:40:16 --> Router Class Initialized
DEBUG - 2016-08-01 19:40:17 --> No URI present. Default controller set.
DEBUG - 2016-08-01 19:40:17 --> Output Class Initialized
DEBUG - 2016-08-01 19:40:17 --> Security Class Initialized
DEBUG - 2016-08-01 19:40:17 --> Input Class Initialized
DEBUG - 2016-08-01 19:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:40:17 --> Language Class Initialized
DEBUG - 2016-08-01 19:40:17 --> Loader Class Initialized
DEBUG - 2016-08-01 19:40:17 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:40:17 --> Database Driver Class Initialized
ERROR - 2016-08-01 19:40:19 --> Severity: Warning  --> mysqli_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\xampp\htdocs\asmc\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2016-08-01 19:40:19 --> Unable to connect to the database
DEBUG - 2016-08-01 19:40:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-08-01 19:40:26 --> Config Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:40:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:40:26 --> URI Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Router Class Initialized
DEBUG - 2016-08-01 19:40:26 --> No URI present. Default controller set.
DEBUG - 2016-08-01 19:40:26 --> Output Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Security Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Input Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:40:26 --> Language Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Loader Class Initialized
DEBUG - 2016-08-01 19:40:26 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:40:26 --> Database Driver Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Session Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Helper loaded: string_helper
DEBUG - 2016-08-01 19:40:27 --> A session cookie was not found.
DEBUG - 2016-08-01 19:40:27 --> Session routines successfully run
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Controller Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Model Class Initialized
DEBUG - 2016-08-01 19:40:27 --> Helper loaded: form_helper
DEBUG - 2016-08-01 19:40:27 --> Form Validation Class Initialized
DEBUG - 2016-08-01 19:40:27 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-01 19:40:27 --> Final output sent to browser
DEBUG - 2016-08-01 19:40:27 --> Total execution time: 0.6006
DEBUG - 2016-08-01 19:53:21 --> Config Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:53:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:53:21 --> URI Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Router Class Initialized
DEBUG - 2016-08-01 19:53:21 --> No URI present. Default controller set.
DEBUG - 2016-08-01 19:53:21 --> Output Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Security Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Input Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:53:21 --> Language Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Loader Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:53:21 --> Database Driver Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Session Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Helper loaded: string_helper
DEBUG - 2016-08-01 19:53:21 --> Session routines successfully run
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Controller Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Helper loaded: form_helper
DEBUG - 2016-08-01 19:53:21 --> Form Validation Class Initialized
DEBUG - 2016-08-01 19:53:21 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-01 19:53:21 --> Final output sent to browser
DEBUG - 2016-08-01 19:53:21 --> Total execution time: 0.1055
DEBUG - 2016-08-01 19:53:21 --> Config Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:53:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:53:21 --> URI Class Initialized
DEBUG - 2016-08-01 19:53:21 --> Router Class Initialized
ERROR - 2016-08-01 19:53:21 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 19:53:28 --> Config Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:53:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:53:28 --> URI Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Router Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Output Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Security Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Input Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:53:28 --> Language Class Initialized
DEBUG - 2016-08-01 19:53:28 --> Loader Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:53:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Session Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 19:53:29 --> Session routines successfully run
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Controller Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 19:53:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-01 19:53:29 --> Config Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:53:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:53:29 --> URI Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Router Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Output Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Security Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Input Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:53:29 --> Language Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Loader Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:53:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Session Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 19:53:29 --> Session routines successfully run
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Controller Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 19:53:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Pagination Class Initialized
DEBUG - 2016-08-01 19:53:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 19:53:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 19:53:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 19:53:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 19:53:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 19:53:29 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 19:53:29 --> Final output sent to browser
DEBUG - 2016-08-01 19:53:29 --> Total execution time: 0.2761
DEBUG - 2016-08-01 19:53:29 --> Config Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:53:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:53:29 --> URI Class Initialized
DEBUG - 2016-08-01 19:53:29 --> Router Class Initialized
ERROR - 2016-08-01 19:53:30 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 19:53:30 --> Config Class Initialized
DEBUG - 2016-08-01 19:53:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:53:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:53:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:53:30 --> URI Class Initialized
DEBUG - 2016-08-01 19:53:30 --> Router Class Initialized
ERROR - 2016-08-01 19:53:30 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 19:55:26 --> Config Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:55:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:55:26 --> URI Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Router Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Output Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Security Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Input Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:55:26 --> Language Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Loader Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:55:26 --> Database Driver Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Session Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Helper loaded: string_helper
DEBUG - 2016-08-01 19:55:26 --> Session routines successfully run
DEBUG - 2016-08-01 19:55:26 --> Model Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Model Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Controller Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Model Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Helper loaded: form_helper
DEBUG - 2016-08-01 19:55:26 --> Form Validation Class Initialized
DEBUG - 2016-08-01 19:55:26 --> Pagination Class Initialized
DEBUG - 2016-08-01 19:55:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 19:55:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 19:55:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 19:55:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 19:55:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 19:55:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 19:55:26 --> Final output sent to browser
DEBUG - 2016-08-01 19:55:26 --> Total execution time: 0.1113
DEBUG - 2016-08-01 19:55:29 --> Config Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 19:55:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 19:55:29 --> URI Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Router Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Output Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Security Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Input Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 19:55:29 --> Language Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Loader Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 19:55:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Session Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 19:55:29 --> Session routines successfully run
DEBUG - 2016-08-01 19:55:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Controller Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Model Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 19:55:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 19:55:29 --> Pagination Class Initialized
DEBUG - 2016-08-01 19:55:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 19:55:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 19:55:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 19:55:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 19:55:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 19:55:29 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 19:55:29 --> Final output sent to browser
DEBUG - 2016-08-01 19:55:29 --> Total execution time: 0.1042
DEBUG - 2016-08-01 20:07:25 --> Config Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:07:25 --> URI Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Router Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Output Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Security Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Input Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:07:25 --> Language Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Loader Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:07:25 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Session Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:07:25 --> Session routines successfully run
DEBUG - 2016-08-01 20:07:25 --> Model Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Model Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Controller Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Model Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:07:25 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:07:25 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:07:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:07:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:07:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:07:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:07:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:07:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:07:25 --> Final output sent to browser
DEBUG - 2016-08-01 20:07:25 --> Total execution time: 0.1045
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Output Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Security Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Input Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:08:29 --> Language Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Loader Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:08:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Session Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:08:29 --> Session routines successfully run
DEBUG - 2016-08-01 20:08:29 --> Model Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Model Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Controller Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Model Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:08:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:08:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:08:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:08:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:08:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:08:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:08:29 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:08:29 --> Final output sent to browser
DEBUG - 2016-08-01 20:08:29 --> Total execution time: 0.1099
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
ERROR - 2016-08-01 20:08:29 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:08:29 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:08:29 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
ERROR - 2016-08-01 20:08:29 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
ERROR - 2016-08-01 20:08:29 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:29 --> Router Class Initialized
ERROR - 2016-08-01 20:08:29 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Output Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Security Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Input Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:08:30 --> Language Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Loader Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:08:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Session Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:08:30 --> Session routines successfully run
DEBUG - 2016-08-01 20:08:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Controller Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:08:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:08:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:08:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:08:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:08:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:08:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:08:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:08:30 --> Final output sent to browser
DEBUG - 2016-08-01 20:08:30 --> Total execution time: 0.1003
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
ERROR - 2016-08-01 20:08:30 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:08:30 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:08:30 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
ERROR - 2016-08-01 20:08:30 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
ERROR - 2016-08-01 20:08:30 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:30 --> Router Class Initialized
ERROR - 2016-08-01 20:08:30 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:40 --> Router Class Initialized
ERROR - 2016-08-01 20:08:40 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:08:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:08:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:08:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:08:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:08:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:08:45 --> Router Class Initialized
ERROR - 2016-08-01 20:08:45 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:09:13 --> Config Class Initialized
DEBUG - 2016-08-01 20:09:13 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:09:13 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:09:13 --> URI Class Initialized
DEBUG - 2016-08-01 20:09:13 --> Router Class Initialized
ERROR - 2016-08-01 20:09:13 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:09:15 --> Config Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:09:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:09:15 --> URI Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Router Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Output Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Security Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Input Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:09:15 --> Language Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Loader Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:09:15 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Session Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:09:15 --> Session routines successfully run
DEBUG - 2016-08-01 20:09:15 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Controller Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:09:15 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:09:15 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:09:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:09:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:09:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:09:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:09:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:09:15 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:09:15 --> Final output sent to browser
DEBUG - 2016-08-01 20:09:15 --> Total execution time: 0.1189
DEBUG - 2016-08-01 20:09:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:09:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:09:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Output Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Security Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Input Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:09:30 --> Language Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Loader Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:09:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Session Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:09:30 --> Session routines successfully run
DEBUG - 2016-08-01 20:09:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Controller Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:09:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:09:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:09:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:09:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:09:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:09:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:09:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:09:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:09:30 --> Final output sent to browser
DEBUG - 2016-08-01 20:09:30 --> Total execution time: 0.1161
DEBUG - 2016-08-01 20:09:31 --> Config Class Initialized
DEBUG - 2016-08-01 20:09:31 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:09:31 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:09:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:09:31 --> Config Class Initialized
DEBUG - 2016-08-01 20:09:31 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:09:31 --> URI Class Initialized
DEBUG - 2016-08-01 20:09:31 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:09:31 --> Router Class Initialized
DEBUG - 2016-08-01 20:09:31 --> UTF-8 Support Enabled
ERROR - 2016-08-01 20:09:31 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:09:31 --> URI Class Initialized
DEBUG - 2016-08-01 20:09:31 --> Router Class Initialized
ERROR - 2016-08-01 20:09:31 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:09:54 --> Config Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:09:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:09:54 --> URI Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Router Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Output Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Security Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Input Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:09:54 --> Language Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Loader Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:09:54 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Session Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:09:54 --> Session routines successfully run
DEBUG - 2016-08-01 20:09:54 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Controller Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Model Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:09:54 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:09:54 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:09:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:09:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:09:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:09:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:09:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:09:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:09:54 --> Final output sent to browser
DEBUG - 2016-08-01 20:09:54 --> Total execution time: 0.1089
DEBUG - 2016-08-01 20:10:19 --> Config Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:10:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:10:19 --> URI Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Router Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Output Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Security Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Input Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:10:19 --> Language Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Loader Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:10:19 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Session Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:10:19 --> Session routines successfully run
DEBUG - 2016-08-01 20:10:19 --> Model Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Model Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Controller Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Model Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:10:19 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:10:19 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:10:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:10:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:10:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:10:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:10:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:10:19 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:10:19 --> Final output sent to browser
DEBUG - 2016-08-01 20:10:19 --> Total execution time: 0.1109
DEBUG - 2016-08-01 20:10:22 --> Config Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:10:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:10:22 --> URI Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Router Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Output Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Security Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Input Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:10:22 --> Language Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Loader Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:10:22 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Session Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:10:22 --> Session routines successfully run
DEBUG - 2016-08-01 20:10:22 --> Model Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Model Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Controller Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Model Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:10:22 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:10:22 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:10:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:10:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:10:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:10:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:10:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:10:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:10:22 --> Final output sent to browser
DEBUG - 2016-08-01 20:10:22 --> Total execution time: 0.1204
DEBUG - 2016-08-01 20:12:32 --> Config Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:12:32 --> URI Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Router Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Output Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Security Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Input Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:12:32 --> Language Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Loader Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:12:32 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Session Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:12:32 --> Session routines successfully run
DEBUG - 2016-08-01 20:12:32 --> Model Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Model Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Controller Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Model Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:12:32 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:12:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:12:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:12:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:12:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:12:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:12:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:12:32 --> Final output sent to browser
DEBUG - 2016-08-01 20:12:32 --> Total execution time: 0.1269
DEBUG - 2016-08-01 20:12:32 --> Config Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Config Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:12:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:12:32 --> URI Class Initialized
DEBUG - 2016-08-01 20:12:32 --> URI Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Router Class Initialized
DEBUG - 2016-08-01 20:12:32 --> Router Class Initialized
ERROR - 2016-08-01 20:12:32 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:12:32 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:13:14 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:14 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Router Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Output Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Security Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Input Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:13:14 --> Language Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Loader Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:13:14 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Session Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:13:14 --> Session routines successfully run
DEBUG - 2016-08-01 20:13:14 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Controller Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:13:14 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:13:14 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:13:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:13:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:13:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:13:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:13:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:13:14 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:13:14 --> Final output sent to browser
DEBUG - 2016-08-01 20:13:14 --> Total execution time: 0.1217
DEBUG - 2016-08-01 20:13:15 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:15 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:15 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Router Class Initialized
DEBUG - 2016-08-01 20:13:15 --> Router Class Initialized
ERROR - 2016-08-01 20:13:15 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:13:15 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:13:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Router Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Output Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Security Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Input Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:13:40 --> Language Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Loader Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:13:40 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Session Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:13:40 --> Session routines successfully run
DEBUG - 2016-08-01 20:13:40 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Controller Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:13:40 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:13:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:13:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:13:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:13:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:13:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:13:40 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:13:40 --> Final output sent to browser
DEBUG - 2016-08-01 20:13:40 --> Total execution time: 0.1231
DEBUG - 2016-08-01 20:13:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:41 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:41 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:41 --> Router Class Initialized
DEBUG - 2016-08-01 20:13:41 --> Router Class Initialized
ERROR - 2016-08-01 20:13:41 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:13:41 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:13:51 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:51 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Router Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Output Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Security Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Input Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:13:51 --> Language Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Loader Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:13:51 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Session Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:13:51 --> Session routines successfully run
DEBUG - 2016-08-01 20:13:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Controller Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:13:51 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:13:51 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:13:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:13:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:13:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:13:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:13:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:13:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:13:51 --> Final output sent to browser
DEBUG - 2016-08-01 20:13:51 --> Total execution time: 0.1474
DEBUG - 2016-08-01 20:13:52 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:52 --> Config Class Initialized
DEBUG - 2016-08-01 20:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:13:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:13:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:13:52 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:52 --> Router Class Initialized
DEBUG - 2016-08-01 20:13:52 --> URI Class Initialized
DEBUG - 2016-08-01 20:13:52 --> Router Class Initialized
ERROR - 2016-08-01 20:13:52 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:13:52 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:14:35 --> Config Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:14:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:14:35 --> URI Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Router Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Output Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Security Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Input Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:14:35 --> Language Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Loader Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:14:35 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Session Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:14:35 --> Session routines successfully run
DEBUG - 2016-08-01 20:14:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Controller Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:14:35 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:14:35 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:14:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:14:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:14:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:14:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:14:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:14:35 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:14:35 --> Final output sent to browser
DEBUG - 2016-08-01 20:14:35 --> Total execution time: 0.1362
DEBUG - 2016-08-01 20:14:36 --> Config Class Initialized
DEBUG - 2016-08-01 20:14:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:14:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:14:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:14:36 --> Config Class Initialized
DEBUG - 2016-08-01 20:14:36 --> URI Class Initialized
DEBUG - 2016-08-01 20:14:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:14:36 --> Router Class Initialized
DEBUG - 2016-08-01 20:14:36 --> Utf8 Class Initialized
ERROR - 2016-08-01 20:14:36 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:14:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:14:36 --> URI Class Initialized
DEBUG - 2016-08-01 20:14:36 --> Router Class Initialized
ERROR - 2016-08-01 20:14:36 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:14:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:14:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:14:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Output Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Security Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Input Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:14:45 --> Language Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Loader Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:14:45 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Session Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:14:45 --> Session routines successfully run
DEBUG - 2016-08-01 20:14:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Controller Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:14:45 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:14:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:14:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:14:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:14:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:14:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:14:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:14:45 --> Final output sent to browser
DEBUG - 2016-08-01 20:14:45 --> Total execution time: 0.1288
DEBUG - 2016-08-01 20:14:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:14:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:14:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:14:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:14:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:14:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:14:45 --> Router Class Initialized
ERROR - 2016-08-01 20:14:45 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:14:45 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:15:26 --> Config Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:15:26 --> URI Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Router Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Output Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Security Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Input Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:15:26 --> Language Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Loader Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:15:26 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Session Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:15:26 --> Session routines successfully run
DEBUG - 2016-08-01 20:15:26 --> Model Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Model Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Controller Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Model Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:15:26 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:15:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:15:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:15:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:15:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:15:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:15:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:15:26 --> Final output sent to browser
DEBUG - 2016-08-01 20:15:26 --> Total execution time: 0.1351
DEBUG - 2016-08-01 20:15:26 --> Config Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Config Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:15:26 --> URI Class Initialized
DEBUG - 2016-08-01 20:15:26 --> URI Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Router Class Initialized
DEBUG - 2016-08-01 20:15:26 --> Router Class Initialized
ERROR - 2016-08-01 20:15:26 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:15:26 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:17:38 --> Config Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:17:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:17:38 --> URI Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Router Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Output Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Security Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Input Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:17:38 --> Language Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Loader Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:17:38 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Session Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:17:38 --> Session routines successfully run
DEBUG - 2016-08-01 20:17:38 --> Model Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Model Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Controller Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Model Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:17:38 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:17:38 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:17:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:17:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:17:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:17:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:17:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:17:38 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:17:38 --> Final output sent to browser
DEBUG - 2016-08-01 20:17:38 --> Total execution time: 0.1255
DEBUG - 2016-08-01 20:17:39 --> Config Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Config Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:17:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:17:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:17:39 --> URI Class Initialized
DEBUG - 2016-08-01 20:17:39 --> URI Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Router Class Initialized
DEBUG - 2016-08-01 20:17:39 --> Router Class Initialized
ERROR - 2016-08-01 20:17:39 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:17:39 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:17:53 --> Config Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:17:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:17:53 --> URI Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Router Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Output Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Security Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Input Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:17:53 --> Language Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Loader Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:17:53 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Session Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:17:53 --> Session routines successfully run
DEBUG - 2016-08-01 20:17:53 --> Model Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Model Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Controller Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Model Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:17:53 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:17:53 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:17:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:17:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:17:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:17:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:17:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:17:53 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:17:53 --> Final output sent to browser
DEBUG - 2016-08-01 20:17:53 --> Total execution time: 0.1552
DEBUG - 2016-08-01 20:17:54 --> Config Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:17:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:17:54 --> URI Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Config Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Router Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Utf8 Class Initialized
ERROR - 2016-08-01 20:17:54 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:17:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:17:54 --> URI Class Initialized
DEBUG - 2016-08-01 20:17:54 --> Router Class Initialized
ERROR - 2016-08-01 20:17:54 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:18:28 --> Config Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:18:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:18:28 --> URI Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Router Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Output Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Security Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Input Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:18:28 --> Language Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Loader Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:18:28 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Session Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:18:28 --> Session routines successfully run
DEBUG - 2016-08-01 20:18:28 --> Model Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Model Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Controller Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Model Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:18:28 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:18:28 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:18:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:18:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:18:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:18:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:18:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:18:28 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:18:28 --> Final output sent to browser
DEBUG - 2016-08-01 20:18:28 --> Total execution time: 0.1267
DEBUG - 2016-08-01 20:18:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:18:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:18:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:18:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:18:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Router Class Initialized
DEBUG - 2016-08-01 20:18:29 --> Router Class Initialized
ERROR - 2016-08-01 20:18:29 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:18:29 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:19:13 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:13 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Output Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Security Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Input Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:19:13 --> Language Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Loader Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:19:13 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Session Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:19:13 --> Session routines successfully run
DEBUG - 2016-08-01 20:19:13 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Controller Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:19:13 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:19:13 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:19:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:19:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:19:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:19:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:19:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:19:13 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:19:13 --> Final output sent to browser
DEBUG - 2016-08-01 20:19:13 --> Total execution time: 0.1389
DEBUG - 2016-08-01 20:19:14 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:14 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:14 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:14 --> Router Class Initialized
ERROR - 2016-08-01 20:19:14 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:19:14 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:19:23 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:23 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Output Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Security Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Input Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:19:23 --> Language Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Loader Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:19:23 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Session Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:19:23 --> Session routines successfully run
DEBUG - 2016-08-01 20:19:23 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Controller Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:19:23 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:19:23 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:19:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:19:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:19:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:19:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:19:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:19:23 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:19:23 --> Final output sent to browser
DEBUG - 2016-08-01 20:19:23 --> Total execution time: 0.1387
DEBUG - 2016-08-01 20:19:24 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:24 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:24 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:24 --> Router Class Initialized
ERROR - 2016-08-01 20:19:24 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:19:24 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:19:39 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:39 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Output Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Security Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Input Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:19:39 --> Language Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Loader Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:19:39 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Session Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:19:39 --> Session routines successfully run
DEBUG - 2016-08-01 20:19:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Controller Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:19:39 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:19:39 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:19:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:19:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:19:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:19:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:19:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:19:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:19:39 --> Final output sent to browser
DEBUG - 2016-08-01 20:19:39 --> Total execution time: 0.1444
DEBUG - 2016-08-01 20:19:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:40 --> Router Class Initialized
ERROR - 2016-08-01 20:19:40 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:19:40 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:19:56 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:56 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Output Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Security Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Input Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:19:56 --> Language Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Loader Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:19:56 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Session Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:19:56 --> Session routines successfully run
DEBUG - 2016-08-01 20:19:56 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Controller Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Model Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:19:56 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:19:56 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:19:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:19:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:19:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:19:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:19:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:19:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:19:56 --> Final output sent to browser
DEBUG - 2016-08-01 20:19:56 --> Total execution time: 0.1494
DEBUG - 2016-08-01 20:19:57 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Config Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:19:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:19:57 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:57 --> URI Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Router Class Initialized
DEBUG - 2016-08-01 20:19:57 --> Router Class Initialized
ERROR - 2016-08-01 20:19:57 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:19:57 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:20:10 --> Config Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:20:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:20:10 --> URI Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Router Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Output Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Security Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Input Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:20:10 --> Language Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Loader Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:20:10 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Session Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:20:10 --> Session routines successfully run
DEBUG - 2016-08-01 20:20:10 --> Model Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Model Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Controller Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Model Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:20:10 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:20:10 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:20:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:20:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:20:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:20:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:20:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:20:10 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:20:10 --> Final output sent to browser
DEBUG - 2016-08-01 20:20:10 --> Total execution time: 0.1329
DEBUG - 2016-08-01 20:20:11 --> Config Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Config Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:20:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:20:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:20:11 --> URI Class Initialized
DEBUG - 2016-08-01 20:20:11 --> URI Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Router Class Initialized
DEBUG - 2016-08-01 20:20:11 --> Router Class Initialized
ERROR - 2016-08-01 20:20:11 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:20:11 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:21:12 --> Config Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:21:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:21:12 --> URI Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Router Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Output Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Security Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Input Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:21:12 --> Language Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Loader Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:21:12 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Session Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:21:12 --> Session routines successfully run
DEBUG - 2016-08-01 20:21:12 --> Model Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Model Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Controller Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Model Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:21:12 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:21:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:21:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:21:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:21:12 --> File loaded: application/views/sidebar.php
ERROR - 2016-08-01 20:21:12 --> Severity: Notice  --> Undefined variable: m D:\xampp\htdocs\asmc\application\views\admin\adminListView.php 62
DEBUG - 2016-08-01 20:21:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:21:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:21:12 --> Final output sent to browser
DEBUG - 2016-08-01 20:21:12 --> Total execution time: 0.1378
DEBUG - 2016-08-01 20:21:12 --> Config Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Config Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:21:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:21:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:21:12 --> URI Class Initialized
DEBUG - 2016-08-01 20:21:12 --> URI Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Router Class Initialized
DEBUG - 2016-08-01 20:21:12 --> Router Class Initialized
ERROR - 2016-08-01 20:21:12 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:21:12 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:21:24 --> Config Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:21:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:21:24 --> URI Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Router Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Output Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Security Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Input Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:21:24 --> Language Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Loader Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:21:24 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Session Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:21:24 --> Session routines successfully run
DEBUG - 2016-08-01 20:21:24 --> Model Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Model Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Controller Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Model Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:21:24 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:21:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:21:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:21:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:21:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:21:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:21:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:21:24 --> Final output sent to browser
DEBUG - 2016-08-01 20:21:24 --> Total execution time: 0.1669
DEBUG - 2016-08-01 20:21:24 --> Config Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Config Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:21:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:21:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:21:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:21:24 --> URI Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Router Class Initialized
DEBUG - 2016-08-01 20:21:24 --> URI Class Initialized
DEBUG - 2016-08-01 20:21:24 --> Router Class Initialized
ERROR - 2016-08-01 20:21:24 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:21:24 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:23:07 --> Config Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:23:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:23:07 --> URI Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Router Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Output Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Security Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Input Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:23:07 --> Language Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Loader Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:23:07 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Session Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:23:07 --> Session routines successfully run
DEBUG - 2016-08-01 20:23:07 --> Model Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Model Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Controller Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Model Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:23:07 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:23:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:23:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:23:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:23:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:23:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:23:07 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:23:07 --> Final output sent to browser
DEBUG - 2016-08-01 20:23:07 --> Total execution time: 0.1346
DEBUG - 2016-08-01 20:23:07 --> Config Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Config Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:23:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:23:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:23:07 --> URI Class Initialized
DEBUG - 2016-08-01 20:23:07 --> URI Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Router Class Initialized
DEBUG - 2016-08-01 20:23:07 --> Router Class Initialized
ERROR - 2016-08-01 20:23:07 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:23:07 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:28:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:28:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Output Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Security Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Input Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:28:30 --> Language Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Loader Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:28:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Session Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:28:30 --> Session routines successfully run
DEBUG - 2016-08-01 20:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Controller Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:28:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:28:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:28:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:28:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:28:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:28:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:28:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:28:30 --> Final output sent to browser
DEBUG - 2016-08-01 20:28:30 --> Total execution time: 0.1407
DEBUG - 2016-08-01 20:28:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:28:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:28:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:28:30 --> Router Class Initialized
ERROR - 2016-08-01 20:28:30 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:28:30 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:28:57 --> Config Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:28:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:28:57 --> URI Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Router Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Output Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Security Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Input Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:28:57 --> Language Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Loader Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:28:57 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Session Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:28:57 --> Session routines successfully run
DEBUG - 2016-08-01 20:28:57 --> Model Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Model Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Controller Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Model Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:28:57 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:28:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:28:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:28:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:28:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:28:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:28:57 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:28:57 --> Final output sent to browser
DEBUG - 2016-08-01 20:28:57 --> Total execution time: 0.1441
DEBUG - 2016-08-01 20:28:57 --> Config Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Config Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:28:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:28:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:28:57 --> URI Class Initialized
DEBUG - 2016-08-01 20:28:57 --> URI Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Router Class Initialized
DEBUG - 2016-08-01 20:28:57 --> Router Class Initialized
ERROR - 2016-08-01 20:28:57 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:28:57 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:30:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:30:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:30:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Router Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Output Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Security Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Input Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:30:44 --> Language Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Loader Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:30:44 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Session Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:30:44 --> Session routines successfully run
DEBUG - 2016-08-01 20:30:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Controller Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:30:44 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:30:44 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:30:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:30:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:30:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:30:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:30:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:30:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:30:44 --> Final output sent to browser
DEBUG - 2016-08-01 20:30:44 --> Total execution time: 0.1482
DEBUG - 2016-08-01 20:30:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:30:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:30:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:30:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:30:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:30:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:30:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:30:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:30:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:30:45 --> UTF-8 Support Enabled
ERROR - 2016-08-01 20:30:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:30:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:30:45 --> Router Class Initialized
ERROR - 2016-08-01 20:30:45 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:31:36 --> Config Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:31:36 --> URI Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Router Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Output Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Security Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Input Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:31:36 --> Language Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Loader Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:31:36 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Session Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:31:36 --> Session routines successfully run
DEBUG - 2016-08-01 20:31:36 --> Model Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Model Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Controller Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Model Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:31:36 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:31:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:31:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:31:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:31:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:31:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:31:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:31:36 --> Final output sent to browser
DEBUG - 2016-08-01 20:31:36 --> Total execution time: 0.1473
DEBUG - 2016-08-01 20:31:36 --> Config Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Config Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:31:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:31:36 --> URI Class Initialized
DEBUG - 2016-08-01 20:31:36 --> URI Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Router Class Initialized
DEBUG - 2016-08-01 20:31:36 --> Router Class Initialized
ERROR - 2016-08-01 20:31:36 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:31:36 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:31:43 --> Config Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:31:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:31:43 --> URI Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Router Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Output Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Security Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Input Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:31:43 --> Language Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Loader Class Initialized
DEBUG - 2016-08-01 20:31:43 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:31:44 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Session Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:31:44 --> Session routines successfully run
DEBUG - 2016-08-01 20:31:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Controller Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:31:44 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:31:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:31:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:31:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:31:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:31:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:31:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:31:44 --> Final output sent to browser
DEBUG - 2016-08-01 20:31:44 --> Total execution time: 0.1411
DEBUG - 2016-08-01 20:31:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:31:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:31:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:31:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:31:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Router Class Initialized
DEBUG - 2016-08-01 20:31:44 --> Router Class Initialized
ERROR - 2016-08-01 20:31:44 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:31:44 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:32:39 --> Config Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:32:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:32:39 --> URI Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Router Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Output Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Security Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Input Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:32:39 --> Language Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Loader Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:32:39 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Session Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:32:39 --> Session routines successfully run
DEBUG - 2016-08-01 20:32:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Controller Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:32:39 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:32:39 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:32:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:32:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:32:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:32:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:32:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:32:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:32:39 --> Final output sent to browser
DEBUG - 2016-08-01 20:32:39 --> Total execution time: 0.1333
DEBUG - 2016-08-01 20:33:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:33:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:33:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Output Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Security Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Input Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:33:30 --> Language Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Loader Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:33:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Session Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:33:30 --> Session routines successfully run
DEBUG - 2016-08-01 20:33:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Controller Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:33:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:33:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:33:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:33:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:33:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:33:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:33:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:33:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:33:30 --> Final output sent to browser
DEBUG - 2016-08-01 20:33:30 --> Total execution time: 0.1352
DEBUG - 2016-08-01 20:34:17 --> Config Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:34:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:34:17 --> URI Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Router Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Output Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Security Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Input Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:34:17 --> Language Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Loader Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:34:17 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Session Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:34:17 --> Session routines successfully run
DEBUG - 2016-08-01 20:34:17 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Controller Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:34:17 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:34:17 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:34:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:34:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:34:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:34:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:34:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:34:17 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:34:17 --> Final output sent to browser
DEBUG - 2016-08-01 20:34:17 --> Total execution time: 0.1407
DEBUG - 2016-08-01 20:34:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:34:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:34:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Output Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Security Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Input Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:34:30 --> Language Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Loader Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:34:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Session Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:34:30 --> Session routines successfully run
DEBUG - 2016-08-01 20:34:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Controller Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:34:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:34:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:34:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:34:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:34:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:34:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:34:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:34:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:34:30 --> Final output sent to browser
DEBUG - 2016-08-01 20:34:30 --> Total execution time: 0.1411
DEBUG - 2016-08-01 20:34:36 --> Config Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:34:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:34:36 --> URI Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Router Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Output Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Security Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Input Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:34:36 --> Language Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Loader Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:34:36 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Session Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:34:36 --> Session routines successfully run
DEBUG - 2016-08-01 20:34:36 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Controller Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:34:36 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:34:36 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:34:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:34:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:34:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:34:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:34:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:34:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:34:36 --> Final output sent to browser
DEBUG - 2016-08-01 20:34:36 --> Total execution time: 0.1362
DEBUG - 2016-08-01 20:34:47 --> Config Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:34:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:34:47 --> URI Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Router Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Output Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Security Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Input Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:34:47 --> Language Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Loader Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:34:47 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Session Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:34:47 --> Session routines successfully run
DEBUG - 2016-08-01 20:34:47 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Controller Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Model Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:34:47 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:34:47 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:34:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:34:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:34:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:34:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:34:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:34:47 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:34:47 --> Final output sent to browser
DEBUG - 2016-08-01 20:34:47 --> Total execution time: 0.1594
DEBUG - 2016-08-01 20:35:35 --> Config Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:35:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:35:35 --> URI Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Router Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Output Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Security Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Input Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:35:35 --> Language Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Loader Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:35:35 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Session Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:35:35 --> Session routines successfully run
DEBUG - 2016-08-01 20:35:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Controller Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:35:35 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:35:35 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:35:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:35:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:35:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:35:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:35:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:35:35 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:35:35 --> Final output sent to browser
DEBUG - 2016-08-01 20:35:35 --> Total execution time: 0.1413
DEBUG - 2016-08-01 20:35:49 --> Config Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:35:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:35:49 --> URI Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Router Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Output Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Security Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Input Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:35:49 --> Language Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Loader Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:35:49 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Session Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:35:49 --> Session routines successfully run
DEBUG - 2016-08-01 20:35:49 --> Model Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Model Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Controller Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Model Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:35:49 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:35:49 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:35:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:35:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:35:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:35:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:35:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:35:49 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:35:49 --> Final output sent to browser
DEBUG - 2016-08-01 20:35:49 --> Total execution time: 0.1506
DEBUG - 2016-08-01 20:36:00 --> Config Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:36:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:36:00 --> URI Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Router Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Output Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Security Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Input Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:36:00 --> Language Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Loader Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:36:00 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Session Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:36:00 --> Session routines successfully run
DEBUG - 2016-08-01 20:36:00 --> Model Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Model Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Controller Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Model Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:36:00 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:36:00 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:36:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:36:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:36:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:36:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:36:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:36:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:36:00 --> Final output sent to browser
DEBUG - 2016-08-01 20:36:00 --> Total execution time: 0.1424
DEBUG - 2016-08-01 20:36:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:36:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:36:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Router Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Output Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Security Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Input Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:36:44 --> Language Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Loader Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:36:44 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Session Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:36:44 --> Session routines successfully run
DEBUG - 2016-08-01 20:36:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Controller Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:36:44 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:36:44 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:36:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:36:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:36:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:36:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:36:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:36:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:36:45 --> Final output sent to browser
DEBUG - 2016-08-01 20:36:45 --> Total execution time: 0.1520
DEBUG - 2016-08-01 20:36:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:36:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:36:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:36:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:36:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:36:45 --> Router Class Initialized
ERROR - 2016-08-01 20:36:45 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:36:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:37:01 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:01 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Output Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Security Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Input Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:37:01 --> Language Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Loader Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:37:01 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Session Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:37:01 --> Session routines successfully run
DEBUG - 2016-08-01 20:37:01 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Controller Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:37:01 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:37:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:37:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:37:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:37:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:37:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:37:01 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:37:01 --> Final output sent to browser
DEBUG - 2016-08-01 20:37:01 --> Total execution time: 0.1574
DEBUG - 2016-08-01 20:37:01 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:01 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:01 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:01 --> Router Class Initialized
ERROR - 2016-08-01 20:37:01 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:37:01 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:37:03 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:03 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Output Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Security Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Input Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:37:03 --> Language Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Loader Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:37:03 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Session Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:37:03 --> Session routines successfully run
DEBUG - 2016-08-01 20:37:03 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Controller Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:37:03 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:37:03 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:37:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:37:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:37:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:37:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:37:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:37:03 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:37:03 --> Final output sent to browser
DEBUG - 2016-08-01 20:37:03 --> Total execution time: 0.1550
DEBUG - 2016-08-01 20:37:04 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:04 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:04 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:04 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:04 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:04 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:04 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:04 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:04 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:04 --> Router Class Initialized
ERROR - 2016-08-01 20:37:04 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:37:04 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:37:17 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:17 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Output Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Security Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Input Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:37:17 --> Language Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Loader Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:37:17 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Session Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:37:17 --> Session routines successfully run
DEBUG - 2016-08-01 20:37:17 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Controller Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:37:17 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:37:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:37:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:37:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:37:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:37:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:37:17 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:37:17 --> Final output sent to browser
DEBUG - 2016-08-01 20:37:17 --> Total execution time: 0.1546
DEBUG - 2016-08-01 20:37:17 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:17 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:17 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:17 --> Router Class Initialized
ERROR - 2016-08-01 20:37:17 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:37:17 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:37:41 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:41 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Output Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Security Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Input Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:37:41 --> Language Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Loader Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:37:41 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Session Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:37:41 --> Session routines successfully run
DEBUG - 2016-08-01 20:37:41 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Controller Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:37:41 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:37:41 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:37:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:37:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:37:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:37:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:37:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:37:41 --> File loaded: application/views/admin/editAdminView.php
DEBUG - 2016-08-01 20:37:41 --> Final output sent to browser
DEBUG - 2016-08-01 20:37:41 --> Total execution time: 0.1808
DEBUG - 2016-08-01 20:37:42 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:42 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:42 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:42 --> Router Class Initialized
ERROR - 2016-08-01 20:37:42 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:37:42 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:37:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Output Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Security Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Input Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:37:44 --> Language Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Loader Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:37:44 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Session Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:37:44 --> Session routines successfully run
DEBUG - 2016-08-01 20:37:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Controller Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:37:44 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:37:44 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:37:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:37:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:37:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:37:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:37:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:37:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:37:44 --> Final output sent to browser
DEBUG - 2016-08-01 20:37:44 --> Total execution time: 0.1584
DEBUG - 2016-08-01 20:37:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:37:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:37:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:37:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:37:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:37:45 --> UTF-8 Support Enabled
ERROR - 2016-08-01 20:37:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:37:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:37:45 --> Router Class Initialized
ERROR - 2016-08-01 20:37:45 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:39:46 --> Config Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:39:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:39:46 --> URI Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Router Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Output Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Security Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Input Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:39:46 --> Language Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Loader Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:39:46 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Session Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:39:46 --> Session routines successfully run
DEBUG - 2016-08-01 20:39:46 --> Model Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Model Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Controller Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Model Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:39:46 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:39:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:39:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:39:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:39:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:39:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:39:46 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:39:46 --> Final output sent to browser
DEBUG - 2016-08-01 20:39:46 --> Total execution time: 0.1653
DEBUG - 2016-08-01 20:39:46 --> Config Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Config Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:39:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:39:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:39:46 --> URI Class Initialized
DEBUG - 2016-08-01 20:39:46 --> URI Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Router Class Initialized
DEBUG - 2016-08-01 20:39:46 --> Router Class Initialized
ERROR - 2016-08-01 20:39:46 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:39:46 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:40:21 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:21 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Router Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Output Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Security Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Input Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:40:21 --> Language Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Loader Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:40:21 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Session Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:40:21 --> Session routines successfully run
DEBUG - 2016-08-01 20:40:21 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Controller Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:40:21 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:40:21 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:40:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:40:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:40:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:40:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:40:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:40:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:40:21 --> Final output sent to browser
DEBUG - 2016-08-01 20:40:21 --> Total execution time: 0.1502
DEBUG - 2016-08-01 20:40:22 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:22 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:22 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Router Class Initialized
DEBUG - 2016-08-01 20:40:22 --> Router Class Initialized
ERROR - 2016-08-01 20:40:22 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:40:22 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:40:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Output Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Security Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Input Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:40:45 --> Language Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Loader Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:40:45 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Session Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:40:45 --> Session routines successfully run
DEBUG - 2016-08-01 20:40:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Controller Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:40:45 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:40:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:40:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:40:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:40:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:40:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:40:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:40:45 --> Final output sent to browser
DEBUG - 2016-08-01 20:40:45 --> Total execution time: 0.1705
DEBUG - 2016-08-01 20:40:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:40:45 --> Router Class Initialized
ERROR - 2016-08-01 20:40:45 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:40:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:40:55 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:55 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Router Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Output Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Security Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Input Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:40:55 --> Language Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Loader Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:40:55 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Session Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:40:55 --> Session routines successfully run
DEBUG - 2016-08-01 20:40:55 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Controller Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Model Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:40:55 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:40:55 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:40:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:40:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:40:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:40:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:40:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:40:55 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:40:55 --> Final output sent to browser
DEBUG - 2016-08-01 20:40:55 --> Total execution time: 0.1561
DEBUG - 2016-08-01 20:40:56 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Config Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:40:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:40:56 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:56 --> URI Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Router Class Initialized
DEBUG - 2016-08-01 20:40:56 --> Router Class Initialized
ERROR - 2016-08-01 20:40:56 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:40:56 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:41:30 --> Config Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:41:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:41:30 --> URI Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Router Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Output Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Security Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Input Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:41:30 --> Language Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Loader Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:41:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Session Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:41:30 --> Session routines successfully run
DEBUG - 2016-08-01 20:41:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Controller Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Model Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:41:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:41:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:41:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:41:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:41:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:41:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:41:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:41:31 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:41:31 --> Final output sent to browser
DEBUG - 2016-08-01 20:41:31 --> Total execution time: 0.1708
DEBUG - 2016-08-01 20:41:31 --> Config Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Config Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:41:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:41:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:41:31 --> URI Class Initialized
DEBUG - 2016-08-01 20:41:31 --> URI Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Router Class Initialized
DEBUG - 2016-08-01 20:41:31 --> Router Class Initialized
ERROR - 2016-08-01 20:41:31 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:41:31 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:41:52 --> Config Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:41:52 --> URI Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Router Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Output Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Security Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Input Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:41:52 --> Language Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Loader Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:41:52 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Session Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:41:52 --> Session routines successfully run
DEBUG - 2016-08-01 20:41:52 --> Model Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Model Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Controller Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Model Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:41:52 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:41:52 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:41:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:41:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:41:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:41:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:41:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:41:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:41:52 --> Final output sent to browser
DEBUG - 2016-08-01 20:41:52 --> Total execution time: 0.1743
DEBUG - 2016-08-01 20:41:53 --> Config Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Config Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:41:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:41:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:41:53 --> URI Class Initialized
DEBUG - 2016-08-01 20:41:53 --> URI Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Router Class Initialized
DEBUG - 2016-08-01 20:41:53 --> Router Class Initialized
ERROR - 2016-08-01 20:41:53 --> 404 Page Not Found --> js
ERROR - 2016-08-01 20:41:53 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 20:42:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:42:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:42:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Router Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Output Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Security Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Input Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:42:40 --> Language Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Loader Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:42:40 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Session Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:42:40 --> Session routines successfully run
DEBUG - 2016-08-01 20:42:40 --> Model Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Model Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Controller Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Model Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:42:40 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:42:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:42:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:42:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:42:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:42:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:42:40 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:42:40 --> Final output sent to browser
DEBUG - 2016-08-01 20:42:40 --> Total execution time: 0.1782
DEBUG - 2016-08-01 20:42:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Config Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:42:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:42:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:42:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:42:40 --> URI Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Router Class Initialized
DEBUG - 2016-08-01 20:42:40 --> Router Class Initialized
ERROR - 2016-08-01 20:42:40 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:42:40 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:45:52 --> Config Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:45:52 --> URI Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Router Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Output Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Security Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Input Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:45:52 --> Language Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Loader Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:45:52 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Session Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:45:52 --> Session routines successfully run
DEBUG - 2016-08-01 20:45:52 --> Model Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Model Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Controller Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Model Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:45:52 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:45:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:45:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:45:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:45:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:45:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:45:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:45:52 --> Final output sent to browser
DEBUG - 2016-08-01 20:45:52 --> Total execution time: 0.1591
DEBUG - 2016-08-01 20:45:52 --> Config Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Config Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:45:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:45:52 --> URI Class Initialized
DEBUG - 2016-08-01 20:45:52 --> URI Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Router Class Initialized
DEBUG - 2016-08-01 20:45:52 --> Router Class Initialized
ERROR - 2016-08-01 20:45:52 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:45:52 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:46:09 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:09 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Router Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Output Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Security Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Input Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:46:09 --> Language Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Loader Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:46:09 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Session Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:46:09 --> Session routines successfully run
DEBUG - 2016-08-01 20:46:09 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Controller Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:46:09 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:46:09 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:46:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:46:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:46:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:46:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:46:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:46:10 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:46:10 --> Final output sent to browser
DEBUG - 2016-08-01 20:46:10 --> Total execution time: 0.1672
DEBUG - 2016-08-01 20:46:10 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:10 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:10 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Router Class Initialized
DEBUG - 2016-08-01 20:46:10 --> Router Class Initialized
ERROR - 2016-08-01 20:46:10 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:46:10 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:46:28 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:28 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Router Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Output Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Security Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Input Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:46:28 --> Language Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Loader Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:46:28 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Session Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:46:28 --> Session routines successfully run
DEBUG - 2016-08-01 20:46:28 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Controller Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:46:28 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:46:28 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:46:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:46:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:46:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:46:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:46:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:46:28 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:46:28 --> Final output sent to browser
DEBUG - 2016-08-01 20:46:28 --> Total execution time: 0.1691
DEBUG - 2016-08-01 20:46:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:29 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Router Class Initialized
DEBUG - 2016-08-01 20:46:29 --> Router Class Initialized
ERROR - 2016-08-01 20:46:29 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:46:29 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:46:42 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:42 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Router Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Output Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Security Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Input Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:46:42 --> Language Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Loader Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:46:42 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Session Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:46:42 --> Session routines successfully run
DEBUG - 2016-08-01 20:46:42 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Controller Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Model Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:46:42 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:46:42 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:46:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:46:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:46:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:46:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:46:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:46:42 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:46:42 --> Final output sent to browser
DEBUG - 2016-08-01 20:46:42 --> Total execution time: 0.1722
DEBUG - 2016-08-01 20:46:43 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Config Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:46:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:46:43 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:43 --> URI Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Router Class Initialized
DEBUG - 2016-08-01 20:46:43 --> Router Class Initialized
ERROR - 2016-08-01 20:46:43 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 20:46:43 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 20:47:41 --> Config Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:47:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:47:41 --> URI Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Router Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Output Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Security Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Input Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:47:41 --> Language Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Loader Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:47:41 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Session Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:47:41 --> Session routines successfully run
DEBUG - 2016-08-01 20:47:41 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Controller Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:47:41 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:47:41 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:47:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:47:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:47:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:47:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:47:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:47:41 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-08-01 20:47:41 --> Final output sent to browser
DEBUG - 2016-08-01 20:47:41 --> Total execution time: 0.1852
DEBUG - 2016-08-01 20:47:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:47:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:47:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Router Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Output Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Security Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Input Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:47:44 --> Language Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Loader Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:47:44 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Session Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:47:44 --> Session routines successfully run
DEBUG - 2016-08-01 20:47:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Controller Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:47:44 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:47:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:47:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:47:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:47:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:47:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:47:44 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-08-01 20:47:44 --> Final output sent to browser
DEBUG - 2016-08-01 20:47:44 --> Total execution time: 0.1933
DEBUG - 2016-08-01 20:47:44 --> Config Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:47:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:47:44 --> URI Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Router Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Output Class Initialized
DEBUG - 2016-08-01 20:47:44 --> Security Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Input Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:47:45 --> Language Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Loader Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:47:45 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Session Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:47:45 --> Session routines successfully run
DEBUG - 2016-08-01 20:47:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Controller Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:47:45 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:47:45 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:47:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:47:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:47:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:47:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:47:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:47:45 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 20:47:45 --> Final output sent to browser
DEBUG - 2016-08-01 20:47:45 --> Total execution time: 0.2164
DEBUG - 2016-08-01 20:47:47 --> Config Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:47:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:47:47 --> URI Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Router Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Output Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Security Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Input Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:47:47 --> Language Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Loader Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:47:47 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Session Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:47:47 --> Session routines successfully run
DEBUG - 2016-08-01 20:47:47 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Controller Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:47:47 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:47:47 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:47:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:47:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:47:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:47:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:47:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:47:47 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-08-01 20:47:47 --> Final output sent to browser
DEBUG - 2016-08-01 20:47:47 --> Total execution time: 0.1759
DEBUG - 2016-08-01 20:47:51 --> Config Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:47:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:47:51 --> URI Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Router Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Output Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Security Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Input Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:47:51 --> Language Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Loader Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:47:51 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Session Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:47:51 --> Session routines successfully run
DEBUG - 2016-08-01 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Controller Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:47:51 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:47:51 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:47:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:47:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:47:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:47:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:47:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:47:51 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2016-08-01 20:47:51 --> Final output sent to browser
DEBUG - 2016-08-01 20:47:51 --> Total execution time: 0.2712
DEBUG - 2016-08-01 20:47:57 --> Config Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:47:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:47:57 --> URI Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Router Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Output Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Security Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Input Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:47:57 --> Language Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Loader Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:47:57 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Session Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:47:57 --> Session routines successfully run
DEBUG - 2016-08-01 20:47:57 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Controller Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Model Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:47:57 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:47:57 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:47:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:47:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:47:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:47:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:47:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:47:57 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:47:57 --> Final output sent to browser
DEBUG - 2016-08-01 20:47:57 --> Total execution time: 0.1749
DEBUG - 2016-08-01 20:48:21 --> Config Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:48:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:48:21 --> URI Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Router Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Output Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Security Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Input Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:48:21 --> Language Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Loader Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:48:21 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Session Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:48:21 --> Session routines successfully run
DEBUG - 2016-08-01 20:48:21 --> Model Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Model Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Controller Class Initialized
DEBUG - 2016-08-01 20:48:21 --> Model Class Initialized
DEBUG - 2016-08-01 20:48:22 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:48:22 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:48:22 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:48:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:48:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:48:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:48:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:48:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:48:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:48:22 --> Final output sent to browser
DEBUG - 2016-08-01 20:48:22 --> Total execution time: 0.1657
DEBUG - 2016-08-01 20:48:50 --> Config Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:48:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:48:50 --> URI Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Router Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Output Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Security Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Input Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:48:50 --> Language Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Loader Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:48:50 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Session Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:48:50 --> Session routines successfully run
DEBUG - 2016-08-01 20:48:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Controller Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:48:50 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:48:50 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:48:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:48:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:48:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:48:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:48:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:48:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:48:50 --> Final output sent to browser
DEBUG - 2016-08-01 20:48:50 --> Total execution time: 0.1594
DEBUG - 2016-08-01 20:49:27 --> Config Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:49:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:49:27 --> URI Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Router Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Output Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Security Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Input Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:49:27 --> Language Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Loader Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:49:27 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Session Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:49:27 --> Session routines successfully run
DEBUG - 2016-08-01 20:49:27 --> Model Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Model Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Controller Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Model Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:49:27 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:49:27 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:49:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:49:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:49:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:49:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:49:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:49:27 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:49:27 --> Final output sent to browser
DEBUG - 2016-08-01 20:49:27 --> Total execution time: 0.1742
DEBUG - 2016-08-01 20:49:50 --> Config Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:49:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:49:50 --> URI Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Router Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Output Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Security Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Input Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:49:50 --> Language Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Loader Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:49:50 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Session Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:49:50 --> Session routines successfully run
DEBUG - 2016-08-01 20:49:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Controller Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:49:50 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:49:50 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:49:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:49:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:49:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:49:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:49:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:49:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:49:50 --> Final output sent to browser
DEBUG - 2016-08-01 20:49:50 --> Total execution time: 0.1628
DEBUG - 2016-08-01 20:53:12 --> Config Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:53:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:53:12 --> URI Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Router Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Output Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Security Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Input Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:53:12 --> Language Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Loader Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:53:12 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Session Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:53:12 --> Session routines successfully run
DEBUG - 2016-08-01 20:53:12 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Controller Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:53:12 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:53:12 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:53:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:53:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:53:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:53:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:53:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:53:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:53:12 --> Final output sent to browser
DEBUG - 2016-08-01 20:53:12 --> Total execution time: 0.1808
DEBUG - 2016-08-01 20:53:39 --> Config Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:53:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:53:39 --> URI Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Router Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Output Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Security Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Input Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:53:39 --> Language Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Loader Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:53:39 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Session Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:53:39 --> Session routines successfully run
DEBUG - 2016-08-01 20:53:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Controller Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:53:39 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:53:39 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:53:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:53:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:53:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:53:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:53:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:53:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:53:39 --> Final output sent to browser
DEBUG - 2016-08-01 20:53:39 --> Total execution time: 0.1660
DEBUG - 2016-08-01 20:53:48 --> Config Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:53:48 --> URI Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Router Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Output Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Security Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Input Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:53:48 --> Language Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Loader Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:53:48 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Session Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:53:48 --> Session routines successfully run
DEBUG - 2016-08-01 20:53:48 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Controller Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Model Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:53:48 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:53:48 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:53:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:53:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:53:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:53:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:53:48 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:53:49 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:53:49 --> Final output sent to browser
DEBUG - 2016-08-01 20:53:49 --> Total execution time: 0.1717
DEBUG - 2016-08-01 20:55:50 --> Config Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:55:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:55:50 --> URI Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Router Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Output Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Security Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Input Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:55:50 --> Language Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Loader Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:55:50 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Session Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:55:50 --> Session routines successfully run
DEBUG - 2016-08-01 20:55:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Controller Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Model Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:55:50 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:55:50 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:55:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:55:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:55:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:55:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:55:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:55:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:55:50 --> Final output sent to browser
DEBUG - 2016-08-01 20:55:50 --> Total execution time: 0.1856
DEBUG - 2016-08-01 20:55:53 --> Config Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:55:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:55:53 --> URI Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Router Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Output Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Security Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Input Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:55:53 --> Language Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Loader Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:55:53 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Session Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:55:53 --> Session routines successfully run
DEBUG - 2016-08-01 20:55:53 --> Model Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Model Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Controller Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Model Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:55:53 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:55:53 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:55:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:55:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:55:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:55:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:55:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:55:53 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:55:53 --> Final output sent to browser
DEBUG - 2016-08-01 20:55:53 --> Total execution time: 0.1705
DEBUG - 2016-08-01 20:56:35 --> Config Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:56:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:56:35 --> URI Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Router Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Output Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Security Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Input Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:56:35 --> Language Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Loader Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:56:35 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Session Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:56:35 --> Session routines successfully run
DEBUG - 2016-08-01 20:56:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Controller Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Model Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:56:35 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:56:35 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:56:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:56:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:56:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:56:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:56:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:56:35 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:56:35 --> Final output sent to browser
DEBUG - 2016-08-01 20:56:35 --> Total execution time: 0.1748
DEBUG - 2016-08-01 20:56:45 --> Config Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:56:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:56:45 --> URI Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Router Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Output Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Security Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Input Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:56:45 --> Language Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Loader Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:56:45 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Session Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:56:45 --> Session routines successfully run
DEBUG - 2016-08-01 20:56:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Controller Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Model Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:56:45 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:56:45 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:56:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:56:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:56:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:56:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:56:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:56:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:56:45 --> Final output sent to browser
DEBUG - 2016-08-01 20:56:45 --> Total execution time: 0.1746
DEBUG - 2016-08-01 20:58:11 --> Config Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:58:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:58:11 --> URI Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Router Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Output Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Security Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Input Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:58:11 --> Language Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Loader Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:58:11 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Session Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:58:11 --> Session routines successfully run
DEBUG - 2016-08-01 20:58:11 --> Model Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Model Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Controller Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Model Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:58:11 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:58:11 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:58:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:58:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:58:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:58:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:58:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:58:11 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:58:11 --> Final output sent to browser
DEBUG - 2016-08-01 20:58:11 --> Total execution time: 0.1752
DEBUG - 2016-08-01 20:58:19 --> Config Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:58:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:58:19 --> URI Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Router Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Output Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Security Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Input Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:58:19 --> Language Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Loader Class Initialized
DEBUG - 2016-08-01 20:58:19 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:58:20 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Session Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:58:20 --> Session routines successfully run
DEBUG - 2016-08-01 20:58:20 --> Model Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Model Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Controller Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Model Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:58:20 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:58:20 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:58:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:58:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:58:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:58:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:58:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:58:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:58:20 --> Final output sent to browser
DEBUG - 2016-08-01 20:58:20 --> Total execution time: 0.1813
DEBUG - 2016-08-01 20:59:24 --> Config Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:59:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:59:24 --> URI Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Router Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Output Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Security Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Input Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:59:24 --> Language Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Loader Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:59:24 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Session Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:59:24 --> Session routines successfully run
DEBUG - 2016-08-01 20:59:24 --> Model Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Model Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Controller Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Model Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:59:24 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:59:24 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:59:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:59:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:59:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:59:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:59:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:59:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:59:24 --> Final output sent to browser
DEBUG - 2016-08-01 20:59:24 --> Total execution time: 0.1768
DEBUG - 2016-08-01 20:59:34 --> Config Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 20:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 20:59:34 --> URI Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Router Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Output Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Security Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Input Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 20:59:34 --> Language Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Loader Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Helper loaded: url_helper
DEBUG - 2016-08-01 20:59:34 --> Database Driver Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Session Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 20:59:34 --> Session routines successfully run
DEBUG - 2016-08-01 20:59:34 --> Model Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Model Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Controller Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Model Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 20:59:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 20:59:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 20:59:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 20:59:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 20:59:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 20:59:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 20:59:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 20:59:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 20:59:34 --> Final output sent to browser
DEBUG - 2016-08-01 20:59:34 --> Total execution time: 0.1905
DEBUG - 2016-08-01 21:00:22 --> Config Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:00:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:00:22 --> URI Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Router Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Output Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Security Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Input Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:00:22 --> Language Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Loader Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:00:22 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Session Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:00:22 --> Session routines successfully run
DEBUG - 2016-08-01 21:00:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:00:22 --> Controller Class Initialized
DEBUG - 2016-08-01 21:00:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:00:23 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:00:23 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:00:23 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Config Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:00:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:00:29 --> URI Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Router Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Output Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Security Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Input Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:00:29 --> Language Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Loader Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:00:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Session Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:00:29 --> Session routines successfully run
DEBUG - 2016-08-01 21:00:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Controller Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:00:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:00:29 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:00:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:00:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:00:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:00:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:00:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:00:29 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:00:29 --> Final output sent to browser
DEBUG - 2016-08-01 21:00:29 --> Total execution time: 0.2074
DEBUG - 2016-08-01 21:01:33 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:33 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Router Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Output Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Security Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Input Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:01:33 --> Language Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Loader Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:01:33 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Session Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:01:33 --> Session routines successfully run
DEBUG - 2016-08-01 21:01:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Controller Class Initialized
DEBUG - 2016-08-01 21:01:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:01:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:01:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:01:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:01:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:01:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:01:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:01:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:01:34 --> Final output sent to browser
DEBUG - 2016-08-01 21:01:34 --> Total execution time: 0.1925
DEBUG - 2016-08-01 21:01:34 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:34 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:34 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Router Class Initialized
DEBUG - 2016-08-01 21:01:34 --> Router Class Initialized
ERROR - 2016-08-01 21:01:34 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:01:34 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:01:40 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:40 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Router Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Output Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Security Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Input Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:01:40 --> Language Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Loader Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:01:40 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Session Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:01:40 --> Session routines successfully run
DEBUG - 2016-08-01 21:01:40 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Controller Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:01:40 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:01:40 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:01:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:01:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:01:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:01:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:01:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:01:40 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:01:40 --> Final output sent to browser
DEBUG - 2016-08-01 21:01:40 --> Total execution time: 0.2140
DEBUG - 2016-08-01 21:01:41 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:41 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:41 --> Router Class Initialized
DEBUG - 2016-08-01 21:01:41 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:41 --> Hooks Class Initialized
ERROR - 2016-08-01 21:01:41 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:01:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:41 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:41 --> Router Class Initialized
ERROR - 2016-08-01 21:01:41 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:01:54 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:54 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Router Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Output Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Security Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Input Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:01:54 --> Language Class Initialized
DEBUG - 2016-08-01 21:01:54 --> Loader Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:01:55 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Session Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:01:55 --> Session routines successfully run
DEBUG - 2016-08-01 21:01:55 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Controller Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Model Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:01:55 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:01:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:01:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:01:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:01:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:01:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:01:55 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:01:55 --> Final output sent to browser
DEBUG - 2016-08-01 21:01:55 --> Total execution time: 0.1979
DEBUG - 2016-08-01 21:01:55 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:01:55 --> Config Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:01:55 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Router Class Initialized
DEBUG - 2016-08-01 21:01:55 --> UTF-8 Support Enabled
ERROR - 2016-08-01 21:01:55 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:01:55 --> URI Class Initialized
DEBUG - 2016-08-01 21:01:55 --> Router Class Initialized
ERROR - 2016-08-01 21:01:55 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:03:41 --> Config Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:03:41 --> URI Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Router Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Output Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Security Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Input Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:03:41 --> Language Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Loader Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:03:41 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Session Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:03:41 --> Session routines successfully run
DEBUG - 2016-08-01 21:03:41 --> Model Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Model Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Controller Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Model Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:03:41 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:03:41 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:03:41 --> Final output sent to browser
DEBUG - 2016-08-01 21:03:41 --> Total execution time: 0.1676
DEBUG - 2016-08-01 21:03:41 --> Config Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:03:41 --> URI Class Initialized
DEBUG - 2016-08-01 21:03:41 --> Router Class Initialized
ERROR - 2016-08-01 21:03:41 --> 404 Page Not Found --> assets
DEBUG - 2016-08-01 21:04:05 --> Config Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:04:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:04:05 --> URI Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Router Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Output Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Security Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Input Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:04:05 --> Language Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Loader Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:04:05 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Session Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:04:05 --> Session routines successfully run
DEBUG - 2016-08-01 21:04:05 --> Model Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Model Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Controller Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Model Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:04:05 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:04:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:04:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:04:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:04:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:04:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:04:05 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:04:05 --> Final output sent to browser
DEBUG - 2016-08-01 21:04:05 --> Total execution time: 0.1812
DEBUG - 2016-08-01 21:04:05 --> Config Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Config Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:04:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:04:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:04:05 --> URI Class Initialized
DEBUG - 2016-08-01 21:04:05 --> URI Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Router Class Initialized
DEBUG - 2016-08-01 21:04:05 --> Router Class Initialized
ERROR - 2016-08-01 21:04:05 --> 404 Page Not Found --> js
ERROR - 2016-08-01 21:04:05 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:05:11 --> Config Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:05:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:05:11 --> URI Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Router Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Output Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Security Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Input Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:05:11 --> Language Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Loader Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:05:11 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Session Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:05:11 --> Session routines successfully run
DEBUG - 2016-08-01 21:05:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Controller Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:05:11 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:05:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:05:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:05:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:05:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:05:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:05:11 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:05:11 --> Final output sent to browser
DEBUG - 2016-08-01 21:05:11 --> Total execution time: 0.1841
DEBUG - 2016-08-01 21:05:11 --> Config Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Config Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:05:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:05:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:05:11 --> URI Class Initialized
DEBUG - 2016-08-01 21:05:11 --> URI Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Router Class Initialized
DEBUG - 2016-08-01 21:05:11 --> Router Class Initialized
ERROR - 2016-08-01 21:05:11 --> 404 Page Not Found --> js
ERROR - 2016-08-01 21:05:11 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:06:07 --> Config Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:06:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:06:07 --> URI Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Router Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Output Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Security Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Input Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:06:07 --> Language Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Loader Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:06:07 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Session Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:06:07 --> Session routines successfully run
DEBUG - 2016-08-01 21:06:07 --> Model Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Model Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Controller Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Model Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:06:07 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:06:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:06:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:06:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:06:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:06:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:06:07 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:06:07 --> Final output sent to browser
DEBUG - 2016-08-01 21:06:07 --> Total execution time: 0.2032
DEBUG - 2016-08-01 21:06:07 --> Config Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Config Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:06:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:06:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:06:07 --> URI Class Initialized
DEBUG - 2016-08-01 21:06:07 --> URI Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Router Class Initialized
DEBUG - 2016-08-01 21:06:07 --> Router Class Initialized
ERROR - 2016-08-01 21:06:07 --> 404 Page Not Found --> js
ERROR - 2016-08-01 21:06:07 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:07:04 --> Config Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:07:04 --> URI Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Router Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Output Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Security Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Input Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:07:04 --> Language Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Loader Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:07:04 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Session Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:07:04 --> Session routines successfully run
DEBUG - 2016-08-01 21:07:04 --> Model Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Model Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Controller Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Model Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:07:04 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:07:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:07:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:07:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:07:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:07:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:07:04 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:07:04 --> Final output sent to browser
DEBUG - 2016-08-01 21:07:04 --> Total execution time: 0.2091
DEBUG - 2016-08-01 21:07:04 --> Config Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Config Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:07:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:07:04 --> URI Class Initialized
DEBUG - 2016-08-01 21:07:04 --> URI Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Router Class Initialized
DEBUG - 2016-08-01 21:07:04 --> Router Class Initialized
ERROR - 2016-08-01 21:07:04 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:07:04 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:07:50 --> Config Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:07:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:07:50 --> URI Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Router Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Output Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Security Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Input Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:07:50 --> Language Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Loader Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:07:50 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Session Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:07:50 --> Session routines successfully run
DEBUG - 2016-08-01 21:07:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Controller Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:07:50 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:07:50 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:07:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:07:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:07:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:07:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:07:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:07:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:07:50 --> Final output sent to browser
DEBUG - 2016-08-01 21:07:50 --> Total execution time: 0.1969
DEBUG - 2016-08-01 21:07:51 --> Config Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Config Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:07:51 --> URI Class Initialized
DEBUG - 2016-08-01 21:07:51 --> URI Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Router Class Initialized
DEBUG - 2016-08-01 21:07:51 --> Router Class Initialized
ERROR - 2016-08-01 21:07:51 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:07:51 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:09:02 --> Config Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:09:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:09:02 --> URI Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Router Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Output Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Security Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Input Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:09:02 --> Language Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Loader Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:09:02 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Session Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:09:02 --> Session routines successfully run
DEBUG - 2016-08-01 21:09:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Controller Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:09:02 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:09:02 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:09:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:09:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:09:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:09:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:09:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:09:02 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:09:02 --> Final output sent to browser
DEBUG - 2016-08-01 21:09:02 --> Total execution time: 0.1925
DEBUG - 2016-08-01 21:09:13 --> Config Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:09:13 --> URI Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Router Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Output Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Security Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Input Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:09:13 --> Language Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Loader Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:09:13 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Session Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:09:13 --> Session routines successfully run
DEBUG - 2016-08-01 21:09:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Controller Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:09:13 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:09:13 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:09:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:09:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:09:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:09:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:09:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:09:13 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:09:13 --> Final output sent to browser
DEBUG - 2016-08-01 21:09:13 --> Total execution time: 0.2011
DEBUG - 2016-08-01 21:09:14 --> Config Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:09:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:09:14 --> URI Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Router Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Output Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Security Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Input Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:09:14 --> Language Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Loader Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:09:14 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Session Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:09:14 --> Session routines successfully run
DEBUG - 2016-08-01 21:09:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Controller Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:09:14 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:09:14 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:09:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:09:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:09:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:09:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:09:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:09:14 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-08-01 21:09:14 --> Final output sent to browser
DEBUG - 2016-08-01 21:09:14 --> Total execution time: 0.1956
DEBUG - 2016-08-01 21:09:15 --> Config Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:09:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:09:15 --> URI Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Router Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Output Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Security Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Input Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:09:15 --> Language Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Loader Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:09:15 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Session Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:09:15 --> Session routines successfully run
DEBUG - 2016-08-01 21:09:15 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Controller Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Model Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:09:15 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:09:15 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:09:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:09:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:09:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:09:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:09:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:09:15 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:09:15 --> Final output sent to browser
DEBUG - 2016-08-01 21:09:15 --> Total execution time: 0.2105
DEBUG - 2016-08-01 21:10:18 --> Config Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:10:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:10:18 --> URI Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Router Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Output Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Security Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Input Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:10:18 --> Language Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Loader Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:10:18 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Session Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:10:18 --> Session routines successfully run
DEBUG - 2016-08-01 21:10:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Controller Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:10:18 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:10:18 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:10:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:10:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:10:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:10:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:10:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:10:18 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:10:18 --> Final output sent to browser
DEBUG - 2016-08-01 21:10:18 --> Total execution time: 0.2143
DEBUG - 2016-08-01 21:10:45 --> Config Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:10:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:10:45 --> URI Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Router Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Output Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Security Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Input Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:10:45 --> Language Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Loader Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:10:45 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Session Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:10:45 --> Session routines successfully run
DEBUG - 2016-08-01 21:10:45 --> Model Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Model Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Controller Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Model Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:10:45 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:10:45 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:10:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:10:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:10:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:10:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:10:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:10:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:10:45 --> Final output sent to browser
DEBUG - 2016-08-01 21:10:45 --> Total execution time: 0.1932
DEBUG - 2016-08-01 21:11:20 --> Config Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:11:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:11:20 --> URI Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Router Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Output Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Security Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Input Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:11:20 --> Language Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Loader Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:11:20 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Session Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:11:20 --> Session routines successfully run
DEBUG - 2016-08-01 21:11:20 --> Model Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Model Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Controller Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Model Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:11:20 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:11:20 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:11:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:11:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:11:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:11:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:11:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:11:20 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:11:20 --> Final output sent to browser
DEBUG - 2016-08-01 21:11:20 --> Total execution time: 0.1948
DEBUG - 2016-08-01 21:11:24 --> Config Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:11:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:11:24 --> URI Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Router Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Output Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Security Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Input Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:11:24 --> Language Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Loader Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:11:24 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Session Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:11:24 --> Session routines successfully run
DEBUG - 2016-08-01 21:11:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Controller Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:11:24 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:11:24 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:11:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:11:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:11:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:11:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:11:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:11:24 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:11:24 --> Final output sent to browser
DEBUG - 2016-08-01 21:11:24 --> Total execution time: 0.2203
DEBUG - 2016-08-01 21:18:54 --> Config Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:18:54 --> URI Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Router Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Output Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Security Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Input Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:18:54 --> Language Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Loader Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:18:54 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Session Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:18:54 --> Session routines successfully run
DEBUG - 2016-08-01 21:18:54 --> Model Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Model Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Controller Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Model Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:18:54 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:18:54 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:18:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:18:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:18:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:18:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:18:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:18:55 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:18:55 --> Final output sent to browser
DEBUG - 2016-08-01 21:18:55 --> Total execution time: 0.2073
DEBUG - 2016-08-01 21:19:23 --> Config Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:19:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:19:23 --> URI Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Router Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Output Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Security Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Input Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:19:23 --> Language Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Loader Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:19:23 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Session Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:19:23 --> Session routines successfully run
DEBUG - 2016-08-01 21:19:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Controller Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:19:23 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:19:23 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:19:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:19:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:19:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:19:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:19:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:19:23 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-08-01 21:19:23 --> Final output sent to browser
DEBUG - 2016-08-01 21:19:23 --> Total execution time: 0.1987
DEBUG - 2016-08-01 21:19:33 --> Config Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:19:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:19:33 --> URI Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Router Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Output Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Security Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Input Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:19:33 --> Language Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Loader Class Initialized
DEBUG - 2016-08-01 21:19:33 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:19:33 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Session Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:19:34 --> Session routines successfully run
DEBUG - 2016-08-01 21:19:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Controller Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:19:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-01 21:19:34 --> Config Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:19:34 --> URI Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Router Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Output Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Security Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Input Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:19:34 --> Language Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Loader Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:19:34 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Session Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:19:34 --> Session routines successfully run
DEBUG - 2016-08-01 21:19:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Controller Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:19:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:19:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:19:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:19:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:19:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:19:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:19:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:19:34 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:19:34 --> Final output sent to browser
DEBUG - 2016-08-01 21:19:34 --> Total execution time: 0.2292
DEBUG - 2016-08-01 21:19:46 --> Config Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:19:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:19:46 --> URI Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Router Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Output Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Security Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Input Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:19:46 --> Language Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Loader Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:19:46 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Session Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:19:46 --> Session routines successfully run
DEBUG - 2016-08-01 21:19:46 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Controller Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Model Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:19:46 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:19:46 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:19:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:19:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:19:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:19:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:19:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:19:46 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:19:46 --> Final output sent to browser
DEBUG - 2016-08-01 21:19:46 --> Total execution time: 0.1950
DEBUG - 2016-08-01 21:20:08 --> Config Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:20:08 --> URI Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Router Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Output Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Security Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Input Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:20:08 --> Language Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Loader Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:20:08 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Session Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:20:08 --> Session routines successfully run
DEBUG - 2016-08-01 21:20:08 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Controller Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:20:08 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:20:08 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:20:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:20:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:20:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:20:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:20:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:20:08 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:20:08 --> Final output sent to browser
DEBUG - 2016-08-01 21:20:09 --> Total execution time: 0.2520
DEBUG - 2016-08-01 21:20:12 --> Config Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:20:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:20:12 --> URI Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Router Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Output Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Security Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Input Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:20:12 --> Language Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Loader Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:20:12 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Session Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:20:12 --> Session routines successfully run
DEBUG - 2016-08-01 21:20:12 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Controller Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:20:12 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:20:12 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:20:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:20:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:20:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:20:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:20:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:20:12 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:20:12 --> Final output sent to browser
DEBUG - 2016-08-01 21:20:12 --> Total execution time: 0.2041
DEBUG - 2016-08-01 21:20:13 --> Config Class Initialized
DEBUG - 2016-08-01 21:20:13 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:20:13 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:20:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:20:14 --> URI Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Router Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Output Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Security Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Input Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:20:14 --> Language Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Loader Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:20:14 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Session Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:20:14 --> Session routines successfully run
DEBUG - 2016-08-01 21:20:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Controller Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:20:14 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:20:14 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:20:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:20:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:20:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:20:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:20:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:20:14 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:20:14 --> Final output sent to browser
DEBUG - 2016-08-01 21:20:14 --> Total execution time: 0.1973
DEBUG - 2016-08-01 21:20:19 --> Config Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:20:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:20:19 --> URI Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Router Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Output Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Security Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Input Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:20:19 --> Language Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Loader Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:20:19 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Session Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:20:19 --> Session routines successfully run
DEBUG - 2016-08-01 21:20:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Controller Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:20:19 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:20:19 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:20:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:20:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:20:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:20:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:20:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:20:20 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:20:20 --> Final output sent to browser
DEBUG - 2016-08-01 21:20:20 --> Total execution time: 0.2125
DEBUG - 2016-08-01 21:20:49 --> Config Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:20:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:20:49 --> URI Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Router Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Output Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Security Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Input Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:20:49 --> Language Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Loader Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:20:49 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Session Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:20:49 --> Session routines successfully run
DEBUG - 2016-08-01 21:20:49 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Controller Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:20:49 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:20:49 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:20:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:20:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:20:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:20:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:20:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:20:49 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:20:49 --> Final output sent to browser
DEBUG - 2016-08-01 21:20:49 --> Total execution time: 0.2150
DEBUG - 2016-08-01 21:20:50 --> Config Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:20:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:20:50 --> URI Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Router Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Output Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Security Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Input Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:20:50 --> Language Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Loader Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:20:50 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Session Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:20:50 --> Session routines successfully run
DEBUG - 2016-08-01 21:20:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Controller Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:20:50 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:20:50 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:20:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:20:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:20:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:20:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:20:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:20:50 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:20:50 --> Final output sent to browser
DEBUG - 2016-08-01 21:20:50 --> Total execution time: 0.1966
DEBUG - 2016-08-01 21:24:50 --> Config Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:24:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:24:50 --> URI Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Router Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Output Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Security Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Input Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:24:50 --> Language Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Loader Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:24:50 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Session Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:24:50 --> Session routines successfully run
DEBUG - 2016-08-01 21:24:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Controller Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Model Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:24:50 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:24:50 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:24:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:24:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:24:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:24:50 --> File loaded: application/views/sidebar.php
ERROR - 2016-08-01 21:24:50 --> Severity: Notice  --> Undefined variable: directors D:\xampp\htdocs\asmc\application\views\manager\managerListView.php 73
DEBUG - 2016-08-01 21:24:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:24:50 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:24:50 --> Final output sent to browser
DEBUG - 2016-08-01 21:24:50 --> Total execution time: 0.2293
DEBUG - 2016-08-01 21:25:00 --> Config Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:25:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:25:00 --> URI Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Router Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Output Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Security Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Input Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:25:00 --> Language Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Loader Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:25:00 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Session Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:25:00 --> Session routines successfully run
DEBUG - 2016-08-01 21:25:00 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Controller Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:25:00 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:25:00 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:25:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:25:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:25:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:25:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:25:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:25:01 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:25:01 --> Final output sent to browser
DEBUG - 2016-08-01 21:25:01 --> Total execution time: 0.2109
DEBUG - 2016-08-01 21:25:30 --> Config Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:25:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:25:30 --> URI Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Router Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Output Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Security Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Input Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:25:30 --> Language Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Loader Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:25:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Session Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:25:30 --> Session routines successfully run
DEBUG - 2016-08-01 21:25:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Controller Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:25:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:25:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:25:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:25:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:25:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:25:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:25:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:25:31 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:25:31 --> Final output sent to browser
DEBUG - 2016-08-01 21:25:31 --> Total execution time: 0.2111
DEBUG - 2016-08-01 21:25:42 --> Config Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:25:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:25:42 --> URI Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Router Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Output Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Security Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Input Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:25:42 --> Language Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Loader Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:25:42 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Session Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:25:42 --> Session routines successfully run
DEBUG - 2016-08-01 21:25:42 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Controller Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:25:42 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:25:42 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:25:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:25:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:25:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:25:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:25:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:25:42 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:25:42 --> Final output sent to browser
DEBUG - 2016-08-01 21:25:42 --> Total execution time: 0.2007
DEBUG - 2016-08-01 21:25:44 --> Config Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:25:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:25:44 --> URI Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Router Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Output Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Security Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Input Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:25:44 --> Language Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Loader Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:25:44 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Session Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:25:44 --> Session routines successfully run
DEBUG - 2016-08-01 21:25:44 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Controller Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:25:44 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:25:44 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:25:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:25:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:25:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:25:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:25:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:25:44 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:25:44 --> Final output sent to browser
DEBUG - 2016-08-01 21:25:44 --> Total execution time: 0.2041
DEBUG - 2016-08-01 21:25:47 --> Config Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:25:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:25:47 --> URI Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Router Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Output Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Security Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Input Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:25:47 --> Language Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Loader Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:25:47 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Session Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:25:47 --> Session routines successfully run
DEBUG - 2016-08-01 21:25:47 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Controller Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:25:47 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:25:47 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:25:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:25:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:25:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:25:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:25:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:25:47 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:25:47 --> Final output sent to browser
DEBUG - 2016-08-01 21:25:47 --> Total execution time: 0.2066
DEBUG - 2016-08-01 21:25:51 --> Config Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:25:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:25:51 --> URI Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Router Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Output Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Security Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Input Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:25:51 --> Language Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Loader Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:25:51 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Session Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:25:51 --> Session routines successfully run
DEBUG - 2016-08-01 21:25:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Controller Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:25:51 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:25:51 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:25:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:25:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:25:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:25:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:25:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:25:51 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:25:51 --> Final output sent to browser
DEBUG - 2016-08-01 21:25:51 --> Total execution time: 0.2047
DEBUG - 2016-08-01 21:26:11 --> Config Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:26:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:26:11 --> URI Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Router Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Output Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Security Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Input Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:26:11 --> Language Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Loader Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:26:11 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Session Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:26:11 --> Session routines successfully run
DEBUG - 2016-08-01 21:26:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Controller Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:26:11 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:26:11 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:26:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:26:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:26:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:26:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:26:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:26:11 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:26:11 --> Final output sent to browser
DEBUG - 2016-08-01 21:26:11 --> Total execution time: 0.2141
DEBUG - 2016-08-01 21:26:27 --> Config Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:26:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:26:27 --> URI Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Router Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Output Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Security Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Input Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:26:27 --> Language Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Loader Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:26:27 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Session Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:26:27 --> Session routines successfully run
DEBUG - 2016-08-01 21:26:27 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Controller Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:26:27 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:26:27 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:26:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:26:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:26:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:26:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:26:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:26:27 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:26:27 --> Final output sent to browser
DEBUG - 2016-08-01 21:26:27 --> Total execution time: 0.2183
DEBUG - 2016-08-01 21:26:29 --> Config Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:26:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:26:29 --> URI Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Router Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Output Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Security Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Input Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:26:29 --> Language Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Loader Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:26:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Session Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:26:29 --> Session routines successfully run
DEBUG - 2016-08-01 21:26:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Controller Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:26:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:26:29 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:26:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:26:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:26:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:26:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:26:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:26:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 21:26:30 --> Final output sent to browser
DEBUG - 2016-08-01 21:26:30 --> Total execution time: 0.2109
DEBUG - 2016-08-01 21:26:33 --> Config Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:26:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:26:33 --> URI Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Router Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Output Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Security Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Input Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:26:33 --> Language Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Loader Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:26:33 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Session Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:26:33 --> Session routines successfully run
DEBUG - 2016-08-01 21:26:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:33 --> Controller Class Initialized
DEBUG - 2016-08-01 21:26:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:26:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:26:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:26:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:26:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:26:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:26:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:26:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:26:34 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:26:34 --> Final output sent to browser
DEBUG - 2016-08-01 21:26:34 --> Total execution time: 0.2185
DEBUG - 2016-08-01 21:26:36 --> Config Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:26:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:26:36 --> URI Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Router Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Output Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Security Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Input Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:26:36 --> Language Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Loader Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:26:36 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Session Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:26:36 --> Session routines successfully run
DEBUG - 2016-08-01 21:26:36 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Controller Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Model Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:26:36 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:26:36 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:26:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:26:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:26:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:26:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:26:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:26:36 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:26:36 --> Final output sent to browser
DEBUG - 2016-08-01 21:26:36 --> Total execution time: 0.2337
DEBUG - 2016-08-01 21:27:24 --> Config Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:27:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:27:24 --> URI Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Router Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Output Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Security Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Input Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:27:24 --> Language Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Loader Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:27:24 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Session Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:27:24 --> Session routines successfully run
DEBUG - 2016-08-01 21:27:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Controller Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:27:24 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:27:24 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:27:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:27:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:27:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:27:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:27:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:27:24 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2016-08-01 21:27:24 --> Final output sent to browser
DEBUG - 2016-08-01 21:27:24 --> Total execution time: 0.3049
DEBUG - 2016-08-01 21:27:25 --> Config Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:27:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:27:25 --> URI Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Router Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Output Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Security Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Input Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:27:25 --> Language Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Loader Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:27:25 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Session Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:27:25 --> Session routines successfully run
DEBUG - 2016-08-01 21:27:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Controller Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:27:25 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:27:25 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:27:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:27:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:27:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:27:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:27:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:27:25 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:27:25 --> Final output sent to browser
DEBUG - 2016-08-01 21:27:25 --> Total execution time: 0.2564
DEBUG - 2016-08-01 21:27:58 --> Config Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:27:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:27:58 --> URI Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Router Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Output Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Security Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Input Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:27:58 --> Language Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Loader Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:27:58 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Session Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:27:58 --> Session routines successfully run
DEBUG - 2016-08-01 21:27:58 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Controller Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Model Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:27:58 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:27:58 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:27:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:27:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:27:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:27:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:27:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:27:58 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:27:58 --> Final output sent to browser
DEBUG - 2016-08-01 21:27:58 --> Total execution time: 0.2165
DEBUG - 2016-08-01 21:28:03 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:03 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:03 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:03 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:03 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:03 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:03 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:03 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:28:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:03 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 21:28:03 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:03 --> Total execution time: 0.2208
DEBUG - 2016-08-01 21:28:14 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:14 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:14 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:14 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:14 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:14 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:14 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:28:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:14 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 21:28:14 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:14 --> Total execution time: 0.2318
DEBUG - 2016-08-01 21:28:19 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:19 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:19 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:19 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:19 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:19 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:19 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:19 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-01 21:28:19 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:19 --> Total execution time: 0.3622
DEBUG - 2016-08-01 21:28:22 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:22 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:22 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:22 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:22 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:22 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:22 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:22 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2016-08-01 21:28:22 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:22 --> Total execution time: 0.2511
DEBUG - 2016-08-01 21:28:23 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:23 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:23 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:23 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:23 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:23 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:23 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:23 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-08-01 21:28:23 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:23 --> Total execution time: 0.2691
DEBUG - 2016-08-01 21:28:25 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:25 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:25 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:25 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:25 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:25 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:25 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:28:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-01 21:28:25 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:25 --> Total execution time: 0.8052
DEBUG - 2016-08-01 21:28:30 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:30 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:30 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:30 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:30 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:30 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:30 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:31 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:31 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:31 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:31 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:31 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-01 21:28:31 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:31 --> Total execution time: 0.3730
DEBUG - 2016-08-01 21:28:34 --> Config Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:28:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:28:34 --> URI Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Router Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Output Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Security Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Input Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:28:34 --> Language Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Loader Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:28:34 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Session Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:28:34 --> Session routines successfully run
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Controller Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:28:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:28:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:28:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:28:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:28:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:28:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:28:35 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-01 21:28:35 --> Final output sent to browser
DEBUG - 2016-08-01 21:28:35 --> Total execution time: 0.4136
DEBUG - 2016-08-01 21:34:33 --> Config Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:34:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:34:33 --> URI Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Router Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Output Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Security Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Input Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:34:33 --> Language Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Loader Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:34:33 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Session Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:34:33 --> Session routines successfully run
DEBUG - 2016-08-01 21:34:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Controller Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:34:33 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:34:33 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:34:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:34:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:34:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:34:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:34:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:34:33 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:34:33 --> Final output sent to browser
DEBUG - 2016-08-01 21:34:33 --> Total execution time: 0.2381
DEBUG - 2016-08-01 21:34:50 --> Config Class Initialized
DEBUG - 2016-08-01 21:34:50 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:34:50 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:34:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:34:50 --> URI Class Initialized
DEBUG - 2016-08-01 21:34:50 --> Router Class Initialized
DEBUG - 2016-08-01 21:34:50 --> Output Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Security Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Input Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:34:51 --> Language Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Loader Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:34:51 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Session Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:34:51 --> Session routines successfully run
DEBUG - 2016-08-01 21:34:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Controller Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:34:51 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:34:51 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:34:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:34:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:34:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:34:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:34:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:34:51 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:34:51 --> Final output sent to browser
DEBUG - 2016-08-01 21:34:51 --> Total execution time: 0.2245
DEBUG - 2016-08-01 21:34:52 --> Config Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:34:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:34:53 --> URI Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Router Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Output Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Security Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Input Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:34:53 --> Language Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Loader Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:34:53 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Session Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:34:53 --> Session routines successfully run
DEBUG - 2016-08-01 21:34:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Controller Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:34:53 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:34:53 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:34:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:34:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:34:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:34:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:34:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:34:53 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:34:53 --> Final output sent to browser
DEBUG - 2016-08-01 21:34:53 --> Total execution time: 0.2243
DEBUG - 2016-08-01 21:35:29 --> Config Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:35:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:35:29 --> URI Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Router Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Output Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Security Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Input Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:35:29 --> Language Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Loader Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:35:29 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Session Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:35:29 --> Session routines successfully run
DEBUG - 2016-08-01 21:35:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Controller Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:35:29 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:35:29 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:35:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:35:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:35:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:35:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:35:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:35:29 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:35:29 --> Final output sent to browser
DEBUG - 2016-08-01 21:35:29 --> Total execution time: 0.2220
DEBUG - 2016-08-01 21:35:34 --> Config Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:35:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:35:34 --> URI Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Router Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Output Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Security Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Input Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:35:34 --> Language Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Loader Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:35:34 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Session Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:35:34 --> Session routines successfully run
DEBUG - 2016-08-01 21:35:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Controller Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Model Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:35:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:35:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:35:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:35:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:35:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:35:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:35:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:35:34 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:35:34 --> Final output sent to browser
DEBUG - 2016-08-01 21:35:34 --> Total execution time: 0.2529
DEBUG - 2016-08-01 21:36:13 --> Config Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:36:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:36:13 --> URI Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Router Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Output Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Security Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Input Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:36:13 --> Language Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Loader Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:36:13 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Session Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:36:13 --> Session routines successfully run
DEBUG - 2016-08-01 21:36:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Controller Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:36:13 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:36:13 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:36:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:36:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:36:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:36:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:36:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:36:13 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:36:13 --> Final output sent to browser
DEBUG - 2016-08-01 21:36:13 --> Total execution time: 0.2348
DEBUG - 2016-08-01 21:36:17 --> Config Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:36:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:36:17 --> URI Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Router Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Output Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Security Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Input Class Initialized
DEBUG - 2016-08-01 21:36:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:36:17 --> Language Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Loader Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:36:18 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Session Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:36:18 --> Session routines successfully run
DEBUG - 2016-08-01 21:36:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Controller Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:36:18 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:36:18 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:36:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:36:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:36:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:36:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:36:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:36:18 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-01 21:36:18 --> Final output sent to browser
DEBUG - 2016-08-01 21:36:18 --> Total execution time: 0.2361
DEBUG - 2016-08-01 21:38:18 --> Config Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:38:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:38:18 --> URI Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Router Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Output Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Security Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Input Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:38:18 --> Language Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Loader Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:38:18 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Session Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:38:18 --> Session routines successfully run
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Controller Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:38:18 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> Model Class Initialized
DEBUG - 2016-08-01 21:38:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:38:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:38:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:38:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:38:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:38:18 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-01 21:38:18 --> Final output sent to browser
DEBUG - 2016-08-01 21:38:18 --> Total execution time: 0.3241
DEBUG - 2016-08-01 21:52:06 --> Config Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:52:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:52:06 --> URI Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Router Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Output Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Security Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Input Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:52:06 --> Language Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Loader Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:52:06 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Session Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:52:06 --> Session routines successfully run
DEBUG - 2016-08-01 21:52:06 --> Model Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Model Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Controller Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Model Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:52:06 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:52:06 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:52:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:52:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:52:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:52:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:52:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:52:06 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:52:06 --> Final output sent to browser
DEBUG - 2016-08-01 21:52:06 --> Total execution time: 0.2880
DEBUG - 2016-08-01 21:53:03 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:03 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Output Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Security Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Input Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:53:03 --> Language Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Loader Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:53:03 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Session Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:53:03 --> Session routines successfully run
DEBUG - 2016-08-01 21:53:03 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Controller Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:53:03 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:53:03 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:53:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:53:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:53:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:53:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:53:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:53:03 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:53:03 --> Final output sent to browser
DEBUG - 2016-08-01 21:53:03 --> Total execution time: 0.2550
DEBUG - 2016-08-01 21:53:21 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:21 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Output Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Security Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Input Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:53:21 --> Language Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Loader Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:53:21 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Session Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:53:21 --> Session routines successfully run
DEBUG - 2016-08-01 21:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Controller Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:53:21 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:53:21 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:53:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:53:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:53:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:53:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:53:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:53:22 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:53:22 --> Final output sent to browser
DEBUG - 2016-08-01 21:53:22 --> Total execution time: 0.2427
DEBUG - 2016-08-01 21:53:22 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:22 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:22 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:22 --> Router Class Initialized
ERROR - 2016-08-01 21:53:22 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:53:22 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:53:36 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:36 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:36 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:37 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Output Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Security Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Input Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:53:37 --> Language Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Loader Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:53:37 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Session Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:53:37 --> Session routines successfully run
DEBUG - 2016-08-01 21:53:37 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Controller Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:53:37 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:53:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:53:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:53:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:53:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:53:37 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:53:37 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:53:37 --> Final output sent to browser
DEBUG - 2016-08-01 21:53:37 --> Total execution time: 0.2457
DEBUG - 2016-08-01 21:53:37 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:37 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:37 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:37 --> Router Class Initialized
ERROR - 2016-08-01 21:53:37 --> 404 Page Not Found --> js
ERROR - 2016-08-01 21:53:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:53:53 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:53 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Output Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Security Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Input Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:53:53 --> Language Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Loader Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:53:53 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Session Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:53:53 --> Session routines successfully run
DEBUG - 2016-08-01 21:53:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Controller Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Model Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:53:53 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:53:53 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:53:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:53:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:53:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:53:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:53:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:53:53 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:53:53 --> Final output sent to browser
DEBUG - 2016-08-01 21:53:53 --> Total execution time: 0.2409
DEBUG - 2016-08-01 21:53:54 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Config Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:53:54 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:54 --> URI Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Router Class Initialized
DEBUG - 2016-08-01 21:53:54 --> Router Class Initialized
ERROR - 2016-08-01 21:53:54 --> 404 Page Not Found --> js
ERROR - 2016-08-01 21:53:54 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:54:01 --> Config Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:54:01 --> URI Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Router Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Output Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Security Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Input Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:54:01 --> Language Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Loader Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:54:01 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:54:01 --> Session Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:54:02 --> Session routines successfully run
DEBUG - 2016-08-01 21:54:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Controller Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:54:02 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:54:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:54:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:54:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:54:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:54:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:54:02 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:54:02 --> Final output sent to browser
DEBUG - 2016-08-01 21:54:02 --> Total execution time: 0.2524
DEBUG - 2016-08-01 21:54:02 --> Config Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Config Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:54:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:54:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:54:02 --> URI Class Initialized
DEBUG - 2016-08-01 21:54:02 --> URI Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Router Class Initialized
DEBUG - 2016-08-01 21:54:02 --> Router Class Initialized
ERROR - 2016-08-01 21:54:02 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:54:02 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:55:26 --> Config Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:55:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:55:26 --> URI Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Router Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Output Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Security Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Input Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:55:26 --> Language Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Loader Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:55:26 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Session Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:55:26 --> Session routines successfully run
DEBUG - 2016-08-01 21:55:26 --> Model Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Model Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Controller Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Model Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:55:26 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:55:26 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:55:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:55:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:55:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:55:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:55:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:55:26 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:55:26 --> Final output sent to browser
DEBUG - 2016-08-01 21:55:26 --> Total execution time: 0.2624
DEBUG - 2016-08-01 21:55:27 --> Config Class Initialized
DEBUG - 2016-08-01 21:55:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:55:27 --> Config Class Initialized
DEBUG - 2016-08-01 21:55:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:55:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:55:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:55:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:55:27 --> URI Class Initialized
DEBUG - 2016-08-01 21:55:27 --> Router Class Initialized
DEBUG - 2016-08-01 21:55:27 --> URI Class Initialized
DEBUG - 2016-08-01 21:55:27 --> Router Class Initialized
ERROR - 2016-08-01 21:55:27 --> 404 Page Not Found --> js
ERROR - 2016-08-01 21:55:27 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 21:57:20 --> Config Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:57:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:57:20 --> URI Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Router Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Output Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Security Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Input Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:57:20 --> Language Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Loader Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:57:20 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Session Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:57:20 --> Session routines successfully run
DEBUG - 2016-08-01 21:57:20 --> Model Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Model Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Controller Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Model Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:57:20 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:57:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:57:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:57:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:57:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:57:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:57:20 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:57:20 --> Final output sent to browser
DEBUG - 2016-08-01 21:57:20 --> Total execution time: 0.2648
DEBUG - 2016-08-01 21:57:20 --> Config Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Config Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:57:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:57:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:57:20 --> URI Class Initialized
DEBUG - 2016-08-01 21:57:20 --> URI Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Router Class Initialized
DEBUG - 2016-08-01 21:57:20 --> Router Class Initialized
ERROR - 2016-08-01 21:57:20 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:57:20 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:57:43 --> Config Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:57:43 --> URI Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Router Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Output Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Security Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Input Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:57:43 --> Language Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Loader Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:57:43 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Session Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:57:43 --> Session routines successfully run
DEBUG - 2016-08-01 21:57:43 --> Model Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Model Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Controller Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Model Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:57:43 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:57:43 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:57:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:57:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:57:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:57:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:57:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:57:44 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:57:44 --> Final output sent to browser
DEBUG - 2016-08-01 21:57:44 --> Total execution time: 0.2624
DEBUG - 2016-08-01 21:57:44 --> Config Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Config Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:57:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:57:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:57:44 --> URI Class Initialized
DEBUG - 2016-08-01 21:57:44 --> URI Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Router Class Initialized
DEBUG - 2016-08-01 21:57:44 --> Router Class Initialized
ERROR - 2016-08-01 21:57:44 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:57:44 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:59:02 --> Config Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:59:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:59:02 --> URI Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Router Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Output Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Security Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Input Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:59:02 --> Language Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Loader Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:59:02 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Session Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:59:02 --> Session routines successfully run
DEBUG - 2016-08-01 21:59:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Controller Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Model Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:59:02 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:59:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:59:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:59:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:59:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:59:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:59:02 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:59:02 --> Final output sent to browser
DEBUG - 2016-08-01 21:59:02 --> Total execution time: 0.2604
DEBUG - 2016-08-01 21:59:02 --> Config Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Config Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:59:02 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:59:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:59:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:59:03 --> URI Class Initialized
DEBUG - 2016-08-01 21:59:03 --> URI Class Initialized
DEBUG - 2016-08-01 21:59:03 --> Router Class Initialized
DEBUG - 2016-08-01 21:59:03 --> Router Class Initialized
ERROR - 2016-08-01 21:59:03 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:59:03 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 21:59:26 --> Config Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:59:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:59:26 --> URI Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Router Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Output Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Security Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Input Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 21:59:26 --> Language Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Loader Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Helper loaded: url_helper
DEBUG - 2016-08-01 21:59:26 --> Database Driver Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Session Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Helper loaded: string_helper
DEBUG - 2016-08-01 21:59:26 --> Session routines successfully run
DEBUG - 2016-08-01 21:59:26 --> Model Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Model Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Controller Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Model Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Helper loaded: form_helper
DEBUG - 2016-08-01 21:59:26 --> Form Validation Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Pagination Class Initialized
DEBUG - 2016-08-01 21:59:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 21:59:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 21:59:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 21:59:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 21:59:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 21:59:26 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 21:59:26 --> Final output sent to browser
DEBUG - 2016-08-01 21:59:26 --> Total execution time: 0.2942
DEBUG - 2016-08-01 21:59:26 --> Config Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Config Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:59:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 21:59:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:59:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 21:59:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:59:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 21:59:27 --> URI Class Initialized
DEBUG - 2016-08-01 21:59:27 --> URI Class Initialized
DEBUG - 2016-08-01 21:59:27 --> Router Class Initialized
DEBUG - 2016-08-01 21:59:27 --> Router Class Initialized
ERROR - 2016-08-01 21:59:27 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 21:59:27 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:00:01 --> Config Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:00:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:00:01 --> URI Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Router Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Output Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Security Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Input Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:00:01 --> Language Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Loader Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:00:01 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Session Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:00:01 --> Session routines successfully run
DEBUG - 2016-08-01 22:00:01 --> Model Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Model Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Controller Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Model Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:00:01 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:00:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:00:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:00:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:00:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:00:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:00:01 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:00:01 --> Final output sent to browser
DEBUG - 2016-08-01 22:00:01 --> Total execution time: 0.2469
DEBUG - 2016-08-01 22:00:01 --> Config Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Config Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:00:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:00:01 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:00:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:00:01 --> URI Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Router Class Initialized
DEBUG - 2016-08-01 22:00:01 --> URI Class Initialized
DEBUG - 2016-08-01 22:00:01 --> Router Class Initialized
ERROR - 2016-08-01 22:00:01 --> 404 Page Not Found --> js
ERROR - 2016-08-01 22:00:01 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:00:48 --> Config Class Initialized
DEBUG - 2016-08-01 22:00:48 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:00:48 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:00:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:00:49 --> URI Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Router Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Output Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Security Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Input Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:00:49 --> Language Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Loader Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:00:49 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Session Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:00:49 --> Session routines successfully run
DEBUG - 2016-08-01 22:00:49 --> Model Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Model Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Controller Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Model Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:00:49 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:00:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:00:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:00:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:00:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:00:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:00:49 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:00:49 --> Final output sent to browser
DEBUG - 2016-08-01 22:00:49 --> Total execution time: 0.2400
DEBUG - 2016-08-01 22:00:49 --> Config Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Config Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:00:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:00:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:00:49 --> URI Class Initialized
DEBUG - 2016-08-01 22:00:49 --> URI Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Router Class Initialized
DEBUG - 2016-08-01 22:00:49 --> Router Class Initialized
ERROR - 2016-08-01 22:00:49 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 22:00:49 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:01:33 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:33 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Output Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Security Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Input Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:01:33 --> Language Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Loader Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:01:33 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Session Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:01:33 --> Session routines successfully run
DEBUG - 2016-08-01 22:01:33 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Controller Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:01:33 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:01:33 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:01:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:01:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:01:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:01:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:01:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:01:33 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:01:33 --> Final output sent to browser
DEBUG - 2016-08-01 22:01:33 --> Total execution time: 0.2767
DEBUG - 2016-08-01 22:01:34 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:34 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:34 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:34 --> Router Class Initialized
ERROR - 2016-08-01 22:01:34 --> 404 Page Not Found --> js
ERROR - 2016-08-01 22:01:34 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:01:41 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:41 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Output Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Security Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Input Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:01:41 --> Language Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Loader Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:01:41 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Session Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:01:41 --> Session routines successfully run
DEBUG - 2016-08-01 22:01:41 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Controller Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:01:41 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:01:41 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:01:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:01:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:01:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:01:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:01:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:01:41 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:01:41 --> Final output sent to browser
DEBUG - 2016-08-01 22:01:41 --> Total execution time: 0.2771
DEBUG - 2016-08-01 22:01:42 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:42 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:42 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:42 --> Router Class Initialized
ERROR - 2016-08-01 22:01:42 --> 404 Page Not Found --> js
ERROR - 2016-08-01 22:01:42 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:01:47 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:47 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Output Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Security Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Input Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:01:47 --> Language Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Loader Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:01:47 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Session Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:01:47 --> Session routines successfully run
DEBUG - 2016-08-01 22:01:47 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Controller Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:01:47 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:01:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:01:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:01:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:01:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:01:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:01:47 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:01:47 --> Final output sent to browser
DEBUG - 2016-08-01 22:01:47 --> Total execution time: 0.2562
DEBUG - 2016-08-01 22:01:47 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:47 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:48 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:48 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:48 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:48 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:48 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:48 --> Router Class Initialized
ERROR - 2016-08-01 22:01:48 --> 404 Page Not Found --> js
ERROR - 2016-08-01 22:01:48 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:01:53 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:53 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Output Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Security Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Input Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:01:53 --> Language Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Loader Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:01:53 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Session Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:01:53 --> Session routines successfully run
DEBUG - 2016-08-01 22:01:53 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Controller Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Model Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:01:53 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:01:53 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:01:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:01:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:01:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:01:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:01:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:01:53 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:01:53 --> Final output sent to browser
DEBUG - 2016-08-01 22:01:53 --> Total execution time: 0.2545
DEBUG - 2016-08-01 22:01:54 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Config Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:01:54 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:54 --> URI Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Router Class Initialized
DEBUG - 2016-08-01 22:01:54 --> Router Class Initialized
ERROR - 2016-08-01 22:01:54 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 22:01:54 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:03:25 --> Config Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:03:25 --> URI Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Router Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Output Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Security Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Input Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:03:25 --> Language Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Loader Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:03:25 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Session Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:03:25 --> Session routines successfully run
DEBUG - 2016-08-01 22:03:25 --> Model Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Model Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Controller Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Model Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:03:25 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:03:25 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:03:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:03:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:03:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:03:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:03:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:03:25 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:03:25 --> Final output sent to browser
DEBUG - 2016-08-01 22:03:25 --> Total execution time: 0.2671
DEBUG - 2016-08-01 22:03:26 --> Config Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Config Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:03:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:03:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:03:26 --> URI Class Initialized
DEBUG - 2016-08-01 22:03:26 --> URI Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Router Class Initialized
DEBUG - 2016-08-01 22:03:26 --> Router Class Initialized
ERROR - 2016-08-01 22:03:26 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 22:03:26 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:03:38 --> Config Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:03:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:03:38 --> URI Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Router Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Output Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Security Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Input Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:03:38 --> Language Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Loader Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:03:38 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Session Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:03:38 --> Session routines successfully run
DEBUG - 2016-08-01 22:03:38 --> Model Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Model Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Controller Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Model Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:03:38 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:03:38 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:03:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:03:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:03:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:03:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:03:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:03:38 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:03:38 --> Final output sent to browser
DEBUG - 2016-08-01 22:03:38 --> Total execution time: 0.2595
DEBUG - 2016-08-01 22:03:39 --> Config Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Config Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:03:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:03:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:03:39 --> URI Class Initialized
DEBUG - 2016-08-01 22:03:39 --> URI Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Router Class Initialized
DEBUG - 2016-08-01 22:03:39 --> Router Class Initialized
ERROR - 2016-08-01 22:03:39 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 22:03:39 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:04:06 --> Config Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:04:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:04:06 --> URI Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Router Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Output Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Security Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Input Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:04:06 --> Language Class Initialized
DEBUG - 2016-08-01 22:04:06 --> Loader Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:04:07 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Session Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:04:07 --> Session routines successfully run
DEBUG - 2016-08-01 22:04:07 --> Model Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Model Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Controller Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Model Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:04:07 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:04:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:04:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:04:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:04:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:04:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:04:07 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:04:07 --> Final output sent to browser
DEBUG - 2016-08-01 22:04:07 --> Total execution time: 0.2601
DEBUG - 2016-08-01 22:04:07 --> Config Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Config Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:04:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:04:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:04:07 --> URI Class Initialized
DEBUG - 2016-08-01 22:04:07 --> URI Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Router Class Initialized
DEBUG - 2016-08-01 22:04:07 --> Router Class Initialized
ERROR - 2016-08-01 22:04:07 --> 404 Page Not Found --> js
ERROR - 2016-08-01 22:04:07 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:04:52 --> Config Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:04:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:04:52 --> URI Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Router Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Output Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Security Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Input Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:04:52 --> Language Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Loader Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:04:52 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Session Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:04:52 --> Session routines successfully run
DEBUG - 2016-08-01 22:04:52 --> Model Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Model Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Controller Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Model Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:04:52 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:04:52 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:04:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:04:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:04:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:04:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:04:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:04:52 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:04:52 --> Final output sent to browser
DEBUG - 2016-08-01 22:04:52 --> Total execution time: 0.2641
DEBUG - 2016-08-01 22:04:53 --> Config Class Initialized
DEBUG - 2016-08-01 22:04:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:04:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:04:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:04:53 --> Config Class Initialized
DEBUG - 2016-08-01 22:04:53 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:04:53 --> URI Class Initialized
DEBUG - 2016-08-01 22:04:53 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:04:53 --> Router Class Initialized
DEBUG - 2016-08-01 22:04:53 --> UTF-8 Support Enabled
ERROR - 2016-08-01 22:04:53 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:04:53 --> URI Class Initialized
DEBUG - 2016-08-01 22:04:53 --> Router Class Initialized
ERROR - 2016-08-01 22:04:53 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:05:04 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:04 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Output Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Security Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Input Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:05:04 --> Language Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Loader Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:05:04 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Session Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:05:04 --> Session routines successfully run
DEBUG - 2016-08-01 22:05:04 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Controller Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:05:04 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:05:04 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:05:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:05:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:05:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:05:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:05:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:05:04 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:05:04 --> Final output sent to browser
DEBUG - 2016-08-01 22:05:04 --> Total execution time: 0.2573
DEBUG - 2016-08-01 22:05:05 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:05 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:05 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:05 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:05 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:05 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:05 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:05 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:05 --> URI Class Initialized
ERROR - 2016-08-01 22:05:05 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:05:05 --> Router Class Initialized
ERROR - 2016-08-01 22:05:05 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:05:19 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:19 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Output Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Security Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Input Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:05:19 --> Language Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Loader Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:05:19 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Session Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:05:19 --> Session routines successfully run
DEBUG - 2016-08-01 22:05:19 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Controller Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:05:19 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:05:19 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:05:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:05:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:05:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:05:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:05:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:05:19 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:05:19 --> Final output sent to browser
DEBUG - 2016-08-01 22:05:19 --> Total execution time: 0.2580
DEBUG - 2016-08-01 22:05:20 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:20 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:20 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:20 --> Router Class Initialized
ERROR - 2016-08-01 22:05:20 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-01 22:05:20 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:05:40 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:40 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Output Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Security Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Input Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:05:40 --> Language Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Loader Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:05:40 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Session Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:05:40 --> Session routines successfully run
DEBUG - 2016-08-01 22:05:40 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Controller Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:05:40 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:05:40 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:05:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:05:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:05:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:05:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:05:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:05:40 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:05:40 --> Final output sent to browser
DEBUG - 2016-08-01 22:05:40 --> Total execution time: 0.2563
DEBUG - 2016-08-01 22:05:41 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:41 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:41 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:41 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:41 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:41 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:41 --> URI Class Initialized
ERROR - 2016-08-01 22:05:41 --> 404 Page Not Found --> js
DEBUG - 2016-08-01 22:05:41 --> Router Class Initialized
ERROR - 2016-08-01 22:05:41 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:05:48 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:48 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Output Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Security Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Input Class Initialized
DEBUG - 2016-08-01 22:05:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:05:48 --> Language Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Loader Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:05:49 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Session Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:05:49 --> Session routines successfully run
DEBUG - 2016-08-01 22:05:49 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Controller Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:05:49 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:05:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:05:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:05:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:05:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:05:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:05:49 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:05:49 --> Final output sent to browser
DEBUG - 2016-08-01 22:05:49 --> Total execution time: 0.2820
DEBUG - 2016-08-01 22:05:49 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:49 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:49 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:49 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:49 --> Router Class Initialized
ERROR - 2016-08-01 22:05:49 --> 404 Page Not Found --> js
ERROR - 2016-08-01 22:05:49 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-01 22:05:56 --> Config Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:05:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:05:56 --> URI Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Router Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Output Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Security Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Input Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:05:56 --> Language Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Loader Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:05:56 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Session Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:05:56 --> Session routines successfully run
DEBUG - 2016-08-01 22:05:56 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Controller Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Model Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:05:56 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:05:56 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:05:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:05:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:05:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:05:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:05:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:05:57 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:05:57 --> Final output sent to browser
DEBUG - 2016-08-01 22:05:57 --> Total execution time: 0.2654
DEBUG - 2016-08-01 22:12:55 --> Config Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:12:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:12:55 --> URI Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Router Class Initialized
DEBUG - 2016-08-01 22:12:55 --> No URI present. Default controller set.
DEBUG - 2016-08-01 22:12:55 --> Output Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Security Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Input Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:12:55 --> Language Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Loader Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:12:55 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Session Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:12:55 --> A session cookie was not found.
DEBUG - 2016-08-01 22:12:55 --> Session routines successfully run
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Controller Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Model Class Initialized
DEBUG - 2016-08-01 22:12:55 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:12:55 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:12:55 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-01 22:12:55 --> Final output sent to browser
DEBUG - 2016-08-01 22:12:55 --> Total execution time: 0.0460
DEBUG - 2016-08-01 22:13:03 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:03 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:03 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:03 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:03 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:03 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-01 22:13:03 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:03 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:03 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:03 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:03 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:03 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:03 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:04 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 22:13:04 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:04 --> Total execution time: 0.1160
DEBUG - 2016-08-01 22:13:07 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:07 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:07 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:07 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:07 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:07 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:07 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:07 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:08 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 22:13:08 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:08 --> Total execution time: 0.1470
DEBUG - 2016-08-01 22:13:12 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:12 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:12 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:12 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:12 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:12 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:12 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:12 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:12 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-01 22:13:12 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:12 --> Total execution time: 0.1110
DEBUG - 2016-08-01 22:13:17 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:17 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:17 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:17 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:17 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:17 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:17 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:17 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:17 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-01 22:13:17 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:17 --> Total execution time: 0.0610
DEBUG - 2016-08-01 22:13:27 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:27 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:27 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:27 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:27 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:27 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:27 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:28 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-01 22:13:28 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:28 --> Total execution time: 1.0551
DEBUG - 2016-08-01 22:13:34 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:34 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:34 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:34 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:34 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:34 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:34 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:13:34 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:34 --> Total execution time: 0.0930
DEBUG - 2016-08-01 22:13:39 --> Config Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:13:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:13:39 --> URI Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Router Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Output Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Security Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Input Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:13:39 --> Language Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Loader Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:13:39 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Session Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:13:39 --> Session routines successfully run
DEBUG - 2016-08-01 22:13:39 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Controller Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Model Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:13:39 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:13:39 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:13:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:13:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:13:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:13:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:13:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:13:39 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:13:39 --> Final output sent to browser
DEBUG - 2016-08-01 22:13:39 --> Total execution time: 0.1010
DEBUG - 2016-08-01 22:14:27 --> Config Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:14:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:14:27 --> URI Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Router Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Output Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Security Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Input Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:14:27 --> Language Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Loader Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:14:27 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Session Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:14:27 --> A session cookie was not found.
DEBUG - 2016-08-01 22:14:27 --> Session routines successfully run
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Controller Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Config Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:14:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:14:27 --> URI Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Router Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Output Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Security Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Input Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:14:27 --> Language Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Loader Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:14:27 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Session Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:14:27 --> Session routines successfully run
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Controller Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:27 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:14:27 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:14:27 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-01 22:14:27 --> Final output sent to browser
DEBUG - 2016-08-01 22:14:27 --> Total execution time: 0.0360
DEBUG - 2016-08-01 22:14:31 --> Config Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:14:31 --> URI Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Router Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Output Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Security Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Input Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:14:31 --> Language Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Loader Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:14:31 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Session Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:14:31 --> Session routines successfully run
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Controller Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:14:31 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-01 22:14:31 --> Config Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:14:31 --> URI Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Router Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Output Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Security Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Input Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:14:31 --> Language Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Loader Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:14:31 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Session Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:14:31 --> Session routines successfully run
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Controller Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:14:31 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:14:31 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:14:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:14:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:14:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:14:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:14:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:14:31 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-01 22:14:31 --> Final output sent to browser
DEBUG - 2016-08-01 22:14:31 --> Total execution time: 0.0630
DEBUG - 2016-08-01 22:14:34 --> Config Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:14:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:14:34 --> URI Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Router Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Output Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Security Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Input Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:14:34 --> Language Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Loader Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:14:34 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Session Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:14:34 --> Session routines successfully run
DEBUG - 2016-08-01 22:14:34 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Controller Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:14:34 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:14:34 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:14:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:14:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:14:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:14:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:14:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:14:34 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:14:34 --> Final output sent to browser
DEBUG - 2016-08-01 22:14:34 --> Total execution time: 0.0590
DEBUG - 2016-08-01 22:14:42 --> Config Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Hooks Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Utf8 Class Initialized
DEBUG - 2016-08-01 22:14:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-01 22:14:42 --> URI Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Router Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Output Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Security Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Input Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-01 22:14:42 --> Language Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Loader Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Helper loaded: url_helper
DEBUG - 2016-08-01 22:14:42 --> Database Driver Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Session Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Helper loaded: string_helper
DEBUG - 2016-08-01 22:14:42 --> Session routines successfully run
DEBUG - 2016-08-01 22:14:42 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Controller Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Model Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Helper loaded: form_helper
DEBUG - 2016-08-01 22:14:42 --> Form Validation Class Initialized
DEBUG - 2016-08-01 22:14:42 --> Pagination Class Initialized
DEBUG - 2016-08-01 22:14:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-01 22:14:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-01 22:14:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-01 22:14:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-01 22:14:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-01 22:14:42 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-01 22:14:42 --> Final output sent to browser
DEBUG - 2016-08-01 22:14:42 --> Total execution time: 0.0700
