<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-06-04 19:02:35 --> Config Class Initialized
DEBUG - 2015-06-04 19:02:35 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:02:35 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:02:35 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:02:36 --> URI Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Router Class Initialized
DEBUG - 2015-06-04 19:02:36 --> No URI present. Default controller set.
DEBUG - 2015-06-04 19:02:36 --> Output Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Security Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Input Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:02:36 --> Language Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Loader Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:02:36 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Session Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:02:36 --> A session cookie was not found.
DEBUG - 2015-06-04 19:02:36 --> Session routines successfully run
DEBUG - 2015-06-04 19:02:36 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Controller Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:36 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:02:36 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:02:36 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-04 19:02:36 --> Final output sent to browser
DEBUG - 2015-06-04 19:02:36 --> Total execution time: 0.1356
DEBUG - 2015-06-04 19:02:40 --> Config Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:02:40 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:02:40 --> URI Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Router Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Output Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Security Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Input Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:02:40 --> Language Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Loader Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:02:40 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Session Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:02:40 --> Session routines successfully run
DEBUG - 2015-06-04 19:02:40 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Controller Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:02:40 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:02:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-04 19:02:40 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-04 19:02:40 --> Final output sent to browser
DEBUG - 2015-06-04 19:02:40 --> Total execution time: 0.0798
DEBUG - 2015-06-04 19:02:51 --> Config Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:02:51 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:02:51 --> URI Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Router Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Output Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Security Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Input Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:02:51 --> Language Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Loader Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:02:51 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Session Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:02:51 --> Session routines successfully run
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Controller Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:02:51 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-04 19:02:51 --> Config Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:02:51 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:02:51 --> URI Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Router Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Output Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Security Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Input Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:02:51 --> Language Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Loader Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:02:51 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Session Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:02:51 --> Session routines successfully run
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Controller Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:02:51 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:02:51 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:02:51 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:02:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:02:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:02:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:02:51 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:02:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-06-04 19:02:51 --> Final output sent to browser
DEBUG - 2015-06-04 19:02:51 --> Total execution time: 0.0598
DEBUG - 2015-06-04 19:02:55 --> Config Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:02:55 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:02:55 --> URI Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Router Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Output Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Security Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Input Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:02:55 --> Language Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Loader Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:02:55 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Session Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:02:55 --> Session routines successfully run
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Controller Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:02:55 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:02:55 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:02:55 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:02:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:02:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:02:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:02:55 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:02:55 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-04 19:02:55 --> Final output sent to browser
DEBUG - 2015-06-04 19:02:55 --> Total execution time: 0.0946
DEBUG - 2015-06-04 19:02:58 --> Config Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:02:58 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:02:58 --> URI Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Router Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Output Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Security Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Input Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:02:58 --> Language Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Loader Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:02:58 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Session Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:02:58 --> Session routines successfully run
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Controller Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:02:58 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:02:58 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:02:58 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:02:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:02:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:02:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:02:58 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:02:58 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-04 19:02:58 --> Final output sent to browser
DEBUG - 2015-06-04 19:02:58 --> Total execution time: 0.0753
DEBUG - 2015-06-04 19:03:27 --> Config Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:03:27 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:03:27 --> URI Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Router Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Output Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Security Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Input Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:03:27 --> Language Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Loader Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:03:27 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Session Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:03:27 --> Session routines successfully run
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Controller Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:03:27 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:03:27 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Config Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:03:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:03:28 --> URI Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Router Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Output Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Security Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Input Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:03:28 --> Language Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Loader Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:03:28 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Session Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:03:28 --> Session routines successfully run
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Controller Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:03:28 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:03:28 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:03:28 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:03:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:03:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:03:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:03:28 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:03:28 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-04 19:03:28 --> Final output sent to browser
DEBUG - 2015-06-04 19:03:28 --> Total execution time: 0.0674
DEBUG - 2015-06-04 19:03:48 --> Config Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:03:48 --> URI Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Router Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Output Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Security Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Input Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:03:48 --> Language Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Loader Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:03:48 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Session Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:03:48 --> Session routines successfully run
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Controller Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:03:48 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Config Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:03:48 --> URI Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Router Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Output Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Security Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Input Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:03:48 --> Language Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Loader Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:03:48 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Session Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:03:48 --> Session routines successfully run
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Controller Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Model Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:03:48 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:03:48 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:03:48 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:03:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:03:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:03:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:03:48 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:03:48 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-04 19:03:48 --> Final output sent to browser
DEBUG - 2015-06-04 19:03:48 --> Total execution time: 0.0657
DEBUG - 2015-06-04 19:04:58 --> Config Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:04:58 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:04:58 --> URI Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Router Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Output Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Security Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Input Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:04:58 --> Language Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Loader Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:04:58 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Session Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:04:58 --> Session routines successfully run
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Controller Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Model Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:04:58 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:04:58 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:04:58 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:04:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:04:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:04:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:04:58 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:04:58 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-04 19:04:58 --> Final output sent to browser
DEBUG - 2015-06-04 19:04:58 --> Total execution time: 0.0927
DEBUG - 2015-06-04 19:05:12 --> Config Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:05:12 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:05:12 --> URI Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Router Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Output Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Security Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Input Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:05:12 --> Language Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Loader Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:05:12 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Session Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:05:12 --> Session routines successfully run
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Controller Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Model Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:05:12 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:05:12 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:05:12 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:05:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:05:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-04 19:05:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:05:12 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:05:12 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-04 19:05:12 --> Final output sent to browser
DEBUG - 2015-06-04 19:05:12 --> Total execution time: 0.0776
DEBUG - 2015-06-04 19:06:47 --> Config Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:06:47 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:06:47 --> URI Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Router Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Output Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Security Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Input Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:06:47 --> Language Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Loader Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:06:47 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Session Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:06:47 --> Session routines successfully run
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Controller Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:06:47 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Config Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:06:47 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:06:47 --> URI Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Router Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Output Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Security Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Input Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:06:47 --> Language Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Loader Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:06:47 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Session Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:06:47 --> Session routines successfully run
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Controller Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:47 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:06:47 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:06:47 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-04 19:06:47 --> Final output sent to browser
DEBUG - 2015-06-04 19:06:47 --> Total execution time: 0.0323
DEBUG - 2015-06-04 19:06:55 --> Config Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:06:55 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:06:55 --> URI Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Router Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Output Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Security Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Input Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:06:55 --> Language Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Loader Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:06:55 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Session Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:06:55 --> Session routines successfully run
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Controller Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:06:55 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-04 19:06:55 --> Config Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:06:55 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:06:55 --> URI Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Router Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Output Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Security Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Input Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:06:55 --> Language Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Loader Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:06:55 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Session Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:06:55 --> Session routines successfully run
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Controller Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:06:55 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:06:55 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:06:55 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:06:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:06:55 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-06-04 19:06:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:06:55 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:06:55 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-06-04 19:06:55 --> Final output sent to browser
DEBUG - 2015-06-04 19:06:55 --> Total execution time: 0.0452
DEBUG - 2015-06-04 19:06:57 --> Config Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:06:57 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:06:57 --> URI Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Router Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Output Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Security Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Input Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:06:57 --> Language Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Loader Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:06:57 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Session Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:06:57 --> Session routines successfully run
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Controller Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:06:57 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:06:57 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:06:57 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:06:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:06:57 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-06-04 19:06:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:06:57 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:06:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-04 19:06:57 --> Final output sent to browser
DEBUG - 2015-06-04 19:06:57 --> Total execution time: 0.0561
DEBUG - 2015-06-04 19:06:59 --> Config Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:06:59 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:06:59 --> URI Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Router Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Output Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Security Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Input Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:06:59 --> Language Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Loader Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:06:59 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Session Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:06:59 --> Session routines successfully run
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Controller Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Model Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:06:59 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:06:59 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:06:59 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:06:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:06:59 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-06-04 19:06:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:06:59 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:06:59 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-04 19:06:59 --> Final output sent to browser
DEBUG - 2015-06-04 19:06:59 --> Total execution time: 0.0633
DEBUG - 2015-06-04 19:07:49 --> Config Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Hooks Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Utf8 Class Initialized
DEBUG - 2015-06-04 19:07:49 --> UTF-8 Support Enabled
DEBUG - 2015-06-04 19:07:49 --> URI Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Router Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Output Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Security Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Input Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-04 19:07:49 --> Language Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Loader Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Helper loaded: url_helper
DEBUG - 2015-06-04 19:07:49 --> Database Driver Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Session Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Helper loaded: string_helper
DEBUG - 2015-06-04 19:07:49 --> Session routines successfully run
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Controller Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Model Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Helper loaded: form_helper
DEBUG - 2015-06-04 19:07:49 --> Form Validation Class Initialized
DEBUG - 2015-06-04 19:07:49 --> Pagination Class Initialized
DEBUG - 2015-06-04 19:07:49 --> File loaded: application/views/header.php
DEBUG - 2015-06-04 19:07:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-04 19:07:49 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-06-04 19:07:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-04 19:07:49 --> File loaded: application/views/footer.php
DEBUG - 2015-06-04 19:07:49 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-04 19:07:49 --> Final output sent to browser
DEBUG - 2015-06-04 19:07:49 --> Total execution time: 0.0920
