<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-06-12 14:04:37 --> Config Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:04:37 --> URI Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Router Class Initialized
DEBUG - 2015-06-12 14:04:37 --> No URI present. Default controller set.
DEBUG - 2015-06-12 14:04:37 --> Output Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Security Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Input Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:04:37 --> Language Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Loader Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:04:37 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Session Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:04:37 --> A session cookie was not found.
DEBUG - 2015-06-12 14:04:37 --> Session routines successfully run
DEBUG - 2015-06-12 14:04:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Controller Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:37 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:04:37 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:04:37 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:04:37 --> Final output sent to browser
DEBUG - 2015-06-12 14:04:37 --> Total execution time: 0.0695
DEBUG - 2015-06-12 14:04:44 --> Config Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:04:44 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:04:44 --> URI Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Router Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Output Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Security Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Input Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:04:44 --> Language Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Loader Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:04:44 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Session Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:04:44 --> Session routines successfully run
DEBUG - 2015-06-12 14:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Controller Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:04:44 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:04:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:04:44 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:04:44 --> Final output sent to browser
DEBUG - 2015-06-12 14:04:44 --> Total execution time: 0.0327
DEBUG - 2015-06-12 14:04:52 --> Config Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:04:52 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:04:52 --> URI Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Router Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Output Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Security Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Input Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:04:52 --> Language Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Loader Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:04:52 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Session Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:04:52 --> Session routines successfully run
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Controller Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:04:52 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:04:52 --> Config Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:04:52 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:04:52 --> URI Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Router Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Output Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Security Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Input Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:04:52 --> Language Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Loader Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:04:52 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Session Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:04:52 --> Session routines successfully run
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Controller Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:04:52 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:04:52 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:04:52 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:04:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:04:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:04:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:04:52 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:04:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-06-12 14:04:52 --> Final output sent to browser
DEBUG - 2015-06-12 14:04:52 --> Total execution time: 0.0518
DEBUG - 2015-06-12 14:05:05 --> Config Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:05:05 --> URI Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Router Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Output Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Security Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Input Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:05:05 --> Language Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Loader Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:05:05 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Session Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:05:05 --> Session routines successfully run
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Controller Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:05:05 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:05:05 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:05:05 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:05:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:05:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:05:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:05:05 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:05:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 14:05:05 --> Final output sent to browser
DEBUG - 2015-06-12 14:05:05 --> Total execution time: 0.1342
DEBUG - 2015-06-12 14:05:08 --> Config Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:05:08 --> URI Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Router Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Output Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Security Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Input Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:05:08 --> Language Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Loader Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:05:08 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Session Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:05:08 --> Session routines successfully run
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Controller Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Model Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:05:08 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:05:08 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:05:08 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:05:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:05:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:05:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:05:08 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:05:08 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 14:05:08 --> Final output sent to browser
DEBUG - 2015-06-12 14:05:08 --> Total execution time: 0.0626
DEBUG - 2015-06-12 14:07:37 --> Config Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:07:37 --> URI Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Router Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Output Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Security Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Input Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:07:37 --> Language Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Loader Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:07:37 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Session Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:07:37 --> Session routines successfully run
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Controller Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:07:37 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:07:37 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:07:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:07:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:07:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:07:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:07:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:07:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 14:07:37 --> Final output sent to browser
DEBUG - 2015-06-12 14:07:37 --> Total execution time: 0.0738
DEBUG - 2015-06-12 14:12:41 --> Config Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:12:41 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:12:41 --> URI Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Router Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Output Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Security Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Input Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:12:41 --> Language Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Loader Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:12:41 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Session Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:12:41 --> Session routines successfully run
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Controller Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:12:41 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:12:41 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:12:41 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:12:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:12:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:12:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:12:41 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:12:41 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 14:12:41 --> Final output sent to browser
DEBUG - 2015-06-12 14:12:41 --> Total execution time: 0.1453
DEBUG - 2015-06-12 14:12:43 --> Config Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:12:43 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:12:43 --> URI Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Router Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Output Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Security Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Input Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:12:43 --> Language Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Loader Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:12:43 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Session Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:12:43 --> Session routines successfully run
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Controller Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Model Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:12:43 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:12:43 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:12:43 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:12:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:12:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:12:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:12:43 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:12:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 14:12:43 --> Final output sent to browser
DEBUG - 2015-06-12 14:12:43 --> Total execution time: 0.0668
DEBUG - 2015-06-12 14:13:15 --> Config Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:13:15 --> URI Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Router Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Output Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Security Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Input Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:13:15 --> Language Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Loader Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:13:15 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Session Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:13:15 --> Session routines successfully run
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Controller Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:13:15 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:13:15 --> Config Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:13:15 --> URI Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Router Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Output Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Security Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Input Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:13:15 --> Language Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Loader Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:13:15 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Session Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:13:15 --> Session routines successfully run
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Controller Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Model Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:13:15 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:13:15 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:13:15 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:13:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:13:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:13:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:13:15 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:13:15 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 14:13:15 --> Final output sent to browser
DEBUG - 2015-06-12 14:13:15 --> Total execution time: 0.0600
DEBUG - 2015-06-12 14:14:53 --> Config Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:14:53 --> URI Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Router Class Initialized
DEBUG - 2015-06-12 14:14:53 --> No URI present. Default controller set.
DEBUG - 2015-06-12 14:14:53 --> Output Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Security Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Input Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:14:53 --> Language Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Loader Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:14:53 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Session Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:14:53 --> A session cookie was not found.
DEBUG - 2015-06-12 14:14:53 --> Session routines successfully run
DEBUG - 2015-06-12 14:14:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Controller Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:14:53 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:14:53 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:14:53 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:14:53 --> Final output sent to browser
DEBUG - 2015-06-12 14:14:53 --> Total execution time: 0.0317
DEBUG - 2015-06-12 14:15:04 --> Config Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:15:04 --> URI Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Router Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Output Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Security Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Input Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:15:04 --> Language Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Loader Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:15:04 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Session Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:15:04 --> Session routines successfully run
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Controller Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:15:04 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:15:04 --> Config Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:15:04 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:15:04 --> URI Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Router Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Output Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Security Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Input Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:15:04 --> Language Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Loader Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:15:04 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Session Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:15:04 --> Session routines successfully run
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Controller Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:15:04 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:15:04 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:15:04 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:15:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:15:04 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:15:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:15:04 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:15:04 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-12 14:15:04 --> Final output sent to browser
DEBUG - 2015-06-12 14:15:04 --> Total execution time: 0.0370
DEBUG - 2015-06-12 14:15:06 --> Config Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:15:06 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:15:06 --> URI Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Router Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Output Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Security Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Input Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:15:06 --> Language Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Loader Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:15:06 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Session Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:15:06 --> Session routines successfully run
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Controller Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:15:06 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:15:06 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:15:06 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:15:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:15:06 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:15:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:15:06 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:15:06 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 14:15:06 --> Final output sent to browser
DEBUG - 2015-06-12 14:15:06 --> Total execution time: 0.1128
DEBUG - 2015-06-12 14:15:14 --> Config Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:15:14 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:15:14 --> URI Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Router Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Output Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Security Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Input Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:15:14 --> Language Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Loader Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:15:14 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Session Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:15:14 --> Session routines successfully run
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Controller Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:15:14 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:15:14 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:15:14 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:15:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:15:14 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:15:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:15:14 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:15:14 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 14:15:14 --> Final output sent to browser
DEBUG - 2015-06-12 14:15:14 --> Total execution time: 0.0568
DEBUG - 2015-06-12 14:15:17 --> Config Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:15:17 --> URI Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Router Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Output Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Security Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Input Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:15:17 --> Language Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Loader Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:15:17 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Session Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:15:17 --> Session routines successfully run
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Controller Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Model Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:15:17 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:15:17 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:15:17 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:15:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:15:17 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:15:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:15:17 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:15:17 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 14:15:17 --> Final output sent to browser
DEBUG - 2015-06-12 14:15:17 --> Total execution time: 0.1317
DEBUG - 2015-06-12 14:19:12 --> Config Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:19:12 --> URI Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Router Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Output Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Security Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Input Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:19:12 --> Language Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Loader Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:19:12 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Session Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:19:12 --> Session routines successfully run
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Controller Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:19:12 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:19:12 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:19:12 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:19:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:19:12 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:19:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:19:12 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:19:12 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 14:19:12 --> Final output sent to browser
DEBUG - 2015-06-12 14:19:12 --> Total execution time: 0.1406
DEBUG - 2015-06-12 14:19:53 --> Config Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:19:53 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:19:53 --> URI Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Router Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Output Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Security Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Input Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:19:53 --> Language Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Loader Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:19:53 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Session Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:19:53 --> Session routines successfully run
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Controller Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:19:53 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:19:53 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:19:53 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:19:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:19:53 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:19:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:19:53 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:19:53 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 14:19:53 --> Final output sent to browser
DEBUG - 2015-06-12 14:19:53 --> Total execution time: 0.1196
DEBUG - 2015-06-12 14:23:18 --> Config Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:23:18 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:23:18 --> URI Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Router Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Output Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Security Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Input Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:23:18 --> Language Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Loader Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:23:18 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Session Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:23:18 --> Session routines successfully run
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Controller Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Model Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:23:18 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:23:18 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:23:18 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:23:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:23:18 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 14:23:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:23:18 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:23:18 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 14:23:18 --> Final output sent to browser
DEBUG - 2015-06-12 14:23:18 --> Total execution time: 0.1419
DEBUG - 2015-06-12 14:24:01 --> Config Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:24:01 --> URI Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Router Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Output Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Security Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Input Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:24:01 --> Language Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Loader Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:24:01 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Session Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:24:01 --> Session routines successfully run
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Controller Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:24:01 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Config Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:24:01 --> URI Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Router Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Output Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Security Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Input Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:24:01 --> Language Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Loader Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:24:01 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Session Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:24:01 --> Session routines successfully run
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Controller Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:01 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:24:01 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:24:01 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:24:01 --> Final output sent to browser
DEBUG - 2015-06-12 14:24:01 --> Total execution time: 0.0349
DEBUG - 2015-06-12 14:24:34 --> Config Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:24:34 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:24:34 --> URI Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Router Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Output Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Security Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Input Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:24:34 --> Language Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Loader Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:24:34 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Session Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:24:34 --> Session routines successfully run
DEBUG - 2015-06-12 14:24:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Controller Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:24:34 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:24:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:24:34 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:24:34 --> Final output sent to browser
DEBUG - 2015-06-12 14:24:34 --> Total execution time: 0.0544
DEBUG - 2015-06-12 14:24:52 --> Config Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:24:52 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:24:52 --> URI Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Router Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Output Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Security Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Input Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:24:52 --> Language Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Loader Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:24:52 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Session Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:24:52 --> Session routines successfully run
DEBUG - 2015-06-12 14:24:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Controller Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:24:52 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:24:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:24:52 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:24:52 --> Final output sent to browser
DEBUG - 2015-06-12 14:24:52 --> Total execution time: 0.0421
DEBUG - 2015-06-12 14:24:55 --> Config Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:24:55 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:24:55 --> URI Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Router Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Output Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Security Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Input Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:24:55 --> Language Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Loader Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:24:55 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Session Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:24:55 --> Session routines successfully run
DEBUG - 2015-06-12 14:24:55 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Controller Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Model Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:24:55 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:24:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:24:55 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 14:24:55 --> Final output sent to browser
DEBUG - 2015-06-12 14:24:55 --> Total execution time: 0.0387
DEBUG - 2015-06-12 14:25:19 --> Config Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:25:19 --> URI Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Router Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Output Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Security Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Input Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:25:19 --> Language Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Loader Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:25:19 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Session Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:25:19 --> Session routines successfully run
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Controller Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:25:19 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 14:25:19 --> Config Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:25:19 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:25:19 --> URI Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Router Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Output Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Security Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Input Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:25:19 --> Language Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Loader Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:25:19 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Session Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:25:19 --> Session routines successfully run
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Controller Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:19 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:25:19 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:25:19 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:25:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:25:19 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 14:25:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:25:19 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:25:19 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-06-12 14:25:19 --> Final output sent to browser
DEBUG - 2015-06-12 14:25:19 --> Total execution time: 0.0366
DEBUG - 2015-06-12 14:25:20 --> Config Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:25:20 --> URI Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Router Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Output Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Security Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Input Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:25:20 --> Language Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Loader Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:25:20 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Session Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:25:20 --> Session routines successfully run
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Controller Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:20 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:25:21 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 14:25:21 --> Final output sent to browser
DEBUG - 2015-06-12 14:25:21 --> Total execution time: 0.0922
DEBUG - 2015-06-12 14:25:21 --> Config Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:25:21 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:25:21 --> URI Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Router Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Output Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Security Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Input Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:25:21 --> Language Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Loader Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:25:21 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Session Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:25:21 --> Session routines successfully run
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Controller Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:25:21 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:25:21 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:25:21 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 14:25:21 --> Final output sent to browser
DEBUG - 2015-06-12 14:25:21 --> Total execution time: 0.0846
DEBUG - 2015-06-12 14:25:34 --> Config Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:25:34 --> URI Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Router Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Output Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Security Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Input Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:25:34 --> Language Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Loader Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:25:34 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Session Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:25:34 --> Session routines successfully run
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Controller Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:25:34 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:25:34 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:25:34 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:25:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:25:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:25:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:25:35 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:25:35 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 14:25:35 --> Final output sent to browser
DEBUG - 2015-06-12 14:25:35 --> Total execution time: 0.1111
DEBUG - 2015-06-12 14:25:38 --> Config Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:25:38 --> URI Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Router Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Output Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Security Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Input Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:25:38 --> Language Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Loader Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:25:38 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Session Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:25:38 --> Session routines successfully run
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Controller Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Model Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:25:38 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:25:38 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:25:38 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:25:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:25:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:25:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:25:38 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:25:38 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 14:25:38 --> Final output sent to browser
DEBUG - 2015-06-12 14:25:38 --> Total execution time: 0.0592
DEBUG - 2015-06-12 14:26:09 --> Config Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:26:09 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:26:09 --> URI Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Router Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Output Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Security Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Input Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:26:09 --> Language Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Loader Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:26:09 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Session Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:26:09 --> Session routines successfully run
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Controller Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:26:09 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:26:09 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:26:09 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:26:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:26:09 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 14:26:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:26:09 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:26:09 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 14:26:09 --> Final output sent to browser
DEBUG - 2015-06-12 14:26:09 --> Total execution time: 0.0981
DEBUG - 2015-06-12 14:26:11 --> Config Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:26:11 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:26:11 --> URI Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Router Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Output Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Security Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Input Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:26:11 --> Language Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Loader Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:26:11 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Session Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:26:11 --> Session routines successfully run
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Controller Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:26:11 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:26:11 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:26:11 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:26:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:26:11 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 14:26:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:26:11 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:26:11 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 14:26:11 --> Final output sent to browser
DEBUG - 2015-06-12 14:26:11 --> Total execution time: 0.0543
DEBUG - 2015-06-12 14:26:37 --> Config Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:26:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:26:37 --> URI Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Router Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Output Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Security Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Input Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:26:37 --> Language Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Loader Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:26:37 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Session Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:26:37 --> Session routines successfully run
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Controller Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Model Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:26:37 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:26:37 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:26:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:26:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:26:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:26:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:26:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:26:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 14:26:37 --> Final output sent to browser
DEBUG - 2015-06-12 14:26:37 --> Total execution time: 0.0643
DEBUG - 2015-06-12 14:35:59 --> Config Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Hooks Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Utf8 Class Initialized
DEBUG - 2015-06-12 14:35:59 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 14:35:59 --> URI Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Router Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Output Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Security Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Input Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 14:35:59 --> Language Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Loader Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Helper loaded: url_helper
DEBUG - 2015-06-12 14:35:59 --> Database Driver Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Session Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Helper loaded: string_helper
DEBUG - 2015-06-12 14:35:59 --> Session routines successfully run
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Controller Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Model Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Helper loaded: form_helper
DEBUG - 2015-06-12 14:35:59 --> Form Validation Class Initialized
DEBUG - 2015-06-12 14:35:59 --> Pagination Class Initialized
DEBUG - 2015-06-12 14:35:59 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 14:35:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 14:35:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 14:35:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 14:35:59 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 14:35:59 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-06-12 14:35:59 --> Final output sent to browser
DEBUG - 2015-06-12 14:35:59 --> Total execution time: 0.0763
DEBUG - 2015-06-12 15:18:50 --> Config Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Hooks Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Utf8 Class Initialized
DEBUG - 2015-06-12 15:18:50 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 15:18:50 --> URI Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Router Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Output Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Security Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Input Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 15:18:50 --> Language Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Loader Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Helper loaded: url_helper
DEBUG - 2015-06-12 15:18:50 --> Database Driver Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Session Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Helper loaded: string_helper
DEBUG - 2015-06-12 15:18:50 --> Session routines successfully run
DEBUG - 2015-06-12 15:18:50 --> Model Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Model Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Controller Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Model Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Model Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Model Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Model Class Initialized
DEBUG - 2015-06-12 15:18:50 --> Helper loaded: form_helper
DEBUG - 2015-06-12 15:18:50 --> Form Validation Class Initialized
DEBUG - 2015-06-12 15:18:50 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 15:18:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 15:18:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 15:18:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 15:18:50 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 15:18:50 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-06-12 15:18:50 --> Final output sent to browser
DEBUG - 2015-06-12 15:18:50 --> Total execution time: 0.0743
DEBUG - 2015-06-12 15:19:00 --> Config Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Hooks Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Utf8 Class Initialized
DEBUG - 2015-06-12 15:19:00 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 15:19:00 --> URI Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Router Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Output Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Security Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Input Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 15:19:00 --> Language Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Loader Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Helper loaded: url_helper
DEBUG - 2015-06-12 15:19:00 --> Database Driver Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Session Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Helper loaded: string_helper
DEBUG - 2015-06-12 15:19:00 --> Session routines successfully run
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Controller Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Model Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Helper loaded: form_helper
DEBUG - 2015-06-12 15:19:00 --> Form Validation Class Initialized
DEBUG - 2015-06-12 15:19:00 --> Pagination Class Initialized
DEBUG - 2015-06-12 15:19:00 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 15:19:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 15:19:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 15:19:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 15:19:00 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 15:19:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 15:19:00 --> Final output sent to browser
DEBUG - 2015-06-12 15:19:00 --> Total execution time: 0.1529
DEBUG - 2015-06-12 16:02:17 --> Config Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:02:17 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:02:17 --> URI Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Router Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Output Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Security Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Input Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:02:17 --> Language Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Loader Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:02:17 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Session Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:02:17 --> Session routines successfully run
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Controller Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Model Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:02:17 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:02:17 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:02:17 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:02:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:02:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:02:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:02:17 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:02:17 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-06-12 16:02:17 --> Final output sent to browser
DEBUG - 2015-06-12 16:02:17 --> Total execution time: 0.0836
DEBUG - 2015-06-12 16:03:10 --> Config Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:03:10 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:03:10 --> URI Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Router Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Output Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Security Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Input Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:03:10 --> Language Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Loader Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:03:10 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Session Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:03:10 --> Session routines successfully run
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Controller Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:03:10 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:03:10 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:03:10 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:03:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:03:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:03:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:03:10 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:03:10 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 16:03:10 --> Final output sent to browser
DEBUG - 2015-06-12 16:03:10 --> Total execution time: 0.1158
DEBUG - 2015-06-12 16:03:14 --> Config Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:03:14 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:03:14 --> URI Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Router Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Output Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Security Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Input Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:03:14 --> Language Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Loader Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:03:14 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Session Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:03:14 --> Session routines successfully run
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Controller Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:03:14 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:03:14 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:03:14 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:03:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:03:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:03:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:03:14 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:03:14 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:03:14 --> Final output sent to browser
DEBUG - 2015-06-12 16:03:14 --> Total execution time: 0.0719
DEBUG - 2015-06-12 16:03:48 --> Config Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:03:48 --> URI Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Router Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Output Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Security Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Input Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:03:48 --> Language Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Loader Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:03:48 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Session Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:03:48 --> Session routines successfully run
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Controller Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:03:48 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 16:03:48 --> Config Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:03:48 --> URI Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Router Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Output Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Security Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Input Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:03:48 --> Language Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Loader Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:03:48 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Session Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:03:48 --> Session routines successfully run
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Controller Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:03:48 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:03:48 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:03:48 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:03:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:03:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:03:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:03:48 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:03:48 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:03:48 --> Final output sent to browser
DEBUG - 2015-06-12 16:03:48 --> Total execution time: 0.0593
DEBUG - 2015-06-12 16:05:05 --> Config Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:05:05 --> URI Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Router Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Output Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Security Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Input Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:05:05 --> Language Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Loader Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:05:05 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Session Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:05:05 --> Session routines successfully run
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Controller Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:05:05 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Config Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:05:05 --> URI Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Router Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Output Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Security Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Input Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:05:05 --> Language Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Loader Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:05:05 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Session Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:05:05 --> Session routines successfully run
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Controller Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:05 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:05:05 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:05:05 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 16:05:05 --> Final output sent to browser
DEBUG - 2015-06-12 16:05:05 --> Total execution time: 0.0321
DEBUG - 2015-06-12 16:05:41 --> Config Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:05:41 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:05:41 --> URI Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Router Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Output Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Security Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Input Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:05:41 --> Language Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Loader Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:05:41 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Session Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:05:41 --> Session routines successfully run
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Controller Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:05:41 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 16:05:41 --> Config Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:05:41 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:05:41 --> URI Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Router Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Output Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Security Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Input Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:05:41 --> Language Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Loader Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:05:41 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Session Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:05:41 --> Session routines successfully run
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Controller Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:41 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:05:41 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:05:41 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:05:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:05:41 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:05:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:05:41 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:05:41 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-06-12 16:05:41 --> Final output sent to browser
DEBUG - 2015-06-12 16:05:41 --> Total execution time: 0.0377
DEBUG - 2015-06-12 16:05:43 --> Config Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:05:43 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:05:43 --> URI Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Router Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Output Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Security Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Input Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:05:43 --> Language Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Loader Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:05:43 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Session Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:05:43 --> Session routines successfully run
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Controller Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:05:43 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:05:43 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:05:43 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:05:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:05:43 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:05:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:05:43 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:05:43 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 16:05:43 --> Final output sent to browser
DEBUG - 2015-06-12 16:05:43 --> Total execution time: 0.0584
DEBUG - 2015-06-12 16:11:47 --> Config Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:11:47 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:11:47 --> URI Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Router Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Output Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Security Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Input Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:11:47 --> Language Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Loader Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:11:47 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Session Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:11:47 --> Session routines successfully run
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Controller Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Model Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:11:47 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:11:47 --> Pagination Class Initialized
ERROR - 2015-06-12 16:11:47 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 169
DEBUG - 2015-06-12 16:11:47 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:11:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:11:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:11:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:11:47 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:11:47 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:11:47 --> Final output sent to browser
DEBUG - 2015-06-12 16:11:47 --> Total execution time: 0.0777
DEBUG - 2015-06-12 16:12:36 --> Config Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:12:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:12:36 --> URI Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Router Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Output Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Security Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Input Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:12:36 --> Language Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Loader Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:12:36 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Session Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:12:36 --> Session routines successfully run
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Controller Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:12:36 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:12:36 --> Pagination Class Initialized
ERROR - 2015-06-12 16:12:36 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 169
DEBUG - 2015-06-12 16:12:36 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:12:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:12:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:12:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:12:36 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:12:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:12:36 --> Final output sent to browser
DEBUG - 2015-06-12 16:12:36 --> Total execution time: 0.0738
DEBUG - 2015-06-12 16:12:46 --> Config Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:12:46 --> URI Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Router Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Output Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Security Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Input Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:12:46 --> Language Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Loader Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:12:46 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Session Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:12:46 --> Session routines successfully run
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Controller Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Model Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:12:46 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:12:46 --> Pagination Class Initialized
ERROR - 2015-06-12 16:12:46 --> Severity: Warning  --> Attempt to assign property of non-object /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 169
DEBUG - 2015-06-12 16:13:03 --> Config Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:13:03 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:13:03 --> URI Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Router Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Output Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Security Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Input Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:13:03 --> Language Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Loader Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:13:03 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Session Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:13:03 --> Session routines successfully run
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Controller Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:13:03 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:13:03 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:13:03 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:13:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:13:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:13:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:13:03 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:13:03 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:13:03 --> Final output sent to browser
DEBUG - 2015-06-12 16:13:03 --> Total execution time: 0.0730
DEBUG - 2015-06-12 16:13:26 --> Config Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:13:26 --> URI Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Router Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Output Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Security Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Input Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:13:26 --> Language Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Loader Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:13:26 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Session Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:13:26 --> Session routines successfully run
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Controller Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:13:26 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:13:26 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Config Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:13:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:13:48 --> URI Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Router Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Output Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Security Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Input Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:13:48 --> Language Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Loader Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:13:48 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Session Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:13:48 --> Session routines successfully run
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Controller Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:13:48 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:13:48 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:13:48 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:13:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:13:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:13:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:13:48 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:13:48 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:13:48 --> Final output sent to browser
DEBUG - 2015-06-12 16:13:48 --> Total execution time: 0.0602
DEBUG - 2015-06-12 16:15:15 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:15 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:15 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:15 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:15 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:15 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:15 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:15 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:15 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:15 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:15 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:15 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:15 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 16:15:15 --> Final output sent to browser
DEBUG - 2015-06-12 16:15:15 --> Total execution time: 0.0297
DEBUG - 2015-06-12 16:15:28 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:28 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:28 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:28 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:28 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:28 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 16:15:28 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:28 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:28 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:28 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:28 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:28 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:28 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:28 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:15:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:15:28 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:15:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:15:28 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:15:28 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-06-12 16:15:28 --> Final output sent to browser
DEBUG - 2015-06-12 16:15:28 --> Total execution time: 0.0380
DEBUG - 2015-06-12 16:15:30 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:30 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:30 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:30 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:30 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:30 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:30 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:30 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:15:30 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:15:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:15:30 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:15:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:15:30 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:15:30 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 16:15:30 --> Final output sent to browser
DEBUG - 2015-06-12 16:15:30 --> Total execution time: 0.0564
DEBUG - 2015-06-12 16:15:33 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:33 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:33 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:33 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:33 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:33 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:33 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:15:33 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:15:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:15:33 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:15:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:15:33 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:15:33 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:15:33 --> Final output sent to browser
DEBUG - 2015-06-12 16:15:33 --> Total execution time: 0.0575
DEBUG - 2015-06-12 16:15:38 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:38 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:38 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:38 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:38 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:38 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:38 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:38 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:39 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:39 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:15:39 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:15:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:15:39 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:15:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:15:39 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:15:39 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 16:15:39 --> Final output sent to browser
DEBUG - 2015-06-12 16:15:39 --> Total execution time: 0.0769
DEBUG - 2015-06-12 16:15:48 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:48 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:48 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:48 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:48 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:48 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Config Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:15:48 --> URI Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Router Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Output Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Security Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Input Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:15:48 --> Language Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Loader Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:15:48 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Session Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:15:48 --> Session routines successfully run
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Controller Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:15:48 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:15:48 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:15:48 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 16:15:48 --> Final output sent to browser
DEBUG - 2015-06-12 16:15:48 --> Total execution time: 0.0306
DEBUG - 2015-06-12 16:16:06 --> Config Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:16:06 --> URI Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Router Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Output Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Security Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Input Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:16:06 --> Language Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Loader Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:16:06 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Session Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:16:06 --> Session routines successfully run
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Controller Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:16:06 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 16:16:06 --> Config Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:16:06 --> URI Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Router Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Output Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Security Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Input Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:16:06 --> Language Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Loader Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:16:06 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Session Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:16:06 --> Session routines successfully run
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Controller Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:06 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:16:06 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:16:06 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:16:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:16:06 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:16:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:16:06 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:16:06 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-06-12 16:16:06 --> Final output sent to browser
DEBUG - 2015-06-12 16:16:06 --> Total execution time: 0.0370
DEBUG - 2015-06-12 16:16:08 --> Config Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:16:08 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:16:08 --> URI Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Router Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Output Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Security Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Input Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:16:08 --> Language Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Loader Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:16:08 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Session Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:16:08 --> Session routines successfully run
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Controller Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Model Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:16:08 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:16:08 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:16:08 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:16:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:16:08 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:16:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:16:08 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:16:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 16:16:08 --> Final output sent to browser
DEBUG - 2015-06-12 16:16:08 --> Total execution time: 0.0646
DEBUG - 2015-06-12 16:25:36 --> Config Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:25:36 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:25:36 --> URI Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Router Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Output Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Security Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Input Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:25:36 --> Language Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Loader Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:25:36 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Session Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:25:36 --> Session routines successfully run
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Controller Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Model Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:25:36 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:25:36 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:25:36 --> DB Transaction Failure
ERROR - 2015-06-12 16:25:36 --> Query error: Unknown column 'additional_agent.agent_id' in 'on clause'
DEBUG - 2015-06-12 16:25:36 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-06-12 16:27:24 --> Config Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:27:24 --> URI Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Router Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Output Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Security Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Input Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:27:24 --> Language Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Loader Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:27:24 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Session Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:27:24 --> Session routines successfully run
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Controller Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:27:24 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:27:24 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:27:24 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:27:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:27:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:27:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:27:24 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:27:24 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:27:24 --> Final output sent to browser
DEBUG - 2015-06-12 16:27:24 --> Total execution time: 0.0858
DEBUG - 2015-06-12 16:27:27 --> Config Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:27:27 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:27:27 --> URI Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Router Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Output Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Security Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Input Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:27:27 --> Language Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Loader Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:27:27 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Session Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:27:27 --> Session routines successfully run
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Controller Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Model Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:27:27 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:27:27 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:27:27 --> DB Transaction Failure
ERROR - 2015-06-12 16:27:27 --> Query error: Unknown column 'additional_agent.agent_id' in 'on clause'
DEBUG - 2015-06-12 16:27:27 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-06-12 16:28:37 --> Config Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:28:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:28:37 --> URI Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Router Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Output Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Security Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Input Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:28:37 --> Language Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Loader Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:28:37 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Session Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:28:37 --> Session routines successfully run
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Controller Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:28:37 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:28:37 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:28:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:28:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:28:37 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:28:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:28:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:28:37 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 16:28:37 --> Final output sent to browser
DEBUG - 2015-06-12 16:28:37 --> Total execution time: 0.0683
DEBUG - 2015-06-12 16:28:43 --> Config Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:28:43 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:28:43 --> URI Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Router Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Output Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Security Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Input Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:28:43 --> Language Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Loader Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:28:43 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Session Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:28:43 --> Session routines successfully run
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Controller Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:28:43 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:28:43 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:28:43 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:28:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:28:43 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:28:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:28:43 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:28:43 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:28:43 --> Final output sent to browser
DEBUG - 2015-06-12 16:28:43 --> Total execution time: 0.0504
DEBUG - 2015-06-12 16:28:48 --> Config Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:28:48 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:28:48 --> URI Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Router Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Output Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Security Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Input Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:28:48 --> Language Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Loader Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:28:48 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Session Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:28:48 --> Session routines successfully run
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Controller Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Model Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:28:48 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:28:48 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:28:48 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:28:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:28:48 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:28:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:28:48 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:28:48 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 16:28:48 --> Final output sent to browser
DEBUG - 2015-06-12 16:28:48 --> Total execution time: 0.0756
DEBUG - 2015-06-12 16:31:15 --> Config Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:31:15 --> URI Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Router Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Output Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Security Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Input Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:31:15 --> Language Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Loader Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:31:15 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Session Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:31:15 --> Session routines successfully run
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Controller Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:31:15 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:31:15 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:31:15 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:31:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:31:15 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-06-12 16:31:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:31:15 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:31:15 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 16:31:15 --> Final output sent to browser
DEBUG - 2015-06-12 16:31:15 --> Total execution time: 0.0650
DEBUG - 2015-06-12 16:31:40 --> Config Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:31:40 --> URI Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Router Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Output Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Security Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Input Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:31:40 --> Language Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Loader Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:31:40 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Session Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:31:40 --> Session routines successfully run
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Controller Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:31:40 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:31:40 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:31:40 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:31:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:31:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:31:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:31:40 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:31:40 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 16:31:40 --> Final output sent to browser
DEBUG - 2015-06-12 16:31:40 --> Total execution time: 0.1225
DEBUG - 2015-06-12 16:31:44 --> Config Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:31:44 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:31:44 --> URI Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Router Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Output Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Security Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Input Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:31:44 --> Language Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Loader Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:31:44 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Session Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:31:44 --> Session routines successfully run
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Controller Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Model Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:31:44 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:31:44 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:31:44 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:31:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:31:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:31:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:31:44 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:31:44 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:31:44 --> Final output sent to browser
DEBUG - 2015-06-12 16:31:44 --> Total execution time: 0.0604
DEBUG - 2015-06-12 16:36:19 --> Config Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:36:19 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:36:19 --> URI Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Router Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Output Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Security Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Input Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:36:19 --> Language Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Loader Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:36:19 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Session Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:36:19 --> Session routines successfully run
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Controller Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:36:19 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:36:19 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:36:19 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:36:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:36:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:36:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:36:19 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:36:19 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:36:19 --> Final output sent to browser
DEBUG - 2015-06-12 16:36:19 --> Total execution time: 0.0773
DEBUG - 2015-06-12 16:37:19 --> Config Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Hooks Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Utf8 Class Initialized
DEBUG - 2015-06-12 16:37:19 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 16:37:19 --> URI Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Router Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Output Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Security Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Input Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 16:37:19 --> Language Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Loader Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Helper loaded: url_helper
DEBUG - 2015-06-12 16:37:19 --> Database Driver Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Session Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Helper loaded: string_helper
DEBUG - 2015-06-12 16:37:19 --> Session routines successfully run
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Controller Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Model Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Helper loaded: form_helper
DEBUG - 2015-06-12 16:37:19 --> Form Validation Class Initialized
DEBUG - 2015-06-12 16:37:19 --> Pagination Class Initialized
DEBUG - 2015-06-12 16:37:20 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 16:37:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 16:37:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 16:37:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 16:37:20 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 16:37:20 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 16:37:20 --> Final output sent to browser
DEBUG - 2015-06-12 16:37:20 --> Total execution time: 0.0906
DEBUG - 2015-06-12 17:00:33 --> Config Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:00:33 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:00:33 --> URI Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Router Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Output Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Security Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Input Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:00:33 --> Language Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Loader Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:00:33 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Session Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:00:33 --> Session routines successfully run
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Controller Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Model Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:00:33 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:00:33 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Config Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:01:37 --> URI Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Router Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Output Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Security Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Input Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:01:37 --> Language Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Loader Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:01:37 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Session Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:01:37 --> Session routines successfully run
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Controller Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:01:37 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:01:37 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:01:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:01:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:01:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:01:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:01:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:01:37 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:01:37 --> Final output sent to browser
DEBUG - 2015-06-12 17:01:37 --> Total execution time: 0.0769
DEBUG - 2015-06-12 17:02:56 --> Config Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:02:56 --> URI Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Router Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Output Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Security Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Input Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:02:56 --> Language Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Loader Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:02:56 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Session Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:02:56 --> Session routines successfully run
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Controller Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:02:56 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:02:56 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:02:57 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:02:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:02:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:02:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:02:57 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:02:57 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:02:57 --> Final output sent to browser
DEBUG - 2015-06-12 17:02:57 --> Total execution time: 0.0596
DEBUG - 2015-06-12 17:04:24 --> Config Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:04:24 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:04:24 --> URI Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Router Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Output Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Security Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Input Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:04:24 --> Language Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Loader Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:04:24 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Session Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:04:24 --> Session routines successfully run
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Controller Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:04:24 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:04:24 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:04:24 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:04:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:04:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:04:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:04:24 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:04:24 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:04:24 --> Final output sent to browser
DEBUG - 2015-06-12 17:04:24 --> Total execution time: 0.0884
DEBUG - 2015-06-12 17:04:44 --> Config Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:04:44 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:04:44 --> URI Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Router Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Output Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Security Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Input Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:04:44 --> Language Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Loader Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:04:44 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Session Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:04:44 --> Session routines successfully run
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Controller Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:04:44 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Config Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:04:44 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:04:44 --> URI Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Router Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Output Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Security Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Input Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:04:44 --> Language Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Loader Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:04:44 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Session Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:04:44 --> Session routines successfully run
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Controller Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Model Class Initialized
DEBUG - 2015-06-12 17:04:44 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:04:44 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:04:44 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 17:04:44 --> Final output sent to browser
DEBUG - 2015-06-12 17:04:44 --> Total execution time: 0.0301
DEBUG - 2015-06-12 17:05:02 --> Config Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:05:02 --> URI Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Router Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Output Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Security Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Input Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:05:02 --> Language Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Loader Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:05:02 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Session Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:05:02 --> Session routines successfully run
DEBUG - 2015-06-12 17:05:02 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Controller Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:05:02 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:05:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:05:02 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 17:05:02 --> Final output sent to browser
DEBUG - 2015-06-12 17:05:02 --> Total execution time: 0.0498
DEBUG - 2015-06-12 17:05:26 --> Config Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:05:26 --> URI Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Router Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Output Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Security Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Input Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:05:26 --> Language Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Loader Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:05:26 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Session Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:05:26 --> Session routines successfully run
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Controller Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:05:26 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:05:26 --> Config Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:05:26 --> URI Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Router Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Output Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Security Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Input Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:05:26 --> Language Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Loader Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:05:26 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Session Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:05:26 --> Session routines successfully run
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Controller Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:05:26 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:05:26 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:05:26 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:05:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:05:26 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 17:05:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:05:26 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:05:26 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-06-12 17:05:26 --> Final output sent to browser
DEBUG - 2015-06-12 17:05:26 --> Total execution time: 0.0394
DEBUG - 2015-06-12 17:05:28 --> Config Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:05:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:05:28 --> URI Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Router Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Output Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Security Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Input Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:05:28 --> Language Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Loader Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:05:28 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Session Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:05:28 --> Session routines successfully run
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Controller Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:05:28 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:05:28 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:05:28 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:05:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:05:28 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 17:05:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:05:28 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:05:28 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-06-12 17:05:28 --> Final output sent to browser
DEBUG - 2015-06-12 17:05:28 --> Total execution time: 0.0599
DEBUG - 2015-06-12 17:05:30 --> Config Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:05:30 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:05:30 --> URI Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Router Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Output Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Security Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Input Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:05:30 --> Language Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Loader Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:05:30 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Session Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:05:30 --> Session routines successfully run
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Controller Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:05:30 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:05:30 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:05:30 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:05:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:05:30 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 17:05:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:05:30 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:05:30 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:05:30 --> Final output sent to browser
DEBUG - 2015-06-12 17:05:30 --> Total execution time: 0.0554
DEBUG - 2015-06-12 17:05:32 --> Config Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:05:32 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:05:32 --> URI Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Router Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Output Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Security Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Input Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:05:32 --> Language Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Loader Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:05:32 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Session Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:05:32 --> Session routines successfully run
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Controller Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Model Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:05:32 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:05:32 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:05:32 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:05:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:05:32 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-06-12 17:05:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:05:32 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:05:32 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-06-12 17:05:32 --> Final output sent to browser
DEBUG - 2015-06-12 17:05:32 --> Total execution time: 0.0633
DEBUG - 2015-06-12 17:11:22 --> Config Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:11:22 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:11:22 --> URI Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Router Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Output Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Security Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Input Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:11:22 --> Language Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Loader Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:11:22 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Session Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:11:22 --> Session routines successfully run
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Controller Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Model Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:11:22 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:11:22 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:11:22 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:11:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:11:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:11:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:11:22 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:11:22 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:11:22 --> Final output sent to browser
DEBUG - 2015-06-12 17:11:22 --> Total execution time: 0.0929
DEBUG - 2015-06-12 17:12:05 --> Config Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:12:05 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:12:05 --> URI Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Router Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Output Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Security Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Input Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:12:05 --> Language Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Loader Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:12:05 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Session Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:12:05 --> Session routines successfully run
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Controller Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:12:05 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:12:05 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:12:05 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:12:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:12:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:12:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:12:05 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:12:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:12:05 --> Final output sent to browser
DEBUG - 2015-06-12 17:12:05 --> Total execution time: 0.0785
DEBUG - 2015-06-12 17:12:14 --> Config Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:12:14 --> URI Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Router Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Output Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Security Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Input Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:12:14 --> Language Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Loader Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:12:14 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Session Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:12:14 --> Session routines successfully run
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Controller Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:12:14 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:12:14 --> Config Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:12:14 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:12:14 --> URI Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Router Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Output Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Security Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Input Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:12:14 --> Language Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Loader Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:12:14 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Session Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:12:14 --> Session routines successfully run
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Controller Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:12:14 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:12:14 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:12:14 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:12:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:12:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:12:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:12:14 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:12:14 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:12:14 --> Final output sent to browser
DEBUG - 2015-06-12 17:12:14 --> Total execution time: 0.0591
DEBUG - 2015-06-12 17:12:22 --> Config Class Initialized
DEBUG - 2015-06-12 17:12:22 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:12:22 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:12:22 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:12:22 --> URI Class Initialized
DEBUG - 2015-06-12 17:12:22 --> Router Class Initialized
DEBUG - 2015-06-12 17:12:22 --> Output Class Initialized
DEBUG - 2015-06-12 17:12:22 --> Security Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Input Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:12:23 --> Language Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Loader Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:12:23 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Session Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:12:23 --> Session routines successfully run
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Controller Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:12:23 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Config Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:12:23 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:12:23 --> URI Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Router Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Output Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Security Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Input Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:12:23 --> Language Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Loader Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:12:23 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Session Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:12:23 --> Session routines successfully run
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Controller Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:12:23 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:12:23 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:12:23 --> File loaded: application/views/loginView.php
DEBUG - 2015-06-12 17:12:23 --> Final output sent to browser
DEBUG - 2015-06-12 17:12:23 --> Total execution time: 0.0286
DEBUG - 2015-06-12 17:14:37 --> Config Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:14:37 --> URI Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Router Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Output Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Security Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Input Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:14:37 --> Language Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Loader Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:14:37 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Session Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:14:37 --> Session routines successfully run
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Controller Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:14:37 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:14:37 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:14:37 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:14:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:14:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:14:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:14:37 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:14:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:14:37 --> Final output sent to browser
DEBUG - 2015-06-12 17:14:37 --> Total execution time: 0.0940
DEBUG - 2015-06-12 17:14:50 --> Config Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:14:50 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:14:50 --> URI Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Router Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Output Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Security Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Input Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:14:50 --> Language Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Loader Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:14:50 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Session Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:14:50 --> Session routines successfully run
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Controller Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Model Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:14:50 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:14:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-06-12 17:14:50 --> Severity: Notice  --> Undefined variable: amt /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 487
ERROR - 2015-06-12 17:14:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
ERROR - 2015-06-12 17:14:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/helpers/url_helper.php 542
DEBUG - 2015-06-12 17:15:12 --> Config Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:15:12 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:15:12 --> URI Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Router Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Output Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Security Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Input Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:15:12 --> Language Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Loader Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:15:12 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Session Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:15:12 --> Session routines successfully run
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Controller Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:15:12 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:15:12 --> Config Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:15:12 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:15:12 --> URI Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Router Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Output Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Security Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Input Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:15:12 --> Language Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Loader Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:15:12 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Session Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:15:12 --> Session routines successfully run
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Controller Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:15:12 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:15:12 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:15:12 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:15:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:15:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:15:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:15:12 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:15:12 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:15:12 --> Final output sent to browser
DEBUG - 2015-06-12 17:15:12 --> Total execution time: 0.0663
DEBUG - 2015-06-12 17:15:28 --> Config Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:15:28 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:15:28 --> URI Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Router Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Output Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Security Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Input Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:15:28 --> Language Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Loader Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:15:28 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Session Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:15:28 --> Session routines successfully run
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Controller Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Model Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:15:28 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:15:28 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:15:28 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:15:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:15:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:15:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:15:28 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:15:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:15:28 --> Final output sent to browser
DEBUG - 2015-06-12 17:15:28 --> Total execution time: 0.0650
DEBUG - 2015-06-12 17:16:23 --> Config Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:16:23 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:16:23 --> URI Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Router Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Output Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Security Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Input Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:16:23 --> Language Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Loader Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:16:23 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Session Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:16:23 --> Session routines successfully run
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Controller Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Model Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:16:23 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:16:23 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:16:23 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:16:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:16:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:16:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:16:23 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:16:23 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:16:23 --> Final output sent to browser
DEBUG - 2015-06-12 17:16:23 --> Total execution time: 0.0903
DEBUG - 2015-06-12 17:17:03 --> Config Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:17:03 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:17:03 --> URI Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Router Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Output Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Security Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Input Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:17:03 --> Language Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Loader Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:17:03 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Session Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:17:03 --> Session routines successfully run
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Controller Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:17:03 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:17:03 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:17:03 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:17:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:17:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:17:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:17:03 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:17:03 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:17:03 --> Final output sent to browser
DEBUG - 2015-06-12 17:17:03 --> Total execution time: 0.0911
DEBUG - 2015-06-12 17:17:07 --> Config Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:17:07 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:17:07 --> URI Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Router Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Output Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Security Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Input Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:17:07 --> Language Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Loader Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:17:07 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Session Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:17:07 --> Session routines successfully run
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Controller Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:07 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:17:08 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:17:08 --> Config Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:17:08 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:17:08 --> URI Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Router Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Output Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Security Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Input Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:17:08 --> Language Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Loader Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:17:08 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Session Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:17:08 --> Session routines successfully run
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Controller Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Model Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:17:08 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:17:08 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:17:08 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:17:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:17:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:17:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:17:08 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:17:08 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:17:08 --> Final output sent to browser
DEBUG - 2015-06-12 17:17:08 --> Total execution time: 0.0584
DEBUG - 2015-06-12 17:18:39 --> Config Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:18:39 --> URI Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Router Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Output Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Security Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Input Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:18:39 --> Language Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Loader Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:18:39 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Session Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:18:39 --> Session routines successfully run
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Controller Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:18:39 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:18:39 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:18:39 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:18:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:18:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:18:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:18:39 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:18:39 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:18:39 --> Final output sent to browser
DEBUG - 2015-06-12 17:18:39 --> Total execution time: 0.0834
DEBUG - 2015-06-12 17:18:42 --> Config Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:18:42 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:18:42 --> URI Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Router Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Output Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Security Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Input Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:18:42 --> Language Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Loader Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:18:42 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Session Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:18:42 --> Session routines successfully run
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Controller Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:18:42 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:18:42 --> Config Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:18:42 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:18:42 --> URI Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Router Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Output Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Security Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Input Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:18:42 --> Language Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Loader Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:18:42 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Session Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:18:42 --> Session routines successfully run
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Controller Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Model Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:18:42 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:18:42 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:18:42 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:18:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:18:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:18:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:18:42 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:18:42 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:18:42 --> Final output sent to browser
DEBUG - 2015-06-12 17:18:42 --> Total execution time: 0.0578
DEBUG - 2015-06-12 17:19:17 --> Config Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:19:17 --> URI Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Router Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Output Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Security Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Input Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:19:17 --> Language Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Loader Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:19:17 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Session Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:19:17 --> Session routines successfully run
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Controller Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:19:17 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:19:17 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:19:17 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:19:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:19:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:19:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:19:17 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:19:17 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:19:17 --> Final output sent to browser
DEBUG - 2015-06-12 17:19:17 --> Total execution time: 0.0652
DEBUG - 2015-06-12 17:19:21 --> Config Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:19:21 --> URI Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Router Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Output Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Security Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Input Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:19:21 --> Language Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Loader Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:19:21 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Session Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:19:21 --> Session routines successfully run
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Controller Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:19:21 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:19:21 --> Config Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:19:21 --> URI Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Router Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Output Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Security Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Input Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:19:21 --> Language Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Loader Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:19:21 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Session Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:19:21 --> Session routines successfully run
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Controller Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:19:21 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:19:21 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:19:21 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:19:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:19:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:19:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:19:21 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:19:21 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:19:21 --> Final output sent to browser
DEBUG - 2015-06-12 17:19:21 --> Total execution time: 0.0641
DEBUG - 2015-06-12 17:19:53 --> Config Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:19:53 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:19:53 --> URI Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Router Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Output Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Security Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Input Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:19:53 --> Language Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Loader Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:19:53 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Session Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:19:53 --> Session routines successfully run
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Controller Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:19:53 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:19:53 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:19:53 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:19:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:19:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:19:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:19:53 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:19:53 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-06-12 17:19:53 --> Final output sent to browser
DEBUG - 2015-06-12 17:19:53 --> Total execution time: 0.0652
DEBUG - 2015-06-12 17:19:56 --> Config Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:19:56 --> URI Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Router Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Output Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Security Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Input Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:19:56 --> Language Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Loader Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:19:56 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Session Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:19:56 --> Session routines successfully run
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Controller Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:19:56 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-06-12 17:19:56 --> Config Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Hooks Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Utf8 Class Initialized
DEBUG - 2015-06-12 17:19:56 --> UTF-8 Support Enabled
DEBUG - 2015-06-12 17:19:56 --> URI Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Router Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Output Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Security Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Input Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-06-12 17:19:56 --> Language Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Loader Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Helper loaded: url_helper
DEBUG - 2015-06-12 17:19:56 --> Database Driver Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Session Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Helper loaded: string_helper
DEBUG - 2015-06-12 17:19:56 --> Session routines successfully run
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Controller Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Model Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Helper loaded: form_helper
DEBUG - 2015-06-12 17:19:56 --> Form Validation Class Initialized
DEBUG - 2015-06-12 17:19:56 --> Pagination Class Initialized
DEBUG - 2015-06-12 17:19:56 --> File loaded: application/views/header.php
DEBUG - 2015-06-12 17:19:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-06-12 17:19:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-06-12 17:19:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-06-12 17:19:56 --> File loaded: application/views/footer.php
DEBUG - 2015-06-12 17:19:56 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-06-12 17:19:56 --> Final output sent to browser
DEBUG - 2015-06-12 17:19:56 --> Total execution time: 0.0637
