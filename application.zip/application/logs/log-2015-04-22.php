<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-22 13:34:26 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:26 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:26 --> No URI present. Default controller set.
DEBUG - 2015-04-22 13:34:26 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:26 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:26 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:26 --> A session cookie was not found.
DEBUG - 2015-04-22 13:34:26 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:26 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:26 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:26 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:26 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-22 13:34:26 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:26 --> Total execution time: 0.1106
DEBUG - 2015-04-22 13:34:35 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:35 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:35 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:35 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:35 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:35 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-22 13:34:35 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:35 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:35 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:35 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:35 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:35 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:35 --> Pagination Class Initialized
DEBUG - 2015-04-22 13:34:35 --> File loaded: application/views/header.php
DEBUG - 2015-04-22 13:34:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-22 13:34:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-22 13:34:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-22 13:34:35 --> File loaded: application/views/footer.php
DEBUG - 2015-04-22 13:34:35 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-22 13:34:35 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:35 --> Total execution time: 0.0432
DEBUG - 2015-04-22 13:34:38 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:38 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:38 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:38 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:39 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:39 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:39 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:39 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:39 --> Pagination Class Initialized
DEBUG - 2015-04-22 13:34:39 --> File loaded: application/views/header.php
DEBUG - 2015-04-22 13:34:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-22 13:34:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-22 13:34:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-22 13:34:39 --> File loaded: application/views/footer.php
DEBUG - 2015-04-22 13:34:39 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-22 13:34:39 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:39 --> Total execution time: 0.0510
DEBUG - 2015-04-22 13:34:40 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:40 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:40 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:40 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:40 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:40 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:40 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:40 --> Pagination Class Initialized
DEBUG - 2015-04-22 13:34:40 --> File loaded: application/views/header.php
DEBUG - 2015-04-22 13:34:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-22 13:34:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-22 13:34:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-22 13:34:40 --> File loaded: application/views/footer.php
DEBUG - 2015-04-22 13:34:40 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-22 13:34:40 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:40 --> Total execution time: 0.0495
DEBUG - 2015-04-22 13:34:41 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:41 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:41 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:41 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:41 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:41 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:41 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:41 --> Pagination Class Initialized
DEBUG - 2015-04-22 13:34:41 --> File loaded: application/views/header.php
DEBUG - 2015-04-22 13:34:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-22 13:34:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-22 13:34:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-22 13:34:41 --> File loaded: application/views/footer.php
DEBUG - 2015-04-22 13:34:41 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-22 13:34:41 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:41 --> Total execution time: 0.0508
DEBUG - 2015-04-22 13:34:45 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:45 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:45 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:45 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:45 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:45 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:45 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:45 --> Pagination Class Initialized
DEBUG - 2015-04-22 13:34:45 --> File loaded: application/views/header.php
DEBUG - 2015-04-22 13:34:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-22 13:34:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-22 13:34:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-22 13:34:45 --> File loaded: application/views/footer.php
DEBUG - 2015-04-22 13:34:45 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-22 13:34:45 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:45 --> Total execution time: 0.0494
DEBUG - 2015-04-22 13:34:51 --> Config Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Hooks Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Utf8 Class Initialized
DEBUG - 2015-04-22 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-22 13:34:51 --> URI Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Router Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Output Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Security Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Input Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-22 13:34:51 --> Language Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Loader Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Helper loaded: url_helper
DEBUG - 2015-04-22 13:34:51 --> Database Driver Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Session Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Helper loaded: string_helper
DEBUG - 2015-04-22 13:34:51 --> Session routines successfully run
DEBUG - 2015-04-22 13:34:51 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Controller Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Model Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Helper loaded: form_helper
DEBUG - 2015-04-22 13:34:51 --> Form Validation Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Pagination Class Initialized
DEBUG - 2015-04-22 13:34:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-22 13:34:51 --> File loaded: application/views/header.php
DEBUG - 2015-04-22 13:34:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-22 13:34:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-22 13:34:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-22 13:34:51 --> File loaded: application/views/footer.php
DEBUG - 2015-04-22 13:34:51 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-22 13:34:51 --> Final output sent to browser
DEBUG - 2015-04-22 13:34:51 --> Total execution time: 0.0411
