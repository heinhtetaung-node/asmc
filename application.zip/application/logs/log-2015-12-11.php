<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-12-11 10:10:42 --> Config Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Hooks Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Utf8 Class Initialized
DEBUG - 2015-12-11 10:10:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 10:10:42 --> URI Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Router Class Initialized
DEBUG - 2015-12-11 10:10:42 --> No URI present. Default controller set.
DEBUG - 2015-12-11 10:10:42 --> Output Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Security Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Input Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 10:10:42 --> Language Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Loader Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Helper loaded: url_helper
DEBUG - 2015-12-11 10:10:42 --> Database Driver Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Session Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Helper loaded: string_helper
DEBUG - 2015-12-11 10:10:42 --> A session cookie was not found.
DEBUG - 2015-12-11 10:10:42 --> Session routines successfully run
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Controller Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:42 --> Helper loaded: form_helper
DEBUG - 2015-12-11 10:10:42 --> Form Validation Class Initialized
DEBUG - 2015-12-11 10:10:42 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-11 10:10:42 --> Final output sent to browser
DEBUG - 2015-12-11 10:10:42 --> Total execution time: 0.0965
DEBUG - 2015-12-11 10:10:47 --> Config Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Hooks Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Utf8 Class Initialized
DEBUG - 2015-12-11 10:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 10:10:47 --> URI Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Router Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Output Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Security Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Input Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 10:10:47 --> Language Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Loader Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Helper loaded: url_helper
DEBUG - 2015-12-11 10:10:47 --> Database Driver Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Session Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Helper loaded: string_helper
DEBUG - 2015-12-11 10:10:47 --> Session routines successfully run
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Controller Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Helper loaded: form_helper
DEBUG - 2015-12-11 10:10:47 --> Form Validation Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-11 10:10:47 --> Config Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Hooks Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Utf8 Class Initialized
DEBUG - 2015-12-11 10:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 10:10:47 --> URI Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Router Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Output Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Security Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Input Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 10:10:47 --> Language Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Loader Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Helper loaded: url_helper
DEBUG - 2015-12-11 10:10:47 --> Database Driver Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Session Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Helper loaded: string_helper
DEBUG - 2015-12-11 10:10:47 --> Session routines successfully run
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Controller Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Helper loaded: form_helper
DEBUG - 2015-12-11 10:10:47 --> Form Validation Class Initialized
DEBUG - 2015-12-11 10:10:47 --> Pagination Class Initialized
DEBUG - 2015-12-11 10:10:47 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 10:10:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 10:10:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 10:10:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 10:10:47 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 10:10:47 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-11 10:10:47 --> Final output sent to browser
DEBUG - 2015-12-11 10:10:47 --> Total execution time: 0.0548
DEBUG - 2015-12-11 10:10:51 --> Config Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Hooks Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Utf8 Class Initialized
DEBUG - 2015-12-11 10:10:51 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 10:10:51 --> URI Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Router Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Output Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Security Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Input Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 10:10:51 --> Language Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Loader Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Helper loaded: url_helper
DEBUG - 2015-12-11 10:10:51 --> Database Driver Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Session Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Helper loaded: string_helper
DEBUG - 2015-12-11 10:10:51 --> Session routines successfully run
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Controller Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Pagination Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Helper loaded: form_helper
DEBUG - 2015-12-11 10:10:51 --> Form Validation Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> Model Class Initialized
DEBUG - 2015-12-11 10:10:51 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 10:10:51 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-11 10:10:51 --> Final output sent to browser
DEBUG - 2015-12-11 10:10:51 --> Total execution time: 0.0909
DEBUG - 2015-12-11 10:13:22 --> Config Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Hooks Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Utf8 Class Initialized
DEBUG - 2015-12-11 10:13:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 10:13:22 --> URI Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Router Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Output Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Security Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Input Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 10:13:22 --> Language Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Loader Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Helper loaded: url_helper
DEBUG - 2015-12-11 10:13:22 --> Database Driver Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Session Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Helper loaded: string_helper
DEBUG - 2015-12-11 10:13:22 --> Session routines successfully run
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Controller Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Pagination Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Helper loaded: form_helper
DEBUG - 2015-12-11 10:13:22 --> Form Validation Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:22 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 10:13:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 10:13:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 10:13:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 10:13:23 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 10:13:23 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-11 10:13:23 --> Final output sent to browser
DEBUG - 2015-12-11 10:13:23 --> Total execution time: 0.0931
DEBUG - 2015-12-11 10:13:26 --> Config Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Hooks Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Utf8 Class Initialized
DEBUG - 2015-12-11 10:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 10:13:26 --> URI Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Router Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Output Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Security Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Input Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 10:13:26 --> Language Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Loader Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Helper loaded: url_helper
DEBUG - 2015-12-11 10:13:26 --> Database Driver Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Session Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Helper loaded: string_helper
DEBUG - 2015-12-11 10:13:26 --> Session routines successfully run
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Controller Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Helper loaded: form_helper
DEBUG - 2015-12-11 10:13:26 --> Form Validation Class Initialized
DEBUG - 2015-12-11 10:13:26 --> Pagination Class Initialized
DEBUG - 2015-12-11 10:13:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 10:13:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 10:13:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 10:13:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 10:13:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 10:13:26 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 10:13:26 --> Final output sent to browser
DEBUG - 2015-12-11 10:13:26 --> Total execution time: 0.0894
DEBUG - 2015-12-11 11:20:34 --> Config Class Initialized
DEBUG - 2015-12-11 11:20:34 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:20:34 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:20:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:20:34 --> URI Class Initialized
DEBUG - 2015-12-11 11:20:34 --> Router Class Initialized
ERROR - 2015-12-11 11:20:34 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:20:36 --> Config Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:20:36 --> URI Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Router Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Output Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Security Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Input Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:20:36 --> Language Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Loader Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:20:36 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Session Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:20:36 --> Session routines successfully run
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Controller Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Model Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:20:36 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:20:36 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:20:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:20:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:20:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:20:36 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:20:36 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:20:36 --> Final output sent to browser
DEBUG - 2015-12-11 11:20:36 --> Total execution time: 0.0782
DEBUG - 2015-12-11 11:20:36 --> Config Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:20:36 --> URI Class Initialized
DEBUG - 2015-12-11 11:20:36 --> Router Class Initialized
ERROR - 2015-12-11 11:20:36 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:21:12 --> Config Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:21:12 --> URI Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Router Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Output Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Security Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Input Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:21:12 --> Language Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Loader Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:21:12 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Session Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:21:12 --> Session routines successfully run
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Controller Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:21:12 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:21:12 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:21:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:21:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:21:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:21:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:21:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:21:12 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:21:12 --> Final output sent to browser
DEBUG - 2015-12-11 11:21:12 --> Total execution time: 0.0550
DEBUG - 2015-12-11 11:21:13 --> Config Class Initialized
DEBUG - 2015-12-11 11:21:13 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:21:13 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:21:13 --> URI Class Initialized
DEBUG - 2015-12-11 11:21:13 --> Router Class Initialized
ERROR - 2015-12-11 11:21:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:22:23 --> Config Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:22:23 --> URI Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Router Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Output Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Security Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Input Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:22:23 --> Language Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Loader Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:22:23 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Session Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:22:23 --> Session routines successfully run
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Controller Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:22:23 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:22:23 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:22:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:22:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:22:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:22:23 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:22:23 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:22:23 --> Final output sent to browser
DEBUG - 2015-12-11 11:22:23 --> Total execution time: 0.0936
DEBUG - 2015-12-11 11:22:23 --> Config Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:22:23 --> URI Class Initialized
DEBUG - 2015-12-11 11:22:23 --> Router Class Initialized
ERROR - 2015-12-11 11:22:23 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:22:39 --> Config Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:22:39 --> URI Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Router Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Output Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Security Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Input Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:22:39 --> Language Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Loader Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:22:39 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Session Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:22:39 --> Session routines successfully run
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Controller Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Model Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:22:39 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:22:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:22:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:22:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:22:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:22:39 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:22:39 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:22:39 --> Final output sent to browser
DEBUG - 2015-12-11 11:22:39 --> Total execution time: 0.0694
DEBUG - 2015-12-11 11:22:39 --> Config Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:22:39 --> URI Class Initialized
DEBUG - 2015-12-11 11:22:39 --> Router Class Initialized
ERROR - 2015-12-11 11:22:39 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:25:04 --> Config Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:25:04 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:25:04 --> URI Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Router Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Output Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Security Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Input Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:25:04 --> Language Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Loader Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:25:04 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Session Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:25:04 --> Session routines successfully run
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Controller Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:25:04 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:25:04 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:25:04 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:25:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:25:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:25:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:25:04 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:25:04 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:25:04 --> Final output sent to browser
DEBUG - 2015-12-11 11:25:04 --> Total execution time: 0.0739
DEBUG - 2015-12-11 11:25:05 --> Config Class Initialized
DEBUG - 2015-12-11 11:25:05 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:25:05 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:25:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:25:05 --> URI Class Initialized
DEBUG - 2015-12-11 11:25:05 --> Router Class Initialized
ERROR - 2015-12-11 11:25:05 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:25:28 --> Config Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:25:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:25:28 --> URI Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Router Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Output Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Security Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Input Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:25:28 --> Language Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Loader Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:25:28 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Session Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:25:28 --> Session routines successfully run
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Controller Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Model Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:25:28 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:25:28 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:25:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:25:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:25:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:25:28 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:25:28 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:25:28 --> Final output sent to browser
DEBUG - 2015-12-11 11:25:28 --> Total execution time: 0.0693
DEBUG - 2015-12-11 11:25:28 --> Config Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:25:28 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:25:28 --> URI Class Initialized
DEBUG - 2015-12-11 11:25:28 --> Router Class Initialized
ERROR - 2015-12-11 11:25:28 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:26:00 --> Config Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:26:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:26:00 --> URI Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Router Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Output Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Security Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Input Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:26:00 --> Language Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Loader Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:26:00 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Session Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:26:00 --> Session routines successfully run
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Controller Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:26:00 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:26:00 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:26:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:26:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:26:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:26:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:26:00 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:26:00 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:26:00 --> Final output sent to browser
DEBUG - 2015-12-11 11:26:00 --> Total execution time: 0.0797
DEBUG - 2015-12-11 11:26:01 --> Config Class Initialized
DEBUG - 2015-12-11 11:26:01 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:26:01 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:26:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:26:01 --> URI Class Initialized
DEBUG - 2015-12-11 11:26:01 --> Router Class Initialized
ERROR - 2015-12-11 11:26:01 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:26:24 --> Config Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:26:24 --> URI Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Router Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Output Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Security Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Input Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:26:24 --> Language Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Loader Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:26:24 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Session Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:26:24 --> Session routines successfully run
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Controller Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:26:24 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:26:24 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:26:24 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:26:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:26:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:26:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:26:24 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:26:24 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:26:24 --> Final output sent to browser
DEBUG - 2015-12-11 11:26:24 --> Total execution time: 0.0620
DEBUG - 2015-12-11 11:26:25 --> Config Class Initialized
DEBUG - 2015-12-11 11:26:25 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:26:25 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:26:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:26:25 --> URI Class Initialized
DEBUG - 2015-12-11 11:26:25 --> Router Class Initialized
ERROR - 2015-12-11 11:26:25 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:26:53 --> Config Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:26:53 --> URI Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Router Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Output Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Security Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Input Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:26:53 --> Language Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Loader Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:26:53 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Session Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:26:53 --> Session routines successfully run
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Controller Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Model Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:26:53 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:26:53 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:26:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:26:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:26:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:26:53 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:26:53 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:26:53 --> Final output sent to browser
DEBUG - 2015-12-11 11:26:53 --> Total execution time: 0.0736
DEBUG - 2015-12-11 11:26:53 --> Config Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:26:53 --> URI Class Initialized
DEBUG - 2015-12-11 11:26:53 --> Router Class Initialized
ERROR - 2015-12-11 11:26:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:27:12 --> Config Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:27:12 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:27:12 --> URI Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Router Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Output Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Security Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Input Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:27:12 --> Language Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Loader Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:27:12 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Session Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:27:12 --> Session routines successfully run
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Controller Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:27:12 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:27:12 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:27:12 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:27:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:27:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:27:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:27:12 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:27:12 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:27:12 --> Final output sent to browser
DEBUG - 2015-12-11 11:27:12 --> Total execution time: 0.0729
DEBUG - 2015-12-11 11:27:13 --> Config Class Initialized
DEBUG - 2015-12-11 11:27:13 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:27:13 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:27:13 --> URI Class Initialized
DEBUG - 2015-12-11 11:27:13 --> Router Class Initialized
ERROR - 2015-12-11 11:27:13 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 11:27:52 --> Config Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:27:52 --> URI Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Router Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Output Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Security Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Input Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 11:27:52 --> Language Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Loader Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Helper loaded: url_helper
DEBUG - 2015-12-11 11:27:52 --> Database Driver Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Session Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Helper loaded: string_helper
DEBUG - 2015-12-11 11:27:52 --> Session routines successfully run
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Controller Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Model Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Helper loaded: form_helper
DEBUG - 2015-12-11 11:27:52 --> Form Validation Class Initialized
DEBUG - 2015-12-11 11:27:52 --> Pagination Class Initialized
DEBUG - 2015-12-11 11:27:52 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 11:27:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 11:27:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 11:27:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 11:27:52 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 11:27:52 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 11:27:52 --> Final output sent to browser
DEBUG - 2015-12-11 11:27:52 --> Total execution time: 0.0781
DEBUG - 2015-12-11 11:27:53 --> Config Class Initialized
DEBUG - 2015-12-11 11:27:53 --> Hooks Class Initialized
DEBUG - 2015-12-11 11:27:53 --> Utf8 Class Initialized
DEBUG - 2015-12-11 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 11:27:53 --> URI Class Initialized
DEBUG - 2015-12-11 11:27:53 --> Router Class Initialized
ERROR - 2015-12-11 11:27:53 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:03:06 --> Config Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:03:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:03:06 --> URI Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Router Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Output Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Security Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Input Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:03:06 --> Language Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Loader Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:03:06 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Session Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:03:06 --> Session routines successfully run
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Controller Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:03:06 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:06 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:03:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:03:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:03:06 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-11 12:03:06 --> Severity: Notice  --> Undefined property: stdClass::$formid /Applications/MAMP/htdocs/asmc/crm/application/views/form/list.php 85
DEBUG - 2015-12-11 12:03:06 --> DB Transaction Failure
ERROR - 2015-12-11 12:03:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2015-12-11 12:03:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-11 12:03:07 --> Config Class Initialized
DEBUG - 2015-12-11 12:03:07 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:03:07 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:03:07 --> URI Class Initialized
DEBUG - 2015-12-11 12:03:07 --> Router Class Initialized
ERROR - 2015-12-11 12:03:07 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:03:15 --> Config Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:03:15 --> URI Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Router Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Output Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Security Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Input Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:03:15 --> Language Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Loader Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:03:15 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Session Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:03:15 --> Session routines successfully run
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Controller Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:03:15 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:15 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:03:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:03:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:03:15 --> File loaded: application/views/sidebar.php
ERROR - 2015-12-11 12:03:15 --> Severity: Notice  --> Undefined property: stdClass::$form_id /Applications/MAMP/htdocs/asmc/crm/application/views/form/list.php 85
DEBUG - 2015-12-11 12:03:15 --> DB Transaction Failure
ERROR - 2015-12-11 12:03:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2015-12-11 12:03:15 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-12-11 12:03:15 --> Config Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:03:15 --> URI Class Initialized
DEBUG - 2015-12-11 12:03:15 --> Router Class Initialized
ERROR - 2015-12-11 12:03:15 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:03:26 --> Config Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:03:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:03:26 --> URI Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Router Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Output Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Security Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Input Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:03:26 --> Language Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Loader Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:03:26 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Session Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:03:26 --> Session routines successfully run
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Controller Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:03:26 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> Model Class Initialized
DEBUG - 2015-12-11 12:03:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:03:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:03:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:03:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:03:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:03:26 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-11 12:03:26 --> Final output sent to browser
DEBUG - 2015-12-11 12:03:26 --> Total execution time: 0.0528
DEBUG - 2015-12-11 12:03:27 --> Config Class Initialized
DEBUG - 2015-12-11 12:03:27 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:03:27 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:03:27 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:03:27 --> URI Class Initialized
DEBUG - 2015-12-11 12:03:27 --> Router Class Initialized
ERROR - 2015-12-11 12:03:27 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:25 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:25 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:25 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:25 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:25 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:25 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:25 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:25 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 12:16:25 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:25 --> Total execution time: 0.1805
DEBUG - 2015-12-11 12:16:25 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:25 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:25 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:25 --> Router Class Initialized
ERROR - 2015-12-11 12:16:25 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:30 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:30 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:30 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:30 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:30 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:30 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:30 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:30 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 12:16:30 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:30 --> Total execution time: 0.0499
DEBUG - 2015-12-11 12:16:30 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:30 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:30 --> Router Class Initialized
ERROR - 2015-12-11 12:16:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:31 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:31 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:31 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:31 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:31 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:31 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:31 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:31 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:31 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-11 12:16:31 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:31 --> Total execution time: 0.0428
DEBUG - 2015-12-11 12:16:32 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:32 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:32 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:32 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:32 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:32 --> Router Class Initialized
ERROR - 2015-12-11 12:16:32 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:33 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:33 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:33 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:33 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:33 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:33 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:33 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:33 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:33 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:33 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:33 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 12:16:33 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:33 --> Total execution time: 0.0491
DEBUG - 2015-12-11 12:16:34 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:34 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:34 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:34 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:34 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:34 --> Router Class Initialized
ERROR - 2015-12-11 12:16:34 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:39 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:39 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:39 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:39 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:39 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:39 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:39 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:39 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 12:16:39 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:39 --> Total execution time: 0.0683
DEBUG - 2015-12-11 12:16:39 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:39 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:39 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:39 --> Router Class Initialized
ERROR - 2015-12-11 12:16:39 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:42 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:42 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:42 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:42 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:42 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:42 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:42 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:42 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:42 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:42 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 12:16:42 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:42 --> Total execution time: 0.0722
DEBUG - 2015-12-11 12:16:43 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:43 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:43 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:43 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:43 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:43 --> Router Class Initialized
ERROR - 2015-12-11 12:16:43 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:16:48 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:48 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:48 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Router Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Output Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Security Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Input Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:16:48 --> Language Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Loader Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:16:48 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Session Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:16:48 --> Session routines successfully run
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Controller Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Model Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:16:48 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:16:48 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:16:48 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:16:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:16:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:16:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:16:48 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:16:48 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 12:16:48 --> Final output sent to browser
DEBUG - 2015-12-11 12:16:48 --> Total execution time: 0.0716
DEBUG - 2015-12-11 12:16:49 --> Config Class Initialized
DEBUG - 2015-12-11 12:16:49 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:16:49 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:16:49 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:16:49 --> URI Class Initialized
DEBUG - 2015-12-11 12:16:49 --> Router Class Initialized
ERROR - 2015-12-11 12:16:49 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:17:00 --> Config Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:17:00 --> URI Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Router Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Output Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Security Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Input Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:17:00 --> Language Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Loader Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:17:00 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Session Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:17:00 --> Session routines successfully run
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Controller Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:17:00 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:17:00 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:17:00 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:17:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:17:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:17:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:17:00 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:17:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 12:17:00 --> Final output sent to browser
DEBUG - 2015-12-11 12:17:00 --> Total execution time: 0.0552
DEBUG - 2015-12-11 12:17:01 --> Config Class Initialized
DEBUG - 2015-12-11 12:17:01 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:17:01 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:17:01 --> URI Class Initialized
DEBUG - 2015-12-11 12:17:01 --> Router Class Initialized
ERROR - 2015-12-11 12:17:01 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:17:05 --> Config Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:17:05 --> URI Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Router Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Output Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Security Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Input Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:17:05 --> Language Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Loader Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:17:05 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Session Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:17:05 --> Session routines successfully run
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Controller Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:17:05 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:17:05 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 12:17:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 12:17:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 12:17:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 12:17:05 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 12:17:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 12:17:05 --> Final output sent to browser
DEBUG - 2015-12-11 12:17:05 --> Total execution time: 0.0446
DEBUG - 2015-12-11 12:17:05 --> Config Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:17:05 --> URI Class Initialized
DEBUG - 2015-12-11 12:17:05 --> Router Class Initialized
ERROR - 2015-12-11 12:17:05 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 12:17:42 --> Config Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:17:42 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:17:42 --> URI Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Router Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Output Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Security Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Input Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:17:42 --> Language Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Loader Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:17:42 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Session Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:17:42 --> Session routines successfully run
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Controller Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Model Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:17:42 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:17:42 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:17:45 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:17:45 --> Final output sent to browser
DEBUG - 2015-12-11 12:17:45 --> Total execution time: 2.3361
DEBUG - 2015-12-11 12:18:20 --> Config Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:18:20 --> URI Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Router Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Output Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Security Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Input Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:18:20 --> Language Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Loader Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:18:20 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Session Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:18:20 --> Session routines successfully run
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Controller Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:18:20 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:18:20 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:18:23 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:18:23 --> Final output sent to browser
DEBUG - 2015-12-11 12:18:23 --> Total execution time: 2.4010
DEBUG - 2015-12-11 12:18:44 --> Config Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:18:44 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:18:44 --> URI Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Router Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Output Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Security Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Input Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:18:44 --> Language Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Loader Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:18:44 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Session Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:18:44 --> Session routines successfully run
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Controller Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Model Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:18:44 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:18:44 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:18:46 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:18:46 --> Final output sent to browser
DEBUG - 2015-12-11 12:18:46 --> Total execution time: 2.2397
DEBUG - 2015-12-11 12:19:03 --> Config Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:19:03 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:19:03 --> URI Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Router Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Output Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Security Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Input Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:19:03 --> Language Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Loader Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:19:03 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Session Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:19:03 --> Session routines successfully run
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Controller Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Model Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:19:03 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:19:03 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:19:05 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:19:05 --> Final output sent to browser
DEBUG - 2015-12-11 12:19:05 --> Total execution time: 2.3303
DEBUG - 2015-12-11 12:36:31 --> Config Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:36:31 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:36:31 --> URI Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Router Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Output Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Security Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Input Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:36:31 --> Language Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Loader Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:36:31 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Session Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:36:31 --> Session routines successfully run
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Controller Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Model Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:36:31 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:36:31 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:36:34 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:36:34 --> Final output sent to browser
DEBUG - 2015-12-11 12:36:34 --> Total execution time: 2.4364
DEBUG - 2015-12-11 12:37:29 --> Config Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:37:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:37:29 --> URI Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Router Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Output Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Security Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Input Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:37:29 --> Language Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Loader Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:37:29 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Session Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:37:29 --> Session routines successfully run
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Controller Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:37:29 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:37:29 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:37:32 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:37:32 --> Final output sent to browser
DEBUG - 2015-12-11 12:37:32 --> Total execution time: 2.8204
DEBUG - 2015-12-11 12:38:29 --> Config Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:38:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:38:29 --> URI Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Router Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Output Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Security Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Input Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:38:29 --> Language Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Loader Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:38:29 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Session Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:38:29 --> Session routines successfully run
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Controller Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:38:29 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:38:29 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:38:32 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:38:32 --> Final output sent to browser
DEBUG - 2015-12-11 12:38:32 --> Total execution time: 2.8293
DEBUG - 2015-12-11 12:38:54 --> Config Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:38:54 --> URI Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Router Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Output Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Security Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Input Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:38:54 --> Language Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Loader Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:38:54 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Session Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:38:54 --> Session routines successfully run
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Controller Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Model Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:38:54 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:38:54 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:38:57 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 12:38:57 --> Final output sent to browser
DEBUG - 2015-12-11 12:38:57 --> Total execution time: 2.8432
DEBUG - 2015-12-11 12:56:11 --> Config Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:56:11 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:56:11 --> URI Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Router Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Output Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Security Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Input Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:56:11 --> Language Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Loader Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:56:11 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Session Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:56:11 --> Session routines successfully run
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Controller Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Model Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:56:11 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:56:11 --> Helper loaded: pdf_helper
ERROR - 2015-12-11 12:56:11 --> Severity: Notice  --> Undefined variable: signature /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/pdf/riskPDF.php 211
ERROR - 2015-12-11 12:56:11 --> Severity: Notice  --> Undefined variable: director_signature /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/pdf/riskPDF.php 219
ERROR - 2015-12-11 12:56:12 --> Severity: Warning  --> getimagesize(div style=): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/tcpdf.php 6850
ERROR - 2015-12-11 12:56:12 --> Severity: Warning  --> file_get_contents(div style=): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/include/tcpdf_static.php 2495
DEBUG - 2015-12-11 12:57:01 --> Config Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:57:01 --> URI Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Router Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Output Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Security Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Input Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:57:01 --> Language Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Loader Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:57:01 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Session Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:57:01 --> Session routines successfully run
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Controller Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:57:01 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:57:01 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:57:04 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-11 12:57:04 --> Final output sent to browser
DEBUG - 2015-12-11 12:57:04 --> Total execution time: 2.4134
DEBUG - 2015-12-11 12:57:36 --> Config Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:57:36 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:57:36 --> URI Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Router Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Output Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Security Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Input Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:57:36 --> Language Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Loader Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:57:36 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Session Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:57:36 --> Session routines successfully run
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Controller Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Model Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:57:36 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:57:36 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:57:39 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-11 12:57:39 --> Final output sent to browser
DEBUG - 2015-12-11 12:57:39 --> Total execution time: 2.4153
DEBUG - 2015-12-11 12:58:01 --> Config Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:58:01 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:58:01 --> URI Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Router Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Output Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Security Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Input Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:58:01 --> Language Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Loader Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:58:01 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Session Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:58:01 --> Session routines successfully run
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Controller Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:58:01 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:58:01 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:58:04 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-11 12:58:04 --> Final output sent to browser
DEBUG - 2015-12-11 12:58:04 --> Total execution time: 2.4947
DEBUG - 2015-12-11 12:58:22 --> Config Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:58:22 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:58:22 --> URI Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Router Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Output Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Security Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Input Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:58:22 --> Language Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Loader Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:58:22 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Session Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:58:22 --> Session routines successfully run
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Controller Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:58:22 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:58:22 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:58:25 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-11 12:58:25 --> Final output sent to browser
DEBUG - 2015-12-11 12:58:25 --> Total execution time: 2.4280
DEBUG - 2015-12-11 12:58:35 --> Config Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:58:35 --> URI Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Router Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Output Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Security Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Input Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:58:35 --> Language Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Loader Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:58:35 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Session Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:58:35 --> Session routines successfully run
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Controller Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Model Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:58:35 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:58:35 --> Helper loaded: pdf_helper
ERROR - 2015-12-11 12:58:35 --> Severity: Notice  --> Undefined variable: signature /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/pdf/riskPDF.php 177
ERROR - 2015-12-11 12:58:35 --> Severity: Notice  --> Undefined variable: director_signature /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/pdf/riskPDF.php 182
ERROR - 2015-12-11 12:58:35 --> Severity: Notice  --> Undefined variable: signature /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/pdf/riskPDF.php 215
ERROR - 2015-12-11 12:58:35 --> Severity: Notice  --> Undefined variable: director_signature /Applications/MAMP/htdocs/asmc/crm/application/views/invoice/pdf/riskPDF.php 221
ERROR - 2015-12-11 12:58:36 --> Severity: Warning  --> getimagesize(div style=): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/tcpdf.php 6850
ERROR - 2015-12-11 12:58:36 --> Severity: Warning  --> file_get_contents(div style=): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/include/tcpdf_static.php 2495
DEBUG - 2015-12-11 12:59:16 --> Config Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Hooks Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Utf8 Class Initialized
DEBUG - 2015-12-11 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 12:59:16 --> URI Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Router Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Output Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Security Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Input Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 12:59:16 --> Language Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Loader Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Helper loaded: url_helper
DEBUG - 2015-12-11 12:59:16 --> Database Driver Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Session Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Helper loaded: string_helper
DEBUG - 2015-12-11 12:59:16 --> Session routines successfully run
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Controller Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Model Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Helper loaded: form_helper
DEBUG - 2015-12-11 12:59:16 --> Form Validation Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Pagination Class Initialized
DEBUG - 2015-12-11 12:59:16 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 12:59:17 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-11 12:59:17 --> Final output sent to browser
DEBUG - 2015-12-11 12:59:17 --> Total execution time: 1.1862
DEBUG - 2015-12-11 13:00:30 --> Config Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 13:00:30 --> URI Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Router Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Output Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Security Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Input Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 13:00:30 --> Language Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Loader Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Helper loaded: url_helper
DEBUG - 2015-12-11 13:00:30 --> Database Driver Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Session Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Helper loaded: string_helper
DEBUG - 2015-12-11 13:00:30 --> Session routines successfully run
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Controller Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Model Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Helper loaded: form_helper
DEBUG - 2015-12-11 13:00:30 --> Form Validation Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Pagination Class Initialized
DEBUG - 2015-12-11 13:00:30 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 13:00:31 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2015-12-11 13:00:31 --> Final output sent to browser
DEBUG - 2015-12-11 13:00:31 --> Total execution time: 1.6068
DEBUG - 2015-12-11 13:12:58 --> Config Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Hooks Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Utf8 Class Initialized
DEBUG - 2015-12-11 13:12:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 13:12:58 --> URI Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Router Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Output Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Security Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Input Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 13:12:58 --> Language Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Loader Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Helper loaded: url_helper
DEBUG - 2015-12-11 13:12:58 --> Database Driver Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Session Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Helper loaded: string_helper
DEBUG - 2015-12-11 13:12:58 --> Session routines successfully run
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Controller Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Model Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Helper loaded: form_helper
DEBUG - 2015-12-11 13:12:58 --> Form Validation Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Pagination Class Initialized
DEBUG - 2015-12-11 13:12:58 --> Helper loaded: pdf_helper
DEBUG - 2015-12-11 13:12:59 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2015-12-11 13:12:59 --> Final output sent to browser
DEBUG - 2015-12-11 13:12:59 --> Total execution time: 1.2159
DEBUG - 2015-12-11 13:43:30 --> Config Class Initialized
DEBUG - 2015-12-11 13:43:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 13:43:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 13:43:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 13:43:30 --> URI Class Initialized
DEBUG - 2015-12-11 13:43:30 --> Router Class Initialized
ERROR - 2015-12-11 13:43:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 13:43:38 --> Config Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Hooks Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Utf8 Class Initialized
DEBUG - 2015-12-11 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 13:43:38 --> URI Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Router Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Output Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Security Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Input Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 13:43:38 --> Language Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Loader Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Helper loaded: url_helper
DEBUG - 2015-12-11 13:43:38 --> Database Driver Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Session Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Helper loaded: string_helper
DEBUG - 2015-12-11 13:43:38 --> Session routines successfully run
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Controller Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Pagination Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Helper loaded: form_helper
DEBUG - 2015-12-11 13:43:38 --> Form Validation Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Model Class Initialized
DEBUG - 2015-12-11 13:43:38 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 13:43:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 13:43:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 13:43:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 13:43:38 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 13:43:38 --> File loaded: application/views/form/list.php
DEBUG - 2015-12-11 13:43:38 --> Final output sent to browser
DEBUG - 2015-12-11 13:43:38 --> Total execution time: 0.0727
DEBUG - 2015-12-11 13:43:38 --> Config Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Hooks Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Utf8 Class Initialized
DEBUG - 2015-12-11 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 13:43:38 --> URI Class Initialized
DEBUG - 2015-12-11 13:43:38 --> Router Class Initialized
ERROR - 2015-12-11 13:43:38 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 14:44:54 --> Config Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Hooks Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Utf8 Class Initialized
DEBUG - 2015-12-11 14:44:54 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 14:44:54 --> URI Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Router Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Output Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Security Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Input Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 14:44:54 --> Language Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Loader Class Initialized
DEBUG - 2015-12-11 14:44:54 --> Helper loaded: url_helper
DEBUG - 2015-12-11 14:44:55 --> Database Driver Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Session Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Helper loaded: string_helper
DEBUG - 2015-12-11 14:44:55 --> Session routines successfully run
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Controller Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Helper loaded: form_helper
DEBUG - 2015-12-11 14:44:55 --> Form Validation Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Pagination Class Initialized
DEBUG - 2015-12-11 14:44:55 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 14:44:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 14:44:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 14:44:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 14:44:55 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 14:44:55 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 14:44:55 --> Final output sent to browser
DEBUG - 2015-12-11 14:44:55 --> Total execution time: 0.1011
DEBUG - 2015-12-11 14:44:55 --> Config Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Hooks Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Utf8 Class Initialized
DEBUG - 2015-12-11 14:44:55 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 14:44:55 --> URI Class Initialized
DEBUG - 2015-12-11 14:44:55 --> Router Class Initialized
ERROR - 2015-12-11 14:44:55 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 14:44:57 --> Config Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Hooks Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Utf8 Class Initialized
DEBUG - 2015-12-11 14:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 14:44:57 --> URI Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Router Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Output Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Security Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Input Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 14:44:57 --> Language Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Loader Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Helper loaded: url_helper
DEBUG - 2015-12-11 14:44:57 --> Database Driver Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Session Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Helper loaded: string_helper
DEBUG - 2015-12-11 14:44:57 --> Session routines successfully run
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Controller Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Model Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Helper loaded: form_helper
DEBUG - 2015-12-11 14:44:57 --> Form Validation Class Initialized
DEBUG - 2015-12-11 14:44:57 --> Pagination Class Initialized
DEBUG - 2015-12-11 14:44:57 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 14:44:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 14:44:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 14:44:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 14:44:57 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 14:44:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-12-11 14:44:57 --> Final output sent to browser
DEBUG - 2015-12-11 14:44:57 --> Total execution time: 0.0467
DEBUG - 2015-12-11 14:44:58 --> Config Class Initialized
DEBUG - 2015-12-11 14:44:58 --> Hooks Class Initialized
DEBUG - 2015-12-11 14:44:58 --> Utf8 Class Initialized
DEBUG - 2015-12-11 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 14:44:58 --> URI Class Initialized
DEBUG - 2015-12-11 14:44:58 --> Router Class Initialized
ERROR - 2015-12-11 14:44:58 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 17:13:18 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:18 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:18 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Router Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Output Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Security Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Input Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:13:18 --> Language Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Loader Class Initialized
DEBUG - 2015-12-11 17:13:18 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:13:19 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Session Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:13:19 --> A session cookie was not found.
DEBUG - 2015-12-11 17:13:19 --> Session routines successfully run
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Controller Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:19 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Router Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Output Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Security Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Input Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:13:19 --> Language Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Loader Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:13:19 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Session Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:13:19 --> Session routines successfully run
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Controller Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Helper loaded: form_helper
DEBUG - 2015-12-11 17:13:19 --> Form Validation Class Initialized
DEBUG - 2015-12-11 17:13:19 --> File loaded: application/views/loginView.php
DEBUG - 2015-12-11 17:13:19 --> Final output sent to browser
DEBUG - 2015-12-11 17:13:19 --> Total execution time: 0.0360
DEBUG - 2015-12-11 17:13:19 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:19 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:19 --> Router Class Initialized
ERROR - 2015-12-11 17:13:19 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 17:13:26 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:26 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Router Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Output Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Security Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Input Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:13:26 --> Language Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Loader Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:13:26 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Session Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:13:26 --> Session routines successfully run
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Controller Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Helper loaded: form_helper
DEBUG - 2015-12-11 17:13:26 --> Form Validation Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-12-11 17:13:26 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:26 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Router Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Output Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Security Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Input Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:13:26 --> Language Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Loader Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:13:26 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Session Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:13:26 --> Session routines successfully run
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Controller Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Helper loaded: form_helper
DEBUG - 2015-12-11 17:13:26 --> Form Validation Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Pagination Class Initialized
DEBUG - 2015-12-11 17:13:26 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 17:13:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 17:13:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 17:13:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 17:13:26 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 17:13:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-12-11 17:13:26 --> Final output sent to browser
DEBUG - 2015-12-11 17:13:26 --> Total execution time: 0.0418
DEBUG - 2015-12-11 17:13:26 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:26 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:26 --> Router Class Initialized
ERROR - 2015-12-11 17:13:26 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 17:13:30 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:30 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Router Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Output Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Security Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Input Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:13:30 --> Language Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Loader Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:13:30 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Session Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:13:30 --> Session routines successfully run
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Controller Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Pagination Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Helper loaded: form_helper
DEBUG - 2015-12-11 17:13:30 --> Form Validation Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Model Class Initialized
DEBUG - 2015-12-11 17:13:30 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 17:13:30 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-11 17:13:30 --> Final output sent to browser
DEBUG - 2015-12-11 17:13:30 --> Total execution time: 0.0430
DEBUG - 2015-12-11 17:13:30 --> Config Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:13:30 --> URI Class Initialized
DEBUG - 2015-12-11 17:13:30 --> Router Class Initialized
ERROR - 2015-12-11 17:13:30 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 17:14:06 --> Config Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:14:06 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:14:06 --> URI Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Router Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Output Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Security Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Input Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:14:06 --> Language Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Loader Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:14:06 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Session Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:14:06 --> Session routines successfully run
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Controller Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Pagination Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Helper loaded: form_helper
DEBUG - 2015-12-11 17:14:06 --> Form Validation Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:06 --> Model Class Initialized
ERROR - 2015-12-11 17:14:06 --> Severity: Notice  --> Undefined property: stdClass::$m_name /Applications/MAMP/htdocs/asmc/crm/application/controllers/form.php 94
ERROR - 2015-12-11 17:14:06 --> Severity: Notice  --> Undefined variable: crm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 130
ERROR - 2015-12-11 17:14:06 --> Severity: Notice  --> Undefined variable: sm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 132
DEBUG - 2015-12-11 17:14:06 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-11 17:14:06 --> Email Class Initialized
DEBUG - 2015-12-11 17:14:07 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-12-11 17:14:07 --> File loaded: application/views/header.php
ERROR - 2015-12-11 17:14:07 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-12-11 17:14:07 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-11 17:14:07 --> Final output sent to browser
DEBUG - 2015-12-11 17:14:07 --> Total execution time: 0.9416
DEBUG - 2015-12-11 17:14:08 --> Config Class Initialized
DEBUG - 2015-12-11 17:14:08 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:14:08 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:14:08 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:14:08 --> URI Class Initialized
DEBUG - 2015-12-11 17:14:08 --> Router Class Initialized
ERROR - 2015-12-11 17:14:08 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 17:14:45 --> Config Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:14:45 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:14:45 --> URI Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Router Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Output Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Security Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Input Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 17:14:45 --> Language Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Loader Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Helper loaded: url_helper
DEBUG - 2015-12-11 17:14:45 --> Database Driver Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Session Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Helper loaded: string_helper
DEBUG - 2015-12-11 17:14:45 --> Session routines successfully run
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Controller Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Pagination Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Helper loaded: form_helper
DEBUG - 2015-12-11 17:14:45 --> Form Validation Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Model Class Initialized
DEBUG - 2015-12-11 17:14:45 --> File loaded: application/views/form/email.php
DEBUG - 2015-12-11 17:14:45 --> Email Class Initialized
DEBUG - 2015-12-11 17:14:45 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-12-11 17:14:46 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 17:14:46 --> File loaded: application/views/form/index.php
DEBUG - 2015-12-11 17:14:46 --> Final output sent to browser
DEBUG - 2015-12-11 17:14:46 --> Total execution time: 0.4152
DEBUG - 2015-12-11 17:14:46 --> Config Class Initialized
DEBUG - 2015-12-11 17:14:46 --> Hooks Class Initialized
DEBUG - 2015-12-11 17:14:46 --> Utf8 Class Initialized
DEBUG - 2015-12-11 17:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 17:14:46 --> URI Class Initialized
DEBUG - 2015-12-11 17:14:46 --> Router Class Initialized
ERROR - 2015-12-11 17:14:46 --> 404 Page Not Found --> js
DEBUG - 2015-12-11 19:07:29 --> Config Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Hooks Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Utf8 Class Initialized
DEBUG - 2015-12-11 19:07:29 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 19:07:29 --> URI Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Router Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Output Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Security Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Input Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-12-11 19:07:29 --> Language Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Loader Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Helper loaded: url_helper
DEBUG - 2015-12-11 19:07:29 --> Database Driver Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Session Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Helper loaded: string_helper
DEBUG - 2015-12-11 19:07:29 --> Session routines successfully run
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Controller Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Model Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Helper loaded: form_helper
DEBUG - 2015-12-11 19:07:29 --> Form Validation Class Initialized
DEBUG - 2015-12-11 19:07:29 --> Pagination Class Initialized
DEBUG - 2015-12-11 19:07:29 --> File loaded: application/views/header.php
DEBUG - 2015-12-11 19:07:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-12-11 19:07:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-12-11 19:07:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-12-11 19:07:29 --> File loaded: application/views/footer.php
DEBUG - 2015-12-11 19:07:29 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-12-11 19:07:29 --> Final output sent to browser
DEBUG - 2015-12-11 19:07:29 --> Total execution time: 0.1049
DEBUG - 2015-12-11 19:07:30 --> Config Class Initialized
DEBUG - 2015-12-11 19:07:30 --> Hooks Class Initialized
DEBUG - 2015-12-11 19:07:30 --> Utf8 Class Initialized
DEBUG - 2015-12-11 19:07:30 --> UTF-8 Support Enabled
DEBUG - 2015-12-11 19:07:30 --> URI Class Initialized
DEBUG - 2015-12-11 19:07:30 --> Router Class Initialized
ERROR - 2015-12-11 19:07:30 --> 404 Page Not Found --> js
