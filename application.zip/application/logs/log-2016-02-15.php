<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-15 10:41:16 --> Config Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:41:16 --> URI Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Router Class Initialized
DEBUG - 2016-02-15 10:41:16 --> No URI present. Default controller set.
DEBUG - 2016-02-15 10:41:16 --> Output Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Security Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Input Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:41:16 --> Language Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Loader Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:41:16 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Session Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:41:16 --> A session cookie was not found.
DEBUG - 2016-02-15 10:41:16 --> Session routines successfully run
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Controller Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:16 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:41:16 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:41:16 --> File loaded: application/views/loginView.php
DEBUG - 2016-02-15 10:41:16 --> Final output sent to browser
DEBUG - 2016-02-15 10:41:16 --> Total execution time: 0.1226
DEBUG - 2016-02-15 10:41:26 --> Config Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:41:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:41:26 --> URI Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Router Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Output Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Security Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Input Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:41:26 --> Language Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Loader Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:41:26 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Session Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:41:26 --> Session routines successfully run
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Controller Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:41:26 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:41:26 --> Config Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:41:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:41:26 --> URI Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Router Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Output Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Security Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Input Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:41:26 --> Language Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Loader Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:41:26 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Session Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:41:26 --> Session routines successfully run
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Controller Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:41:26 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:41:26 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:41:26 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:41:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:41:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:41:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:41:26 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:41:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-02-15 10:41:26 --> Final output sent to browser
DEBUG - 2016-02-15 10:41:26 --> Total execution time: 0.0450
DEBUG - 2016-02-15 10:41:48 --> Config Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:41:48 --> URI Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Router Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Output Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Security Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Input Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:41:48 --> Language Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Loader Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:41:48 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Session Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:41:48 --> Session routines successfully run
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Controller Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:41:48 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> Model Class Initialized
DEBUG - 2016-02-15 10:41:48 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:41:48 --> File loaded: application/views/form/index.php
DEBUG - 2016-02-15 10:41:48 --> Final output sent to browser
DEBUG - 2016-02-15 10:41:48 --> Total execution time: 0.0610
DEBUG - 2016-02-15 10:42:18 --> Config Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:42:18 --> URI Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Router Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Output Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Security Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Input Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:42:18 --> Language Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Loader Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:42:18 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Session Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:42:18 --> Session routines successfully run
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Controller Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:42:18 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:18 --> Model Class Initialized
ERROR - 2016-02-15 10:42:18 --> Severity: Notice  --> Undefined variable: crm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 130
ERROR - 2016-02-15 10:42:18 --> Severity: Notice  --> Undefined variable: sm /Applications/MAMP/htdocs/asmc/crm/application/views/form/email.php 132
DEBUG - 2016-02-15 10:42:18 --> File loaded: application/views/form/email.php
DEBUG - 2016-02-15 10:42:18 --> Email Class Initialized
DEBUG - 2016-02-15 10:42:18 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:42:18 --> File loaded: application/views/form/index.php
DEBUG - 2016-02-15 10:42:18 --> Final output sent to browser
DEBUG - 2016-02-15 10:42:18 --> Total execution time: 0.1428
DEBUG - 2016-02-15 10:42:23 --> Config Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:42:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:42:23 --> URI Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Router Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Output Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Security Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Input Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:42:23 --> Language Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Loader Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:42:23 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Session Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:42:23 --> Session routines successfully run
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Controller Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:42:23 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:23 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:42:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:42:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:42:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:42:23 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:42:23 --> File loaded: application/views/form/list.php
DEBUG - 2016-02-15 10:42:23 --> Final output sent to browser
DEBUG - 2016-02-15 10:42:23 --> Total execution time: 0.0738
DEBUG - 2016-02-15 10:42:27 --> Config Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:42:27 --> URI Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Router Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Output Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Security Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Input Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:42:27 --> Language Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Loader Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:42:27 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Session Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:42:27 --> Session routines successfully run
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Controller Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:42:27 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:42:27 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:42:27 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:42:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:42:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:42:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:42:27 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:42:27 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-15 10:42:27 --> Final output sent to browser
DEBUG - 2016-02-15 10:42:27 --> Total execution time: 0.0585
DEBUG - 2016-02-15 10:42:59 --> Config Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:42:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:42:59 --> URI Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Router Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Output Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Security Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Input Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:42:59 --> Language Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Loader Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:42:59 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Session Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:42:59 --> Session routines successfully run
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Controller Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Model Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:42:59 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:42:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:42:59 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:42:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:42:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:42:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:42:59 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:42:59 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-15 10:42:59 --> Final output sent to browser
DEBUG - 2016-02-15 10:42:59 --> Total execution time: 0.0636
DEBUG - 2016-02-15 10:43:08 --> Config Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:43:08 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:43:08 --> URI Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Router Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Output Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Security Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Input Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:43:08 --> Language Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Loader Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:43:08 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Session Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:43:08 --> Session routines successfully run
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Controller Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:43:08 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:43:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:43:08 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:43:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:43:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:43:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:43:08 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:43:08 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-15 10:43:08 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:08 --> Total execution time: 0.0774
DEBUG - 2016-02-15 10:43:14 --> Config Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:43:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:43:14 --> URI Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Router Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Output Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Security Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Input Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:43:14 --> Language Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Loader Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:43:14 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Session Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:43:14 --> Session routines successfully run
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Controller Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:43:14 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:43:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:43:14 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:43:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:43:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:43:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:43:14 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:43:14 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-15 10:43:14 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:14 --> Total execution time: 0.0677
DEBUG - 2016-02-15 10:43:23 --> Config Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:43:23 --> URI Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Router Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Output Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Security Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Input Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:43:23 --> Language Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Loader Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:43:23 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Session Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:43:23 --> Session routines successfully run
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Controller Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:43:23 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:43:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:43:23 --> Helper loaded: pdf_helper
DEBUG - 2016-02-15 10:43:24 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-15 10:43:25 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-15 10:43:26 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-15 10:43:28 --> Config Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:43:28 --> URI Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Router Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Output Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Security Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Input Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:43:28 --> Language Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Loader Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:43:28 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Session Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:43:28 --> Session routines successfully run
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Controller Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Model Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:43:28 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:43:28 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:43:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-15 10:43:28 --> Final output sent to browser
DEBUG - 2016-02-15 10:43:28 --> Total execution time: 0.0589
DEBUG - 2016-02-15 10:44:09 --> Config Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:44:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:44:09 --> URI Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Router Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Output Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Security Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Input Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:44:09 --> Language Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Loader Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:44:09 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Session Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:44:09 --> Session routines successfully run
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Controller Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:44:09 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:44:09 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:44:09 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:44:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:44:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:44:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:44:09 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:44:09 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-15 10:44:09 --> Final output sent to browser
DEBUG - 2016-02-15 10:44:09 --> Total execution time: 0.0869
DEBUG - 2016-02-15 10:44:13 --> Config Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:44:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:44:13 --> URI Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Router Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Output Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Security Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Input Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:44:13 --> Language Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Loader Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:44:13 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Session Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:44:13 --> Session routines successfully run
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Controller Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:44:13 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:44:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:44:14 --> Helper loaded: pdf_helper
DEBUG - 2016-02-15 10:44:14 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-15 10:44:15 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-15 10:44:16 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-15 10:44:18 --> Config Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:44:18 --> URI Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Router Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Output Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Security Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Input Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:44:18 --> Language Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Loader Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:44:18 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Session Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:44:18 --> Session routines successfully run
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Controller Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Model Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:44:18 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:44:18 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:44:18 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-15 10:44:18 --> Final output sent to browser
DEBUG - 2016-02-15 10:44:18 --> Total execution time: 0.0556
DEBUG - 2016-02-15 10:45:23 --> Config Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:45:23 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:45:23 --> URI Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Router Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Output Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Security Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Input Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:45:23 --> Language Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Loader Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:45:23 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Session Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:45:23 --> Session routines successfully run
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Controller Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:45:23 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:45:23 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:45:23 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:45:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:45:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:45:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:45:23 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:45:23 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-15 10:45:23 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:23 --> Total execution time: 0.0835
DEBUG - 2016-02-15 10:45:32 --> Config Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:45:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:45:32 --> URI Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Router Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Output Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Security Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Input Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:45:32 --> Language Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Loader Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:45:32 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Session Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:45:32 --> Session routines successfully run
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Controller Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:45:32 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:45:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 10:45:32 --> Helper loaded: pdf_helper
DEBUG - 2016-02-15 10:45:33 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-15 10:45:34 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-15 10:45:35 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-15 10:45:37 --> Config Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Hooks Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Utf8 Class Initialized
DEBUG - 2016-02-15 10:45:37 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 10:45:37 --> URI Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Router Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Output Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Security Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Input Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 10:45:37 --> Language Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Loader Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Helper loaded: url_helper
DEBUG - 2016-02-15 10:45:37 --> Database Driver Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Session Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Helper loaded: string_helper
DEBUG - 2016-02-15 10:45:37 --> Session routines successfully run
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Controller Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Model Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Helper loaded: form_helper
DEBUG - 2016-02-15 10:45:37 --> Form Validation Class Initialized
DEBUG - 2016-02-15 10:45:37 --> Pagination Class Initialized
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 10:45:37 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-15 10:45:37 --> Final output sent to browser
DEBUG - 2016-02-15 10:45:37 --> Total execution time: 0.0563
DEBUG - 2016-02-15 12:38:59 --> Config Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:38:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:38:59 --> URI Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Router Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Output Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Security Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Input Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:38:59 --> Language Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Loader Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:38:59 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Session Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:38:59 --> Session routines successfully run
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Controller Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:38:59 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> Model Class Initialized
DEBUG - 2016-02-15 12:38:59 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:38:59 --> File loaded: application/views/form/index.php
DEBUG - 2016-02-15 12:38:59 --> Final output sent to browser
DEBUG - 2016-02-15 12:38:59 --> Total execution time: 0.1554
DEBUG - 2016-02-15 12:39:40 --> Config Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:39:40 --> URI Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Router Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Output Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Security Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Input Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:39:40 --> Language Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Loader Class Initialized
DEBUG - 2016-02-15 12:39:40 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:39:40 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Session Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:39:41 --> Session routines successfully run
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Controller Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:39:41 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:39:41 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:39:41 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:39:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:39:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:39:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:39:41 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:39:41 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-15 12:39:41 --> Final output sent to browser
DEBUG - 2016-02-15 12:39:41 --> Total execution time: 0.1165
DEBUG - 2016-02-15 12:40:14 --> Config Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:40:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:40:14 --> URI Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Router Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Output Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Security Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Input Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:40:14 --> Language Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Loader Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:40:14 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Session Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:40:14 --> Session routines successfully run
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Controller Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:40:14 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:40:14 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:40:14 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:40:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:40:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:40:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:40:14 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:40:14 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-15 12:40:14 --> Final output sent to browser
DEBUG - 2016-02-15 12:40:14 --> Total execution time: 0.0802
DEBUG - 2016-02-15 12:40:41 --> Config Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:40:41 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:40:41 --> URI Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Router Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Output Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Security Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Input Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:40:41 --> Language Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Loader Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:40:41 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Session Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:40:41 --> Session routines successfully run
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Controller Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:40:41 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:40:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 12:40:41 --> Helper loaded: pdf_helper
DEBUG - 2016-02-15 12:40:41 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-15 12:40:43 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-02-15 12:40:44 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-02-15 12:40:45 --> Config Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:40:45 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:40:45 --> URI Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Router Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Output Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Security Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Input Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:40:45 --> Language Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Loader Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:40:45 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Session Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:40:45 --> Session routines successfully run
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Controller Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Model Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:40:45 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:40:45 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:40:45 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-15 12:40:45 --> Final output sent to browser
DEBUG - 2016-02-15 12:40:45 --> Total execution time: 0.0794
DEBUG - 2016-02-15 12:41:13 --> Config Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:41:13 --> URI Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Router Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Output Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Security Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Input Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:41:13 --> Language Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Loader Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:41:13 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Session Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:41:13 --> Session routines successfully run
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Controller Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:41:13 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:41:13 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:41:13 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:41:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:41:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:41:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:41:13 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:41:13 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-15 12:41:13 --> Final output sent to browser
DEBUG - 2016-02-15 12:41:13 --> Total execution time: 0.0832
DEBUG - 2016-02-15 12:41:39 --> Config Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:41:39 --> URI Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Router Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Output Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Security Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Input Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:41:39 --> Language Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Loader Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:41:39 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Session Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:41:39 --> Session routines successfully run
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Controller Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:41:39 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:41:39 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:41:39 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:41:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:41:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:41:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:41:39 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:41:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-02-15 12:41:39 --> Final output sent to browser
DEBUG - 2016-02-15 12:41:39 --> Total execution time: 0.0961
DEBUG - 2016-02-15 12:41:43 --> Config Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:41:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:41:43 --> URI Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Router Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Output Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Security Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Input Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:41:43 --> Language Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Loader Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:41:43 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Session Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:41:43 --> Session routines successfully run
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Controller Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:41:43 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:41:43 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:41:43 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:41:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:41:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:41:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:41:43 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:41:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-15 12:41:43 --> Final output sent to browser
DEBUG - 2016-02-15 12:41:43 --> Total execution time: 0.0712
DEBUG - 2016-02-15 12:41:55 --> Config Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:41:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:41:55 --> URI Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Router Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Output Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Security Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Input Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:41:55 --> Language Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Loader Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:41:55 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Session Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:41:55 --> Session routines successfully run
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Controller Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:41:55 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:41:55 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:41:55 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:41:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:41:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:41:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:41:55 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:41:55 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-02-15 12:41:55 --> Final output sent to browser
DEBUG - 2016-02-15 12:41:55 --> Total execution time: 0.0620
DEBUG - 2016-02-15 12:41:58 --> Config Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:41:58 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:41:58 --> URI Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Router Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Output Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Security Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Input Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:41:58 --> Language Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Loader Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:41:58 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Session Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:41:58 --> Session routines successfully run
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Controller Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Model Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:41:58 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:41:58 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:41:58 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:41:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:41:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:41:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:41:58 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:41:58 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-15 12:41:58 --> Final output sent to browser
DEBUG - 2016-02-15 12:41:58 --> Total execution time: 0.0669
DEBUG - 2016-02-15 12:44:44 --> Config Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:44:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:44:44 --> URI Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Router Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Output Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Security Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Input Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:44:44 --> Language Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Loader Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:44:44 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Session Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:44:44 --> Session routines successfully run
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Controller Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:44:44 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:44:44 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:44:44 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:44:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:44:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:44:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:44:44 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:44:44 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-15 12:44:44 --> Final output sent to browser
DEBUG - 2016-02-15 12:44:44 --> Total execution time: 0.1042
DEBUG - 2016-02-15 12:44:49 --> Config Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:44:49 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:44:49 --> URI Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Router Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Output Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Security Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Input Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:44:49 --> Language Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Loader Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:44:49 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Session Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:44:49 --> Session routines successfully run
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Controller Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:44:49 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:44:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-15 12:44:49 --> Helper loaded: pdf_helper
DEBUG - 2016-02-15 12:44:50 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-15 12:44:51 --> File loaded: application/views/invoice/pdf/agreementProgressivePDF.php
DEBUG - 2016-02-15 12:44:52 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/invoice/pdf/payoutProgressivePDF.php
DEBUG - 2016-02-15 12:44:54 --> Config Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Hooks Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Utf8 Class Initialized
DEBUG - 2016-02-15 12:44:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-15 12:44:54 --> URI Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Router Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Output Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Security Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Input Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-15 12:44:54 --> Language Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Loader Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Helper loaded: url_helper
DEBUG - 2016-02-15 12:44:54 --> Database Driver Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Session Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Helper loaded: string_helper
DEBUG - 2016-02-15 12:44:54 --> Session routines successfully run
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Controller Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Model Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Helper loaded: form_helper
DEBUG - 2016-02-15 12:44:54 --> Form Validation Class Initialized
DEBUG - 2016-02-15 12:44:54 --> Pagination Class Initialized
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/header.php
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/footer.php
DEBUG - 2016-02-15 12:44:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-15 12:44:54 --> Final output sent to browser
DEBUG - 2016-02-15 12:44:54 --> Total execution time: 0.0580
