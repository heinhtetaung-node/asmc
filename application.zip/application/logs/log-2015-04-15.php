<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-15 09:15:33 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:15:33 --> URI Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Router Class Initialized
DEBUG - 2015-04-15 09:15:33 --> No URI present. Default controller set.
DEBUG - 2015-04-15 09:15:33 --> Output Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Security Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Input Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:15:33 --> Language Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Loader Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:15:33 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Session Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:15:33 --> A session cookie was not found.
DEBUG - 2015-04-15 09:15:33 --> Session routines successfully run
DEBUG - 2015-04-15 09:15:33 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Controller Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:33 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:15:33 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:15:33 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-15 09:15:33 --> Final output sent to browser
DEBUG - 2015-04-15 09:15:33 --> Total execution time: 0.0763
DEBUG - 2015-04-15 09:15:55 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:15:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:15:55 --> URI Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Router Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Output Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Security Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Input Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:15:55 --> Language Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Loader Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:15:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Session Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:15:55 --> Session routines successfully run
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Controller Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:15:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-15 09:15:55 --> Config Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:15:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:15:55 --> URI Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Router Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Output Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Security Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Input Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:15:55 --> Language Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Loader Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:15:55 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Session Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:15:55 --> Session routines successfully run
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Controller Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Model Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:15:55 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:15:55 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:15:55 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:15:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:15:55 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:15:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:15:55 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:15:55 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-15 09:15:55 --> Final output sent to browser
DEBUG - 2015-04-15 09:15:55 --> Total execution time: 0.0482
DEBUG - 2015-04-15 09:16:00 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:00 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:00 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:00 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:01 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:01 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:01 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:01 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:01 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:01 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:16:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:16:01 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:16:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:16:01 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:16:01 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-15 09:16:01 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:01 --> Total execution time: 0.0518
DEBUG - 2015-04-15 09:16:02 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:02 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:02 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:02 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:02 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:02 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:02 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:02 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:02 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:16:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:16:02 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:16:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:16:02 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:16:02 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-04-15 09:16:02 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:02 --> Total execution time: 0.0428
DEBUG - 2015-04-15 09:16:03 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:03 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:03 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:03 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:03 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:03 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:03 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:03 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:16:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:16:03 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:16:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:16:03 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:16:03 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-04-15 09:16:03 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:03 --> Total execution time: 0.0486
DEBUG - 2015-04-15 09:16:04 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:04 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:04 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:04 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:04 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:04 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:04 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:16:04 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:16:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:16:04 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:16:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:16:04 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:16:04 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-15 09:16:04 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:04 --> Total execution time: 0.0545
DEBUG - 2015-04-15 09:16:05 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:05 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:05 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:05 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:05 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:16:05 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:16:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:16:05 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:16:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:16:05 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:16:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-15 09:16:05 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:05 --> Total execution time: 0.0507
DEBUG - 2015-04-15 09:16:06 --> Config Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:16:06 --> URI Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Router Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Output Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Security Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Input Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:16:06 --> Language Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Loader Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:16:06 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Session Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:16:06 --> Session routines successfully run
DEBUG - 2015-04-15 09:16:06 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Controller Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Model Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:16:06 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:16:06 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:16:06 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:16:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:16:06 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:16:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:16:06 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:16:06 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-15 09:16:06 --> Final output sent to browser
DEBUG - 2015-04-15 09:16:06 --> Total execution time: 0.0444
DEBUG - 2015-04-15 09:17:03 --> Config Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:17:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:17:03 --> URI Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Router Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Output Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Security Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Input Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:17:03 --> Language Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Loader Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:17:03 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Session Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:17:03 --> Session routines successfully run
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Controller Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:17:03 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:17:03 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:17:03 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:17:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:17:03 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:17:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:17:03 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:17:03 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-15 09:17:03 --> Final output sent to browser
DEBUG - 2015-04-15 09:17:03 --> Total execution time: 0.0539
DEBUG - 2015-04-15 09:17:05 --> Config Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:17:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:17:05 --> URI Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Router Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Output Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Security Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Input Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:17:05 --> Language Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Loader Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:17:05 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Session Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:17:05 --> Session routines successfully run
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Controller Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Model Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:17:05 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:17:05 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:17:05 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:17:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:17:05 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:17:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:17:05 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:17:05 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-15 09:17:05 --> Final output sent to browser
DEBUG - 2015-04-15 09:17:05 --> Total execution time: 0.0665
DEBUG - 2015-04-15 09:18:43 --> Config Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Hooks Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Utf8 Class Initialized
DEBUG - 2015-04-15 09:18:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-15 09:18:43 --> URI Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Router Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Output Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Security Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Input Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-15 09:18:43 --> Language Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Loader Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Helper loaded: url_helper
DEBUG - 2015-04-15 09:18:43 --> Database Driver Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Session Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Helper loaded: string_helper
DEBUG - 2015-04-15 09:18:43 --> Session routines successfully run
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Controller Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Model Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Helper loaded: form_helper
DEBUG - 2015-04-15 09:18:43 --> Form Validation Class Initialized
DEBUG - 2015-04-15 09:18:43 --> Pagination Class Initialized
DEBUG - 2015-04-15 09:18:43 --> File loaded: application/views/header.php
DEBUG - 2015-04-15 09:18:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-15 09:18:43 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-15 09:18:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-15 09:18:43 --> File loaded: application/views/footer.php
DEBUG - 2015-04-15 09:18:43 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-15 09:18:43 --> Final output sent to browser
DEBUG - 2015-04-15 09:18:43 --> Total execution time: 0.0563
