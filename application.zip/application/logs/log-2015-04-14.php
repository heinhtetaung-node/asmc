<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-14 14:17:26 --> Config Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:17:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:17:26 --> URI Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Router Class Initialized
DEBUG - 2015-04-14 14:17:26 --> No URI present. Default controller set.
DEBUG - 2015-04-14 14:17:26 --> Output Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Security Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Input Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:17:26 --> Language Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Loader Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:17:26 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Session Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:17:26 --> A session cookie was not found.
DEBUG - 2015-04-14 14:17:26 --> Session routines successfully run
DEBUG - 2015-04-14 14:17:26 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Controller Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:26 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:17:26 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:17:26 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-14 14:17:26 --> Final output sent to browser
DEBUG - 2015-04-14 14:17:26 --> Total execution time: 0.0567
DEBUG - 2015-04-14 14:17:37 --> Config Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:17:37 --> URI Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Router Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Output Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Security Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Input Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:17:37 --> Language Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Loader Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:17:37 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Session Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:17:37 --> Session routines successfully run
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Controller Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:17:37 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-14 14:17:37 --> Config Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:17:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:17:37 --> URI Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Router Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Output Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Security Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Input Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:17:37 --> Language Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Loader Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:17:37 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Session Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:17:37 --> Session routines successfully run
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Controller Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Model Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:17:37 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:17:37 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:17:37 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:17:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:17:37 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-04-14 14:17:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:17:37 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:17:37 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-14 14:17:37 --> Final output sent to browser
DEBUG - 2015-04-14 14:17:37 --> Total execution time: 0.0553
DEBUG - 2015-04-14 14:20:42 --> Config Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:20:42 --> URI Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Router Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Output Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Security Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Input Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:20:42 --> Language Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Loader Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:20:42 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Session Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:20:42 --> Session routines successfully run
DEBUG - 2015-04-14 14:20:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Controller Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:20:42 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:20:42 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:20:42 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:20:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:20:42 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-04-14 14:20:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:20:42 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:20:42 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-14 14:20:42 --> Final output sent to browser
DEBUG - 2015-04-14 14:20:42 --> Total execution time: 0.0620
DEBUG - 2015-04-14 14:20:44 --> Config Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:20:44 --> URI Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Router Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Output Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Security Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Input Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:20:44 --> Language Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Loader Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:20:44 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Session Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:20:44 --> Session routines successfully run
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Controller Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Model Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:20:44 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:20:44 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:20:44 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:20:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:20:44 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-04-14 14:20:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:20:44 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:20:44 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-14 14:20:44 --> Final output sent to browser
DEBUG - 2015-04-14 14:20:44 --> Total execution time: 0.0668
DEBUG - 2015-04-14 14:21:36 --> Config Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:21:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:21:36 --> URI Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Router Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Output Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Security Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Input Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:21:36 --> Language Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Loader Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:21:36 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Session Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:21:36 --> Session routines successfully run
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Controller Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:21:36 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Config Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:21:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:21:36 --> URI Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Router Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Output Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Security Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Input Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:21:36 --> Language Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Loader Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:21:36 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Session Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:21:36 --> Session routines successfully run
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Controller Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:36 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:21:36 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:21:36 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-14 14:21:36 --> Final output sent to browser
DEBUG - 2015-04-14 14:21:36 --> Total execution time: 0.0342
DEBUG - 2015-04-14 14:21:42 --> Config Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:21:42 --> URI Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Router Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Output Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Security Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Input Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:21:42 --> Language Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Loader Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:21:42 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Session Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:21:42 --> Session routines successfully run
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Controller Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:21:42 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-14 14:21:42 --> Config Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:21:42 --> URI Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Router Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Output Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Security Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Input Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:21:42 --> Language Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Loader Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:21:42 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Session Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:21:42 --> Session routines successfully run
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Controller Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:42 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:21:42 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:21:42 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:21:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:21:42 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-14 14:21:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:21:42 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:21:42 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-14 14:21:42 --> Final output sent to browser
DEBUG - 2015-04-14 14:21:42 --> Total execution time: 0.0404
DEBUG - 2015-04-14 14:21:43 --> Config Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:21:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:21:43 --> URI Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Router Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Output Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Security Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Input Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:21:43 --> Language Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Loader Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:21:43 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Session Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:21:43 --> Session routines successfully run
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Controller Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Model Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:21:43 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:21:43 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:21:43 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:21:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:21:43 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-14 14:21:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:21:43 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:21:43 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-14 14:21:43 --> Final output sent to browser
DEBUG - 2015-04-14 14:21:43 --> Total execution time: 0.0564
DEBUG - 2015-04-14 14:23:47 --> Config Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:23:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:23:47 --> URI Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Router Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Output Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Security Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Input Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:23:47 --> Language Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Loader Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:23:47 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Session Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:23:47 --> Session routines successfully run
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Controller Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:23:47 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Config Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:23:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:23:47 --> URI Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Router Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Output Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Security Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Input Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:23:47 --> Language Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Loader Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:23:47 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Session Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:23:47 --> Session routines successfully run
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Controller Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Model Class Initialized
DEBUG - 2015-04-14 14:23:47 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:23:47 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:23:47 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-14 14:23:47 --> Final output sent to browser
DEBUG - 2015-04-14 14:23:47 --> Total execution time: 0.0343
DEBUG - 2015-04-14 14:24:05 --> Config Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:24:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:24:05 --> URI Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Router Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Output Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Security Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Input Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:24:05 --> Language Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Loader Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:24:05 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Session Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:24:05 --> Session routines successfully run
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Controller Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:24:05 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-14 14:24:05 --> Config Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:24:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:24:05 --> URI Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Router Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Output Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Security Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Input Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:24:05 --> Language Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Loader Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:24:05 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Session Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:24:05 --> Session routines successfully run
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Controller Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:24:05 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:24:05 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:24:05 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:24:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:24:05 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-14 14:24:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:24:05 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:24:05 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-14 14:24:05 --> Final output sent to browser
DEBUG - 2015-04-14 14:24:05 --> Total execution time: 0.0404
DEBUG - 2015-04-14 14:24:08 --> Config Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:24:08 --> URI Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Router Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Output Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Security Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Input Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:24:08 --> Language Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Loader Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:24:08 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Session Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:24:08 --> Session routines successfully run
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Controller Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:24:08 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:24:08 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:24:08 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:24:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:24:08 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-14 14:24:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:24:08 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:24:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-14 14:24:08 --> Final output sent to browser
DEBUG - 2015-04-14 14:24:08 --> Total execution time: 0.0504
DEBUG - 2015-04-14 14:24:14 --> Config Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:24:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:24:14 --> URI Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Router Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Output Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Security Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Input Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:24:14 --> Language Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Loader Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:24:14 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Session Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:24:14 --> Session routines successfully run
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Controller Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:24:14 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:24:14 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:24:14 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:24:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:24:14 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-14 14:24:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:24:14 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:24:14 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-14 14:24:14 --> Final output sent to browser
DEBUG - 2015-04-14 14:24:14 --> Total execution time: 0.0516
DEBUG - 2015-04-14 14:24:22 --> Config Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:24:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:24:22 --> URI Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Router Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Output Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Security Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Input Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:24:22 --> Language Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Loader Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:24:22 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Session Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:24:22 --> Session routines successfully run
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Controller Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Model Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:24:22 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:24:22 --> Helper loaded: pdf_helper
DEBUG - 2015-04-14 14:24:23 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-04-14 14:24:23 --> Final output sent to browser
DEBUG - 2015-04-14 14:24:23 --> Total execution time: 1.4287
DEBUG - 2015-04-14 14:27:24 --> Config Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:27:24 --> URI Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Router Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Output Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Security Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Input Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:27:24 --> Language Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Loader Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:27:24 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Session Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:27:24 --> Session routines successfully run
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Controller Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Model Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:27:24 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:27:24 --> Helper loaded: pdf_helper
DEBUG - 2015-04-14 14:27:25 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-04-14 14:27:25 --> Final output sent to browser
DEBUG - 2015-04-14 14:27:25 --> Total execution time: 1.3372
DEBUG - 2015-04-14 14:28:42 --> Config Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:28:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:28:42 --> URI Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Router Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Output Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Security Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Input Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:28:42 --> Language Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Loader Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:28:42 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Session Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:28:42 --> Session routines successfully run
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Controller Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:28:42 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:28:42 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:28:42 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:28:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:28:42 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-14 14:28:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:28:42 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:28:42 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-14 14:28:42 --> Final output sent to browser
DEBUG - 2015-04-14 14:28:42 --> Total execution time: 0.0502
DEBUG - 2015-04-14 14:28:52 --> Config Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:28:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:28:52 --> URI Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Router Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Output Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Security Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Input Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:28:52 --> Language Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Loader Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:28:52 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Session Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:28:52 --> Session routines successfully run
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Controller Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Model Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:28:52 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:28:52 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:28:52 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:28:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:28:52 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-14 14:28:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:28:52 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:28:52 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-14 14:28:52 --> Final output sent to browser
DEBUG - 2015-04-14 14:28:52 --> Total execution time: 0.0528
DEBUG - 2015-04-14 14:29:42 --> Config Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Hooks Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Utf8 Class Initialized
DEBUG - 2015-04-14 14:29:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-14 14:29:42 --> URI Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Router Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Output Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Security Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Input Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-14 14:29:42 --> Language Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Loader Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Helper loaded: url_helper
DEBUG - 2015-04-14 14:29:42 --> Database Driver Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Session Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Helper loaded: string_helper
DEBUG - 2015-04-14 14:29:42 --> Session routines successfully run
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Controller Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Model Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Helper loaded: form_helper
DEBUG - 2015-04-14 14:29:42 --> Form Validation Class Initialized
DEBUG - 2015-04-14 14:29:42 --> Pagination Class Initialized
DEBUG - 2015-04-14 14:29:42 --> File loaded: application/views/header.php
DEBUG - 2015-04-14 14:29:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-14 14:29:42 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-14 14:29:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-14 14:29:42 --> File loaded: application/views/footer.php
DEBUG - 2015-04-14 14:29:42 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-14 14:29:42 --> Final output sent to browser
DEBUG - 2015-04-14 14:29:42 --> Total execution time: 0.0588
