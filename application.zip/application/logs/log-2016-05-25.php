<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-25 09:35:03 --> Severity: Notice  --> Only variable references should be returned by reference /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 257
DEBUG - 2016-05-25 09:35:03 --> Config Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Hooks Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Utf8 Class Initialized
DEBUG - 2016-05-25 09:35:03 --> UTF-8 Support Enabled
DEBUG - 2016-05-25 09:35:03 --> URI Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Router Class Initialized
DEBUG - 2016-05-25 09:35:03 --> No URI present. Default controller set.
DEBUG - 2016-05-25 09:35:03 --> Output Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Security Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Input Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-05-25 09:35:03 --> Language Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Loader Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Helper loaded: url_helper
DEBUG - 2016-05-25 09:35:03 --> Database Driver Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Session Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Helper loaded: string_helper
DEBUG - 2016-05-25 09:35:03 --> A session cookie was not found.
ERROR - 2016-05-25 09:35:03 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2016-05-25 09:35:03 --> Session routines successfully run
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Controller Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Model Class Initialized
DEBUG - 2016-05-25 09:35:03 --> Helper loaded: form_helper
DEBUG - 2016-05-25 09:35:03 --> Form Validation Class Initialized
DEBUG - 2016-05-25 09:35:03 --> File loaded: application/views/loginView.php
DEBUG - 2016-05-25 09:35:03 --> Final output sent to browser
DEBUG - 2016-05-25 09:35:03 --> Total execution time: 0.0695
