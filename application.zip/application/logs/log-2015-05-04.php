<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-05-04 15:03:41 --> Config Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:03:41 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:03:41 --> URI Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Router Class Initialized
DEBUG - 2015-05-04 15:03:41 --> No URI present. Default controller set.
DEBUG - 2015-05-04 15:03:41 --> Output Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Security Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Input Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:03:41 --> Language Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Loader Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:03:41 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Session Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:03:41 --> A session cookie was not found.
DEBUG - 2015-05-04 15:03:41 --> Session routines successfully run
DEBUG - 2015-05-04 15:03:41 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Controller Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:41 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:03:41 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:03:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 15:03:41 --> Final output sent to browser
DEBUG - 2015-05-04 15:03:41 --> Total execution time: 0.1006
DEBUG - 2015-05-04 15:03:45 --> Config Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:03:45 --> URI Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Router Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Output Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Security Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Input Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:03:45 --> Language Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Loader Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:03:45 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Session Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:03:45 --> Session routines successfully run
DEBUG - 2015-05-04 15:03:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Controller Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:03:45 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:03:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 15:03:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 15:03:45 --> Final output sent to browser
DEBUG - 2015-05-04 15:03:45 --> Total execution time: 0.0528
DEBUG - 2015-05-04 15:03:52 --> Config Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:03:52 --> URI Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Router Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Output Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Security Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Input Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:03:52 --> Language Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Loader Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:03:52 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Session Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:03:52 --> Session routines successfully run
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Controller Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:03:52 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 15:03:52 --> Config Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:03:52 --> URI Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Router Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Output Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Security Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Input Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:03:52 --> Language Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Loader Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:03:52 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Session Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:03:52 --> Session routines successfully run
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Controller Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Model Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:03:52 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:03:52 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:03:52 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:03:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:03:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:03:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:03:52 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:03:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-04 15:03:52 --> Final output sent to browser
DEBUG - 2015-05-04 15:03:52 --> Total execution time: 0.0484
DEBUG - 2015-05-04 15:04:44 --> Config Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:04:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:04:44 --> URI Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Router Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Output Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Security Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Input Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:04:44 --> Language Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Loader Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:04:44 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Session Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:04:44 --> Session routines successfully run
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Controller Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:04:44 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:04:44 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:04:44 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:04:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:04:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:04:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:04:44 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:04:44 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-04 15:04:44 --> Final output sent to browser
DEBUG - 2015-05-04 15:04:44 --> Total execution time: 0.1221
DEBUG - 2015-05-04 15:04:48 --> Config Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:04:48 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:04:48 --> URI Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Router Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Output Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Security Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Input Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:04:48 --> Language Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Loader Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:04:48 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Session Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:04:48 --> Session routines successfully run
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Controller Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Model Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:04:48 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:04:48 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:04:48 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:04:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:04:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:04:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:04:48 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:04:48 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-04 15:04:48 --> Final output sent to browser
DEBUG - 2015-05-04 15:04:48 --> Total execution time: 0.0708
DEBUG - 2015-05-04 15:05:45 --> Config Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:05:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:05:45 --> URI Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Router Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Output Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Security Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Input Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:05:45 --> Language Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Loader Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:05:45 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Session Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:05:45 --> Session routines successfully run
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Controller Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:05:45 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:05:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 15:05:46 --> Helper loaded: pdf_helper
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-05-04 15:05:46 --> Config Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:05:46 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:05:46 --> URI Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Router Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Output Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Security Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Input Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:05:46 --> Language Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Loader Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:05:46 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Session Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:05:46 --> Session routines successfully run
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Controller Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Model Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:05:46 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:05:46 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:05:46 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-04 15:05:46 --> Final output sent to browser
DEBUG - 2015-05-04 15:05:46 --> Total execution time: 0.0596
DEBUG - 2015-05-04 15:08:31 --> Config Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:08:31 --> URI Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Router Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Output Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Security Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Input Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:08:31 --> Language Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Loader Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:08:31 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Session Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:08:31 --> Session routines successfully run
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Controller Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:08:31 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:08:31 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:08:31 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:08:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:08:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:08:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:08:31 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:08:31 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-04 15:08:31 --> Final output sent to browser
DEBUG - 2015-05-04 15:08:31 --> Total execution time: 0.0910
DEBUG - 2015-05-04 15:08:35 --> Config Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:08:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:08:35 --> URI Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Router Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Output Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Security Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Input Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:08:35 --> Language Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Loader Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:08:35 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Session Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:08:35 --> Session routines successfully run
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Controller Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:08:35 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:08:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 15:08:35 --> Helper loaded: pdf_helper
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-05-04 15:08:36 --> Config Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:08:36 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:08:36 --> URI Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Router Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Output Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Security Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Input Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:08:36 --> Language Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Loader Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:08:36 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Session Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:08:36 --> Session routines successfully run
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Controller Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:08:36 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:08:36 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:08:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-04 15:08:36 --> Final output sent to browser
DEBUG - 2015-05-04 15:08:36 --> Total execution time: 0.0534
DEBUG - 2015-05-04 15:08:45 --> Config Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:08:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:08:45 --> URI Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Router Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Output Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Security Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Input Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:08:45 --> Language Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Loader Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:08:45 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Session Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:08:45 --> Session routines successfully run
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Controller Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:08:45 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:08:45 --> Helper loaded: pdf_helper
DEBUG - 2015-05-04 15:08:46 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2015-05-04 15:08:46 --> Final output sent to browser
DEBUG - 2015-05-04 15:08:46 --> Total execution time: 1.4311
DEBUG - 2015-05-04 15:55:54 --> Config Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:55:54 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:55:54 --> URI Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Router Class Initialized
DEBUG - 2015-05-04 15:55:54 --> No URI present. Default controller set.
DEBUG - 2015-05-04 15:55:54 --> Output Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Security Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Input Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:55:54 --> Language Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Loader Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:55:54 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Session Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:55:54 --> Session routines successfully run
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Controller Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:55:54 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Config Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:55:54 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:55:54 --> URI Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Router Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Output Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Security Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Input Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:55:54 --> Language Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Loader Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:55:54 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Session Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:55:54 --> Session routines successfully run
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Controller Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Model Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:55:54 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:55:54 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:55:54 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:55:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:55:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:55:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:55:54 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:55:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-04 15:55:54 --> Final output sent to browser
DEBUG - 2015-05-04 15:55:54 --> Total execution time: 0.0434
DEBUG - 2015-05-04 15:56:01 --> Config Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Hooks Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Utf8 Class Initialized
DEBUG - 2015-05-04 15:56:01 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 15:56:01 --> URI Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Router Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Output Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Security Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Input Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 15:56:01 --> Language Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Loader Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Helper loaded: url_helper
DEBUG - 2015-05-04 15:56:01 --> Database Driver Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Session Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Helper loaded: string_helper
DEBUG - 2015-05-04 15:56:01 --> Session routines successfully run
DEBUG - 2015-05-04 15:56:01 --> Model Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Model Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Controller Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Model Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Helper loaded: form_helper
DEBUG - 2015-05-04 15:56:01 --> Form Validation Class Initialized
DEBUG - 2015-05-04 15:56:01 --> Pagination Class Initialized
DEBUG - 2015-05-04 15:56:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 15:56:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 15:56:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 15:56:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 15:56:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 15:56:01 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-05-04 15:56:01 --> Final output sent to browser
DEBUG - 2015-05-04 15:56:01 --> Total execution time: 0.0474
DEBUG - 2015-05-04 16:04:34 --> Config Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:04:34 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:04:34 --> URI Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Router Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Output Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Security Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Input Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:04:34 --> Language Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Loader Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:04:34 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Session Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:04:34 --> Session routines successfully run
DEBUG - 2015-05-04 16:04:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Controller Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:04:34 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:04:34 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:04:34 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:04:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:04:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:04:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:04:34 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:04:34 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-05-04 16:04:34 --> Final output sent to browser
DEBUG - 2015-05-04 16:04:34 --> Total execution time: 0.0685
DEBUG - 2015-05-04 16:04:39 --> Config Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:04:39 --> URI Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Router Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Output Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Security Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Input Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:04:39 --> Language Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Loader Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:04:39 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Session Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:04:39 --> Session routines successfully run
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Controller Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:04:39 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Config Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:04:39 --> URI Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Router Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Output Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Security Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Input Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:04:39 --> Language Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Loader Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:04:39 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Session Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:04:39 --> Session routines successfully run
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Controller Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:39 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:04:39 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:04:39 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 16:04:39 --> Final output sent to browser
DEBUG - 2015-05-04 16:04:39 --> Total execution time: 0.0348
DEBUG - 2015-05-04 16:04:50 --> Config Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:04:50 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:04:50 --> URI Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Router Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Output Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Security Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Input Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:04:50 --> Language Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Loader Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:04:50 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Session Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:04:50 --> Session routines successfully run
DEBUG - 2015-05-04 16:04:50 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Controller Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Model Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:04:50 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:04:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:04:50 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 16:04:50 --> Final output sent to browser
DEBUG - 2015-05-04 16:04:50 --> Total execution time: 0.0415
DEBUG - 2015-05-04 16:11:43 --> Config Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:11:43 --> URI Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Router Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Output Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Security Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Input Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:11:43 --> Language Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Loader Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:11:43 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Session Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:11:43 --> Session routines successfully run
DEBUG - 2015-05-04 16:11:43 --> Model Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Model Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Controller Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Model Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Model Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Model Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Model Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:11:43 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:11:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:11:43 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 16:11:43 --> Final output sent to browser
DEBUG - 2015-05-04 16:11:43 --> Total execution time: 0.0498
DEBUG - 2015-05-04 16:12:00 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:00 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:00 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:00 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:00 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:00 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:12:00 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:00 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:00 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:00 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:00 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:00 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:00 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:00 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:12:00 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:12:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:12:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:12:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:12:00 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:12:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-04 16:12:00 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:00 --> Total execution time: 0.0433
DEBUG - 2015-05-04 16:12:03 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:03 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:03 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:03 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:03 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:03 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:03 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:12:03 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:12:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:12:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:12:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:12:03 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:12:03 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-05-04 16:12:03 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:03 --> Total execution time: 0.0469
DEBUG - 2015-05-04 16:12:07 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:07 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:07 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:07 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:07 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:07 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:07 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:07 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:07 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:07 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:07 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:07 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:07 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 16:12:07 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:07 --> Total execution time: 0.0370
DEBUG - 2015-05-04 16:12:17 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:17 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:17 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:17 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:17 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:17 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:17 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:17 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:12:17 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 16:12:17 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:17 --> Total execution time: 0.0378
DEBUG - 2015-05-04 16:12:24 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:24 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:24 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:24 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:24 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:24 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:24 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:12:24 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:24 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:24 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:24 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:24 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:24 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:24 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:24 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:12:24 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:12:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:12:24 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-04 16:12:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:12:24 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:12:24 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-05-04 16:12:24 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:24 --> Total execution time: 0.0428
DEBUG - 2015-05-04 16:12:26 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:26 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:26 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:26 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:26 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:26 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:26 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:26 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:12:26 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:12:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:12:26 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-04 16:12:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:12:26 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:12:26 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-04 16:12:26 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:26 --> Total execution time: 0.0526
DEBUG - 2015-05-04 16:12:32 --> Config Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:12:32 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:12:32 --> URI Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Router Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Output Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Security Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Input Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:12:32 --> Language Class Initialized
DEBUG - 2015-05-04 16:12:32 --> Loader Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:12:33 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Session Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:12:33 --> Session routines successfully run
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Controller Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Model Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:12:33 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:12:33 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:12:33 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:12:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:12:33 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-04 16:12:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:12:33 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:12:33 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-04 16:12:33 --> Final output sent to browser
DEBUG - 2015-05-04 16:12:33 --> Total execution time: 0.0640
DEBUG - 2015-05-04 16:13:03 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:03 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:03 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:03 --> No URI present. Default controller set.
DEBUG - 2015-05-04 16:13:03 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:03 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:03 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:03 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:03 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:03 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:03 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:03 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:03 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:03 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:03 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:03 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:03 --> Total execution time: 0.0315
DEBUG - 2015-05-04 16:13:07 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:07 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:07 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:07 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:07 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:07 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:07 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:07 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:07 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:07 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:07 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:07 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:07 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-04 16:13:07 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:07 --> Total execution time: 0.0326
DEBUG - 2015-05-04 16:13:12 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:12 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:12 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:12 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:12 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:12 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:12 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:13:12 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:12 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:12 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:12 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:12 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:12 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:12 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:12 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:12 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:12 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-04 16:13:12 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:12 --> Total execution time: 0.0447
DEBUG - 2015-05-04 16:13:14 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:14 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:14 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:14 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:14 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:14 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:14 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:14 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:14 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:14 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:14 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-04 16:13:14 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:14 --> Total execution time: 0.0689
DEBUG - 2015-05-04 16:13:15 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:15 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:15 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:15 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:15 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:15 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:15 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:15 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:15 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:16 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:16 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-04 16:13:16 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:16 --> Total execution time: 0.0719
DEBUG - 2015-05-04 16:13:20 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:20 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:20 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:20 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:20 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:20 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:20 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:20 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:20 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:20 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:20 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-04 16:13:20 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:20 --> Total execution time: 0.0671
DEBUG - 2015-05-04 16:13:27 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:27 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:27 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:27 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:27 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:27 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:13:28 --> Helper loaded: pdf_helper
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-05-04 16:13:28 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:28 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:28 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:28 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:28 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:28 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:28 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:28 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-04 16:13:28 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:28 --> Total execution time: 0.0569
DEBUG - 2015-05-04 16:13:34 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:34 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:34 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:34 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:34 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:34 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:34 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:34 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:35 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:35 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:35 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-04 16:13:35 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:35 --> Total execution time: 0.0707
DEBUG - 2015-05-04 16:13:39 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:39 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:39 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:39 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:39 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:39 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: pdf_helper
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-05-04 16:13:39 --> Config Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Hooks Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Utf8 Class Initialized
DEBUG - 2015-05-04 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-04 16:13:39 --> URI Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Router Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Output Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Security Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Input Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-04 16:13:39 --> Language Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Loader Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: url_helper
DEBUG - 2015-05-04 16:13:39 --> Database Driver Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Session Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: string_helper
DEBUG - 2015-05-04 16:13:39 --> Session routines successfully run
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Controller Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Model Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Helper loaded: form_helper
DEBUG - 2015-05-04 16:13:39 --> Form Validation Class Initialized
DEBUG - 2015-05-04 16:13:39 --> Pagination Class Initialized
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/header.php
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/footer.php
DEBUG - 2015-05-04 16:13:39 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-04 16:13:39 --> Final output sent to browser
DEBUG - 2015-05-04 16:13:39 --> Total execution time: 0.0643
