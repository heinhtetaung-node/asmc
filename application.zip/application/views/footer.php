
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url();?>js/accordion.js"></script> 
<script src="<?php echo base_url();?>js/common-script.js"></script> 
<script src="<?php echo base_url();?>js/jquery.nicescroll.js"></script> 
<script src="<?php echo base_url();?>js/jquery.sparkline.js"></script> 
<script src="<?php echo base_url();?>js/sparkline-chart.js"></script> 
<script src="<?php echo base_url();?>js/graph.js"></script>
<script src="<?php echo base_url();?>js/edit-graph.js"></script>
<script src="<?php echo base_url();?>plugins/kalendar/kalendar.js" type="text/javascript"></script> 
<script src="<?php echo base_url();?>plugins/kalendar/edit-kalendar.js" type="text/javascript"></script> 
<script src="<?php echo base_url();?>plugins/knob/jquery.knob.min.js"></script> 
<!-- <script src="<?php echo base_url();?>plugins/demo-slider/demo-slider.js"></script> -->

</body>
</html>