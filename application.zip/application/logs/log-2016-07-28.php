<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-07-28 20:08:44 --> Config Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:08:44 --> URI Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Router Class Initialized
DEBUG - 2016-07-28 20:08:44 --> No URI present. Default controller set.
DEBUG - 2016-07-28 20:08:44 --> Output Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Security Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Input Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:08:44 --> Language Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Loader Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:08:44 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Session Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:08:44 --> A session cookie was not found.
DEBUG - 2016-07-28 20:08:44 --> Session routines successfully run
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Controller Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:44 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:08:44 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:08:44 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:08:44 --> Final output sent to browser
DEBUG - 2016-07-28 20:08:44 --> Total execution time: 0.1869
DEBUG - 2016-07-28 20:08:57 --> Config Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:08:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:08:57 --> URI Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Router Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Output Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Security Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Input Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:08:57 --> Language Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Loader Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:08:57 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Session Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:08:57 --> Session routines successfully run
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Controller Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:08:57 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:08:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:08:57 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:08:57 --> Final output sent to browser
DEBUG - 2016-07-28 20:08:57 --> Total execution time: 0.0320
DEBUG - 2016-07-28 20:11:47 --> Config Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:11:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:11:47 --> URI Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Router Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Output Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Security Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Input Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:11:47 --> Language Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Loader Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:11:47 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Session Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:11:47 --> Session routines successfully run
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Controller Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:11:47 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:11:47 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:11:47 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:11:47 --> Final output sent to browser
DEBUG - 2016-07-28 20:11:47 --> Total execution time: 0.0251
DEBUG - 2016-07-28 20:11:57 --> Config Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:11:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:11:57 --> URI Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Router Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Output Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Security Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Input Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:11:57 --> Language Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Loader Class Initialized
DEBUG - 2016-07-28 20:11:57 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:11:58 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Session Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:11:58 --> Session routines successfully run
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Controller Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Model Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:11:58 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:11:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:11:58 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:11:58 --> Final output sent to browser
DEBUG - 2016-07-28 20:11:58 --> Total execution time: 0.0249
DEBUG - 2016-07-28 20:12:03 --> Config Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:12:03 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:12:03 --> URI Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Router Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Output Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Security Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Input Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:12:03 --> Language Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Loader Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:12:03 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Session Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:12:03 --> Session routines successfully run
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Controller Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:12:03 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:12:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:12:03 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:12:03 --> Final output sent to browser
DEBUG - 2016-07-28 20:12:03 --> Total execution time: 0.0258
DEBUG - 2016-07-28 20:12:46 --> Config Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:12:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:12:46 --> URI Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Router Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Output Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Security Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Input Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:12:46 --> Language Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Loader Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:12:46 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Session Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:12:46 --> Session routines successfully run
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Controller Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:12:46 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:12:46 --> Config Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:12:46 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:12:46 --> URI Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Router Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Output Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Security Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Input Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:12:46 --> Language Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Loader Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:12:46 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Session Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:12:46 --> Session routines successfully run
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Controller Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:12:46 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:12:46 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:12:46 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:12:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:12:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:12:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:12:46 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:12:46 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:12:46 --> Final output sent to browser
DEBUG - 2016-07-28 20:12:46 --> Total execution time: 0.1117
DEBUG - 2016-07-28 20:12:54 --> Config Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:12:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:12:54 --> URI Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Router Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Output Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Security Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Input Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:12:54 --> Language Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Loader Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:12:54 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Session Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:12:54 --> Session routines successfully run
DEBUG - 2016-07-28 20:12:54 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Controller Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:12:54 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:12:54 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:12:54 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:12:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:12:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:12:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:12:54 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:12:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:12:54 --> Final output sent to browser
DEBUG - 2016-07-28 20:12:54 --> Total execution time: 0.0337
DEBUG - 2016-07-28 20:12:57 --> Config Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:12:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:12:57 --> URI Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Router Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Output Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Security Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Input Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:12:57 --> Language Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Loader Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:12:57 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Session Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:12:57 --> Session routines successfully run
DEBUG - 2016-07-28 20:12:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Controller Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:12:57 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:12:57 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:12:57 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:12:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:12:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:12:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:12:57 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:12:57 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-07-28 20:12:57 --> Final output sent to browser
DEBUG - 2016-07-28 20:12:57 --> Total execution time: 0.0627
DEBUG - 2016-07-28 20:13:07 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:07 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:07 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:07 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:07 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:07 --> Router Class Initialized
ERROR - 2016-07-28 20:13:07 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:13:08 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:08 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Router Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Output Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Security Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Input Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:13:08 --> Language Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Loader Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:13:08 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Session Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:13:08 --> Session routines successfully run
DEBUG - 2016-07-28 20:13:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Controller Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:13:08 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:13:08 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:13:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:13:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:13:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:13:08 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:13:08 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-07-28 20:13:08 --> Final output sent to browser
DEBUG - 2016-07-28 20:13:08 --> Total execution time: 0.0260
DEBUG - 2016-07-28 20:13:08 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:08 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:08 --> Router Class Initialized
ERROR - 2016-07-28 20:13:08 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:13:35 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:35 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Router Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Output Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Security Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Input Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:13:35 --> Language Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Loader Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:13:35 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Session Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:13:35 --> Session routines successfully run
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Controller Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:13:35 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:13:35 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:13:36 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:13:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:13:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:13:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:13:36 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:13:36 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-07-28 20:13:36 --> Final output sent to browser
DEBUG - 2016-07-28 20:13:36 --> Total execution time: 0.2584
DEBUG - 2016-07-28 20:13:36 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:36 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:36 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:36 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:36 --> Router Class Initialized
ERROR - 2016-07-28 20:13:36 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:13:41 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:41 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Router Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Output Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Security Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Input Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:13:41 --> Language Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Loader Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:13:41 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Session Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:13:41 --> Session routines successfully run
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Controller Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:13:41 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:41 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:13:41 --> File loaded: application/views/form/index.php
DEBUG - 2016-07-28 20:13:41 --> Final output sent to browser
DEBUG - 2016-07-28 20:13:41 --> Total execution time: 0.0514
DEBUG - 2016-07-28 20:13:41 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:41 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:41 --> Router Class Initialized
ERROR - 2016-07-28 20:13:41 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:13:45 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:45 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:45 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:45 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:45 --> Router Class Initialized
ERROR - 2016-07-28 20:13:45 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:13:48 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:48 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Router Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Output Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Security Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Input Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:13:48 --> Language Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Loader Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:13:48 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Session Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:13:48 --> Session routines successfully run
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Controller Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:13:48 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:13:48 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:13:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:13:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:13:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:13:48 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:13:48 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-07-28 20:13:48 --> Final output sent to browser
DEBUG - 2016-07-28 20:13:48 --> Total execution time: 0.0630
DEBUG - 2016-07-28 20:13:48 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:48 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:48 --> Router Class Initialized
ERROR - 2016-07-28 20:13:48 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:13:56 --> Config Class Initialized
DEBUG - 2016-07-28 20:13:56 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:13:56 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:13:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:13:56 --> URI Class Initialized
DEBUG - 2016-07-28 20:13:56 --> Router Class Initialized
ERROR - 2016-07-28 20:13:56 --> 404 Page Not Found --> js
DEBUG - 2016-07-28 20:16:40 --> Config Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:16:40 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:16:40 --> URI Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Router Class Initialized
DEBUG - 2016-07-28 20:16:40 --> No URI present. Default controller set.
DEBUG - 2016-07-28 20:16:40 --> Output Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Security Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Input Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:16:40 --> Language Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Loader Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:16:40 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Session Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:16:40 --> A session cookie was not found.
DEBUG - 2016-07-28 20:16:40 --> Session routines successfully run
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Controller Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Model Class Initialized
DEBUG - 2016-07-28 20:16:40 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:16:40 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:16:40 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:16:40 --> Final output sent to browser
DEBUG - 2016-07-28 20:16:40 --> Total execution time: 0.0233
DEBUG - 2016-07-28 20:17:11 --> Config Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:17:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:17:11 --> URI Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Router Class Initialized
DEBUG - 2016-07-28 20:17:11 --> No URI present. Default controller set.
DEBUG - 2016-07-28 20:17:11 --> Output Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Security Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Input Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:17:11 --> Language Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Loader Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:17:11 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Session Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:17:11 --> A session cookie was not found.
DEBUG - 2016-07-28 20:17:11 --> Session routines successfully run
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Controller Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:11 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:17:11 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:17:11 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:17:11 --> Final output sent to browser
DEBUG - 2016-07-28 20:17:11 --> Total execution time: 0.0232
DEBUG - 2016-07-28 20:17:22 --> Config Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:17:22 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:17:22 --> URI Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Router Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Output Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Security Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Input Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:17:22 --> Language Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Loader Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:17:22 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Session Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:17:22 --> Session routines successfully run
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Controller Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:17:22 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:17:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:17:22 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-28 20:17:22 --> Final output sent to browser
DEBUG - 2016-07-28 20:17:22 --> Total execution time: 0.0248
DEBUG - 2016-07-28 20:17:34 --> Config Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:17:34 --> URI Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Router Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Output Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Security Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Input Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:17:34 --> Language Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Loader Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:17:34 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Session Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:17:34 --> Session routines successfully run
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Controller Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:17:34 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-07-28 20:17:34 --> Config Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:17:34 --> URI Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Router Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Output Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Security Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Input Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:17:34 --> Language Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Loader Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:17:34 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Session Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:17:34 --> Session routines successfully run
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Controller Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:17:34 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:17:34 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:17:34 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:17:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:17:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:17:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:17:34 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:17:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:17:34 --> Final output sent to browser
DEBUG - 2016-07-28 20:17:34 --> Total execution time: 0.0260
DEBUG - 2016-07-28 20:18:08 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:08 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:08 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:08 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:08 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:08 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:08 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:08 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:08 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:08 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:18:08 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:08 --> Total execution time: 0.0310
DEBUG - 2016-07-28 20:18:10 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:10 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:10 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:10 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:10 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:10 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:10 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:10 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:10 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:10 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:10 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:10 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-07-28 20:18:10 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:10 --> Total execution time: 0.0251
DEBUG - 2016-07-28 20:18:14 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:14 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:14 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:14 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:14 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:14 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:14 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:14 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:14 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:14 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:14 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-07-28 20:18:14 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:14 --> Total execution time: 0.0344
DEBUG - 2016-07-28 20:18:15 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:15 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:15 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:15 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:15 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:15 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:15 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:15 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:15 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:15 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:15 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:15 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-07-28 20:18:15 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:15 --> Total execution time: 0.0372
DEBUG - 2016-07-28 20:18:18 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:18 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:18 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:18 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:18 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:18 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:18 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:18 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:18 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:18 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:18 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:18 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-07-28 20:18:18 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:18 --> Total execution time: 0.0649
DEBUG - 2016-07-28 20:18:20 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:20 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:20 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:20 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:20 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:20 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:20 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:20 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:20 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:20 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:20 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:20 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2016-07-28 20:18:20 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:20 --> Total execution time: 0.0349
DEBUG - 2016-07-28 20:18:23 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:23 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:23 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:23 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:23 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:23 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:23 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:23 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:23 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:23 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-07-28 20:18:23 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:23 --> Total execution time: 0.0540
DEBUG - 2016-07-28 20:18:24 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:24 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:24 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:24 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:24 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:24 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:24 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:24 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:24 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:24 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:24 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:24 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2016-07-28 20:18:24 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:24 --> Total execution time: 0.0263
DEBUG - 2016-07-28 20:18:28 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:28 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:28 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:28 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:28 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:28 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:28 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:28 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:28 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:28 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:28 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:28 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-07-28 20:18:28 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:28 --> Total execution time: 0.0286
DEBUG - 2016-07-28 20:18:29 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:29 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:29 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:29 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:29 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:29 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:29 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:29 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:29 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:29 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:29 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:29 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2016-07-28 20:18:29 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:29 --> Total execution time: 0.0266
DEBUG - 2016-07-28 20:18:32 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:32 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:32 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:32 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:32 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:32 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:32 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:32 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:32 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:32 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-07-28 20:18:32 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:32 --> Total execution time: 0.0530
DEBUG - 2016-07-28 20:18:33 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:33 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:33 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:33 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:33 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:33 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:33 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:33 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:33 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:18:33 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:33 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:33 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-07-28 20:18:33 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:33 --> Total execution time: 0.0259
DEBUG - 2016-07-28 20:18:35 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:35 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:35 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:35 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:35 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:35 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:35 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:35 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:35 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:35 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:35 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-07-28 20:18:35 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:35 --> Total execution time: 0.0279
DEBUG - 2016-07-28 20:18:37 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:37 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:37 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:37 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:37 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:37 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:37 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:37 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:37 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:37 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:37 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2016-07-28 20:18:37 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:37 --> Total execution time: 0.0267
DEBUG - 2016-07-28 20:18:38 --> Config Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:18:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:18:38 --> URI Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Router Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Output Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Security Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Input Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:18:38 --> Language Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Loader Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:18:38 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Session Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:18:38 --> Session routines successfully run
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Controller Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:18:38 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:18:38 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:18:38 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:18:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:18:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:18:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:18:38 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:18:38 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-07-28 20:18:38 --> Final output sent to browser
DEBUG - 2016-07-28 20:18:38 --> Total execution time: 0.0289
DEBUG - 2016-07-28 20:19:00 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:00 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:00 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:00 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:00 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:00 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:00 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:00 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:19:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:19:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:19:00 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:19:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-07-28 20:19:00 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:00 --> Total execution time: 0.2299
DEBUG - 2016-07-28 20:19:02 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:02 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:02 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:02 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:02 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:02 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:02 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:02 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:02 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:19:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:19:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:19:02 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:19:02 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-07-28 20:19:02 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:02 --> Total execution time: 0.0843
DEBUG - 2016-07-28 20:19:05 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:05 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:05 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:05 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:05 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:05 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:05 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:05 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:05 --> File loaded: application/views/form/index.php
DEBUG - 2016-07-28 20:19:05 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:05 --> Total execution time: 0.0374
DEBUG - 2016-07-28 20:19:10 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:10 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:10 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:10 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:10 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:10 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:10 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:10 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:10 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:10 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:19:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:19:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:19:10 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:19:10 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:19:10 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:10 --> Total execution time: 0.0260
DEBUG - 2016-07-28 20:19:12 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:12 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:12 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:12 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:12 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:12 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:12 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:12 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:12 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:12 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:19:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:19:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:19:12 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:19:12 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-07-28 20:19:12 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:12 --> Total execution time: 0.0250
DEBUG - 2016-07-28 20:19:16 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:16 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:16 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:16 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:16 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:16 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:16 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:16 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:16 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:16 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:19:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:19:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:19:16 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:19:16 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:19:16 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:16 --> Total execution time: 0.0260
DEBUG - 2016-07-28 20:19:17 --> Config Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:19:17 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:19:17 --> URI Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Router Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Output Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Security Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Input Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:19:17 --> Language Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Loader Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:19:17 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Session Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:19:17 --> Session routines successfully run
DEBUG - 2016-07-28 20:19:17 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Controller Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Model Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:19:17 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:19:17 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:19:17 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:19:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:19:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:19:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:19:17 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:19:17 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-07-28 20:19:17 --> Final output sent to browser
DEBUG - 2016-07-28 20:19:17 --> Total execution time: 0.0250
DEBUG - 2016-07-28 20:23:41 --> Config Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:23:41 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:23:41 --> URI Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Router Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Output Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Security Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Input Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:23:41 --> Language Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Loader Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:23:41 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Session Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:23:41 --> Session routines successfully run
DEBUG - 2016-07-28 20:23:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Controller Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:23:41 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:23:41 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:23:41 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:23:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:23:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:23:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:23:41 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:23:41 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-07-28 20:23:41 --> Final output sent to browser
DEBUG - 2016-07-28 20:23:41 --> Total execution time: 0.0260
DEBUG - 2016-07-28 20:23:48 --> Config Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:23:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:23:48 --> URI Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Router Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Output Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Security Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Input Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:23:48 --> Language Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Loader Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:23:48 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Session Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:23:48 --> Session routines successfully run
DEBUG - 2016-07-28 20:23:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Controller Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:23:48 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:23:48 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:23:48 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:23:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:23:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:23:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:23:48 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:23:48 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:23:48 --> Final output sent to browser
DEBUG - 2016-07-28 20:23:48 --> Total execution time: 0.0262
DEBUG - 2016-07-28 20:23:52 --> Config Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:23:52 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:23:52 --> URI Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Router Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Output Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Security Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Input Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:23:52 --> Language Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Loader Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:23:52 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Session Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:23:52 --> Session routines successfully run
DEBUG - 2016-07-28 20:23:52 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Controller Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:23:52 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:23:52 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:23:52 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:23:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:23:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:23:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:23:52 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:23:52 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-07-28 20:23:52 --> Final output sent to browser
DEBUG - 2016-07-28 20:23:52 --> Total execution time: 0.0769
DEBUG - 2016-07-28 20:23:54 --> Config Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:23:54 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:23:54 --> URI Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Router Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Output Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Security Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Input Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:23:54 --> Language Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Loader Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:23:54 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Session Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:23:54 --> Session routines successfully run
DEBUG - 2016-07-28 20:23:54 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Controller Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:23:54 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:23:54 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:23:54 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:23:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:23:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:23:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:23:54 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:23:54 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-07-28 20:23:54 --> Final output sent to browser
DEBUG - 2016-07-28 20:23:54 --> Total execution time: 0.0251
DEBUG - 2016-07-28 20:23:57 --> Config Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:23:57 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:23:57 --> URI Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Router Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Output Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Security Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Input Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:23:57 --> Language Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Loader Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:23:57 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Session Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:23:57 --> Session routines successfully run
DEBUG - 2016-07-28 20:23:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Controller Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Model Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:23:57 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:23:57 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:23:57 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:23:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:23:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:23:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:23:57 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:23:57 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2016-07-28 20:23:57 --> Final output sent to browser
DEBUG - 2016-07-28 20:23:57 --> Total execution time: 0.0275
DEBUG - 2016-07-28 20:24:06 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:06 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:06 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:06 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:06 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:06 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:06 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:06 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:24:06 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:06 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:06 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-07-28 20:24:06 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:06 --> Total execution time: 0.0286
DEBUG - 2016-07-28 20:24:08 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:08 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:08 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:08 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:08 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:08 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:08 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:08 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:24:08 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:08 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:08 --> File loaded: application/views/agent/addAgentView.php
DEBUG - 2016-07-28 20:24:08 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:08 --> Total execution time: 0.0265
DEBUG - 2016-07-28 20:24:11 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:11 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:11 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:11 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:11 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:11 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:11 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:24:11 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:11 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:11 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-07-28 20:24:11 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:11 --> Total execution time: 0.0379
DEBUG - 2016-07-28 20:24:14 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:14 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:14 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:14 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:14 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:14 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:14 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:14 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:14 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:24:14 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:14 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:14 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2016-07-28 20:24:14 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:14 --> Total execution time: 0.0617
DEBUG - 2016-07-28 20:24:23 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:23 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:23 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:23 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:23 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:23 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:23 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:23 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:23 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:23 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:23 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-07-28 20:24:23 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:23 --> Total execution time: 0.0336
DEBUG - 2016-07-28 20:24:32 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:32 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:32 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:32 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:32 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:32 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:32 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:32 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:32 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:32 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:32 --> File loaded: application/views/message/readView.php
DEBUG - 2016-07-28 20:24:32 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:32 --> Total execution time: 0.0275
DEBUG - 2016-07-28 20:24:36 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:36 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:36 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:36 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:36 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:36 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:36 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:36 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:36 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:36 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:36 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-07-28 20:24:36 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:36 --> Total execution time: 0.0279
DEBUG - 2016-07-28 20:24:39 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:39 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:39 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:39 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:39 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:39 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:39 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:39 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:39 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:39 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:39 --> File loaded: application/views/message/readView.php
DEBUG - 2016-07-28 20:24:39 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:39 --> Total execution time: 0.0271
DEBUG - 2016-07-28 20:24:44 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:44 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:44 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:44 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:44 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:44 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:44 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:44 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:44 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:44 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:44 --> File loaded: application/views/message/messageComposeView.php
DEBUG - 2016-07-28 20:24:44 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:44 --> Total execution time: 0.0265
DEBUG - 2016-07-28 20:24:48 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:48 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:48 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:48 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:48 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:48 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:48 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:48 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:48 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:48 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:48 --> File loaded: application/views/message/sentView.php
DEBUG - 2016-07-28 20:24:48 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:48 --> Total execution time: 0.0290
DEBUG - 2016-07-28 20:24:53 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:53 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:53 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:53 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:53 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:53 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:53 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:53 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:24:53 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:53 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:53 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-07-28 20:24:53 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:53 --> Total execution time: 0.2914
DEBUG - 2016-07-28 20:24:56 --> Config Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:24:56 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:24:56 --> URI Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Router Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Output Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Security Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Input Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:24:56 --> Language Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Loader Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:24:56 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Session Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:24:56 --> Session routines successfully run
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Controller Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Model Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:24:56 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:24:56 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:24:56 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:24:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:24:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:24:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:24:56 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:24:56 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-07-28 20:24:56 --> Final output sent to browser
DEBUG - 2016-07-28 20:24:56 --> Total execution time: 0.0435
DEBUG - 2016-07-28 20:25:00 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:00 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:00 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:00 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:00 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:00 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:00 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:00 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:00 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:25:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:25:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:25:00 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:25:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-07-28 20:25:00 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:00 --> Total execution time: 0.2755
DEBUG - 2016-07-28 20:25:11 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:11 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:11 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:11 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:11 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:11 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:11 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:11 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:12 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:25:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:25:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:25:12 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:25:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-07-28 20:25:12 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:12 --> Total execution time: 0.2446
DEBUG - 2016-07-28 20:25:34 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:34 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:34 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:34 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:34 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:34 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:34 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:34 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:34 --> File loaded: application/views/form/index.php
DEBUG - 2016-07-28 20:25:34 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:34 --> Total execution time: 0.0307
DEBUG - 2016-07-28 20:25:38 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:38 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:38 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:38 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:38 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:38 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:38 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:38 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:25:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:25:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:25:38 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:25:38 --> File loaded: application/views/form/list.php
DEBUG - 2016-07-28 20:25:38 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:38 --> Total execution time: 0.0487
DEBUG - 2016-07-28 20:25:43 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:43 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:43 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:43 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:43 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:43 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:43 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:43 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:25:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:25:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:25:43 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:25:43 --> File loaded: application/views/form/list.php
DEBUG - 2016-07-28 20:25:43 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:43 --> Total execution time: 0.0317
DEBUG - 2016-07-28 20:25:45 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:45 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:45 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:45 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:45 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:46 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:46 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:46 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:46 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:25:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:25:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:25:46 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:25:46 --> File loaded: application/views/form/list.php
DEBUG - 2016-07-28 20:25:46 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:46 --> Total execution time: 0.0502
DEBUG - 2016-07-28 20:25:49 --> Config Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:25:49 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:25:49 --> URI Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Router Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Output Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Security Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Input Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:25:49 --> Language Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Loader Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:25:49 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Session Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:25:49 --> Session routines successfully run
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Controller Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Model Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:25:49 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:25:49 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:25:49 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:25:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:25:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:25:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:25:49 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:25:49 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-07-28 20:25:49 --> Final output sent to browser
DEBUG - 2016-07-28 20:25:49 --> Total execution time: 0.0440
DEBUG - 2016-07-28 20:26:01 --> Config Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:26:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:26:01 --> URI Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Router Class Initialized
DEBUG - 2016-07-28 20:26:01 --> No URI present. Default controller set.
DEBUG - 2016-07-28 20:26:01 --> Output Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Security Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Input Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:26:01 --> Language Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Loader Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:26:01 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Session Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:26:01 --> Session routines successfully run
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Controller Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:26:01 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Config Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Hooks Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Utf8 Class Initialized
DEBUG - 2016-07-28 20:26:01 --> UTF-8 Support Enabled
DEBUG - 2016-07-28 20:26:01 --> URI Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Router Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Output Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Security Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Input Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-28 20:26:01 --> Language Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Loader Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Helper loaded: url_helper
DEBUG - 2016-07-28 20:26:01 --> Database Driver Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Session Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Helper loaded: string_helper
DEBUG - 2016-07-28 20:26:01 --> Session routines successfully run
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Controller Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Model Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Helper loaded: form_helper
DEBUG - 2016-07-28 20:26:01 --> Form Validation Class Initialized
DEBUG - 2016-07-28 20:26:01 --> Pagination Class Initialized
DEBUG - 2016-07-28 20:26:01 --> File loaded: application/views/header.php
DEBUG - 2016-07-28 20:26:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-07-28 20:26:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-07-28 20:26:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-07-28 20:26:01 --> File loaded: application/views/footer.php
DEBUG - 2016-07-28 20:26:01 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-07-28 20:26:01 --> Final output sent to browser
DEBUG - 2016-07-28 20:26:01 --> Total execution time: 0.0262
