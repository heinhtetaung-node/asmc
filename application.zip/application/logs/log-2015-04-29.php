<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-29 11:58:39 --> Config Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Hooks Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Utf8 Class Initialized
DEBUG - 2015-04-29 11:58:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 11:58:39 --> URI Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Router Class Initialized
DEBUG - 2015-04-29 11:58:39 --> No URI present. Default controller set.
DEBUG - 2015-04-29 11:58:39 --> Output Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Security Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Input Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 11:58:39 --> Language Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Loader Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Helper loaded: url_helper
DEBUG - 2015-04-29 11:58:39 --> Database Driver Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Session Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Helper loaded: string_helper
DEBUG - 2015-04-29 11:58:39 --> A session cookie was not found.
DEBUG - 2015-04-29 11:58:39 --> Session routines successfully run
DEBUG - 2015-04-29 11:58:39 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Controller Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:39 --> Helper loaded: form_helper
DEBUG - 2015-04-29 11:58:39 --> Form Validation Class Initialized
DEBUG - 2015-04-29 11:58:39 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-29 11:58:39 --> Final output sent to browser
DEBUG - 2015-04-29 11:58:39 --> Total execution time: 0.0765
DEBUG - 2015-04-29 11:58:49 --> Config Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Hooks Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Utf8 Class Initialized
DEBUG - 2015-04-29 11:58:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 11:58:49 --> URI Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Router Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Output Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Security Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Input Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 11:58:49 --> Language Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Loader Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Helper loaded: url_helper
DEBUG - 2015-04-29 11:58:49 --> Database Driver Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Session Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Helper loaded: string_helper
DEBUG - 2015-04-29 11:58:49 --> Session routines successfully run
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Controller Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Helper loaded: form_helper
DEBUG - 2015-04-29 11:58:49 --> Form Validation Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-29 11:58:49 --> Config Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Hooks Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Utf8 Class Initialized
DEBUG - 2015-04-29 11:58:49 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 11:58:49 --> URI Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Router Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Output Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Security Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Input Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 11:58:49 --> Language Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Loader Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Helper loaded: url_helper
DEBUG - 2015-04-29 11:58:49 --> Database Driver Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Session Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Helper loaded: string_helper
DEBUG - 2015-04-29 11:58:49 --> Session routines successfully run
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Controller Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Model Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Helper loaded: form_helper
DEBUG - 2015-04-29 11:58:49 --> Form Validation Class Initialized
DEBUG - 2015-04-29 11:58:49 --> Pagination Class Initialized
DEBUG - 2015-04-29 11:58:49 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 11:58:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 11:58:49 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-04-29 11:58:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 11:58:49 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 11:58:49 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-29 11:58:49 --> Final output sent to browser
DEBUG - 2015-04-29 11:58:49 --> Total execution time: 0.0604
DEBUG - 2015-04-29 12:05:22 --> Config Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:05:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:05:22 --> URI Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Router Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Output Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Security Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Input Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:05:22 --> Language Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Loader Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:05:22 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Session Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:05:22 --> Session routines successfully run
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Controller Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:05:22 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Config Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:05:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:05:22 --> URI Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Router Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Output Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Security Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Input Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:05:22 --> Language Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Loader Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:05:22 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Session Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:05:22 --> Session routines successfully run
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Controller Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:05:22 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:05:22 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:05:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-29 12:05:22 --> Final output sent to browser
DEBUG - 2015-04-29 12:05:22 --> Total execution time: 0.0325
DEBUG - 2015-04-29 12:06:30 --> Config Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:06:30 --> URI Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Router Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Output Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Security Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Input Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:06:30 --> Language Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Loader Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:06:30 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Session Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:06:30 --> Session routines successfully run
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Controller Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:06:30 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-29 12:06:30 --> Config Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:06:30 --> URI Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Router Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Output Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Security Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Input Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:06:30 --> Language Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Loader Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:06:30 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Session Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:06:30 --> Session routines successfully run
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Controller Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Model Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:06:30 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:06:30 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:06:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:06:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:06:30 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:06:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:06:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:06:30 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-29 12:06:30 --> Final output sent to browser
DEBUG - 2015-04-29 12:06:30 --> Total execution time: 0.0442
DEBUG - 2015-04-29 12:07:22 --> Config Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:07:22 --> URI Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Router Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Output Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Security Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Input Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:07:22 --> Language Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Loader Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:07:22 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Session Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:07:22 --> Session routines successfully run
DEBUG - 2015-04-29 12:07:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:22 --> Controller Class Initialized
DEBUG - 2015-04-29 12:07:23 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:23 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:07:23 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:07:23 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:07:23 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:07:23 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:07:23 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:07:23 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:07:23 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:07:23 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-29 12:07:23 --> Final output sent to browser
DEBUG - 2015-04-29 12:07:23 --> Total execution time: 0.0422
DEBUG - 2015-04-29 12:07:25 --> Config Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:07:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:07:25 --> URI Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Router Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Output Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Security Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Input Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:07:25 --> Language Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Loader Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:07:25 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Session Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:07:25 --> Session routines successfully run
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Controller Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Model Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:07:25 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:07:25 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:07:25 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:07:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:07:25 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:07:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:07:25 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:07:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:07:25 --> Final output sent to browser
DEBUG - 2015-04-29 12:07:25 --> Total execution time: 0.0556
DEBUG - 2015-04-29 12:08:32 --> Config Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:08:32 --> URI Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Router Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Output Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Security Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Input Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:08:32 --> Language Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Loader Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:08:32 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Session Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:08:32 --> Session routines successfully run
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Controller Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:08:32 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:08:32 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:08:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:08:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:08:32 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:08:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:08:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:08:32 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:08:32 --> Final output sent to browser
DEBUG - 2015-04-29 12:08:32 --> Total execution time: 0.0432
DEBUG - 2015-04-29 12:10:08 --> Config Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:10:08 --> URI Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Router Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Output Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Security Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Input Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:10:08 --> Language Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Loader Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:10:08 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Session Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:10:08 --> Session routines successfully run
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Controller Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Model Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:10:08 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:10:08 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:10:08 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:10:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:10:08 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:10:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:10:08 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:10:08 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-29 12:10:08 --> Final output sent to browser
DEBUG - 2015-04-29 12:10:08 --> Total execution time: 0.0566
DEBUG - 2015-04-29 12:11:11 --> Config Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:11:11 --> URI Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Router Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Output Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Security Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Input Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:11:11 --> Language Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Loader Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:11:11 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Session Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:11:11 --> Session routines successfully run
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Controller Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:11:11 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:11:11 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:11:11 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:11:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:11:11 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:11:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:11:11 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:11:11 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-29 12:11:11 --> Final output sent to browser
DEBUG - 2015-04-29 12:11:11 --> Total execution time: 0.0508
DEBUG - 2015-04-29 12:11:43 --> Config Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:11:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:11:43 --> URI Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Router Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Output Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Security Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Input Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:11:43 --> Language Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Loader Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:11:43 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Session Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:11:43 --> Session routines successfully run
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Controller Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:11:43 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:11:43 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:11:43 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:11:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:11:43 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:11:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:11:43 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:11:43 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-29 12:11:43 --> Final output sent to browser
DEBUG - 2015-04-29 12:11:43 --> Total execution time: 0.0616
DEBUG - 2015-04-29 12:11:44 --> Config Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:11:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:11:44 --> URI Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Router Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Output Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Security Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Input Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:11:44 --> Language Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Loader Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:11:44 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Session Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:11:44 --> Session routines successfully run
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Controller Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Model Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:11:44 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:11:44 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:11:44 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:11:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:11:44 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:11:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:11:44 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:11:44 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:11:44 --> Final output sent to browser
DEBUG - 2015-04-29 12:11:44 --> Total execution time: 0.0503
DEBUG - 2015-04-29 12:12:21 --> Config Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:12:21 --> URI Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Router Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Output Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Security Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Input Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:12:21 --> Language Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Loader Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:12:21 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Session Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:12:21 --> Session routines successfully run
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Controller Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:12:21 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:12:21 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:12:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:12:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:12:21 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-29 12:12:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:12:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:12:21 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:12:21 --> Final output sent to browser
DEBUG - 2015-04-29 12:12:21 --> Total execution time: 0.0520
DEBUG - 2015-04-29 12:12:52 --> Config Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:12:52 --> URI Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Router Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Output Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Security Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Input Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:12:52 --> Language Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Loader Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:12:52 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Session Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:12:52 --> Session routines successfully run
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Controller Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:12:52 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Config Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:12:52 --> URI Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Router Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Output Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Security Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Input Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:12:52 --> Language Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Loader Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:12:52 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Session Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:12:52 --> Session routines successfully run
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Controller Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:52 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:12:52 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:12:52 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-29 12:12:52 --> Final output sent to browser
DEBUG - 2015-04-29 12:12:52 --> Total execution time: 0.0340
DEBUG - 2015-04-29 12:12:59 --> Config Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:12:59 --> URI Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Router Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Output Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Security Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Input Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:12:59 --> Language Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Loader Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:12:59 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Session Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:12:59 --> Session routines successfully run
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Controller Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:12:59 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-29 12:12:59 --> Config Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:12:59 --> URI Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Router Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Output Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Security Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Input Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:12:59 --> Language Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Loader Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:12:59 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Session Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:12:59 --> Session routines successfully run
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Controller Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:12:59 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:12:59 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:12:59 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:12:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:12:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:12:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:12:59 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:12:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-29 12:12:59 --> Final output sent to browser
DEBUG - 2015-04-29 12:12:59 --> Total execution time: 0.0362
DEBUG - 2015-04-29 12:13:11 --> Config Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:13:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:13:11 --> URI Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Router Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Output Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Security Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Input Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:13:11 --> Language Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Loader Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:13:11 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Session Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:13:11 --> Session routines successfully run
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Controller Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:13:11 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:13:11 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:13:11 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:13:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:13:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:13:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:13:11 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:13:11 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:13:11 --> Final output sent to browser
DEBUG - 2015-04-29 12:13:11 --> Total execution time: 0.0651
DEBUG - 2015-04-29 12:13:59 --> Config Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:13:59 --> URI Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Router Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Output Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Security Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Input Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:13:59 --> Language Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Loader Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:13:59 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Session Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:13:59 --> Session routines successfully run
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Controller Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Model Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:13:59 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:13:59 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:13:59 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:13:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:13:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:13:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:13:59 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:13:59 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:13:59 --> Final output sent to browser
DEBUG - 2015-04-29 12:13:59 --> Total execution time: 0.0533
DEBUG - 2015-04-29 12:14:21 --> Config Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:14:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:14:21 --> URI Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Router Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Output Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Security Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Input Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:14:21 --> Language Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Loader Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:14:21 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Session Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:14:21 --> Session routines successfully run
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Controller Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:14:21 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:14:21 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:14:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:14:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:14:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:14:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:14:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:14:21 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-04-29 12:14:21 --> Final output sent to browser
DEBUG - 2015-04-29 12:14:21 --> Total execution time: 0.0544
DEBUG - 2015-04-29 12:14:29 --> Config Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:14:29 --> URI Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Router Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Output Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Security Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Input Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:14:29 --> Language Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Loader Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:14:29 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Session Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:14:29 --> Session routines successfully run
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Controller Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:14:29 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:14:29 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:14:29 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:14:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:14:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:14:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:14:29 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:14:29 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-29 12:14:29 --> Final output sent to browser
DEBUG - 2015-04-29 12:14:29 --> Total execution time: 0.0612
DEBUG - 2015-04-29 12:14:32 --> Config Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:14:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:14:32 --> URI Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Router Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Output Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Security Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Input Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:14:32 --> Language Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Loader Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:14:32 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Session Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:14:32 --> Session routines successfully run
DEBUG - 2015-04-29 12:14:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Controller Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:14:32 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:14:32 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:14:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:14:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:14:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:14:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:14:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:14:32 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-29 12:14:32 --> Final output sent to browser
DEBUG - 2015-04-29 12:14:32 --> Total execution time: 0.0570
DEBUG - 2015-04-29 12:14:35 --> Config Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Hooks Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Utf8 Class Initialized
DEBUG - 2015-04-29 12:14:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-29 12:14:35 --> URI Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Router Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Output Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Security Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Input Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-29 12:14:35 --> Language Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Loader Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Helper loaded: url_helper
DEBUG - 2015-04-29 12:14:35 --> Database Driver Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Session Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Helper loaded: string_helper
DEBUG - 2015-04-29 12:14:35 --> Session routines successfully run
DEBUG - 2015-04-29 12:14:35 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Controller Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Model Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Helper loaded: form_helper
DEBUG - 2015-04-29 12:14:35 --> Form Validation Class Initialized
DEBUG - 2015-04-29 12:14:35 --> Pagination Class Initialized
DEBUG - 2015-04-29 12:14:35 --> File loaded: application/views/header.php
DEBUG - 2015-04-29 12:14:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-29 12:14:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-29 12:14:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-29 12:14:35 --> File loaded: application/views/footer.php
DEBUG - 2015-04-29 12:14:35 --> File loaded: application/views/agent/editAgentView.php
DEBUG - 2015-04-29 12:14:35 --> Final output sent to browser
DEBUG - 2015-04-29 12:14:35 --> Total execution time: 0.0483
