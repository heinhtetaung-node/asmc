<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-06 09:00:46 --> Config Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:00:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:00:46 --> URI Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Router Class Initialized
DEBUG - 2015-04-06 09:00:46 --> No URI present. Default controller set.
DEBUG - 2015-04-06 09:00:46 --> Output Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Security Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Input Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:00:46 --> Language Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Loader Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:00:46 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Session Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:00:46 --> A session cookie was not found.
DEBUG - 2015-04-06 09:00:46 --> Session routines successfully run
DEBUG - 2015-04-06 09:00:46 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Controller Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:46 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:00:46 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:00:46 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-06 09:00:46 --> Final output sent to browser
DEBUG - 2015-04-06 09:00:46 --> Total execution time: 0.0638
DEBUG - 2015-04-06 09:00:54 --> Config Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:00:54 --> URI Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Router Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Output Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Security Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Input Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:00:54 --> Language Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Loader Class Initialized
DEBUG - 2015-04-06 09:00:54 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:00:54 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Session Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:00:55 --> Session routines successfully run
DEBUG - 2015-04-06 09:00:55 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Controller Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Model Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:00:55 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:00:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-06 09:00:55 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-06 09:00:55 --> Final output sent to browser
DEBUG - 2015-04-06 09:00:55 --> Total execution time: 0.0392
DEBUG - 2015-04-06 09:01:01 --> Config Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:01:01 --> URI Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Router Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Output Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Security Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Input Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:01:01 --> Language Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Loader Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:01:01 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Session Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:01:01 --> Session routines successfully run
DEBUG - 2015-04-06 09:01:01 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Controller Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:01:01 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:01:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-06 09:01:01 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-06 09:01:01 --> Final output sent to browser
DEBUG - 2015-04-06 09:01:01 --> Total execution time: 0.0363
DEBUG - 2015-04-06 09:01:16 --> Config Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:01:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:01:16 --> URI Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Router Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Output Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Security Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Input Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:01:16 --> Language Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Loader Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:01:16 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Session Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:01:16 --> Session routines successfully run
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Controller Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:01:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-06 09:01:16 --> Config Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:01:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:01:16 --> URI Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Router Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Output Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Security Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Input Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:01:16 --> Language Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Loader Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:01:16 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Session Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:01:16 --> Session routines successfully run
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Controller Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:01:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:01:16 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:01:16 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:01:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:01:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:01:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:01:16 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:01:16 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-06 09:01:16 --> Final output sent to browser
DEBUG - 2015-04-06 09:01:16 --> Total execution time: 0.0422
DEBUG - 2015-04-06 09:01:18 --> Config Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:01:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:01:18 --> URI Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Router Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Output Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Security Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Input Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:01:18 --> Language Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Loader Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:01:18 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Session Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:01:18 --> Session routines successfully run
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Controller Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:01:18 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:01:18 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:01:18 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:01:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:01:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:01:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:01:18 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:01:18 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 09:01:18 --> Final output sent to browser
DEBUG - 2015-04-06 09:01:18 --> Total execution time: 0.0472
DEBUG - 2015-04-06 09:01:37 --> Config Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:01:37 --> URI Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Router Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Output Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Security Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Input Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:01:37 --> Language Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Loader Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:01:37 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Session Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:01:37 --> Session routines successfully run
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Controller Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Model Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:01:37 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:01:37 --> Pagination Class Initialized
ERROR - 2015-04-06 09:01:37 --> Severity: Warning  --> Missing argument 1 for Invoice_model::getStartEndPayoutDate(), called in /Applications/MAMP/htdocs/asmc/crm/application/controllers/commission.php on line 97 and defined /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 279
ERROR - 2015-04-06 09:01:37 --> Severity: Notice  --> Undefined variable: m_id /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 280
DEBUG - 2015-04-06 09:01:37 --> DB Transaction Failure
ERROR - 2015-04-06 09:01:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1
DEBUG - 2015-04-06 09:01:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2015-04-06 09:01:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 442
DEBUG - 2015-04-06 09:02:21 --> Config Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:02:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:02:21 --> URI Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Router Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Output Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Security Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Input Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:02:21 --> Language Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Loader Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:02:21 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Session Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:02:21 --> Session routines successfully run
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Controller Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:02:21 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:02:21 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Config Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:03:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:03:14 --> URI Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Router Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Output Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Security Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Input Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:03:14 --> Language Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Loader Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:03:14 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Session Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:03:14 --> Session routines successfully run
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Controller Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:03:14 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:03:14 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Config Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:03:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:03:40 --> URI Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Router Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Output Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Security Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Input Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:03:40 --> Language Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Loader Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:03:40 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Session Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:03:40 --> Session routines successfully run
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Controller Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:03:40 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:03:40 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Config Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:03:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:03:54 --> URI Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Router Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Output Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Security Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Input Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:03:54 --> Language Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Loader Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:03:54 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Session Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:03:54 --> Session routines successfully run
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Controller Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Model Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:03:54 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:03:54 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Config Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:07:35 --> URI Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Router Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Output Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Security Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Input Class Initialized
DEBUG - 2015-04-06 09:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:07:35 --> Language Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Config Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:07:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:07:50 --> URI Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Router Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Output Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Security Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Input Class Initialized
DEBUG - 2015-04-06 09:07:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:07:50 --> Language Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Config Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:07:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:07:59 --> URI Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Router Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Output Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Security Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Input Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:07:59 --> Language Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Loader Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:07:59 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Session Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:07:59 --> Session routines successfully run
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Controller Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Model Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:07:59 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:07:59 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Config Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:08:16 --> URI Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Router Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Output Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Security Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Input Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:08:16 --> Language Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Loader Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:08:16 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Session Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:08:16 --> Session routines successfully run
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Controller Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:08:16 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:08:16 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Config Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:08:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:08:30 --> URI Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Router Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Output Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Security Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Input Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:08:30 --> Language Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Loader Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:08:30 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Session Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:08:30 --> Session routines successfully run
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Controller Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Model Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:08:30 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:08:30 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Config Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:09:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:09:28 --> URI Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Router Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Output Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Security Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Input Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:09:28 --> Language Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Loader Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:09:28 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Session Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:09:28 --> Session routines successfully run
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Controller Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:09:28 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:09:28 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Config Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:10:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:10:40 --> URI Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Router Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Output Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Security Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Input Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:10:40 --> Language Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Loader Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:10:40 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Session Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:10:40 --> Session routines successfully run
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Controller Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:10:40 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:10:40 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Config Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:10:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:10:57 --> URI Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Router Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Output Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Security Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Input Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:10:57 --> Language Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Loader Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:10:57 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Session Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:10:57 --> Session routines successfully run
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Controller Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Model Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:10:57 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:10:57 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Config Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:11:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:11:50 --> URI Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Router Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Output Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Security Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Input Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:11:50 --> Language Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Loader Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:11:50 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Session Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:11:50 --> Session routines successfully run
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Controller Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Model Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:11:50 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:11:50 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Config Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:12:21 --> URI Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Router Class Initialized
DEBUG - 2015-04-06 09:12:21 --> No URI present. Default controller set.
DEBUG - 2015-04-06 09:12:21 --> Output Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Security Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Input Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:12:21 --> Language Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Loader Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:12:21 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Session Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:12:21 --> Session routines successfully run
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Controller Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:12:21 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Config Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:12:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:12:21 --> URI Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Router Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Output Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Security Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Input Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:12:21 --> Language Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Loader Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:12:21 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Session Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:12:21 --> Session routines successfully run
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:21 --> Controller Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Config Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:12:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:12:25 --> URI Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Router Class Initialized
DEBUG - 2015-04-06 09:12:25 --> No URI present. Default controller set.
DEBUG - 2015-04-06 09:12:25 --> Output Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Security Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Input Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:12:25 --> Language Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Loader Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:12:25 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Session Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:12:25 --> Session routines successfully run
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Controller Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:12:25 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Config Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:12:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:12:25 --> URI Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Router Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Output Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Security Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Input Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:12:25 --> Language Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Loader Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:12:25 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Session Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:12:25 --> Session routines successfully run
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:25 --> Controller Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Config Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:12:28 --> URI Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Router Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Output Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Security Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Input Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:12:28 --> Language Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Loader Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:12:28 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Session Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:12:28 --> Session routines successfully run
DEBUG - 2015-04-06 09:12:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:12:28 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:28 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:28 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:28 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:28 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:28 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:29 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:29 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:29 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:29 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:29 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:29 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:35 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:35 --> No URI present. Default controller set.
DEBUG - 2015-04-06 09:13:35 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:35 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:35 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:35 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:13:35 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:35 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:35 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:35 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:35 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:13:35 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:13:35 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:13:35 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:13:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:13:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:13:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:13:35 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:13:35 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-06 09:13:35 --> Final output sent to browser
DEBUG - 2015-04-06 09:13:35 --> Total execution time: 0.0367
DEBUG - 2015-04-06 09:13:38 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:38 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:38 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:38 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:38 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:13:38 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:13:38 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:13:38 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:13:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:13:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:13:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:13:38 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:13:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-06 09:13:38 --> Final output sent to browser
DEBUG - 2015-04-06 09:13:38 --> Total execution time: 0.0551
DEBUG - 2015-04-06 09:13:39 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:39 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:39 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:39 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:39 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:13:39 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:13:39 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Config Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:13:56 --> URI Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Router Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Output Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Security Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Input Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:13:56 --> Language Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Loader Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:13:56 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Session Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:13:56 --> Session routines successfully run
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Controller Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Model Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:13:56 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:13:56 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Config Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:22:03 --> URI Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Router Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Output Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Security Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Input Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:22:03 --> Language Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Loader Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:22:03 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Session Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:22:03 --> Session routines successfully run
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Controller Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:22:03 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:22:03 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:22:03 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:22:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:22:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:22:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:22:03 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:22:03 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 09:22:03 --> Final output sent to browser
DEBUG - 2015-04-06 09:22:03 --> Total execution time: 0.0516
DEBUG - 2015-04-06 09:22:34 --> Config Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:22:34 --> URI Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Router Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Output Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Security Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Input Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:22:34 --> Language Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Loader Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:22:34 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Session Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:22:34 --> Session routines successfully run
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Controller Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Model Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:22:34 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:22:34 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:22:34 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:22:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:22:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:22:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:22:34 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:22:34 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 09:22:34 --> Final output sent to browser
DEBUG - 2015-04-06 09:22:34 --> Total execution time: 0.0491
DEBUG - 2015-04-06 09:23:05 --> Config Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Hooks Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Utf8 Class Initialized
DEBUG - 2015-04-06 09:23:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 09:23:05 --> URI Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Router Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Output Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Security Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Input Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 09:23:05 --> Language Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Loader Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Helper loaded: url_helper
DEBUG - 2015-04-06 09:23:05 --> Database Driver Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Session Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Helper loaded: string_helper
DEBUG - 2015-04-06 09:23:05 --> Session routines successfully run
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Controller Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Model Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Helper loaded: form_helper
DEBUG - 2015-04-06 09:23:05 --> Form Validation Class Initialized
DEBUG - 2015-04-06 09:23:05 --> Pagination Class Initialized
DEBUG - 2015-04-06 09:23:05 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 09:23:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 09:23:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 09:23:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 09:23:05 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 09:23:05 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 09:23:05 --> Final output sent to browser
DEBUG - 2015-04-06 09:23:05 --> Total execution time: 0.0510
DEBUG - 2015-04-06 10:51:58 --> Config Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Hooks Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Utf8 Class Initialized
DEBUG - 2015-04-06 10:51:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 10:51:58 --> URI Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Router Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Output Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Security Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Input Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 10:51:58 --> Language Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Loader Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Helper loaded: url_helper
DEBUG - 2015-04-06 10:51:58 --> Database Driver Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Session Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Helper loaded: string_helper
DEBUG - 2015-04-06 10:51:58 --> Session routines successfully run
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Controller Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Model Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Helper loaded: form_helper
DEBUG - 2015-04-06 10:51:58 --> Form Validation Class Initialized
DEBUG - 2015-04-06 10:51:58 --> Pagination Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Config Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Hooks Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Utf8 Class Initialized
DEBUG - 2015-04-06 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 10:57:33 --> URI Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Router Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Output Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Security Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Input Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 10:57:33 --> Language Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Loader Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Helper loaded: url_helper
DEBUG - 2015-04-06 10:57:33 --> Database Driver Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Session Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Helper loaded: string_helper
DEBUG - 2015-04-06 10:57:33 --> Session routines successfully run
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Controller Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Helper loaded: form_helper
DEBUG - 2015-04-06 10:57:33 --> Form Validation Class Initialized
DEBUG - 2015-04-06 10:57:33 --> Pagination Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Config Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Hooks Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Utf8 Class Initialized
DEBUG - 2015-04-06 10:57:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 10:57:44 --> URI Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Router Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Output Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Security Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Input Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 10:57:44 --> Language Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Loader Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Helper loaded: url_helper
DEBUG - 2015-04-06 10:57:44 --> Database Driver Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Session Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Helper loaded: string_helper
DEBUG - 2015-04-06 10:57:44 --> Session routines successfully run
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Controller Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Model Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Helper loaded: form_helper
DEBUG - 2015-04-06 10:57:44 --> Form Validation Class Initialized
DEBUG - 2015-04-06 10:57:44 --> Pagination Class Initialized
DEBUG - 2015-04-06 10:57:44 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 10:57:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 10:57:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 10:57:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 10:57:44 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 10:57:44 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 10:57:44 --> Final output sent to browser
DEBUG - 2015-04-06 10:57:44 --> Total execution time: 0.0479
DEBUG - 2015-04-06 10:58:08 --> Config Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Hooks Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Utf8 Class Initialized
DEBUG - 2015-04-06 10:58:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 10:58:08 --> URI Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Router Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Output Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Security Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Input Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 10:58:08 --> Language Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Loader Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Helper loaded: url_helper
DEBUG - 2015-04-06 10:58:08 --> Database Driver Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Session Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Helper loaded: string_helper
DEBUG - 2015-04-06 10:58:08 --> Session routines successfully run
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Controller Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Model Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Helper loaded: form_helper
DEBUG - 2015-04-06 10:58:08 --> Form Validation Class Initialized
DEBUG - 2015-04-06 10:58:08 --> Pagination Class Initialized
DEBUG - 2015-04-06 10:58:08 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 10:58:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 10:58:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 10:58:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 10:58:08 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 10:58:08 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 10:58:08 --> Final output sent to browser
DEBUG - 2015-04-06 10:58:08 --> Total execution time: 0.0486
DEBUG - 2015-04-06 11:01:21 --> Config Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:01:21 --> URI Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Router Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Output Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Security Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Input Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:01:21 --> Language Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Loader Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:01:21 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Session Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:01:21 --> Session routines successfully run
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Controller Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:01:21 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:01:21 --> Pagination Class Initialized
DEBUG - 2015-04-06 11:01:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 11:01:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 11:01:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-06 11:01:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 11:01:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 11:01:21 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 11:01:21 --> Final output sent to browser
DEBUG - 2015-04-06 11:01:21 --> Total execution time: 0.0457
DEBUG - 2015-04-06 11:01:24 --> Config Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:01:24 --> URI Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Router Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Output Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Security Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Input Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:01:24 --> Language Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Loader Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:01:24 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Session Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:01:24 --> Session routines successfully run
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Controller Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:01:24 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Config Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:01:24 --> URI Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Router Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Output Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Security Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Input Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:01:24 --> Language Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Loader Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:01:24 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Session Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:01:24 --> Session routines successfully run
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Controller Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:24 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:01:24 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:01:24 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-06 11:01:24 --> Final output sent to browser
DEBUG - 2015-04-06 11:01:24 --> Total execution time: 0.0302
DEBUG - 2015-04-06 11:01:30 --> Config Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:01:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:01:30 --> URI Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Router Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Output Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Security Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Input Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:01:30 --> Language Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Loader Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:01:30 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Session Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:01:30 --> Session routines successfully run
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Controller Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:01:30 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-06 11:01:30 --> Config Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:01:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:01:30 --> URI Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Router Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Output Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Security Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Input Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:01:30 --> Language Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Loader Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:01:30 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Session Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:01:30 --> Session routines successfully run
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Controller Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:30 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:01:30 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:01:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 11:01:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 11:01:30 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-06 11:01:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 11:01:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 11:01:30 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-06 11:01:30 --> Final output sent to browser
DEBUG - 2015-04-06 11:01:30 --> Total execution time: 0.0358
DEBUG - 2015-04-06 11:01:32 --> Config Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:01:32 --> URI Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Router Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Output Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Security Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Input Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:01:32 --> Language Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Loader Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:01:32 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Session Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:01:32 --> Session routines successfully run
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Controller Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Model Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:01:32 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:01:32 --> Pagination Class Initialized
DEBUG - 2015-04-06 11:01:32 --> DB Transaction Failure
ERROR - 2015-04-06 11:01:32 --> Query error: Unknown column 'm_id' in 'where clause'
DEBUG - 2015-04-06 11:01:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-04-06 11:02:37 --> Config Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Hooks Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Utf8 Class Initialized
DEBUG - 2015-04-06 11:02:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-06 11:02:37 --> URI Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Router Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Output Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Security Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Input Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-06 11:02:37 --> Language Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Loader Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Helper loaded: url_helper
DEBUG - 2015-04-06 11:02:37 --> Database Driver Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Session Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Helper loaded: string_helper
DEBUG - 2015-04-06 11:02:37 --> Session routines successfully run
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Controller Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Model Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Helper loaded: form_helper
DEBUG - 2015-04-06 11:02:37 --> Form Validation Class Initialized
DEBUG - 2015-04-06 11:02:37 --> Pagination Class Initialized
DEBUG - 2015-04-06 11:02:37 --> File loaded: application/views/header.php
DEBUG - 2015-04-06 11:02:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-06 11:02:37 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-06 11:02:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-06 11:02:37 --> File loaded: application/views/footer.php
DEBUG - 2015-04-06 11:02:37 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-06 11:02:37 --> Final output sent to browser
DEBUG - 2015-04-06 11:02:37 --> Total execution time: 0.0440
