<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-08-25 09:02:49 --> Config Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:02:49 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:02:49 --> URI Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Router Class Initialized
DEBUG - 2015-08-25 09:02:49 --> No URI present. Default controller set.
DEBUG - 2015-08-25 09:02:49 --> Output Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Security Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Input Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 09:02:49 --> Language Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Loader Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Helper loaded: url_helper
DEBUG - 2015-08-25 09:02:49 --> Database Driver Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Session Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Helper loaded: string_helper
DEBUG - 2015-08-25 09:02:49 --> A session cookie was not found.
DEBUG - 2015-08-25 09:02:49 --> Session routines successfully run
DEBUG - 2015-08-25 09:02:49 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Controller Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Helper loaded: form_helper
DEBUG - 2015-08-25 09:02:49 --> Form Validation Class Initialized
DEBUG - 2015-08-25 09:02:49 --> File loaded: application/views/loginView.php
DEBUG - 2015-08-25 09:02:49 --> Final output sent to browser
DEBUG - 2015-08-25 09:02:49 --> Total execution time: 0.1197
DEBUG - 2015-08-25 09:02:49 --> Config Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:02:49 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:02:49 --> URI Class Initialized
DEBUG - 2015-08-25 09:02:49 --> Router Class Initialized
ERROR - 2015-08-25 09:02:49 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 09:02:57 --> Config Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:02:57 --> URI Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Router Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Output Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Security Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Input Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 09:02:57 --> Language Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Loader Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Helper loaded: url_helper
DEBUG - 2015-08-25 09:02:57 --> Database Driver Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Session Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Helper loaded: string_helper
DEBUG - 2015-08-25 09:02:57 --> Session routines successfully run
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Controller Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Helper loaded: form_helper
DEBUG - 2015-08-25 09:02:57 --> Form Validation Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 09:02:57 --> Config Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:02:57 --> URI Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Router Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Output Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Security Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Input Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 09:02:57 --> Language Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Loader Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Helper loaded: url_helper
DEBUG - 2015-08-25 09:02:57 --> Database Driver Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Session Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Helper loaded: string_helper
DEBUG - 2015-08-25 09:02:57 --> Session routines successfully run
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Controller Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Helper loaded: form_helper
DEBUG - 2015-08-25 09:02:57 --> Form Validation Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Pagination Class Initialized
DEBUG - 2015-08-25 09:02:57 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 09:02:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 09:02:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 09:02:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 09:02:57 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 09:02:57 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-08-25 09:02:57 --> Final output sent to browser
DEBUG - 2015-08-25 09:02:57 --> Total execution time: 0.0487
DEBUG - 2015-08-25 09:02:57 --> Config Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:02:57 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:02:57 --> URI Class Initialized
DEBUG - 2015-08-25 09:02:57 --> Router Class Initialized
ERROR - 2015-08-25 09:02:57 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 09:02:59 --> Config Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:02:59 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:02:59 --> URI Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Router Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Output Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Security Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Input Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 09:02:59 --> Language Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Loader Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Helper loaded: url_helper
DEBUG - 2015-08-25 09:02:59 --> Database Driver Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Session Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Helper loaded: string_helper
DEBUG - 2015-08-25 09:02:59 --> Session routines successfully run
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Controller Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Model Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Helper loaded: form_helper
DEBUG - 2015-08-25 09:02:59 --> Form Validation Class Initialized
DEBUG - 2015-08-25 09:02:59 --> Pagination Class Initialized
DEBUG - 2015-08-25 09:02:59 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 09:02:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 09:02:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 09:02:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 09:02:59 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 09:02:59 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-25 09:02:59 --> Final output sent to browser
DEBUG - 2015-08-25 09:02:59 --> Total execution time: 0.2000
DEBUG - 2015-08-25 09:03:00 --> Config Class Initialized
DEBUG - 2015-08-25 09:03:00 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:03:00 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:03:00 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:03:00 --> URI Class Initialized
DEBUG - 2015-08-25 09:03:00 --> Router Class Initialized
ERROR - 2015-08-25 09:03:00 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 09:03:03 --> Config Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:03:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:03:03 --> URI Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Router Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Output Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Security Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Input Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 09:03:03 --> Language Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Loader Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Helper loaded: url_helper
DEBUG - 2015-08-25 09:03:03 --> Database Driver Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Session Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Helper loaded: string_helper
DEBUG - 2015-08-25 09:03:03 --> Session routines successfully run
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Controller Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Helper loaded: form_helper
DEBUG - 2015-08-25 09:03:03 --> Form Validation Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Pagination Class Initialized
DEBUG - 2015-08-25 09:03:03 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 09:03:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 09:03:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 09:03:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 09:03:03 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 09:03:03 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 09:03:03 --> Final output sent to browser
DEBUG - 2015-08-25 09:03:03 --> Total execution time: 0.0979
DEBUG - 2015-08-25 09:03:03 --> Config Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:03:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:03:03 --> URI Class Initialized
DEBUG - 2015-08-25 09:03:03 --> Router Class Initialized
ERROR - 2015-08-25 09:03:03 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 09:03:50 --> Config Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:03:50 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:03:50 --> URI Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Router Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Output Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Security Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Input Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 09:03:50 --> Language Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Loader Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Helper loaded: url_helper
DEBUG - 2015-08-25 09:03:50 --> Database Driver Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Session Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Helper loaded: string_helper
DEBUG - 2015-08-25 09:03:50 --> Session routines successfully run
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Controller Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Model Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Helper loaded: form_helper
DEBUG - 2015-08-25 09:03:50 --> Form Validation Class Initialized
DEBUG - 2015-08-25 09:03:50 --> Pagination Class Initialized
DEBUG - 2015-08-25 09:03:50 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 09:03:50 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 09:03:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 09:03:50 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 09:03:50 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 09:03:50 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 09:03:50 --> Final output sent to browser
DEBUG - 2015-08-25 09:03:50 --> Total execution time: 0.0706
DEBUG - 2015-08-25 09:03:51 --> Config Class Initialized
DEBUG - 2015-08-25 09:03:51 --> Hooks Class Initialized
DEBUG - 2015-08-25 09:03:51 --> Utf8 Class Initialized
DEBUG - 2015-08-25 09:03:51 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 09:03:51 --> URI Class Initialized
DEBUG - 2015-08-25 09:03:51 --> Router Class Initialized
ERROR - 2015-08-25 09:03:51 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:37:22 --> Config Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:37:22 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:37:22 --> URI Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Router Class Initialized
DEBUG - 2015-08-25 13:37:22 --> No URI present. Default controller set.
DEBUG - 2015-08-25 13:37:22 --> Output Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Security Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Input Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:37:22 --> Language Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Loader Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:37:22 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Session Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:37:22 --> A session cookie was not found.
DEBUG - 2015-08-25 13:37:22 --> Session routines successfully run
DEBUG - 2015-08-25 13:37:22 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Controller Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:22 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:37:22 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:37:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-08-25 13:37:22 --> Final output sent to browser
DEBUG - 2015-08-25 13:37:22 --> Total execution time: 0.0693
DEBUG - 2015-08-25 13:37:34 --> Config Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:37:34 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:37:34 --> URI Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Router Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Output Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Security Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Input Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:37:34 --> Language Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Loader Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:37:34 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Session Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:37:34 --> Session routines successfully run
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Controller Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:37:34 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:37:34 --> Config Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:37:34 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:37:34 --> URI Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Router Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Output Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Security Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Input Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:37:34 --> Language Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Loader Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:37:34 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Session Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:37:34 --> Session routines successfully run
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Controller Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:37:34 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:37:34 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:37:34 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:37:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:37:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:37:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:37:34 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:37:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-08-25 13:37:34 --> Final output sent to browser
DEBUG - 2015-08-25 13:37:34 --> Total execution time: 0.0473
DEBUG - 2015-08-25 13:37:36 --> Config Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:37:36 --> URI Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Router Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Output Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Security Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Input Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:37:36 --> Language Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Loader Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:37:36 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Session Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:37:36 --> Session routines successfully run
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Controller Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:37:36 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:37:36 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:37:36 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:37:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:37:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:37:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:37:36 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:37:36 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-25 13:37:36 --> Final output sent to browser
DEBUG - 2015-08-25 13:37:36 --> Total execution time: 0.1133
DEBUG - 2015-08-25 13:37:38 --> Config Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:37:38 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:37:38 --> URI Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Router Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Output Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Security Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Input Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:37:38 --> Language Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Loader Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:37:38 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Session Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:37:38 --> Session routines successfully run
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Controller Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Model Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:37:38 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:37:38 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:37:38 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:37:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:37:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:37:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:37:38 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:37:38 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:37:38 --> Final output sent to browser
DEBUG - 2015-08-25 13:37:38 --> Total execution time: 0.0563
DEBUG - 2015-08-25 13:39:18 --> Config Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:39:18 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:39:18 --> URI Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Router Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Output Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Security Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Input Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:39:18 --> Language Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Loader Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:39:18 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Session Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:39:18 --> Session routines successfully run
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Controller Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:39:18 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:39:18 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Config Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:39:36 --> URI Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Router Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Output Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Security Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Input Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:39:36 --> Language Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Loader Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:39:36 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Session Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:39:36 --> Session routines successfully run
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Controller Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Model Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:39:36 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:39:36 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:39:36 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:39:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:39:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:39:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:39:36 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:39:36 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:39:36 --> Final output sent to browser
DEBUG - 2015-08-25 13:39:36 --> Total execution time: 0.0777
DEBUG - 2015-08-25 13:39:51 --> Config Class Initialized
DEBUG - 2015-08-25 13:39:51 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:39:51 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:39:51 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:39:51 --> URI Class Initialized
DEBUG - 2015-08-25 13:39:51 --> Router Class Initialized
ERROR - 2015-08-25 13:39:51 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:40:17 --> Config Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:40:17 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:40:17 --> URI Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Router Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Output Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Security Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Input Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:40:17 --> Language Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Loader Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:40:17 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Session Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:40:17 --> Session routines successfully run
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Controller Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:40:17 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:40:17 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:40:17 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:40:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:40:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:40:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:40:18 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:40:18 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:40:18 --> Final output sent to browser
DEBUG - 2015-08-25 13:40:18 --> Total execution time: 0.0577
DEBUG - 2015-08-25 13:40:18 --> Config Class Initialized
DEBUG - 2015-08-25 13:40:18 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:40:18 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:40:18 --> URI Class Initialized
DEBUG - 2015-08-25 13:40:18 --> Router Class Initialized
ERROR - 2015-08-25 13:40:18 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:41:18 --> Config Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:41:18 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:41:18 --> URI Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Router Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Output Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Security Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Input Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:41:18 --> Language Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Loader Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:41:18 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Session Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:41:18 --> Session routines successfully run
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Controller Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Model Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:41:18 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:41:18 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:41:18 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:41:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:41:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:41:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:41:18 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:41:18 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:41:18 --> Final output sent to browser
DEBUG - 2015-08-25 13:41:18 --> Total execution time: 0.0694
DEBUG - 2015-08-25 13:41:19 --> Config Class Initialized
DEBUG - 2015-08-25 13:41:19 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:41:19 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:41:19 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:41:19 --> URI Class Initialized
DEBUG - 2015-08-25 13:41:19 --> Router Class Initialized
ERROR - 2015-08-25 13:41:19 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:43:31 --> Config Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:43:31 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:43:31 --> URI Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Router Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Output Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Security Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Input Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:43:31 --> Language Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Loader Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:43:31 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Session Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:43:31 --> Session routines successfully run
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Controller Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:43:31 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:43:31 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:43:31 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:43:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:43:31 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:43:31 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:43:31 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:43:31 --> Final output sent to browser
DEBUG - 2015-08-25 13:43:31 --> Total execution time: 0.0619
DEBUG - 2015-08-25 13:43:31 --> Config Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:43:31 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:43:31 --> URI Class Initialized
DEBUG - 2015-08-25 13:43:31 --> Router Class Initialized
ERROR - 2015-08-25 13:43:31 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:43:47 --> Config Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:43:47 --> URI Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Router Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Output Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Security Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Input Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:43:47 --> Language Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Loader Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:43:47 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Session Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:43:47 --> Session routines successfully run
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Controller Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Model Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:43:47 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:43:47 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:43:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:43:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:43:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:43:47 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:43:47 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:43:47 --> Final output sent to browser
DEBUG - 2015-08-25 13:43:47 --> Total execution time: 0.0590
DEBUG - 2015-08-25 13:43:47 --> Config Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:43:47 --> URI Class Initialized
DEBUG - 2015-08-25 13:43:47 --> Router Class Initialized
ERROR - 2015-08-25 13:43:47 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:44:26 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:26 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Router Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Output Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Security Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Input Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:44:26 --> Language Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Loader Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:44:26 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Session Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:44:26 --> Session routines successfully run
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Controller Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:44:26 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:44:26 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:44:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:44:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:44:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:44:26 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:44:26 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:44:26 --> Final output sent to browser
DEBUG - 2015-08-25 13:44:26 --> Total execution time: 0.0594
DEBUG - 2015-08-25 13:44:26 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:26 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:26 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:26 --> Router Class Initialized
ERROR - 2015-08-25 13:44:26 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:44:37 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:37 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Router Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Output Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Security Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Input Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:44:37 --> Language Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Loader Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:44:37 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Session Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:44:37 --> Session routines successfully run
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Controller Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:44:37 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:44:37 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:44:37 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:44:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:44:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:44:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:44:37 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:44:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:44:37 --> Final output sent to browser
DEBUG - 2015-08-25 13:44:37 --> Total execution time: 0.0723
DEBUG - 2015-08-25 13:44:38 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:38 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:38 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:38 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:38 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:38 --> Router Class Initialized
ERROR - 2015-08-25 13:44:38 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:44:43 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:43 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:43 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Router Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Output Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Security Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Input Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:44:43 --> Language Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Loader Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:44:43 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Session Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:44:43 --> Session routines successfully run
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Controller Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:44:43 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:44:43 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:44:43 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:44:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:44:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:44:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:44:43 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:44:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:44:43 --> Final output sent to browser
DEBUG - 2015-08-25 13:44:43 --> Total execution time: 0.0754
DEBUG - 2015-08-25 13:44:44 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:44 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:44 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:44 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:44 --> Router Class Initialized
ERROR - 2015-08-25 13:44:44 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:44:49 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:49 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:49 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Router Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Output Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Security Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Input Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:44:49 --> Language Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Loader Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:44:49 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Session Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:44:49 --> Session routines successfully run
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Controller Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:44:49 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:44:49 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:44:49 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:44:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:44:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:44:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:44:49 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:44:49 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:44:49 --> Final output sent to browser
DEBUG - 2015-08-25 13:44:49 --> Total execution time: 0.0703
DEBUG - 2015-08-25 13:44:50 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:50 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:50 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:50 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:50 --> Router Class Initialized
ERROR - 2015-08-25 13:44:50 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:44:56 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:56 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:56 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Router Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Output Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Security Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Input Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:44:56 --> Language Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Loader Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:44:56 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Session Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:44:56 --> Session routines successfully run
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Controller Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Model Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:44:56 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:44:56 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:44:56 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:44:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:44:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:44:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:44:56 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:44:56 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:44:56 --> Final output sent to browser
DEBUG - 2015-08-25 13:44:56 --> Total execution time: 0.0731
DEBUG - 2015-08-25 13:44:57 --> Config Class Initialized
DEBUG - 2015-08-25 13:44:57 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:44:57 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:44:57 --> URI Class Initialized
DEBUG - 2015-08-25 13:44:57 --> Router Class Initialized
ERROR - 2015-08-25 13:44:57 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:45:08 --> Config Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:45:08 --> URI Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Router Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Output Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Security Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Input Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:45:08 --> Language Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Loader Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:45:08 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Session Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:45:08 --> A session cookie was not found.
DEBUG - 2015-08-25 13:45:08 --> Session routines successfully run
DEBUG - 2015-08-25 13:45:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Controller Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Config Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:45:08 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:45:08 --> URI Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Router Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Output Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Security Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Input Class Initialized
DEBUG - 2015-08-25 13:45:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:45:08 --> Language Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Loader Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:45:09 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Session Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:45:09 --> Session routines successfully run
DEBUG - 2015-08-25 13:45:09 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Controller Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:09 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:45:09 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:45:09 --> File loaded: application/views/loginView.php
DEBUG - 2015-08-25 13:45:09 --> Final output sent to browser
DEBUG - 2015-08-25 13:45:09 --> Total execution time: 0.0292
DEBUG - 2015-08-25 13:45:11 --> Config Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:45:11 --> URI Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Router Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Output Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Security Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Input Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:45:11 --> Language Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Loader Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:45:11 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Session Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:45:11 --> Session routines successfully run
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Controller Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:45:11 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:45:11 --> Config Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:45:11 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:45:11 --> URI Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Router Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Output Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Security Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Input Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:45:11 --> Language Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Loader Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:45:11 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Session Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:45:11 --> Session routines successfully run
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Controller Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:45:11 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:45:11 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:45:11 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:45:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:45:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:45:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:45:11 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:45:11 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-08-25 13:45:11 --> Final output sent to browser
DEBUG - 2015-08-25 13:45:11 --> Total execution time: 0.0362
DEBUG - 2015-08-25 13:45:13 --> Config Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:45:13 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:45:13 --> URI Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Router Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Output Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Security Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Input Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:45:13 --> Language Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Loader Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:45:13 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Session Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:45:13 --> Session routines successfully run
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Controller Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:45:13 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:45:13 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:45:13 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:45:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:45:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:45:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:45:13 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:45:13 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:45:13 --> Final output sent to browser
DEBUG - 2015-08-25 13:45:13 --> Total execution time: 0.0518
DEBUG - 2015-08-25 13:45:46 --> Config Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:45:46 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:45:46 --> URI Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Router Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Output Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Security Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Input Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:45:46 --> Language Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Loader Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:45:46 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Session Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:45:46 --> Session routines successfully run
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Controller Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:45:46 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:45:46 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:45:46 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:45:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:45:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:45:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:45:46 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:45:46 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-08-25 13:45:46 --> Final output sent to browser
DEBUG - 2015-08-25 13:45:46 --> Total execution time: 0.0528
DEBUG - 2015-08-25 13:46:12 --> Config Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:46:12 --> URI Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Router Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Output Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Security Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Input Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:46:12 --> Language Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Loader Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:46:12 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Session Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:46:12 --> Session routines successfully run
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Controller Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:46:12 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:46:12 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:46:12 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:46:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:46:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:46:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:46:12 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:46:12 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-08-25 13:46:12 --> Final output sent to browser
DEBUG - 2015-08-25 13:46:12 --> Total execution time: 0.0556
DEBUG - 2015-08-25 13:46:13 --> Config Class Initialized
DEBUG - 2015-08-25 13:46:13 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:46:13 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:46:13 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:46:13 --> URI Class Initialized
DEBUG - 2015-08-25 13:46:13 --> Router Class Initialized
ERROR - 2015-08-25 13:46:13 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:46:52 --> Config Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:46:52 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:46:52 --> URI Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Router Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Output Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Security Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Input Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:46:52 --> Language Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Loader Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:46:52 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Session Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:46:52 --> Session routines successfully run
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Controller Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Model Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:46:52 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:46:52 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:46:52 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:46:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:46:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:46:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:46:52 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:46:52 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-08-25 13:46:52 --> Final output sent to browser
DEBUG - 2015-08-25 13:46:52 --> Total execution time: 0.0641
DEBUG - 2015-08-25 13:46:53 --> Config Class Initialized
DEBUG - 2015-08-25 13:46:53 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:46:53 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:46:53 --> URI Class Initialized
DEBUG - 2015-08-25 13:46:53 --> Router Class Initialized
ERROR - 2015-08-25 13:46:53 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:47:17 --> Config Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:47:17 --> URI Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Router Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Output Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Security Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Input Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:47:17 --> Language Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Loader Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:47:17 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Session Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:47:17 --> Session routines successfully run
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Controller Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:47:17 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:47:17 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:47:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:47:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:47:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:47:17 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:47:17 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-08-25 13:47:17 --> Final output sent to browser
DEBUG - 2015-08-25 13:47:17 --> Total execution time: 0.0546
DEBUG - 2015-08-25 13:47:17 --> Config Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:47:17 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:47:17 --> URI Class Initialized
DEBUG - 2015-08-25 13:47:17 --> Router Class Initialized
ERROR - 2015-08-25 13:47:17 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:48:00 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:00 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:00 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Router Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Output Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Security Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Input Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:48:00 --> Language Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Loader Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:48:00 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Session Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:48:00 --> Session routines successfully run
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Controller Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:48:00 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:48:00 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:48:00 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:48:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:48:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:48:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:48:00 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:48:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-25 13:48:00 --> Final output sent to browser
DEBUG - 2015-08-25 13:48:00 --> Total execution time: 0.0817
DEBUG - 2015-08-25 13:48:01 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:01 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:01 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:01 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:01 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:01 --> Router Class Initialized
ERROR - 2015-08-25 13:48:01 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:48:03 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:03 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Router Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Output Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Security Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Input Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:48:03 --> Language Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Loader Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:48:03 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Session Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:48:03 --> Session routines successfully run
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Controller Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:48:03 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:48:03 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:48:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:48:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:48:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:48:03 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:48:03 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:48:03 --> Final output sent to browser
DEBUG - 2015-08-25 13:48:03 --> Total execution time: 0.0707
DEBUG - 2015-08-25 13:48:03 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:03 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:03 --> Router Class Initialized
ERROR - 2015-08-25 13:48:03 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:48:07 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:07 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:07 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Router Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Output Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Security Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Input Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:48:07 --> Language Class Initialized
DEBUG - 2015-08-25 13:48:07 --> Loader Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:48:08 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Session Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:48:08 --> Session routines successfully run
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Controller Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:48:08 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:48:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:48:12 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:12 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:12 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Router Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Output Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Security Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Input Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:48:12 --> Language Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Loader Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:48:12 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Session Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:48:12 --> Session routines successfully run
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Controller Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:48:12 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:48:12 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:48:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:48:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:48:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:48:12 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:48:12 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:48:12 --> Final output sent to browser
DEBUG - 2015-08-25 13:48:12 --> Total execution time: 0.0561
DEBUG - 2015-08-25 13:48:12 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:12 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:12 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:12 --> Router Class Initialized
ERROR - 2015-08-25 13:48:12 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:48:17 --> Config Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:48:17 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:48:17 --> URI Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Router Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Output Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Security Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Input Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:48:17 --> Language Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Loader Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:48:17 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Session Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:48:17 --> Session routines successfully run
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Controller Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Model Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:48:17 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:48:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:50:48 --> Config Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:50:48 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:50:48 --> URI Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Router Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Output Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Security Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Input Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:50:48 --> Language Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Loader Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:50:48 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Session Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:50:48 --> Session routines successfully run
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Controller Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Model Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:50:48 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:50:48 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-08-25 13:50:48 --> Severity: Notice  --> Undefined index: inv_starter_pack /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 446
DEBUG - 2015-08-25 13:51:13 --> Config Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:51:13 --> URI Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Router Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Output Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Security Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Input Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:51:13 --> Language Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Loader Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:51:13 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Session Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:51:13 --> Session routines successfully run
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Controller Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:51:13 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:51:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:51:27 --> Config Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:51:27 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:51:27 --> URI Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Router Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Output Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Security Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Input Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:51:27 --> Language Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Loader Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:51:27 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Session Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:51:27 --> Session routines successfully run
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Controller Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:51:27 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:51:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:51:28 --> Config Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:51:28 --> URI Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Router Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Output Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Security Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Input Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:51:28 --> Language Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Loader Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:51:28 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Session Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:51:28 --> Session routines successfully run
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Controller Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:51:28 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:51:28 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:51:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:51:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:51:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:51:28 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:51:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 13:51:28 --> Final output sent to browser
DEBUG - 2015-08-25 13:51:28 --> Total execution time: 0.0604
DEBUG - 2015-08-25 13:51:28 --> Config Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:51:28 --> URI Class Initialized
DEBUG - 2015-08-25 13:51:28 --> Router Class Initialized
ERROR - 2015-08-25 13:51:28 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:51:37 --> Config Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:51:37 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:51:37 --> URI Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Router Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Output Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Security Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Input Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:51:37 --> Language Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Loader Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:51:37 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Session Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:51:37 --> Session routines successfully run
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Controller Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Model Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:51:37 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:51:37 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:51:37 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:51:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:51:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:51:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:51:37 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:51:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 13:51:37 --> Final output sent to browser
DEBUG - 2015-08-25 13:51:37 --> Total execution time: 0.0704
DEBUG - 2015-08-25 13:51:38 --> Config Class Initialized
DEBUG - 2015-08-25 13:51:38 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:51:38 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:51:38 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:51:38 --> URI Class Initialized
DEBUG - 2015-08-25 13:51:38 --> Router Class Initialized
ERROR - 2015-08-25 13:51:38 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:52:54 --> Config Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:52:54 --> URI Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Router Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Output Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Security Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Input Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:52:54 --> Language Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Loader Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:52:54 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Session Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:52:54 --> Session routines successfully run
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Controller Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:52:54 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 13:52:54 --> Config Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:52:54 --> URI Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Router Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Output Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Security Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Input Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:52:54 --> Language Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Loader Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:52:54 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Session Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:52:54 --> Session routines successfully run
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Controller Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Model Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:52:54 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:52:54 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:52:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:52:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:52:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:52:54 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:52:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 13:52:54 --> Final output sent to browser
DEBUG - 2015-08-25 13:52:54 --> Total execution time: 0.0614
DEBUG - 2015-08-25 13:52:54 --> Config Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:52:54 --> URI Class Initialized
DEBUG - 2015-08-25 13:52:54 --> Router Class Initialized
ERROR - 2015-08-25 13:52:54 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:53:46 --> Config Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:53:46 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:53:46 --> URI Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Router Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Output Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Security Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Input Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:53:46 --> Language Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Loader Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:53:46 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Session Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:53:46 --> Session routines successfully run
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Controller Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Model Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:53:46 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:53:46 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:53:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:53:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:53:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:53:46 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:53:46 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 13:53:46 --> Final output sent to browser
DEBUG - 2015-08-25 13:53:46 --> Total execution time: 0.0651
DEBUG - 2015-08-25 13:53:46 --> Config Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:53:46 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:53:46 --> URI Class Initialized
DEBUG - 2015-08-25 13:53:46 --> Router Class Initialized
ERROR - 2015-08-25 13:53:46 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:54:51 --> Config Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:54:51 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:54:51 --> URI Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Router Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Output Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Security Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Input Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:54:51 --> Language Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Loader Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:54:51 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Session Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:54:51 --> Session routines successfully run
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Controller Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Model Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:54:51 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:54:51 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:54:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:54:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:54:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:54:51 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:54:51 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 13:54:51 --> Final output sent to browser
DEBUG - 2015-08-25 13:54:51 --> Total execution time: 0.0566
DEBUG - 2015-08-25 13:54:51 --> Config Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:54:51 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:54:51 --> URI Class Initialized
DEBUG - 2015-08-25 13:54:51 --> Router Class Initialized
ERROR - 2015-08-25 13:54:51 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:58:25 --> Config Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:58:25 --> URI Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Router Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Output Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Security Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Input Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:58:25 --> Language Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Loader Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:58:25 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Session Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:58:25 --> Session routines successfully run
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Controller Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:58:25 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:58:25 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:58:25 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:58:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:58:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:58:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:58:25 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:58:25 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 13:58:25 --> Final output sent to browser
DEBUG - 2015-08-25 13:58:25 --> Total execution time: 0.0696
DEBUG - 2015-08-25 13:58:26 --> Config Class Initialized
DEBUG - 2015-08-25 13:58:26 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:58:26 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:58:26 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:58:26 --> URI Class Initialized
DEBUG - 2015-08-25 13:58:26 --> Router Class Initialized
ERROR - 2015-08-25 13:58:26 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:59:20 --> Config Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:59:20 --> URI Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Router Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Output Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Security Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Input Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:59:20 --> Language Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Loader Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:59:20 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Session Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:59:20 --> Session routines successfully run
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Controller Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:59:20 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Config Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:59:20 --> URI Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Router Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Output Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Security Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Input Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:59:20 --> Language Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Loader Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:59:20 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Session Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:59:20 --> Session routines successfully run
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Controller Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:59:20 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:59:20 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 13:59:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 13:59:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 13:59:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 13:59:20 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 13:59:20 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 13:59:20 --> Final output sent to browser
DEBUG - 2015-08-25 13:59:20 --> Total execution time: 0.0629
DEBUG - 2015-08-25 13:59:20 --> Config Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:59:20 --> URI Class Initialized
DEBUG - 2015-08-25 13:59:20 --> Router Class Initialized
ERROR - 2015-08-25 13:59:20 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 13:59:25 --> Config Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Hooks Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Utf8 Class Initialized
DEBUG - 2015-08-25 13:59:25 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 13:59:25 --> URI Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Router Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Output Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Security Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Input Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 13:59:25 --> Language Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Loader Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Helper loaded: url_helper
DEBUG - 2015-08-25 13:59:25 --> Database Driver Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Session Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Helper loaded: string_helper
DEBUG - 2015-08-25 13:59:25 --> Session routines successfully run
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Controller Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Model Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Helper loaded: form_helper
DEBUG - 2015-08-25 13:59:25 --> Form Validation Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Pagination Class Initialized
DEBUG - 2015-08-25 13:59:25 --> Helper loaded: pdf_helper
DEBUG - 2015-08-25 13:59:26 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2015-08-25 13:59:26 --> Final output sent to browser
DEBUG - 2015-08-25 13:59:26 --> Total execution time: 0.5397
DEBUG - 2015-08-25 14:00:08 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:08 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:08 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Router Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Output Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Security Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Input Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 14:00:08 --> Language Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Loader Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Helper loaded: url_helper
DEBUG - 2015-08-25 14:00:08 --> Database Driver Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Session Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Helper loaded: string_helper
DEBUG - 2015-08-25 14:00:08 --> Session routines successfully run
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Controller Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Helper loaded: form_helper
DEBUG - 2015-08-25 14:00:08 --> Form Validation Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Pagination Class Initialized
DEBUG - 2015-08-25 14:00:08 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 14:00:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 14:00:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 14:00:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 14:00:08 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 14:00:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-08-25 14:00:08 --> Final output sent to browser
DEBUG - 2015-08-25 14:00:08 --> Total execution time: 0.1208
DEBUG - 2015-08-25 14:00:08 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:08 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:08 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:08 --> Router Class Initialized
ERROR - 2015-08-25 14:00:08 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 14:00:16 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:16 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Router Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Output Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Security Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Input Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 14:00:16 --> Language Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Loader Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Helper loaded: url_helper
DEBUG - 2015-08-25 14:00:16 --> Database Driver Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Session Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Helper loaded: string_helper
DEBUG - 2015-08-25 14:00:16 --> Session routines successfully run
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Controller Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Helper loaded: form_helper
DEBUG - 2015-08-25 14:00:16 --> Form Validation Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Pagination Class Initialized
DEBUG - 2015-08-25 14:00:16 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 14:00:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 14:00:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 14:00:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 14:00:16 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 14:00:16 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 14:00:16 --> Final output sent to browser
DEBUG - 2015-08-25 14:00:16 --> Total execution time: 0.0699
DEBUG - 2015-08-25 14:00:16 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:16 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:16 --> Router Class Initialized
ERROR - 2015-08-25 14:00:16 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 14:00:52 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:52 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Router Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Output Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Security Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Input Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 14:00:52 --> Language Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Loader Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Helper loaded: url_helper
DEBUG - 2015-08-25 14:00:52 --> Database Driver Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Session Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Helper loaded: string_helper
DEBUG - 2015-08-25 14:00:52 --> Session routines successfully run
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Controller Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Helper loaded: form_helper
DEBUG - 2015-08-25 14:00:52 --> Form Validation Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Pagination Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-08-25 14:00:52 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:52 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Router Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Output Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Security Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Input Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 14:00:52 --> Language Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Loader Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Helper loaded: url_helper
DEBUG - 2015-08-25 14:00:52 --> Database Driver Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Session Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Helper loaded: string_helper
DEBUG - 2015-08-25 14:00:52 --> Session routines successfully run
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Controller Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Model Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Helper loaded: form_helper
DEBUG - 2015-08-25 14:00:52 --> Form Validation Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Pagination Class Initialized
DEBUG - 2015-08-25 14:00:52 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 14:00:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 14:00:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 14:00:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 14:00:52 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 14:00:52 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-08-25 14:00:52 --> Final output sent to browser
DEBUG - 2015-08-25 14:00:52 --> Total execution time: 0.0595
DEBUG - 2015-08-25 14:00:52 --> Config Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:00:52 --> URI Class Initialized
DEBUG - 2015-08-25 14:00:52 --> Router Class Initialized
ERROR - 2015-08-25 14:00:52 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 14:01:05 --> Config Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:01:05 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:01:05 --> URI Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Router Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Output Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Security Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Input Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 14:01:05 --> Language Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Loader Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Helper loaded: url_helper
DEBUG - 2015-08-25 14:01:05 --> Database Driver Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Session Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Helper loaded: string_helper
DEBUG - 2015-08-25 14:01:05 --> Session routines successfully run
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Controller Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Helper loaded: form_helper
DEBUG - 2015-08-25 14:01:05 --> Form Validation Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Pagination Class Initialized
DEBUG - 2015-08-25 14:01:05 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 14:01:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 14:01:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 14:01:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 14:01:05 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 14:01:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 14:01:05 --> Final output sent to browser
DEBUG - 2015-08-25 14:01:05 --> Total execution time: 0.0636
DEBUG - 2015-08-25 14:01:05 --> Config Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:01:05 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:01:05 --> URI Class Initialized
DEBUG - 2015-08-25 14:01:05 --> Router Class Initialized
ERROR - 2015-08-25 14:01:05 --> 404 Page Not Found --> js
DEBUG - 2015-08-25 14:01:56 --> Config Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:01:56 --> URI Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Router Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Output Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Security Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Input Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Global POST and COOKIE data sanitized
DEBUG - 2015-08-25 14:01:56 --> Language Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Loader Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Helper loaded: url_helper
DEBUG - 2015-08-25 14:01:56 --> Database Driver Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Session Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Helper loaded: string_helper
DEBUG - 2015-08-25 14:01:56 --> Session routines successfully run
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Controller Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Model Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Helper loaded: form_helper
DEBUG - 2015-08-25 14:01:56 --> Form Validation Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Pagination Class Initialized
DEBUG - 2015-08-25 14:01:56 --> File loaded: application/views/header.php
DEBUG - 2015-08-25 14:01:56 --> File loaded: application/views/navbar.php
DEBUG - 2015-08-25 14:01:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-08-25 14:01:56 --> File loaded: application/views/sidebar.php
DEBUG - 2015-08-25 14:01:56 --> File loaded: application/views/footer.php
DEBUG - 2015-08-25 14:01:56 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-08-25 14:01:56 --> Final output sent to browser
DEBUG - 2015-08-25 14:01:56 --> Total execution time: 0.0599
DEBUG - 2015-08-25 14:01:56 --> Config Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Hooks Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Utf8 Class Initialized
DEBUG - 2015-08-25 14:01:56 --> UTF-8 Support Enabled
DEBUG - 2015-08-25 14:01:56 --> URI Class Initialized
DEBUG - 2015-08-25 14:01:56 --> Router Class Initialized
ERROR - 2015-08-25 14:01:56 --> 404 Page Not Found --> js
