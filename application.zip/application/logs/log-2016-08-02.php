<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-08-02 00:15:01 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:01 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:01 --> No URI present. Default controller set.
DEBUG - 2016-08-02 00:15:01 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:01 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:01 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:01 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:02 --> A session cookie was not found.
DEBUG - 2016-08-02 00:15:02 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:02 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:02 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:02 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-02 00:15:02 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:02 --> Total execution time: 1.4461
DEBUG - 2016-08-02 00:15:11 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:11 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:11 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:11 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:11 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-02 00:15:12 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:12 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:12 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:12 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:12 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:12 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:12 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:12 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:15:12 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:12 --> Total execution time: 0.2930
DEBUG - 2016-08-02 00:15:16 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:16 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:16 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:16 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:16 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:16 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:16 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:16 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:16 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:15:16 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:16 --> Total execution time: 0.0390
DEBUG - 2016-08-02 00:15:19 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:19 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:19 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:19 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:19 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 00:15:19 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:19 --> Total execution time: 0.1870
DEBUG - 2016-08-02 00:15:31 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:31 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:31 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:31 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:31 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:31 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:31 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-02 00:15:31 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:31 --> Total execution time: 0.2620
DEBUG - 2016-08-02 00:15:35 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:35 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:35 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:35 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:35 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:36 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 00:15:36 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:36 --> Total execution time: 1.2561
DEBUG - 2016-08-02 00:15:44 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:44 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:44 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:44 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:44 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:44 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:44 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:44 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 00:15:44 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:44 --> Total execution time: 0.3140
DEBUG - 2016-08-02 00:15:46 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:46 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:46 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:46 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:46 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:47 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 00:15:47 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:47 --> Total execution time: 0.3226
DEBUG - 2016-08-02 00:15:53 --> Config Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:15:53 --> URI Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Router Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Output Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Security Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Input Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:15:53 --> Language Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Loader Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:15:53 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Session Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:15:53 --> Session routines successfully run
DEBUG - 2016-08-02 00:15:53 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Controller Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Model Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:15:53 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:15:53 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:15:53 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:15:53 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:15:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:15:53 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:15:53 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:15:53 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 00:15:53 --> Final output sent to browser
DEBUG - 2016-08-02 00:15:53 --> Total execution time: 0.1270
DEBUG - 2016-08-02 00:17:30 --> Config Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:17:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:17:30 --> URI Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Router Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Output Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Security Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Input Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:17:30 --> Language Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Loader Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:17:30 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Session Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:17:30 --> Session routines successfully run
DEBUG - 2016-08-02 00:17:30 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Controller Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:17:30 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:17:30 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:17:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:17:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:17:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:17:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:17:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:17:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:17:30 --> Final output sent to browser
DEBUG - 2016-08-02 00:17:30 --> Total execution time: 0.0380
DEBUG - 2016-08-02 00:17:35 --> Config Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:17:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:17:35 --> URI Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Router Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Output Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Security Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Input Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:17:35 --> Language Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Loader Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:17:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Session Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:17:35 --> Session routines successfully run
DEBUG - 2016-08-02 00:17:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Controller Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:17:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:17:35 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:17:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:17:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:17:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:17:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:17:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:17:35 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 00:17:35 --> Final output sent to browser
DEBUG - 2016-08-02 00:17:35 --> Total execution time: 0.0620
DEBUG - 2016-08-02 00:17:38 --> Config Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:17:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:17:38 --> URI Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Router Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Output Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Security Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Input Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:17:38 --> Language Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Loader Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:17:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Session Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:17:38 --> Session routines successfully run
DEBUG - 2016-08-02 00:17:38 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Controller Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:17:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:17:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:17:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:17:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:17:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:17:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:17:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:17:38 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 00:17:38 --> Final output sent to browser
DEBUG - 2016-08-02 00:17:38 --> Total execution time: 0.0650
DEBUG - 2016-08-02 00:17:49 --> Config Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:17:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:17:49 --> URI Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Router Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Output Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Security Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Input Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:17:49 --> Language Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Loader Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:17:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Session Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:17:49 --> Session routines successfully run
DEBUG - 2016-08-02 00:17:49 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Controller Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Model Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:17:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:17:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:17:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:17:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:17:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:17:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:17:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:17:49 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-02 00:17:49 --> Final output sent to browser
DEBUG - 2016-08-02 00:17:49 --> Total execution time: 0.1610
DEBUG - 2016-08-02 00:18:27 --> Config Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:18:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:18:27 --> URI Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Router Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Output Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Security Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Input Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:18:27 --> Language Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Loader Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:18:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Session Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:18:27 --> Session routines successfully run
DEBUG - 2016-08-02 00:18:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Controller Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:18:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:18:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:18:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:18:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:18:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:18:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:18:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:18:27 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 00:18:27 --> Final output sent to browser
DEBUG - 2016-08-02 00:18:27 --> Total execution time: 0.1350
DEBUG - 2016-08-02 00:20:05 --> Config Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:20:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:20:05 --> URI Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Router Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Output Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Security Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Input Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:20:05 --> Language Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Loader Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:20:05 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Session Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:20:05 --> Session routines successfully run
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Controller Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:20:05 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:20:05 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:20:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:20:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:20:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:20:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:20:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:20:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 00:20:05 --> Final output sent to browser
DEBUG - 2016-08-02 00:20:05 --> Total execution time: 0.3250
DEBUG - 2016-08-02 00:20:08 --> Config Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:20:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:20:08 --> URI Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Router Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Output Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Security Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Input Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:20:08 --> Language Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Loader Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:20:08 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Session Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:20:08 --> Session routines successfully run
DEBUG - 2016-08-02 00:20:08 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Controller Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Model Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:20:08 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:20:08 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:20:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:20:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:20:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:20:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:20:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:20:08 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 00:20:08 --> Final output sent to browser
DEBUG - 2016-08-02 00:20:08 --> Total execution time: 0.0610
DEBUG - 2016-08-02 00:21:00 --> Config Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:21:00 --> URI Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Router Class Initialized
DEBUG - 2016-08-02 00:21:00 --> No URI present. Default controller set.
DEBUG - 2016-08-02 00:21:00 --> Output Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Security Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Input Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:21:00 --> Language Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Loader Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:21:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Session Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:21:00 --> Session routines successfully run
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Controller Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:21:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Config Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:21:00 --> URI Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Router Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Output Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Security Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Input Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:21:00 --> Language Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Loader Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:21:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Session Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:21:00 --> Session routines successfully run
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Controller Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:21:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:21:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:21:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:21:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:21:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:21:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:21:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:21:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:21:00 --> Final output sent to browser
DEBUG - 2016-08-02 00:21:00 --> Total execution time: 0.0450
DEBUG - 2016-08-02 00:21:04 --> Config Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:21:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:21:04 --> URI Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Router Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Output Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Security Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Input Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:21:04 --> Language Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Loader Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:21:04 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Session Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:21:04 --> Session routines successfully run
DEBUG - 2016-08-02 00:21:04 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Controller Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:21:04 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:21:04 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:21:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:21:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:21:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:21:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:21:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:21:04 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:21:04 --> Final output sent to browser
DEBUG - 2016-08-02 00:21:04 --> Total execution time: 0.0470
DEBUG - 2016-08-02 00:21:06 --> Config Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:21:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:21:06 --> URI Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Router Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Output Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Security Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Input Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:21:06 --> Language Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Loader Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:21:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Session Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:21:06 --> Session routines successfully run
DEBUG - 2016-08-02 00:21:06 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Controller Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:21:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:21:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:21:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:21:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:21:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:21:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:21:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:21:06 --> File loaded: application/views/admin/addAdminView.php
DEBUG - 2016-08-02 00:21:06 --> Final output sent to browser
DEBUG - 2016-08-02 00:21:06 --> Total execution time: 0.0650
DEBUG - 2016-08-02 00:21:07 --> Config Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:21:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:21:07 --> URI Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Router Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Output Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Security Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Input Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:21:07 --> Language Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Loader Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:21:07 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Session Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:21:07 --> Session routines successfully run
DEBUG - 2016-08-02 00:21:07 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Controller Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Model Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:21:07 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:21:07 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:21:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:21:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:21:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:21:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:21:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:21:07 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:21:07 --> Final output sent to browser
DEBUG - 2016-08-02 00:21:07 --> Total execution time: 0.0410
DEBUG - 2016-08-02 00:24:36 --> Config Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:24:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:24:36 --> URI Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Router Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Output Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Security Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Input Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:24:36 --> Language Class Initialized
DEBUG - 2016-08-02 00:24:36 --> Loader Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:24:37 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Session Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:24:37 --> Session routines successfully run
DEBUG - 2016-08-02 00:24:37 --> Model Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Model Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Controller Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Model Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:24:37 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:24:37 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:24:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:24:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:24:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:24:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:24:37 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:24:37 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 00:24:37 --> Final output sent to browser
DEBUG - 2016-08-02 00:24:37 --> Total execution time: 0.0660
DEBUG - 2016-08-02 00:26:18 --> Config Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:26:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:26:18 --> URI Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Router Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Output Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Security Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Input Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:26:18 --> Language Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Loader Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:26:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Session Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:26:18 --> Session routines successfully run
DEBUG - 2016-08-02 00:26:18 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Controller Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:26:18 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:26:18 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:26:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:26:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:26:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:26:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:26:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:26:18 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:26:18 --> Final output sent to browser
DEBUG - 2016-08-02 00:26:18 --> Total execution time: 0.0380
DEBUG - 2016-08-02 00:26:22 --> Config Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:26:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:26:22 --> URI Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Router Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Output Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Security Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Input Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:26:22 --> Language Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Loader Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:26:22 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Session Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:26:22 --> Session routines successfully run
DEBUG - 2016-08-02 00:26:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Controller Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:26:22 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:26:22 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:26:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:26:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:26:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:26:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:26:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:26:22 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 00:26:22 --> Final output sent to browser
DEBUG - 2016-08-02 00:26:22 --> Total execution time: 0.0620
DEBUG - 2016-08-02 00:26:27 --> Config Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:26:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:26:27 --> URI Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Router Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Output Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Security Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Input Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:26:27 --> Language Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Loader Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:26:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Session Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:26:27 --> Session routines successfully run
DEBUG - 2016-08-02 00:26:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Controller Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:26:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:26:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:26:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:26:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:26:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:26:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:26:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:26:27 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 00:26:27 --> Final output sent to browser
DEBUG - 2016-08-02 00:26:27 --> Total execution time: 0.0410
DEBUG - 2016-08-02 00:26:32 --> Config Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:26:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:26:32 --> URI Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Router Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Output Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Security Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Input Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:26:32 --> Language Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Loader Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:26:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Session Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:26:32 --> Session routines successfully run
DEBUG - 2016-08-02 00:26:32 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Controller Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Model Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:26:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:26:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:26:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:26:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:26:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:26:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:26:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:26:32 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-02 00:26:32 --> Final output sent to browser
DEBUG - 2016-08-02 00:26:32 --> Total execution time: 0.0460
DEBUG - 2016-08-02 00:29:14 --> Config Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:29:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:29:14 --> URI Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Router Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Output Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Security Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Input Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:29:14 --> Language Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Loader Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:29:14 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Session Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:29:14 --> Session routines successfully run
DEBUG - 2016-08-02 00:29:14 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Controller Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:29:14 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:29:14 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:29:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:29:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:29:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:29:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:29:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:29:14 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:29:14 --> Final output sent to browser
DEBUG - 2016-08-02 00:29:14 --> Total execution time: 0.0530
DEBUG - 2016-08-02 00:29:19 --> Config Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:29:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:29:19 --> URI Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Router Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Output Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Security Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Input Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:29:19 --> Language Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Loader Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:29:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Session Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:29:19 --> Session routines successfully run
DEBUG - 2016-08-02 00:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Controller Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:29:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:29:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:29:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:29:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:29:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:29:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:29:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:29:19 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 00:29:19 --> Final output sent to browser
DEBUG - 2016-08-02 00:29:19 --> Total execution time: 0.0390
DEBUG - 2016-08-02 00:29:24 --> Config Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:29:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:29:24 --> URI Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Router Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Output Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Security Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Input Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:29:24 --> Language Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Loader Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:29:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Session Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:29:24 --> Session routines successfully run
DEBUG - 2016-08-02 00:29:24 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Controller Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:29:24 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:29:24 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:29:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:29:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:29:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:29:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:29:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:29:24 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 00:29:24 --> Final output sent to browser
DEBUG - 2016-08-02 00:29:24 --> Total execution time: 0.0590
DEBUG - 2016-08-02 00:29:27 --> Config Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:29:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:29:27 --> URI Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Router Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Output Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Security Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Input Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:29:27 --> Language Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Loader Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:29:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Session Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:29:27 --> Session routines successfully run
DEBUG - 2016-08-02 00:29:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Controller Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Model Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:29:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:29:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:29:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:29:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:29:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:29:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:29:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:29:27 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:29:27 --> Final output sent to browser
DEBUG - 2016-08-02 00:29:27 --> Total execution time: 0.0480
DEBUG - 2016-08-02 00:30:09 --> Config Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:30:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:30:09 --> URI Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Router Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Output Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Security Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Input Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:30:09 --> Language Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Loader Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:30:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Session Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:30:09 --> Session routines successfully run
DEBUG - 2016-08-02 00:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Controller Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:30:09 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:30:09 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:30:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:30:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:30:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:30:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:30:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:30:09 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 00:30:09 --> Final output sent to browser
DEBUG - 2016-08-02 00:30:09 --> Total execution time: 0.0400
DEBUG - 2016-08-02 00:30:15 --> Config Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:30:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:30:15 --> URI Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Router Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Output Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Security Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Input Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:30:15 --> Language Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Loader Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:30:15 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Session Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:30:15 --> Session routines successfully run
DEBUG - 2016-08-02 00:30:15 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Controller Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:30:15 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:30:15 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:30:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:30:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:30:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:30:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:30:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:30:15 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 00:30:15 --> Final output sent to browser
DEBUG - 2016-08-02 00:30:15 --> Total execution time: 0.0490
DEBUG - 2016-08-02 00:30:22 --> Config Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:30:22 --> URI Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Router Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Output Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Security Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Input Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:30:22 --> Language Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Loader Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:30:22 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Session Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:30:22 --> Session routines successfully run
DEBUG - 2016-08-02 00:30:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Controller Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:30:22 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:30:22 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:30:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:30:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:30:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:30:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:30:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:30:22 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-02 00:30:22 --> Final output sent to browser
DEBUG - 2016-08-02 00:30:22 --> Total execution time: 0.0570
DEBUG - 2016-08-02 00:30:30 --> Config Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:30:30 --> URI Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Router Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Output Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Security Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Input Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:30:30 --> Language Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Loader Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:30:30 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Session Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:30:30 --> Session routines successfully run
DEBUG - 2016-08-02 00:30:30 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Controller Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:30:30 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:30:30 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:30:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:30:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:30:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:30:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:30:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:30:30 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 00:30:30 --> Final output sent to browser
DEBUG - 2016-08-02 00:30:30 --> Total execution time: 0.0700
DEBUG - 2016-08-02 00:30:45 --> Config Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:30:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:30:45 --> URI Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Router Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Output Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Security Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Input Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:30:45 --> Language Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Loader Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:30:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Session Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:30:45 --> Session routines successfully run
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Controller Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:30:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:30:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:30:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:30:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:30:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:30:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:30:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:30:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 00:30:46 --> Final output sent to browser
DEBUG - 2016-08-02 00:30:46 --> Total execution time: 0.3060
DEBUG - 2016-08-02 00:30:48 --> Config Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:30:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:30:48 --> URI Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Router Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Output Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Security Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Input Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:30:48 --> Language Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Loader Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:30:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Session Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:30:48 --> Session routines successfully run
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Controller Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:30:48 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:48 --> Model Class Initialized
DEBUG - 2016-08-02 00:30:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:30:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:30:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:30:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:30:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:30:49 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 00:30:49 --> Final output sent to browser
DEBUG - 2016-08-02 00:30:49 --> Total execution time: 0.1440
DEBUG - 2016-08-02 00:34:10 --> Config Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:34:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:34:10 --> URI Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Router Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Output Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Security Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Input Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:34:10 --> Language Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Loader Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:34:10 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Session Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:34:10 --> Session routines successfully run
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Controller Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Model Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:34:10 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:34:10 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:34:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:34:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:34:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:34:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:34:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:34:10 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 00:34:10 --> Final output sent to browser
DEBUG - 2016-08-02 00:34:10 --> Total execution time: 0.3090
DEBUG - 2016-08-02 00:57:33 --> Config Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:57:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:57:33 --> URI Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Router Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Output Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Security Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Input Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:57:33 --> Language Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Loader Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:57:33 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Session Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:57:33 --> Session routines successfully run
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Controller Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:57:33 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:33 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Config Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:57:43 --> URI Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Router Class Initialized
DEBUG - 2016-08-02 00:57:43 --> No URI present. Default controller set.
DEBUG - 2016-08-02 00:57:43 --> Output Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Security Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Input Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:57:43 --> Language Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Loader Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:57:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Session Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:57:43 --> Session routines successfully run
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Controller Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:57:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Config Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 00:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 00:57:43 --> URI Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Router Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Output Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Security Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Input Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 00:57:43 --> Language Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Loader Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 00:57:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Session Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 00:57:43 --> Session routines successfully run
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Controller Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 00:57:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 00:57:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 00:57:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 00:57:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 00:57:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 00:57:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 00:57:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 00:57:43 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 00:57:43 --> Final output sent to browser
DEBUG - 2016-08-02 00:57:43 --> Total execution time: 0.0312
DEBUG - 2016-08-02 01:11:07 --> Config Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:11:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:11:07 --> URI Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Router Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Output Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Security Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Input Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:11:07 --> Language Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Loader Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:11:07 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Session Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:11:07 --> Session routines successfully run
DEBUG - 2016-08-02 01:11:07 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:07 --> Controller Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:11:08 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Model Class Initialized
DEBUG - 2016-08-02 01:11:08 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Config Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:12:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:12:52 --> URI Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Router Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Output Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Security Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Input Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:12:52 --> Language Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Loader Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:12:52 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Session Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:12:52 --> Session routines successfully run
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Controller Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:12:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:12:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:12:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:12:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:12:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:12:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:12:52 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:12:52 --> Final output sent to browser
DEBUG - 2016-08-02 01:12:52 --> Total execution time: 0.1012
DEBUG - 2016-08-02 01:13:18 --> Config Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:13:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:13:18 --> URI Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Router Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Output Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Security Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Input Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:13:18 --> Language Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Loader Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:13:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Session Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:13:18 --> Session routines successfully run
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Controller Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:13:18 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:13:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:13:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:13:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:13:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:13:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:13:18 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:13:18 --> Final output sent to browser
DEBUG - 2016-08-02 01:13:18 --> Total execution time: 0.0790
DEBUG - 2016-08-02 01:14:25 --> Config Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:14:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:14:25 --> URI Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Router Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Output Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Security Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Input Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:14:25 --> Language Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Loader Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:14:25 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Session Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:14:25 --> Session routines successfully run
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Controller Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:14:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:14:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:14:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:14:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:14:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:14:25 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:14:25 --> Final output sent to browser
DEBUG - 2016-08-02 01:14:25 --> Total execution time: 0.0906
DEBUG - 2016-08-02 01:14:31 --> Config Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:14:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:14:31 --> URI Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Router Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Output Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Security Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Input Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:14:31 --> Language Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Loader Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:14:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Session Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:14:31 --> Session routines successfully run
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Controller Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:14:31 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> Model Class Initialized
DEBUG - 2016-08-02 01:14:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:14:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:14:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:14:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:14:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:14:31 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:14:31 --> Final output sent to browser
DEBUG - 2016-08-02 01:14:31 --> Total execution time: 0.0850
DEBUG - 2016-08-02 01:15:19 --> Config Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:15:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:15:19 --> URI Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Router Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Output Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Security Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Input Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:15:19 --> Language Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Loader Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:15:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Session Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:15:19 --> Session routines successfully run
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Controller Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:15:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:15:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:15:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:15:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:15:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:15:19 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:15:19 --> Final output sent to browser
DEBUG - 2016-08-02 01:15:19 --> Total execution time: 0.1066
DEBUG - 2016-08-02 01:15:37 --> Config Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:15:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:15:37 --> URI Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Router Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Output Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Security Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Input Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:15:37 --> Language Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Loader Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:15:37 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Session Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:15:37 --> Session routines successfully run
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Controller Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:15:37 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> Model Class Initialized
DEBUG - 2016-08-02 01:15:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:15:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:15:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:15:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:15:37 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:15:37 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:15:37 --> Final output sent to browser
DEBUG - 2016-08-02 01:15:37 --> Total execution time: 0.0966
DEBUG - 2016-08-02 01:22:11 --> Config Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:22:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:22:11 --> URI Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Router Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Output Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Security Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Input Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:22:11 --> Language Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Loader Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:22:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Session Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:22:11 --> Session routines successfully run
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Controller Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:22:11 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:22:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:22:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:22:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:22:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:22:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:22:11 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:22:11 --> Final output sent to browser
DEBUG - 2016-08-02 01:22:11 --> Total execution time: 0.0876
DEBUG - 2016-08-02 01:23:12 --> Config Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:23:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:23:12 --> URI Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Router Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Output Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Security Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Input Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:23:12 --> Language Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Loader Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:23:12 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Session Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:23:12 --> Session routines successfully run
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Controller Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:23:12 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:23:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:23:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:23:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:23:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:23:12 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:23:12 --> Final output sent to browser
DEBUG - 2016-08-02 01:23:12 --> Total execution time: 0.0690
DEBUG - 2016-08-02 01:23:41 --> Config Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:23:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:23:41 --> URI Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Router Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Output Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Security Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Input Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:23:41 --> Language Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Loader Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:23:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Session Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:23:41 --> Session routines successfully run
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Controller Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:23:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:23:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:23:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:23:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:23:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:23:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:23:41 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:23:41 --> Final output sent to browser
DEBUG - 2016-08-02 01:23:41 --> Total execution time: 0.0750
DEBUG - 2016-08-02 01:26:04 --> Config Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:26:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:26:04 --> URI Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Router Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Output Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Security Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Input Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:26:04 --> Language Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Loader Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:26:04 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Session Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:26:04 --> Session routines successfully run
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Controller Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:26:04 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:26:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:26:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:26:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:26:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:26:04 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:26:04 --> Final output sent to browser
DEBUG - 2016-08-02 01:26:04 --> Total execution time: 0.0670
DEBUG - 2016-08-02 01:26:28 --> Config Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:26:28 --> URI Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Router Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Output Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Security Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Input Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:26:28 --> Language Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Loader Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:26:28 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Session Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:26:28 --> Session routines successfully run
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Controller Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:26:28 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> Model Class Initialized
DEBUG - 2016-08-02 01:26:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:26:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:26:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:26:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:26:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:26:28 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:26:28 --> Final output sent to browser
DEBUG - 2016-08-02 01:26:28 --> Total execution time: 0.0716
DEBUG - 2016-08-02 01:27:00 --> Config Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:27:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:27:00 --> URI Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Router Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Output Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Security Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Input Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:27:00 --> Language Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Loader Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:27:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Session Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:27:00 --> Session routines successfully run
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Controller Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:27:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:27:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:27:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:27:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:27:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:27:00 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:27:00 --> Final output sent to browser
DEBUG - 2016-08-02 01:27:00 --> Total execution time: 0.0600
DEBUG - 2016-08-02 01:27:40 --> Config Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:27:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:27:40 --> URI Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Router Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Output Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Security Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Input Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:27:40 --> Language Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Loader Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:27:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Session Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:27:40 --> Session routines successfully run
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Controller Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:27:40 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:27:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:27:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:27:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:27:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:27:40 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:27:40 --> Final output sent to browser
DEBUG - 2016-08-02 01:27:40 --> Total execution time: 0.0610
DEBUG - 2016-08-02 01:27:56 --> Config Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:27:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:27:56 --> URI Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Router Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Output Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Security Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Input Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:27:56 --> Language Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Loader Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:27:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Session Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:27:56 --> Session routines successfully run
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Controller Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:27:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:27:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:27:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:27:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:27:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:27:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:27:56 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:27:56 --> Final output sent to browser
DEBUG - 2016-08-02 01:27:56 --> Total execution time: 0.0560
DEBUG - 2016-08-02 01:28:11 --> Config Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:28:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:28:11 --> URI Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Router Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Output Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Security Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Input Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:28:11 --> Language Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Loader Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:28:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Session Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:28:11 --> A session cookie was not found.
DEBUG - 2016-08-02 01:28:11 --> Session routines successfully run
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Controller Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Config Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:28:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:28:11 --> URI Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Router Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Output Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Security Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Input Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:28:11 --> Language Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Loader Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:28:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Session Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:28:11 --> Session routines successfully run
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Controller Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:11 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:28:11 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:28:11 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-02 01:28:11 --> Final output sent to browser
DEBUG - 2016-08-02 01:28:11 --> Total execution time: 0.0312
DEBUG - 2016-08-02 01:28:19 --> Config Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:28:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:28:19 --> URI Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Router Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Output Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Security Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Input Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:28:19 --> Language Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Loader Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:28:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Session Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:28:19 --> Session routines successfully run
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Controller Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:28:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-02 01:28:19 --> Config Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:28:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:28:19 --> URI Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Router Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Output Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Security Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Input Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:28:19 --> Language Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Loader Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:28:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Session Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:28:19 --> Session routines successfully run
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Controller Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:28:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:28:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:28:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:28:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:28:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:28:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:28:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:28:19 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 01:28:19 --> Final output sent to browser
DEBUG - 2016-08-02 01:28:19 --> Total execution time: 0.0624
DEBUG - 2016-08-02 01:28:23 --> Config Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:28:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:28:23 --> URI Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Router Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Output Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Security Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Input Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:28:23 --> Language Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Loader Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:28:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Session Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:28:23 --> Session routines successfully run
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Controller Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:28:23 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> Model Class Initialized
DEBUG - 2016-08-02 01:28:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:28:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:28:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:28:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:28:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:28:23 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:28:23 --> Final output sent to browser
DEBUG - 2016-08-02 01:28:23 --> Total execution time: 0.0780
DEBUG - 2016-08-02 01:32:40 --> Config Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:32:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:32:40 --> URI Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Router Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Output Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Security Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Input Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:32:40 --> Language Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Loader Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:32:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Session Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:32:40 --> Session routines successfully run
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Controller Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:32:40 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:32:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:32:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:32:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:32:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:32:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:32:40 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:32:40 --> Final output sent to browser
DEBUG - 2016-08-02 01:32:40 --> Total execution time: 0.0720
DEBUG - 2016-08-02 01:33:51 --> Config Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:33:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:33:51 --> URI Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Router Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Output Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Security Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Input Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:33:51 --> Language Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Loader Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:33:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Session Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:33:51 --> Session routines successfully run
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Controller Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:33:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> Model Class Initialized
DEBUG - 2016-08-02 01:33:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:33:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:33:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:33:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:33:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:33:51 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:33:51 --> Final output sent to browser
DEBUG - 2016-08-02 01:33:51 --> Total execution time: 0.0610
DEBUG - 2016-08-02 01:34:00 --> Config Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:34:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:34:00 --> URI Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Router Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Output Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Security Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Input Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:34:00 --> Language Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Loader Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:34:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Session Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:34:00 --> Session routines successfully run
DEBUG - 2016-08-02 01:34:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Controller Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:34:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:34:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:34:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:34:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:34:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:34:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:34:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:34:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 01:34:00 --> Final output sent to browser
DEBUG - 2016-08-02 01:34:00 --> Total execution time: 0.0740
DEBUG - 2016-08-02 01:34:21 --> Config Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:34:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:34:21 --> URI Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Router Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Output Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Security Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Input Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:34:21 --> Language Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Loader Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:34:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Session Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:34:21 --> Session routines successfully run
DEBUG - 2016-08-02 01:34:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Controller Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:34:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:34:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:34:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:34:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:34:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:34:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:34:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:34:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 01:34:21 --> Final output sent to browser
DEBUG - 2016-08-02 01:34:21 --> Total execution time: 0.0380
DEBUG - 2016-08-02 01:34:29 --> Config Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:34:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:34:29 --> URI Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Router Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Output Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Security Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Input Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:34:29 --> Language Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Loader Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:34:29 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Session Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:34:29 --> Session routines successfully run
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Controller Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:34:29 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:34:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:34:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:34:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:34:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:34:29 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:34:29 --> Final output sent to browser
DEBUG - 2016-08-02 01:34:29 --> Total execution time: 0.1060
DEBUG - 2016-08-02 01:34:38 --> Config Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:34:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:34:38 --> URI Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Router Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Output Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Security Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Input Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:34:38 --> Language Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Loader Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:34:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Session Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:34:38 --> Session routines successfully run
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Controller Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:34:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:34:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:34:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:34:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:34:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:34:38 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:34:38 --> Final output sent to browser
DEBUG - 2016-08-02 01:34:38 --> Total execution time: 0.0570
DEBUG - 2016-08-02 01:34:54 --> Config Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:34:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:34:54 --> URI Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Router Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Output Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Security Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Input Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:34:54 --> Language Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Loader Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:34:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Session Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:34:54 --> Session routines successfully run
DEBUG - 2016-08-02 01:34:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Controller Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:34:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:34:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:34:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:34:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:34:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:34:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:34:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:34:54 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 01:34:54 --> Final output sent to browser
DEBUG - 2016-08-02 01:34:54 --> Total execution time: 0.0500
DEBUG - 2016-08-02 01:34:59 --> Config Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:34:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:34:59 --> URI Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Router Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Output Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Security Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Input Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:34:59 --> Language Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Loader Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:34:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Session Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:34:59 --> Session routines successfully run
DEBUG - 2016-08-02 01:34:59 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Controller Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Model Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:34:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:34:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:34:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:34:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:34:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:34:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:34:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:34:59 --> File loaded: application/views/manager/addManagerView.php
DEBUG - 2016-08-02 01:34:59 --> Final output sent to browser
DEBUG - 2016-08-02 01:34:59 --> Total execution time: 0.0790
DEBUG - 2016-08-02 01:35:00 --> Config Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:35:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:35:00 --> URI Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Router Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Output Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Security Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Input Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:35:00 --> Language Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Loader Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:35:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Session Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:35:00 --> Session routines successfully run
DEBUG - 2016-08-02 01:35:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Controller Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:35:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:35:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:35:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:35:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:35:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:35:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:35:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:35:00 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 01:35:00 --> Final output sent to browser
DEBUG - 2016-08-02 01:35:00 --> Total execution time: 0.0500
DEBUG - 2016-08-02 01:35:12 --> Config Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:35:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:35:12 --> URI Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Router Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Output Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Security Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Input Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:35:12 --> Language Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Loader Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:35:12 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Session Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:35:12 --> Session routines successfully run
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Controller Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:35:12 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:35:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:35:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:35:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:35:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:35:13 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:35:13 --> Final output sent to browser
DEBUG - 2016-08-02 01:35:13 --> Total execution time: 0.0620
DEBUG - 2016-08-02 01:35:57 --> Config Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:35:57 --> URI Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Router Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Output Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Security Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Input Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:35:57 --> Language Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Loader Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:35:57 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Session Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:35:57 --> Session routines successfully run
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Controller Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:35:57 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:35:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:35:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:35:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:35:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:35:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:35:57 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:35:57 --> Final output sent to browser
DEBUG - 2016-08-02 01:35:57 --> Total execution time: 0.1010
DEBUG - 2016-08-02 01:36:00 --> Config Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:36:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:36:00 --> URI Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Router Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Output Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Security Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Input Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:36:00 --> Language Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Loader Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:36:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Session Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:36:00 --> Session routines successfully run
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Controller Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:36:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:36:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:36:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:36:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:36:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:36:00 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:36:00 --> Final output sent to browser
DEBUG - 2016-08-02 01:36:00 --> Total execution time: 0.0650
DEBUG - 2016-08-02 01:36:34 --> Config Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:36:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:36:34 --> URI Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Router Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Output Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Security Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Input Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:36:34 --> Language Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Loader Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:36:34 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Session Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:36:34 --> Session routines successfully run
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Controller Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:36:34 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:36:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:36:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:36:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:36:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:36:34 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:36:34 --> Final output sent to browser
DEBUG - 2016-08-02 01:36:34 --> Total execution time: 0.1126
DEBUG - 2016-08-02 01:36:57 --> Config Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:36:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:36:57 --> URI Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Router Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Output Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Security Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Input Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:36:57 --> Language Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Loader Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:36:57 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Session Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:36:57 --> Session routines successfully run
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Controller Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:36:57 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> Model Class Initialized
DEBUG - 2016-08-02 01:36:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:36:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:36:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:36:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:36:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:36:57 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:36:57 --> Final output sent to browser
DEBUG - 2016-08-02 01:36:57 --> Total execution time: 0.0580
DEBUG - 2016-08-02 01:37:19 --> Config Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:37:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:37:19 --> URI Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Router Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Output Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Security Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Input Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:37:19 --> Language Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Loader Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:37:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Session Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:37:19 --> Session routines successfully run
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Controller Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:37:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:37:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:37:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:37:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:37:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:37:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:37:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:37:19 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-02 01:37:19 --> Final output sent to browser
DEBUG - 2016-08-02 01:37:19 --> Total execution time: 0.1546
DEBUG - 2016-08-02 01:39:41 --> Config Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:39:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:39:41 --> URI Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Router Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Output Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Security Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Input Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:39:41 --> Language Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Loader Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:39:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Session Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:39:41 --> Session routines successfully run
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Controller Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:39:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:39:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:39:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:39:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:39:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:39:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:39:41 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:39:41 --> Final output sent to browser
DEBUG - 2016-08-02 01:39:41 --> Total execution time: 0.0796
DEBUG - 2016-08-02 01:40:06 --> Config Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:40:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:40:06 --> URI Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Router Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Output Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Security Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Input Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:40:06 --> Language Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Loader Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:40:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Session Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:40:06 --> Session routines successfully run
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Controller Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:40:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:40:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:40:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:40:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:40:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:40:06 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:40:06 --> Final output sent to browser
DEBUG - 2016-08-02 01:40:06 --> Total execution time: 0.0700
DEBUG - 2016-08-02 01:40:48 --> Config Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:40:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:40:48 --> URI Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Router Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Output Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Security Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Input Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:40:48 --> Language Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Loader Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:40:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Session Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:40:48 --> Session routines successfully run
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Controller Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:40:48 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:40:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:40:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:40:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:40:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:40:48 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:40:48 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:40:48 --> Final output sent to browser
DEBUG - 2016-08-02 01:40:48 --> Total execution time: 0.0710
DEBUG - 2016-08-02 01:41:52 --> Config Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:41:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:41:52 --> URI Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Router Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Output Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Security Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Input Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:41:52 --> Language Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Loader Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:41:52 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Session Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:41:52 --> Session routines successfully run
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Controller Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:41:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> Model Class Initialized
DEBUG - 2016-08-02 01:41:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:41:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:41:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:41:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:41:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:41:52 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:41:52 --> Final output sent to browser
DEBUG - 2016-08-02 01:41:52 --> Total execution time: 0.0640
DEBUG - 2016-08-02 01:42:24 --> Config Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:42:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:42:24 --> URI Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Router Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Output Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Security Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Input Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:42:24 --> Language Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Loader Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:42:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Session Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:42:24 --> Session routines successfully run
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Controller Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:42:24 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:42:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:42:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:42:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:42:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:42:24 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:42:24 --> Final output sent to browser
DEBUG - 2016-08-02 01:42:24 --> Total execution time: 0.1550
DEBUG - 2016-08-02 01:42:45 --> Config Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:42:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:42:45 --> URI Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Router Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Output Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Security Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Input Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:42:45 --> Language Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Loader Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:42:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Session Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:42:45 --> Session routines successfully run
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Controller Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:42:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:42:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:42:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:42:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:42:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:42:45 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:42:45 --> Final output sent to browser
DEBUG - 2016-08-02 01:42:45 --> Total execution time: 0.0670
DEBUG - 2016-08-02 01:42:48 --> Config Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:42:48 --> URI Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Router Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Output Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Security Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Input Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:42:48 --> Language Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Loader Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:42:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Session Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:42:48 --> Session routines successfully run
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Controller Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:42:48 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> Model Class Initialized
DEBUG - 2016-08-02 01:42:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:42:48 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 01:42:48 --> Final output sent to browser
DEBUG - 2016-08-02 01:42:48 --> Total execution time: 0.0690
DEBUG - 2016-08-02 01:43:15 --> Config Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:43:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:43:15 --> URI Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Router Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Output Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Security Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Input Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:43:15 --> Language Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Loader Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:43:15 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Session Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:43:15 --> Session routines successfully run
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Controller Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:43:15 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:15 --> Model Class Initialized
ERROR - 2016-08-02 01:43:15 --> Severity: Notice  --> Undefined variable: crm D:\xampp\htdocs\asmc\application\views\form\email.php 130
ERROR - 2016-08-02 01:43:15 --> Severity: Notice  --> Undefined variable: sm D:\xampp\htdocs\asmc\application\views\form\email.php 132
DEBUG - 2016-08-02 01:43:15 --> File loaded: application/views/form/email.php
DEBUG - 2016-08-02 01:43:15 --> Email Class Initialized
DEBUG - 2016-08-02 01:43:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:43:15 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 01:43:15 --> Final output sent to browser
DEBUG - 2016-08-02 01:43:15 --> Total execution time: 0.2960
DEBUG - 2016-08-02 01:43:19 --> Config Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:43:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:43:19 --> URI Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Router Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Output Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Security Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Input Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:43:19 --> Language Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Loader Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:43:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Session Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:43:19 --> Session routines successfully run
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Controller Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:43:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> Model Class Initialized
DEBUG - 2016-08-02 01:43:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:43:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:43:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:43:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:43:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:43:19 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:43:19 --> Final output sent to browser
DEBUG - 2016-08-02 01:43:19 --> Total execution time: 0.0696
DEBUG - 2016-08-02 01:45:41 --> Config Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:45:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:45:41 --> URI Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Router Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Output Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Security Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Input Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:45:41 --> Language Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Loader Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:45:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Session Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:45:41 --> Session routines successfully run
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Controller Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:45:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:45:41 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 01:45:41 --> Final output sent to browser
DEBUG - 2016-08-02 01:45:41 --> Total execution time: 0.1300
DEBUG - 2016-08-02 01:45:45 --> Config Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:45:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:45:45 --> URI Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Router Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Output Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Security Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Input Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:45:45 --> Language Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Loader Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:45:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Session Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:45:45 --> Session routines successfully run
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Controller Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:45:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> Model Class Initialized
DEBUG - 2016-08-02 01:45:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:45:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:45:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:45:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:45:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:45:45 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:45:45 --> Final output sent to browser
DEBUG - 2016-08-02 01:45:45 --> Total execution time: 0.0936
DEBUG - 2016-08-02 01:47:21 --> Config Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:47:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:47:21 --> URI Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Router Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Output Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Security Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Input Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:47:21 --> Language Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Loader Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:47:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Session Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:47:21 --> Session routines successfully run
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Controller Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:47:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:47:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:47:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:47:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:47:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:47:21 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:47:21 --> Final output sent to browser
DEBUG - 2016-08-02 01:47:21 --> Total execution time: 0.1076
DEBUG - 2016-08-02 01:47:54 --> Config Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:47:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:47:54 --> URI Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Router Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Output Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Security Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Input Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:47:54 --> Language Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Loader Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:47:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Session Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:47:54 --> Session routines successfully run
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Controller Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:47:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> Model Class Initialized
DEBUG - 2016-08-02 01:47:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:47:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:47:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:47:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:47:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:47:54 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:47:54 --> Final output sent to browser
DEBUG - 2016-08-02 01:47:54 --> Total execution time: 0.1040
DEBUG - 2016-08-02 01:48:18 --> Config Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:48:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:48:18 --> URI Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Router Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Output Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Security Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Input Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:48:18 --> Language Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Loader Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:48:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Session Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:48:18 --> Session routines successfully run
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Controller Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:48:18 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:48:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:48:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:48:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:48:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:48:18 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:48:18 --> Final output sent to browser
DEBUG - 2016-08-02 01:48:18 --> Total execution time: 0.0850
DEBUG - 2016-08-02 01:48:40 --> Config Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:48:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:48:40 --> URI Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Router Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Output Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Security Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Input Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:48:40 --> Language Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Loader Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:48:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Session Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:48:40 --> Session routines successfully run
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Controller Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:48:40 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> Model Class Initialized
DEBUG - 2016-08-02 01:48:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:48:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:48:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:48:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:48:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:48:40 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:48:40 --> Final output sent to browser
DEBUG - 2016-08-02 01:48:40 --> Total execution time: 0.0936
DEBUG - 2016-08-02 01:49:00 --> Config Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:49:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:49:00 --> URI Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Router Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Output Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Security Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Input Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:49:00 --> Language Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Loader Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:49:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Session Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:49:00 --> Session routines successfully run
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Controller Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:49:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:49:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:49:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:49:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:49:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:49:00 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:49:00 --> Final output sent to browser
DEBUG - 2016-08-02 01:49:00 --> Total execution time: 0.0630
DEBUG - 2016-08-02 01:49:49 --> Config Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:49:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:49:49 --> URI Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Router Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Output Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Security Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Input Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:49:49 --> Language Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Loader Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:49:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Session Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:49:49 --> Session routines successfully run
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Controller Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:49:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> Model Class Initialized
DEBUG - 2016-08-02 01:49:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:49:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:49:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:49:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:49:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:49:49 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:49:49 --> Final output sent to browser
DEBUG - 2016-08-02 01:49:49 --> Total execution time: 0.0736
DEBUG - 2016-08-02 01:51:26 --> Config Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:51:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:51:26 --> URI Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Router Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Output Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Security Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Input Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:51:26 --> Language Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Loader Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:51:26 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Session Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:51:26 --> Session routines successfully run
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Controller Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:51:26 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:51:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:51:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:51:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:51:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:51:26 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:51:26 --> Final output sent to browser
DEBUG - 2016-08-02 01:51:26 --> Total execution time: 0.0930
DEBUG - 2016-08-02 01:51:32 --> Config Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:51:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:51:32 --> URI Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Router Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Output Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Security Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Input Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:51:32 --> Language Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Loader Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:51:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Session Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:51:32 --> Session routines successfully run
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Controller Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:51:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:51:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:51:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:51:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:51:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:51:32 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:51:32 --> Final output sent to browser
DEBUG - 2016-08-02 01:51:32 --> Total execution time: 0.0806
DEBUG - 2016-08-02 01:51:56 --> Config Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 01:51:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 01:51:56 --> URI Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Router Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Output Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Security Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Input Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 01:51:56 --> Language Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Loader Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 01:51:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Session Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 01:51:56 --> Session routines successfully run
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Controller Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 01:51:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> Model Class Initialized
DEBUG - 2016-08-02 01:51:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 01:51:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 01:51:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 01:51:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 01:51:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 01:51:56 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 01:51:56 --> Final output sent to browser
DEBUG - 2016-08-02 01:51:56 --> Total execution time: 0.0780
DEBUG - 2016-08-02 10:55:10 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:10 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:10 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:10 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:10 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:11 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:11 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:11 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:11 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:55:11 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:11 --> Total execution time: 0.4757
DEBUG - 2016-08-02 10:55:16 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:16 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:16 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:16 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:16 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:16 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:16 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:55:16 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:16 --> Total execution time: 0.2839
DEBUG - 2016-08-02 10:55:18 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:18 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:18 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:18 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:18 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:18 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:18 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-02 10:55:18 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:18 --> Total execution time: 0.3204
DEBUG - 2016-08-02 10:55:20 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:20 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:20 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:20 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:20 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 10:55:20 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:20 --> Total execution time: 0.5728
DEBUG - 2016-08-02 10:55:21 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:22 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:22 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:22 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:22 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:22 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:22 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 10:55:22 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:22 --> Total execution time: 0.2834
DEBUG - 2016-08-02 10:55:25 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:25 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:25 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:25 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:25 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:25 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:55:25 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:25 --> Total execution time: 0.2939
DEBUG - 2016-08-02 10:55:31 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:31 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:31 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:31 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:31 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:31 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:31 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:31 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 10:55:31 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:31 --> Total execution time: 0.2266
DEBUG - 2016-08-02 10:55:34 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:34 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:34 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:34 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:34 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:34 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:34 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/director/addDirectorView.php
DEBUG - 2016-08-02 10:55:35 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:35 --> Total execution time: 0.2592
DEBUG - 2016-08-02 10:55:35 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:35 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:35 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:35 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:35 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:35 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:35 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 10:55:35 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:35 --> Total execution time: 0.2345
DEBUG - 2016-08-02 10:55:39 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:39 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:39 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:39 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:39 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:39 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:39 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:39 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:39 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 10:55:39 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:39 --> Total execution time: 0.2476
DEBUG - 2016-08-02 10:55:46 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:46 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:46 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:46 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:46 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:46 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:46 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-02 10:55:46 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:46 --> Total execution time: 0.2514
DEBUG - 2016-08-02 10:55:50 --> Config Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:55:50 --> URI Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Router Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Output Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Security Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Input Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:55:50 --> Language Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Loader Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:55:50 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Session Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:55:50 --> Session routines successfully run
DEBUG - 2016-08-02 10:55:50 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Controller Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Model Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:55:50 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:55:50 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:55:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:55:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:55:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:55:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:55:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:55:50 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 10:55:50 --> Final output sent to browser
DEBUG - 2016-08-02 10:55:50 --> Total execution time: 0.2492
DEBUG - 2016-08-02 10:56:04 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:04 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:04 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:04 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:04 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:04 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:04 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:56:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:56:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:56:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:56:04 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 10:56:04 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:04 --> Total execution time: 0.5646
DEBUG - 2016-08-02 10:56:14 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:14 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:14 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:14 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:14 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:14 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:56:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:56:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:56:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:56:15 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:56:15 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:15 --> Total execution time: 0.3028
DEBUG - 2016-08-02 10:56:34 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:34 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:34 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:34 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:34 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:34 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:34 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 10:56:34 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:34 --> Total execution time: 0.2546
DEBUG - 2016-08-02 10:56:41 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:41 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:41 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:41 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:41 --> Model Class Initialized
ERROR - 2016-08-02 10:56:41 --> Severity: Notice  --> Undefined variable: crm D:\xampp\htdocs\asmc\application\views\form\email.php 130
ERROR - 2016-08-02 10:56:41 --> Severity: Notice  --> Undefined variable: sm D:\xampp\htdocs\asmc\application\views\form\email.php 132
DEBUG - 2016-08-02 10:56:41 --> File loaded: application/views/form/email.php
DEBUG - 2016-08-02 10:56:41 --> Email Class Initialized
DEBUG - 2016-08-02 10:56:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:41 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 10:56:41 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:41 --> Total execution time: 0.5785
DEBUG - 2016-08-02 10:56:43 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:43 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:43 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:43 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:43 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 10:56:43 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:43 --> Total execution time: 0.2289
DEBUG - 2016-08-02 10:56:48 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:48 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:48 --> No URI present. Default controller set.
DEBUG - 2016-08-02 10:56:48 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:48 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:48 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:49 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:49 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:49 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:49 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:56:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:56:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:56:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:56:49 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 10:56:49 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:49 --> Total execution time: 0.2290
DEBUG - 2016-08-02 10:56:52 --> Config Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:56:52 --> URI Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Router Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Output Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Security Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Input Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:56:52 --> Language Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Loader Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:56:52 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Session Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:56:52 --> Session routines successfully run
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Controller Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:56:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> Model Class Initialized
DEBUG - 2016-08-02 10:56:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:56:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:56:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:56:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:56:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:56:52 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:56:52 --> Final output sent to browser
DEBUG - 2016-08-02 10:56:52 --> Total execution time: 0.3073
DEBUG - 2016-08-02 10:57:13 --> Config Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:57:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:57:13 --> URI Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Router Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Output Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Security Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Input Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:57:13 --> Language Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Loader Class Initialized
DEBUG - 2016-08-02 10:57:13 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:57:14 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Session Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:57:14 --> A session cookie was not found.
DEBUG - 2016-08-02 10:57:14 --> Session routines successfully run
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Controller Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Config Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:57:14 --> URI Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Router Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Output Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Security Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Input Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:57:14 --> Language Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Loader Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:57:14 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Session Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:57:14 --> Session routines successfully run
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Controller Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:14 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:57:14 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:57:14 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-02 10:57:14 --> Final output sent to browser
DEBUG - 2016-08-02 10:57:14 --> Total execution time: 0.2238
DEBUG - 2016-08-02 10:57:26 --> Config Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:57:26 --> URI Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Router Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Output Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Security Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Input Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:57:26 --> Language Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Loader Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Session Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:57:26 --> Session routines successfully run
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Controller Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:57:26 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-02 10:57:26 --> Config Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:57:26 --> URI Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Router Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Output Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Security Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Input Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:57:26 --> Language Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Loader Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:57:26 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Session Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:57:26 --> Session routines successfully run
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Controller Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:57:26 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:57:26 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:57:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:57:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:57:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:57:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:57:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:57:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 10:57:26 --> Final output sent to browser
DEBUG - 2016-08-02 10:57:26 --> Total execution time: 0.2407
DEBUG - 2016-08-02 10:57:32 --> Config Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:57:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:57:32 --> URI Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Router Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Output Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Security Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Input Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:57:32 --> Language Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Loader Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:57:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Session Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:57:32 --> Session routines successfully run
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Controller Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:57:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> Model Class Initialized
DEBUG - 2016-08-02 10:57:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:57:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:57:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:57:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:57:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:57:32 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:57:32 --> Final output sent to browser
DEBUG - 2016-08-02 10:57:32 --> Total execution time: 0.2784
DEBUG - 2016-08-02 10:59:06 --> Config Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:59:06 --> URI Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Router Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Output Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Security Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Input Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:59:06 --> Language Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Loader Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:59:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Session Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:59:06 --> Session routines successfully run
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Controller Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:59:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:59:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:59:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:59:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:59:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:59:06 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:59:06 --> Final output sent to browser
DEBUG - 2016-08-02 10:59:06 --> Total execution time: 0.2962
DEBUG - 2016-08-02 10:59:13 --> Config Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:59:13 --> URI Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Router Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Output Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Security Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Input Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:59:13 --> Language Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Loader Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:59:13 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Session Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:59:13 --> Session routines successfully run
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Controller Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:59:13 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:59:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:59:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:59:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:59:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:59:13 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 10:59:13 --> Final output sent to browser
DEBUG - 2016-08-02 10:59:13 --> Total execution time: 0.2979
DEBUG - 2016-08-02 10:59:24 --> Config Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 10:59:24 --> URI Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Router Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Output Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Security Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Input Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 10:59:24 --> Language Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Loader Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 10:59:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Session Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 10:59:24 --> Session routines successfully run
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Controller Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Model Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Helper loaded: form_helper
DEBUG - 2016-08-02 10:59:24 --> Form Validation Class Initialized
DEBUG - 2016-08-02 10:59:24 --> Pagination Class Initialized
DEBUG - 2016-08-02 10:59:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 10:59:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 10:59:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 10:59:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 10:59:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 10:59:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 10:59:25 --> Final output sent to browser
DEBUG - 2016-08-02 10:59:25 --> Total execution time: 0.7968
DEBUG - 2016-08-02 11:24:49 --> Config Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:24:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:24:49 --> URI Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Router Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Output Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Security Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Input Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:24:49 --> Language Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Loader Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:24:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Session Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:24:49 --> Session routines successfully run
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Controller Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:24:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:24:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:24:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:24:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:24:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:24:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:24:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:24:49 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:24:49 --> Final output sent to browser
DEBUG - 2016-08-02 11:24:49 --> Total execution time: 0.7001
DEBUG - 2016-08-02 11:25:14 --> Config Class Initialized
DEBUG - 2016-08-02 11:25:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:25:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:25:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:25:14 --> URI Class Initialized
DEBUG - 2016-08-02 11:25:14 --> Router Class Initialized
ERROR - 2016-08-02 11:25:14 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 11:26:03 --> Config Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:26:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:26:03 --> URI Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Router Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Output Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Security Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Input Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:26:03 --> Language Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Loader Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:26:03 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Session Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:26:03 --> Session routines successfully run
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Controller Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:26:03 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:26:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:26:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:26:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:26:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:26:03 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 11:26:03 --> Final output sent to browser
DEBUG - 2016-08-02 11:26:03 --> Total execution time: 0.3149
DEBUG - 2016-08-02 11:26:03 --> Config Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:26:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:26:03 --> URI Class Initialized
DEBUG - 2016-08-02 11:26:03 --> Router Class Initialized
ERROR - 2016-08-02 11:26:04 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 11:26:07 --> Config Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:26:08 --> URI Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Router Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Output Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Security Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Input Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:26:08 --> Language Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Loader Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:26:08 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Session Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:26:08 --> Session routines successfully run
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Controller Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:26:08 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:26:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:26:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:26:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:26:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:26:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:26:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:26:08 --> Final output sent to browser
DEBUG - 2016-08-02 11:26:08 --> Total execution time: 0.5620
DEBUG - 2016-08-02 11:26:08 --> Config Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:26:08 --> URI Class Initialized
DEBUG - 2016-08-02 11:26:08 --> Router Class Initialized
ERROR - 2016-08-02 11:26:08 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 11:26:40 --> Config Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:26:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:26:40 --> URI Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Router Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Output Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Security Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Input Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:26:40 --> Language Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Loader Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:26:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Session Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:26:40 --> Session routines successfully run
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Controller Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:26:40 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:26:40 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:26:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:26:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:26:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:26:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:26:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:26:41 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:26:41 --> Final output sent to browser
DEBUG - 2016-08-02 11:26:41 --> Total execution time: 0.5579
DEBUG - 2016-08-02 11:27:01 --> Config Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:27:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:27:01 --> URI Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Router Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Output Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Security Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Input Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:27:01 --> Language Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Loader Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:27:01 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Session Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:27:01 --> Session routines successfully run
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Controller Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:27:01 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:27:01 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:27:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:27:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:27:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:27:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:27:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:27:01 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:27:01 --> Final output sent to browser
DEBUG - 2016-08-02 11:27:01 --> Total execution time: 0.5400
DEBUG - 2016-08-02 11:28:24 --> Config Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:28:24 --> URI Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Router Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Output Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Security Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Input Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:28:24 --> Language Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Loader Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:28:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Session Class Initialized
DEBUG - 2016-08-02 11:28:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:28:24 --> Session routines successfully run
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Controller Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:28:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:28:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:28:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:28:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:28:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:28:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:28:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:28:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:28:25 --> Final output sent to browser
DEBUG - 2016-08-02 11:28:25 --> Total execution time: 0.6195
DEBUG - 2016-08-02 11:28:28 --> Config Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:28:28 --> URI Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Router Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Output Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Security Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Input Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:28:28 --> Language Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Loader Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:28:28 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Session Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:28:28 --> Session routines successfully run
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Controller Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Model Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:28:28 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:28:28 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:28:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:28:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:28:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:28:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:28:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:28:29 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:28:29 --> Final output sent to browser
DEBUG - 2016-08-02 11:28:29 --> Total execution time: 0.5803
DEBUG - 2016-08-02 11:29:19 --> Config Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:29:19 --> URI Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Router Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Output Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Security Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Input Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:29:19 --> Language Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Loader Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:29:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Session Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:29:19 --> Session routines successfully run
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Controller Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:29:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:29:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:29:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:29:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:29:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:29:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:29:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:29:19 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:29:19 --> Final output sent to browser
DEBUG - 2016-08-02 11:29:19 --> Total execution time: 0.6064
DEBUG - 2016-08-02 11:29:29 --> Config Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:29:29 --> URI Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Router Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Output Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Security Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Input Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:29:29 --> Language Class Initialized
DEBUG - 2016-08-02 11:29:29 --> Loader Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:29:30 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Session Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:29:30 --> Session routines successfully run
DEBUG - 2016-08-02 11:29:30 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Controller Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:29:30 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:29:30 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:29:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:29:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:29:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:29:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:29:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:29:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 11:29:30 --> Final output sent to browser
DEBUG - 2016-08-02 11:29:30 --> Total execution time: 0.2882
DEBUG - 2016-08-02 11:29:32 --> Config Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:29:32 --> URI Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Router Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Output Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Security Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Input Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:29:32 --> Language Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Loader Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:29:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Session Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:29:32 --> Session routines successfully run
DEBUG - 2016-08-02 11:29:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Controller Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:29:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:29:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:29:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:29:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:29:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:29:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:29:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:29:32 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 11:29:32 --> Final output sent to browser
DEBUG - 2016-08-02 11:29:32 --> Total execution time: 0.2976
DEBUG - 2016-08-02 11:29:37 --> Config Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:29:37 --> URI Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Router Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Output Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Security Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Input Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:29:37 --> Language Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Loader Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:29:37 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Session Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:29:37 --> Session routines successfully run
DEBUG - 2016-08-02 11:29:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Controller Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:29:37 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:29:37 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:29:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:29:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:29:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:29:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:29:37 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:29:37 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 11:29:37 --> Final output sent to browser
DEBUG - 2016-08-02 11:29:37 --> Total execution time: 0.2738
DEBUG - 2016-08-02 11:29:43 --> Config Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:29:43 --> URI Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Router Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Output Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Security Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Input Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:29:43 --> Language Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Loader Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:29:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Session Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:29:43 --> Session routines successfully run
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Controller Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:29:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:29:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:29:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:29:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:29:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:29:43 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 11:29:43 --> Final output sent to browser
DEBUG - 2016-08-02 11:29:43 --> Total execution time: 0.3399
DEBUG - 2016-08-02 11:29:45 --> Config Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:29:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:29:45 --> URI Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Router Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Output Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Security Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Input Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:29:45 --> Language Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Loader Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:29:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Session Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:29:45 --> Session routines successfully run
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Controller Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Model Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:29:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:29:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:29:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:29:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:29:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:29:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:29:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:29:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:29:46 --> Final output sent to browser
DEBUG - 2016-08-02 11:29:46 --> Total execution time: 0.5660
DEBUG - 2016-08-02 11:30:09 --> Config Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:30:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:30:09 --> URI Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Router Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Output Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Security Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Input Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:30:09 --> Language Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Loader Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:30:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Session Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:30:09 --> Session routines successfully run
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Controller Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:30:09 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:30:09 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:30:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:30:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:30:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:30:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:30:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:30:10 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:30:10 --> Final output sent to browser
DEBUG - 2016-08-02 11:30:10 --> Total execution time: 0.5600
DEBUG - 2016-08-02 11:30:32 --> Config Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:30:32 --> URI Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Router Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Output Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Security Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Input Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:30:32 --> Language Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Loader Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:30:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Session Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:30:32 --> Session routines successfully run
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Controller Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:30:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:30:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:30:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:30:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:30:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:30:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:30:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:30:32 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:30:32 --> Final output sent to browser
DEBUG - 2016-08-02 11:30:32 --> Total execution time: 0.5419
DEBUG - 2016-08-02 11:32:23 --> Config Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:32:23 --> URI Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Router Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Output Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Security Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Input Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:32:23 --> Language Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Loader Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:32:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Session Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:32:23 --> Session routines successfully run
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Controller Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:32:23 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:32:23 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:32:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:32:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:32:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:32:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:32:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:32:23 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:32:23 --> Final output sent to browser
DEBUG - 2016-08-02 11:32:23 --> Total execution time: 0.5396
DEBUG - 2016-08-02 11:32:33 --> Config Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:32:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:32:33 --> URI Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Router Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Output Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Security Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Input Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:32:33 --> Language Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Loader Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:32:33 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Session Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:32:33 --> Session routines successfully run
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Controller Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:32:33 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:32:33 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:32:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:32:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:32:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:32:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:32:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:32:33 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:32:33 --> Final output sent to browser
DEBUG - 2016-08-02 11:32:33 --> Total execution time: 0.5391
DEBUG - 2016-08-02 11:32:49 --> Config Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:32:49 --> URI Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Router Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Output Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Security Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Input Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:32:49 --> Language Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Loader Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:32:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Session Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:32:49 --> Session routines successfully run
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Controller Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Model Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:32:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:32:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:32:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:32:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:32:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:32:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:32:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:32:49 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:32:49 --> Final output sent to browser
DEBUG - 2016-08-02 11:32:49 --> Total execution time: 0.5326
DEBUG - 2016-08-02 11:33:33 --> Config Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:33:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:33:33 --> URI Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Router Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Output Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Security Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Input Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:33:33 --> Language Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Loader Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:33:33 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Session Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:33:33 --> Session routines successfully run
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Controller Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Model Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:33:33 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:33:33 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:33:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:33:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:33:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:33:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:33:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:33:34 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:33:34 --> Final output sent to browser
DEBUG - 2016-08-02 11:33:34 --> Total execution time: 0.5266
DEBUG - 2016-08-02 11:34:09 --> Config Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:34:09 --> URI Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Router Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Output Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Security Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Input Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:34:09 --> Language Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Loader Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:34:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Session Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:34:09 --> Session routines successfully run
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Controller Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:34:09 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:34:09 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:34:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:34:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:34:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:34:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:34:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:34:09 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:34:09 --> Final output sent to browser
DEBUG - 2016-08-02 11:34:09 --> Total execution time: 0.5347
DEBUG - 2016-08-02 11:34:16 --> Config Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:34:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:34:16 --> URI Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Router Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Output Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Security Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Input Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:34:16 --> Language Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Loader Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:34:16 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Session Class Initialized
DEBUG - 2016-08-02 11:34:16 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:34:16 --> Session routines successfully run
DEBUG - 2016-08-02 11:34:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Controller Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:34:17 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:34:17 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:34:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:34:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:34:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:34:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:34:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:34:17 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:34:17 --> Final output sent to browser
DEBUG - 2016-08-02 11:34:17 --> Total execution time: 0.5617
DEBUG - 2016-08-02 11:34:53 --> Config Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:34:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:34:53 --> URI Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Router Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Output Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Security Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Input Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:34:53 --> Language Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Loader Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:34:53 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Session Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:34:53 --> Session routines successfully run
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Controller Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Model Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:34:53 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:34:53 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:34:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:34:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:34:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:34:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:34:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:34:54 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:34:54 --> Final output sent to browser
DEBUG - 2016-08-02 11:34:54 --> Total execution time: 0.5464
DEBUG - 2016-08-02 11:35:08 --> Config Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:35:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:35:08 --> URI Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Router Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Output Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Security Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Input Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:35:08 --> Language Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Loader Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:35:08 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Session Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:35:08 --> Session routines successfully run
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Controller Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:35:08 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:35:08 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:35:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:35:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:35:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:35:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:35:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:35:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:35:08 --> Final output sent to browser
DEBUG - 2016-08-02 11:35:08 --> Total execution time: 0.5669
DEBUG - 2016-08-02 11:35:32 --> Config Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:35:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:35:32 --> URI Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Router Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Output Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Security Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Input Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:35:32 --> Language Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Loader Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:35:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Session Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:35:32 --> Session routines successfully run
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Controller Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:35:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:35:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:35:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:35:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:35:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:35:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:35:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:35:33 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:35:33 --> Final output sent to browser
DEBUG - 2016-08-02 11:35:33 --> Total execution time: 0.5702
DEBUG - 2016-08-02 11:35:39 --> Config Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:35:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:35:39 --> URI Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Router Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Output Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Security Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Input Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:35:39 --> Language Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Loader Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:35:39 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Session Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:35:39 --> Session routines successfully run
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Controller Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:35:39 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:35:39 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:35:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:35:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:35:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:35:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:35:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:35:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:35:39 --> Final output sent to browser
DEBUG - 2016-08-02 11:35:39 --> Total execution time: 0.5856
DEBUG - 2016-08-02 11:36:26 --> Config Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:36:27 --> URI Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Router Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Output Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Security Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Input Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:36:27 --> Language Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Loader Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:36:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Session Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:36:27 --> Session routines successfully run
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Controller Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:36:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:36:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:36:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:36:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:36:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:36:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:36:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:36:27 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:36:27 --> Final output sent to browser
DEBUG - 2016-08-02 11:36:27 --> Total execution time: 0.6035
DEBUG - 2016-08-02 11:39:58 --> Config Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:39:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:39:58 --> URI Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Router Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Output Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Security Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Input Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:39:58 --> Language Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Loader Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:39:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Session Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:39:58 --> Session routines successfully run
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Controller Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:39:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:39:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:39:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:39:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:39:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:39:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:39:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:39:58 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:39:58 --> Final output sent to browser
DEBUG - 2016-08-02 11:39:58 --> Total execution time: 0.5851
DEBUG - 2016-08-02 11:40:36 --> Config Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:40:36 --> URI Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Router Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Output Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Security Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Input Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:40:36 --> Language Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Loader Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:40:36 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Session Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:40:36 --> Session routines successfully run
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Controller Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Model Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:40:36 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:40:36 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:40:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:40:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:40:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:40:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:40:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:40:36 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:40:36 --> Final output sent to browser
DEBUG - 2016-08-02 11:40:36 --> Total execution time: 0.5853
DEBUG - 2016-08-02 11:40:37 --> Config Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Config Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:40:37 --> URI Class Initialized
DEBUG - 2016-08-02 11:40:37 --> URI Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Router Class Initialized
DEBUG - 2016-08-02 11:40:37 --> Router Class Initialized
ERROR - 2016-08-02 11:40:37 --> 404 Page Not Found --> js
ERROR - 2016-08-02 11:40:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 11:41:24 --> Config Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:41:24 --> URI Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Router Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Output Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Security Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Input Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:41:24 --> Language Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Loader Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:41:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:41:24 --> Session Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:41:25 --> Session routines successfully run
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Controller Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:41:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:41:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:41:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:41:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:41:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:41:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:41:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:41:25 --> Final output sent to browser
DEBUG - 2016-08-02 11:41:25 --> Total execution time: 0.5421
DEBUG - 2016-08-02 11:41:25 --> Config Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Config Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:41:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:41:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:41:25 --> URI Class Initialized
DEBUG - 2016-08-02 11:41:25 --> URI Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Router Class Initialized
DEBUG - 2016-08-02 11:41:25 --> Router Class Initialized
ERROR - 2016-08-02 11:41:25 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 11:41:25 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 11:41:37 --> Config Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:41:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:41:37 --> URI Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Router Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Output Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Security Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Input Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:41:37 --> Language Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Loader Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:41:37 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Session Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:41:37 --> Session routines successfully run
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Controller Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Model Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:41:37 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:41:37 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:41:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:41:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:41:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:41:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:41:37 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:41:37 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:41:37 --> Final output sent to browser
DEBUG - 2016-08-02 11:41:37 --> Total execution time: 0.5355
DEBUG - 2016-08-02 11:41:38 --> Config Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Config Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:41:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:41:38 --> URI Class Initialized
DEBUG - 2016-08-02 11:41:38 --> URI Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Router Class Initialized
DEBUG - 2016-08-02 11:41:38 --> Router Class Initialized
ERROR - 2016-08-02 11:41:38 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 11:41:38 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 11:42:38 --> Config Class Initialized
DEBUG - 2016-08-02 11:42:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:42:39 --> URI Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Router Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Output Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Security Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Input Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:42:39 --> Language Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Loader Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:42:39 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Session Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:42:39 --> Session routines successfully run
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Controller Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Model Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:42:39 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:42:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:42:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:42:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:42:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:42:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:42:39 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:42:39 --> Final output sent to browser
DEBUG - 2016-08-02 11:42:39 --> Total execution time: 0.6288
DEBUG - 2016-08-02 11:42:39 --> Config Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:42:39 --> Config Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:42:39 --> URI Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Router Class Initialized
DEBUG - 2016-08-02 11:42:39 --> UTF-8 Support Enabled
ERROR - 2016-08-02 11:42:39 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 11:42:39 --> URI Class Initialized
DEBUG - 2016-08-02 11:42:39 --> Router Class Initialized
ERROR - 2016-08-02 11:42:40 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 11:43:35 --> Config Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:43:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:43:35 --> URI Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Router Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Output Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Security Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Input Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:43:35 --> Language Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Loader Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:43:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Session Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:43:35 --> Session routines successfully run
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Controller Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:43:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:43:35 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:43:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:43:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:43:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:43:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:43:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:43:35 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:43:35 --> Final output sent to browser
DEBUG - 2016-08-02 11:43:35 --> Total execution time: 0.5391
DEBUG - 2016-08-02 11:43:37 --> Config Class Initialized
DEBUG - 2016-08-02 11:43:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:43:37 --> Config Class Initialized
DEBUG - 2016-08-02 11:43:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:43:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:43:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:43:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:43:37 --> URI Class Initialized
DEBUG - 2016-08-02 11:43:37 --> Router Class Initialized
DEBUG - 2016-08-02 11:43:37 --> URI Class Initialized
DEBUG - 2016-08-02 11:43:37 --> Router Class Initialized
ERROR - 2016-08-02 11:43:37 --> 404 Page Not Found --> js
ERROR - 2016-08-02 11:43:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 11:43:58 --> Config Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:43:58 --> URI Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Router Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Output Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Security Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Input Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:43:58 --> Language Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Loader Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:43:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Session Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:43:58 --> Session routines successfully run
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Controller Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Model Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:43:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:43:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:43:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:43:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:43:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:43:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:43:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:43:59 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:43:59 --> Final output sent to browser
DEBUG - 2016-08-02 11:43:59 --> Total execution time: 0.6147
DEBUG - 2016-08-02 11:44:00 --> Config Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Config Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:44:00 --> URI Class Initialized
DEBUG - 2016-08-02 11:44:00 --> URI Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Router Class Initialized
DEBUG - 2016-08-02 11:44:00 --> Router Class Initialized
ERROR - 2016-08-02 11:44:00 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 11:44:00 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 11:44:38 --> Config Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:44:38 --> URI Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Router Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Output Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Security Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Input Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:44:38 --> Language Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Loader Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:44:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Session Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:44:38 --> Session routines successfully run
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Controller Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:44:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:44:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:44:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:44:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:44:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:44:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:44:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:44:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:44:38 --> Final output sent to browser
DEBUG - 2016-08-02 11:44:38 --> Total execution time: 0.4621
DEBUG - 2016-08-02 11:44:49 --> Config Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:44:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:44:49 --> URI Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Router Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Output Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Security Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Input Class Initialized
DEBUG - 2016-08-02 11:44:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:44:49 --> Language Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Loader Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:44:50 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Session Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:44:50 --> Session routines successfully run
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Controller Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Model Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:44:50 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:44:50 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:44:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:44:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:44:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:44:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:44:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:44:50 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:44:50 --> Final output sent to browser
DEBUG - 2016-08-02 11:44:50 --> Total execution time: 0.4572
DEBUG - 2016-08-02 11:45:16 --> Config Class Initialized
DEBUG - 2016-08-02 11:45:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:45:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:45:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:45:16 --> URI Class Initialized
DEBUG - 2016-08-02 11:45:16 --> Router Class Initialized
DEBUG - 2016-08-02 11:45:16 --> Output Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Security Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Input Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:45:17 --> Language Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Loader Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:45:17 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Session Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:45:17 --> Session routines successfully run
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Controller Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:45:17 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:45:17 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:45:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:45:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:45:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:45:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:45:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:45:17 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:45:17 --> Final output sent to browser
DEBUG - 2016-08-02 11:45:17 --> Total execution time: 0.5672
DEBUG - 2016-08-02 11:45:40 --> Config Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:45:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:45:40 --> URI Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Router Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Output Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Security Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Input Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:45:40 --> Language Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Loader Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:45:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Session Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:45:40 --> Session routines successfully run
DEBUG - 2016-08-02 11:45:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:40 --> Controller Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:45:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:45:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:45:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:45:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:45:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:45:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:45:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:45:41 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:45:41 --> Final output sent to browser
DEBUG - 2016-08-02 11:45:41 --> Total execution time: 0.4959
DEBUG - 2016-08-02 11:45:45 --> Config Class Initialized
DEBUG - 2016-08-02 11:45:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:45:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:45:45 --> URI Class Initialized
DEBUG - 2016-08-02 11:45:45 --> Router Class Initialized
DEBUG - 2016-08-02 11:45:45 --> Output Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Security Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Input Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:45:46 --> Language Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Loader Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:45:46 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Session Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:45:46 --> Session routines successfully run
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Controller Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Model Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:45:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:45:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:45:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:45:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:45:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:45:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:45:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:45:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:45:46 --> Final output sent to browser
DEBUG - 2016-08-02 11:45:46 --> Total execution time: 0.4914
DEBUG - 2016-08-02 11:46:13 --> Config Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:46:13 --> URI Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Router Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Output Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Security Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Input Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:46:13 --> Language Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Loader Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:46:13 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Session Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:46:13 --> Session routines successfully run
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Controller Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Model Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:46:13 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:46:13 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:46:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:46:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:46:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:46:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:46:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:46:13 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:46:13 --> Final output sent to browser
DEBUG - 2016-08-02 11:46:13 --> Total execution time: 0.5707
DEBUG - 2016-08-02 11:49:15 --> Config Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:49:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:49:15 --> URI Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Router Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Output Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Security Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Input Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:49:15 --> Language Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Loader Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:49:15 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Session Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:49:15 --> Session routines successfully run
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Controller Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:49:15 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:49:15 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:49:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:49:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:49:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:49:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:49:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:49:16 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:49:16 --> Final output sent to browser
DEBUG - 2016-08-02 11:49:16 --> Total execution time: 0.4709
DEBUG - 2016-08-02 11:49:23 --> Config Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:49:23 --> URI Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Router Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Output Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Security Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Input Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:49:23 --> Language Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Loader Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:49:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Session Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:49:23 --> Session routines successfully run
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Controller Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:23 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:24 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:49:24 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:49:24 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:49:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:49:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:49:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:49:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:49:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:49:24 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:49:24 --> Final output sent to browser
DEBUG - 2016-08-02 11:49:24 --> Total execution time: 0.5697
DEBUG - 2016-08-02 11:49:32 --> Config Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:49:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:49:32 --> URI Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Router Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Output Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Security Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Input Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:49:32 --> Language Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Loader Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:49:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Session Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:49:32 --> Session routines successfully run
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Controller Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:49:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:49:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:49:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:49:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:49:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:49:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:49:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:49:32 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:49:32 --> Final output sent to browser
DEBUG - 2016-08-02 11:49:32 --> Total execution time: 0.5114
DEBUG - 2016-08-02 11:49:38 --> Config Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:49:38 --> URI Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Router Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Output Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Security Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Input Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:49:38 --> Language Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Loader Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:49:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Session Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:49:38 --> Session routines successfully run
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Controller Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:49:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:49:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:49:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:49:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:49:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:49:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:49:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:49:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:49:38 --> Final output sent to browser
DEBUG - 2016-08-02 11:49:38 --> Total execution time: 0.4693
DEBUG - 2016-08-02 11:49:55 --> Config Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:49:55 --> URI Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Router Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Output Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Security Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Input Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:49:55 --> Language Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Loader Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:49:55 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Session Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:49:55 --> Session routines successfully run
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Controller Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Model Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:49:55 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:49:55 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:49:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:49:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:49:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:49:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:49:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:49:56 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:49:56 --> Final output sent to browser
DEBUG - 2016-08-02 11:49:56 --> Total execution time: 0.5158
DEBUG - 2016-08-02 11:52:16 --> Config Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:52:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:52:16 --> URI Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Router Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Output Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Security Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Input Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:52:16 --> Language Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Loader Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:52:16 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Session Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:52:16 --> Session routines successfully run
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Controller Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:52:16 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:52:16 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:52:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:52:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:52:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:52:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:52:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:52:16 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:52:16 --> Final output sent to browser
DEBUG - 2016-08-02 11:52:16 --> Total execution time: 0.3377
DEBUG - 2016-08-02 11:52:22 --> Config Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:52:22 --> URI Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Router Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Output Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Security Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Input Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:52:22 --> Language Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Loader Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:52:22 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Session Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:52:22 --> Session routines successfully run
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Controller Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:52:22 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:52:22 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:52:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:52:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:52:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:52:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:52:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:52:22 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:52:22 --> Final output sent to browser
DEBUG - 2016-08-02 11:52:22 --> Total execution time: 0.5143
DEBUG - 2016-08-02 11:52:26 --> Config Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:52:26 --> URI Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Router Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Output Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Security Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Input Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:52:26 --> Language Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Loader Class Initialized
DEBUG - 2016-08-02 11:52:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:52:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Session Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:52:27 --> Session routines successfully run
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Controller Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:52:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:52:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:52:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:52:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:52:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:52:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:52:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:52:27 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:52:27 --> Final output sent to browser
DEBUG - 2016-08-02 11:52:27 --> Total execution time: 0.4992
DEBUG - 2016-08-02 11:53:01 --> Config Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:53:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:53:01 --> URI Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Router Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Output Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Security Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Input Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:53:01 --> Language Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Loader Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:53:01 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Session Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:53:01 --> Session routines successfully run
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Controller Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Model Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:53:01 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:53:01 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:53:01 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:53:01 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:53:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:53:01 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:53:01 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:53:01 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:53:01 --> Final output sent to browser
DEBUG - 2016-08-02 11:53:01 --> Total execution time: 0.3506
DEBUG - 2016-08-02 11:57:02 --> Config Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:57:02 --> URI Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Router Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Output Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Security Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Input Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:57:02 --> Language Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Loader Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:57:02 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Session Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:57:02 --> Session routines successfully run
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Controller Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:57:02 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:57:02 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:57:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:57:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:57:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:57:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:57:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:57:02 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:57:02 --> Final output sent to browser
DEBUG - 2016-08-02 11:57:02 --> Total execution time: 0.3533
DEBUG - 2016-08-02 11:57:10 --> Config Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:57:10 --> URI Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Router Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Output Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Security Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Input Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:57:10 --> Language Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Loader Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:57:10 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Session Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:57:10 --> Session routines successfully run
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Controller Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:57:10 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:57:10 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:57:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:57:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:57:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:57:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:57:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:57:10 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:57:10 --> Final output sent to browser
DEBUG - 2016-08-02 11:57:10 --> Total execution time: 0.5179
DEBUG - 2016-08-02 11:57:27 --> Config Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:57:27 --> URI Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Router Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Output Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Security Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Input Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:57:27 --> Language Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Loader Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:57:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Session Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:57:27 --> Session routines successfully run
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Controller Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:57:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:57:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:57:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:57:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:57:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:57:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:57:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:57:27 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:57:27 --> Final output sent to browser
DEBUG - 2016-08-02 11:57:27 --> Total execution time: 0.5131
DEBUG - 2016-08-02 11:57:56 --> Config Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:57:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:57:56 --> URI Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Router Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Output Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Security Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Input Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:57:56 --> Language Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Loader Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:57:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Session Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:57:56 --> Session routines successfully run
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Controller Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:57:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:57:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:57:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:57:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:57:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:57:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:57:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:57:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:57:57 --> Final output sent to browser
DEBUG - 2016-08-02 11:57:57 --> Total execution time: 0.5949
DEBUG - 2016-08-02 11:58:25 --> Config Class Initialized
DEBUG - 2016-08-02 11:58:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:58:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:58:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:58:25 --> URI Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Router Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Output Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Security Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Input Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:58:26 --> Language Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Loader Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:58:26 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Session Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:58:26 --> Session routines successfully run
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Controller Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:58:26 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:58:26 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:58:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:58:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:58:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:58:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:58:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:58:26 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:58:26 --> Final output sent to browser
DEBUG - 2016-08-02 11:58:26 --> Total execution time: 0.5007
DEBUG - 2016-08-02 11:58:57 --> Config Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 11:58:57 --> URI Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Router Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Output Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Security Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Input Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 11:58:57 --> Language Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Loader Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Helper loaded: url_helper
DEBUG - 2016-08-02 11:58:57 --> Database Driver Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Session Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Helper loaded: string_helper
DEBUG - 2016-08-02 11:58:57 --> Session routines successfully run
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Controller Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Model Class Initialized
DEBUG - 2016-08-02 11:58:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 11:58:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 11:58:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 11:58:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 11:58:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 11:58:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 11:58:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 11:58:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 11:58:58 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 11:58:58 --> Final output sent to browser
DEBUG - 2016-08-02 11:58:58 --> Total execution time: 0.5236
DEBUG - 2016-08-02 12:02:04 --> Config Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:02:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:02:04 --> URI Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Router Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Output Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Security Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Input Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:02:04 --> Language Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Loader Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:02:04 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Session Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:02:04 --> Session routines successfully run
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Controller Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:02:04 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:02:04 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:02:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:02:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:02:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:02:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:02:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:02:05 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:02:05 --> Final output sent to browser
DEBUG - 2016-08-02 12:02:05 --> Total execution time: 0.5203
DEBUG - 2016-08-02 12:02:05 --> Config Class Initialized
DEBUG - 2016-08-02 12:02:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:02:05 --> Config Class Initialized
DEBUG - 2016-08-02 12:02:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:02:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:02:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:02:05 --> URI Class Initialized
DEBUG - 2016-08-02 12:02:05 --> Router Class Initialized
DEBUG - 2016-08-02 12:02:05 --> URI Class Initialized
DEBUG - 2016-08-02 12:02:05 --> Router Class Initialized
ERROR - 2016-08-02 12:02:05 --> 404 Page Not Found --> js
ERROR - 2016-08-02 12:02:05 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 12:02:44 --> Config Class Initialized
DEBUG - 2016-08-02 12:02:44 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:02:44 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:02:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:02:45 --> URI Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Router Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Output Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Security Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Input Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:02:45 --> Language Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Loader Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:02:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Session Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:02:45 --> Session routines successfully run
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Controller Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Model Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:02:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:02:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:02:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:02:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:02:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:02:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:02:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:02:45 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:02:45 --> Final output sent to browser
DEBUG - 2016-08-02 12:02:45 --> Total execution time: 0.5484
DEBUG - 2016-08-02 12:02:46 --> Config Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Config Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:02:46 --> URI Class Initialized
DEBUG - 2016-08-02 12:02:46 --> URI Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Router Class Initialized
DEBUG - 2016-08-02 12:02:46 --> Router Class Initialized
ERROR - 2016-08-02 12:02:46 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 12:02:46 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 12:03:23 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:23 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Router Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Output Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Security Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Input Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:03:23 --> Language Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Loader Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:03:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Session Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:03:23 --> Session routines successfully run
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Controller Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:03:23 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:03:23 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:03:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:03:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:03:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:03:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:03:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:03:23 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:03:23 --> Final output sent to browser
DEBUG - 2016-08-02 12:03:23 --> Total execution time: 0.5363
DEBUG - 2016-08-02 12:03:24 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:24 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:24 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Router Class Initialized
DEBUG - 2016-08-02 12:03:24 --> Router Class Initialized
ERROR - 2016-08-02 12:03:24 --> 404 Page Not Found --> js
ERROR - 2016-08-02 12:03:24 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 12:03:41 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:41 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Router Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Output Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Security Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Input Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:03:41 --> Language Class Initialized
DEBUG - 2016-08-02 12:03:41 --> Loader Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:03:42 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Session Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:03:42 --> Session routines successfully run
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Controller Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:03:42 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:03:42 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:03:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:03:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:03:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:03:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:03:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:03:42 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:03:42 --> Final output sent to browser
DEBUG - 2016-08-02 12:03:42 --> Total execution time: 0.5790
DEBUG - 2016-08-02 12:03:43 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:43 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:43 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Router Class Initialized
DEBUG - 2016-08-02 12:03:43 --> Router Class Initialized
ERROR - 2016-08-02 12:03:43 --> 404 Page Not Found --> js
ERROR - 2016-08-02 12:03:43 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 12:03:56 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:56 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Router Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Output Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Security Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Input Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:03:56 --> Language Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Loader Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:03:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Session Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:03:56 --> Session routines successfully run
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Controller Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:03:57 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:03:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:03:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:03:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:03:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:03:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:03:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:03:57 --> Final output sent to browser
DEBUG - 2016-08-02 12:03:57 --> Total execution time: 0.5681
DEBUG - 2016-08-02 12:03:57 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Config Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:03:57 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:57 --> URI Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Router Class Initialized
DEBUG - 2016-08-02 12:03:57 --> Router Class Initialized
ERROR - 2016-08-02 12:03:57 --> 404 Page Not Found --> js
ERROR - 2016-08-02 12:03:57 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 12:06:42 --> Config Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:06:42 --> URI Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Router Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Output Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Security Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Input Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:06:42 --> Language Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Loader Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:06:42 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Session Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:06:42 --> Session routines successfully run
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Controller Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Model Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:06:42 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:06:42 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:06:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:06:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:06:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:06:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:06:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:06:42 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:06:42 --> Final output sent to browser
DEBUG - 2016-08-02 12:06:42 --> Total execution time: 0.6063
DEBUG - 2016-08-02 12:15:26 --> Config Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:15:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:15:26 --> URI Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Router Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Output Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Security Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Input Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:15:26 --> Language Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Loader Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:15:26 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Session Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:15:26 --> Session routines successfully run
DEBUG - 2016-08-02 12:15:26 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Controller Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:15:26 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:15:26 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:15:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:15:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:15:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:15:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:15:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:15:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 12:15:26 --> Final output sent to browser
DEBUG - 2016-08-02 12:15:26 --> Total execution time: 0.3069
DEBUG - 2016-08-02 12:15:28 --> Config Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:15:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:15:28 --> URI Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Router Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Output Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Security Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Input Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:15:28 --> Language Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Loader Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:15:28 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Session Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:15:28 --> Session routines successfully run
DEBUG - 2016-08-02 12:15:28 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Controller Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:15:28 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:15:28 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:15:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:15:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:15:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:15:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:15:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:15:28 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 12:15:28 --> Final output sent to browser
DEBUG - 2016-08-02 12:15:28 --> Total execution time: 0.3111
DEBUG - 2016-08-02 12:15:43 --> Config Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:15:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:15:43 --> URI Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Router Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Output Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Security Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Input Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:15:43 --> Language Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Loader Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:15:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Session Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:15:43 --> Session routines successfully run
DEBUG - 2016-08-02 12:15:43 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Controller Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Model Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:15:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:15:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:15:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:15:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:15:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:15:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:15:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:15:43 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 12:15:43 --> Final output sent to browser
DEBUG - 2016-08-02 12:15:43 --> Total execution time: 0.2762
DEBUG - 2016-08-02 12:16:28 --> Config Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:16:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:16:28 --> URI Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Router Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Output Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Security Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Input Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:16:28 --> Language Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Loader Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:16:28 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Session Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:16:28 --> Session routines successfully run
DEBUG - 2016-08-02 12:16:28 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Controller Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:16:28 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:16:28 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:16:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:16:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:16:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:16:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:16:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:16:28 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 12:16:28 --> Final output sent to browser
DEBUG - 2016-08-02 12:16:28 --> Total execution time: 0.2786
DEBUG - 2016-08-02 12:16:40 --> Config Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:16:40 --> URI Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Router Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Output Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Security Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Input Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:16:40 --> Language Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Loader Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:16:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Session Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:16:40 --> Session routines successfully run
DEBUG - 2016-08-02 12:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Controller Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:16:40 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:16:40 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:16:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:16:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:16:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:16:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:16:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:16:40 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 12:16:40 --> Final output sent to browser
DEBUG - 2016-08-02 12:16:40 --> Total execution time: 0.2785
DEBUG - 2016-08-02 12:17:34 --> Config Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:17:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:17:34 --> URI Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Router Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Output Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Security Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Input Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:17:34 --> Language Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Loader Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:17:34 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Session Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:17:34 --> Session routines successfully run
DEBUG - 2016-08-02 12:17:34 --> Model Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Model Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Controller Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Model Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Model Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:17:34 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:17:34 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:17:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:17:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:17:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:17:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:17:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:17:35 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-02 12:17:35 --> Final output sent to browser
DEBUG - 2016-08-02 12:17:35 --> Total execution time: 0.3120
DEBUG - 2016-08-02 12:18:30 --> Config Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:18:30 --> URI Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Router Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Output Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Security Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Input Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:18:30 --> Language Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Loader Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:18:30 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Session Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:18:30 --> Session routines successfully run
DEBUG - 2016-08-02 12:18:30 --> Model Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Model Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Controller Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Model Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:18:30 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:18:30 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:18:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:18:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:18:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:18:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:18:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:18:30 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2016-08-02 12:18:30 --> Final output sent to browser
DEBUG - 2016-08-02 12:18:30 --> Total execution time: 0.3243
DEBUG - 2016-08-02 12:19:18 --> Config Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:19:18 --> URI Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Router Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Output Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Security Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Input Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:19:18 --> Language Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Loader Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:19:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Session Class Initialized
DEBUG - 2016-08-02 12:19:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:19:19 --> Session routines successfully run
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Controller Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:19:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:19:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:19:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:19:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:19:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:19:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:19:19 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-02 12:19:19 --> Final output sent to browser
DEBUG - 2016-08-02 12:19:19 --> Total execution time: 0.4402
DEBUG - 2016-08-02 12:19:20 --> Config Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:19:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:19:20 --> URI Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Router Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Output Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Security Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Input Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:19:20 --> Language Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Loader Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:19:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Session Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:19:20 --> Session routines successfully run
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Controller Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:19:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:19:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:19:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:19:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:19:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:19:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:19:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:19:21 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:19:21 --> Final output sent to browser
DEBUG - 2016-08-02 12:19:21 --> Total execution time: 0.5888
DEBUG - 2016-08-02 12:19:46 --> Config Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:19:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:19:46 --> URI Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Router Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Output Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Security Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Input Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:19:46 --> Language Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Loader Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:19:46 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Session Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:19:46 --> Session routines successfully run
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Controller Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:19:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:19:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:19:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:19:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:19:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:19:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:19:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:19:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:19:46 --> Final output sent to browser
DEBUG - 2016-08-02 12:19:46 --> Total execution time: 0.5093
DEBUG - 2016-08-02 12:19:57 --> Config Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:19:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:19:57 --> URI Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Router Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Output Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Security Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Input Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:19:57 --> Language Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Loader Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:19:57 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Session Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:19:57 --> Session routines successfully run
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Controller Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Model Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:19:57 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:19:57 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:19:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:19:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:19:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:19:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:19:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:19:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:19:57 --> Final output sent to browser
DEBUG - 2016-08-02 12:19:57 --> Total execution time: 0.6625
DEBUG - 2016-08-02 12:20:06 --> Config Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:20:06 --> URI Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Router Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Output Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Security Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Input Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:20:06 --> Language Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Loader Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:20:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Session Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:20:06 --> Session routines successfully run
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Controller Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:20:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:20:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:20:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:20:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:20:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:20:06 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 12:20:06 --> Final output sent to browser
DEBUG - 2016-08-02 12:20:06 --> Total execution time: 0.3962
DEBUG - 2016-08-02 12:20:46 --> Config Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:20:46 --> URI Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Router Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Output Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Security Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Input Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:20:46 --> Language Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Loader Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:20:46 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Session Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:20:46 --> Session routines successfully run
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Controller Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:20:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:20:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:20:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:20:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:20:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:20:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:20:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:20:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:20:47 --> Final output sent to browser
DEBUG - 2016-08-02 12:20:47 --> Total execution time: 0.6038
DEBUG - 2016-08-02 12:20:56 --> Config Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:20:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:20:56 --> URI Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Router Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Output Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Security Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Input Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:20:56 --> Language Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Loader Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:20:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Session Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:20:56 --> Session routines successfully run
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Controller Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:20:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:20:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:20:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:20:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:20:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:20:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:20:56 --> File loaded: application/views/message/inboxView.php
DEBUG - 2016-08-02 12:20:56 --> Final output sent to browser
DEBUG - 2016-08-02 12:20:56 --> Total execution time: 0.3615
DEBUG - 2016-08-02 12:20:59 --> Config Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:20:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:20:59 --> URI Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Router Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Output Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Security Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Input Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:20:59 --> Language Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Loader Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:20:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Session Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:20:59 --> Session routines successfully run
DEBUG - 2016-08-02 12:20:59 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Controller Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Model Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:20:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:20:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:20:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:20:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:20:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:20:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:20:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:20:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 12:20:59 --> Final output sent to browser
DEBUG - 2016-08-02 12:20:59 --> Total execution time: 0.2948
DEBUG - 2016-08-02 12:21:02 --> Config Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:21:02 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:21:02 --> URI Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Router Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Output Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Security Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Input Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:21:02 --> Language Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Loader Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:21:02 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Session Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:21:02 --> Session routines successfully run
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Controller Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:21:02 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:21:02 --> File loaded: application/views/form/index.php
DEBUG - 2016-08-02 12:21:02 --> Final output sent to browser
DEBUG - 2016-08-02 12:21:02 --> Total execution time: 0.3415
DEBUG - 2016-08-02 12:21:05 --> Config Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:21:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:21:05 --> URI Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Router Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Output Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Security Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Input Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:21:05 --> Language Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Loader Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:21:05 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Session Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:21:05 --> Session routines successfully run
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Controller Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:21:05 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:21:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:21:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:21:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:21:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:21:05 --> File loaded: application/views/form/list.php
DEBUG - 2016-08-02 12:21:05 --> Final output sent to browser
DEBUG - 2016-08-02 12:21:05 --> Total execution time: 0.3549
DEBUG - 2016-08-02 12:21:11 --> Config Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:21:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:21:11 --> URI Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Router Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Output Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Security Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Input Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:21:11 --> Language Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Loader Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:21:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Session Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:21:11 --> Session routines successfully run
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Controller Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:21:11 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:21:11 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:21:11 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:21:11 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:21:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:21:11 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:21:11 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:21:11 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-08-02 12:21:11 --> Final output sent to browser
DEBUG - 2016-08-02 12:21:11 --> Total execution time: 0.3742
DEBUG - 2016-08-02 12:21:19 --> Config Class Initialized
DEBUG - 2016-08-02 12:21:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 12:21:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 12:21:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 12:21:19 --> URI Class Initialized
DEBUG - 2016-08-02 12:21:19 --> Router Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Output Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Security Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Input Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 12:21:20 --> Language Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Loader Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 12:21:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Session Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 12:21:20 --> Session routines successfully run
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Controller Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 12:21:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 12:21:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 12:21:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 12:21:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 12:21:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 12:21:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 12:21:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 12:21:20 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-08-02 12:21:20 --> Final output sent to browser
DEBUG - 2016-08-02 12:21:20 --> Total execution time: 0.5589
DEBUG - 2016-08-02 19:21:09 --> Config Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:21:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:21:09 --> URI Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Router Class Initialized
DEBUG - 2016-08-02 19:21:09 --> No URI present. Default controller set.
DEBUG - 2016-08-02 19:21:09 --> Output Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Security Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Input Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:21:09 --> Language Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Loader Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:21:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Session Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:21:09 --> A session cookie was not found.
DEBUG - 2016-08-02 19:21:09 --> Session routines successfully run
DEBUG - 2016-08-02 19:21:09 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Controller Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:09 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:10 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:10 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:10 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:10 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:21:10 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:21:10 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-02 19:21:10 --> Final output sent to browser
DEBUG - 2016-08-02 19:21:10 --> Total execution time: 1.0301
DEBUG - 2016-08-02 19:21:13 --> Config Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:21:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:21:13 --> URI Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Router Class Initialized
DEBUG - 2016-08-02 19:21:13 --> No URI present. Default controller set.
DEBUG - 2016-08-02 19:21:13 --> Output Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Security Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Input Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:21:13 --> Language Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Loader Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:21:13 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Session Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:21:13 --> Session routines successfully run
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Controller Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:13 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:21:13 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:21:13 --> File loaded: application/views/loginView.php
DEBUG - 2016-08-02 19:21:13 --> Final output sent to browser
DEBUG - 2016-08-02 19:21:13 --> Total execution time: 0.2970
DEBUG - 2016-08-02 19:21:33 --> Config Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:21:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:21:33 --> URI Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Router Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Output Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Security Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Input Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:21:33 --> Language Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Loader Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:21:33 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Session Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:21:33 --> Session routines successfully run
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Controller Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:21:33 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:21:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-08-02 19:21:34 --> Config Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:21:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:21:34 --> URI Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Router Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Output Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Security Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Input Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:21:34 --> Language Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Loader Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:21:34 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Session Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:21:34 --> Session routines successfully run
DEBUG - 2016-08-02 19:21:34 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Controller Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Model Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:21:34 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:21:34 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:21:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:21:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:21:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:21:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:21:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:21:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:21:34 --> Final output sent to browser
DEBUG - 2016-08-02 19:21:34 --> Total execution time: 0.5523
DEBUG - 2016-08-02 19:24:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:24:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:24:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Router Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Output Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Security Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Input Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:24:21 --> Language Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Loader Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:24:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Session Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:24:21 --> Session routines successfully run
DEBUG - 2016-08-02 19:24:21 --> Model Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Model Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Controller Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Model Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:24:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:24:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:24:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:24:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:24:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:24:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:24:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:24:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:24:21 --> Final output sent to browser
DEBUG - 2016-08-02 19:24:21 --> Total execution time: 0.3342
DEBUG - 2016-08-02 19:24:22 --> Config Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Config Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:24:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:24:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:24:22 --> URI Class Initialized
DEBUG - 2016-08-02 19:24:22 --> URI Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Router Class Initialized
DEBUG - 2016-08-02 19:24:22 --> Router Class Initialized
ERROR - 2016-08-02 19:24:22 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:24:22 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:24:57 --> Config Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:24:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:24:57 --> URI Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Router Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Output Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Security Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Input Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:24:57 --> Language Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Loader Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:24:57 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Session Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:24:57 --> Session routines successfully run
DEBUG - 2016-08-02 19:24:57 --> Model Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Model Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Controller Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Model Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:24:57 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:24:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:24:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:24:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:24:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:24:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:24:57 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:24:57 --> Final output sent to browser
DEBUG - 2016-08-02 19:24:57 --> Total execution time: 0.3106
DEBUG - 2016-08-02 19:24:57 --> Config Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Config Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:24:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:24:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:24:57 --> URI Class Initialized
DEBUG - 2016-08-02 19:24:57 --> URI Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Router Class Initialized
DEBUG - 2016-08-02 19:24:57 --> Router Class Initialized
ERROR - 2016-08-02 19:24:57 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:24:57 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:25:06 --> Config Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:25:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:25:06 --> URI Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Router Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Output Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Security Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Input Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:25:06 --> Language Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Loader Class Initialized
DEBUG - 2016-08-02 19:25:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:25:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Session Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:25:07 --> Session routines successfully run
DEBUG - 2016-08-02 19:25:07 --> Model Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Model Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Controller Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Model Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:25:07 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:25:07 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:25:07 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:25:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:25:07 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:25:07 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:25:07 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:25:07 --> Final output sent to browser
DEBUG - 2016-08-02 19:25:07 --> Total execution time: 0.3354
DEBUG - 2016-08-02 19:25:07 --> Config Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Config Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:25:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:25:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:25:07 --> URI Class Initialized
DEBUG - 2016-08-02 19:25:07 --> URI Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Router Class Initialized
DEBUG - 2016-08-02 19:25:07 --> Router Class Initialized
ERROR - 2016-08-02 19:25:07 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:25:07 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Output Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Security Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Input Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:28:32 --> Language Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Loader Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:28:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Session Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:28:32 --> Session routines successfully run
DEBUG - 2016-08-02 19:28:32 --> Model Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Model Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Controller Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Model Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:28:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:28:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:28:32 --> Final output sent to browser
DEBUG - 2016-08-02 19:28:32 --> Total execution time: 0.3254
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
ERROR - 2016-08-02 19:28:32 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:28:32 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
ERROR - 2016-08-02 19:28:32 --> 404 Page Not Found --> js
ERROR - 2016-08-02 19:28:32 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:28:32 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:28:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:28:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:28:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:28:32 --> Router Class Initialized
ERROR - 2016-08-02 19:28:32 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:29:11 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:11 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:11 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Router Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Output Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Security Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Input Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:29:11 --> Language Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Loader Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:29:11 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Session Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:29:11 --> Session routines successfully run
DEBUG - 2016-08-02 19:29:11 --> Model Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Model Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Controller Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Model Class Initialized
DEBUG - 2016-08-02 19:29:11 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:29:11 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:29:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:29:12 --> Final output sent to browser
DEBUG - 2016-08-02 19:29:12 --> Total execution time: 0.3549
DEBUG - 2016-08-02 19:29:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Router Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Router Class Initialized
ERROR - 2016-08-02 19:29:12 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:29:12 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:29:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:29:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Router Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Router Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Router Class Initialized
DEBUG - 2016-08-02 19:29:12 --> Router Class Initialized
ERROR - 2016-08-02 19:29:12 --> 404 Page Not Found --> assets
ERROR - 2016-08-02 19:29:12 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:29:12 --> 404 Page Not Found --> js
ERROR - 2016-08-02 19:29:12 --> 404 Page Not Found --> assets
DEBUG - 2016-08-02 19:30:58 --> Config Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:30:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:30:58 --> URI Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Router Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Output Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Security Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Input Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:30:58 --> Language Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Loader Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:30:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Session Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:30:58 --> Session routines successfully run
DEBUG - 2016-08-02 19:30:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Controller Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:30:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:30:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:30:58 --> Final output sent to browser
DEBUG - 2016-08-02 19:30:58 --> Total execution time: 0.3517
DEBUG - 2016-08-02 19:30:58 --> Config Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Config Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:30:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:30:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:30:58 --> URI Class Initialized
DEBUG - 2016-08-02 19:30:58 --> URI Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Router Class Initialized
DEBUG - 2016-08-02 19:30:58 --> Router Class Initialized
ERROR - 2016-08-02 19:30:58 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:30:58 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:31:51 --> Config Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:31:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:31:51 --> URI Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Router Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Output Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Security Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Input Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:31:51 --> Language Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Loader Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:31:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Session Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:31:51 --> Session routines successfully run
DEBUG - 2016-08-02 19:31:51 --> Model Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Model Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Controller Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Model Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:31:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:31:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:31:51 --> Final output sent to browser
DEBUG - 2016-08-02 19:31:51 --> Total execution time: 0.3422
DEBUG - 2016-08-02 19:31:51 --> Config Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:31:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:31:51 --> URI Class Initialized
DEBUG - 2016-08-02 19:31:51 --> Router Class Initialized
ERROR - 2016-08-02 19:31:51 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:31:52 --> Config Class Initialized
DEBUG - 2016-08-02 19:31:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:31:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:31:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:31:52 --> URI Class Initialized
DEBUG - 2016-08-02 19:31:52 --> Router Class Initialized
ERROR - 2016-08-02 19:31:52 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:33:24 --> Config Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:33:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:33:24 --> URI Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Router Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Output Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Security Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Input Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:33:24 --> Language Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Loader Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:33:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Session Class Initialized
DEBUG - 2016-08-02 19:33:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:33:24 --> Session routines successfully run
DEBUG - 2016-08-02 19:33:25 --> Model Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Model Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Controller Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Model Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:33:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:33:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:33:25 --> Final output sent to browser
DEBUG - 2016-08-02 19:33:25 --> Total execution time: 0.3520
DEBUG - 2016-08-02 19:33:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:33:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:33:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Router Class Initialized
ERROR - 2016-08-02 19:33:25 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:33:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:33:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:33:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:33:25 --> Router Class Initialized
ERROR - 2016-08-02 19:33:25 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:35:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Router Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Output Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Security Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Input Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:35:25 --> Language Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Loader Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:35:25 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Session Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:35:25 --> Session routines successfully run
DEBUG - 2016-08-02 19:35:25 --> Model Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Model Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Controller Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Model Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:35:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:35:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:35:25 --> Final output sent to browser
DEBUG - 2016-08-02 19:35:25 --> Total execution time: 0.3487
DEBUG - 2016-08-02 19:35:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Router Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Router Class Initialized
ERROR - 2016-08-02 19:35:25 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:35:25 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:35:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Router Class Initialized
ERROR - 2016-08-02 19:35:25 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:35:25 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:25 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:25 --> Router Class Initialized
ERROR - 2016-08-02 19:35:25 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:35:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Router Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Output Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Security Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Input Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:35:59 --> Language Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Loader Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:35:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Session Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:35:59 --> Session routines successfully run
DEBUG - 2016-08-02 19:35:59 --> Model Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Model Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Controller Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Model Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:35:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:35:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:35:59 --> Final output sent to browser
DEBUG - 2016-08-02 19:35:59 --> Total execution time: 0.3459
DEBUG - 2016-08-02 19:35:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Router Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Router Class Initialized
ERROR - 2016-08-02 19:35:59 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:35:59 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:35:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Router Class Initialized
ERROR - 2016-08-02 19:35:59 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:35:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:35:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:35:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:35:59 --> Router Class Initialized
ERROR - 2016-08-02 19:35:59 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:36:20 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:20 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Router Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Output Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Security Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Input Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:36:20 --> Language Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Loader Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:36:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Session Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:36:20 --> Session routines successfully run
DEBUG - 2016-08-02 19:36:20 --> Model Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Model Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Controller Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Model Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:36:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:36:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:36:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:36:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:36:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:36:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:36:21 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:36:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:36:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:36:21 --> Final output sent to browser
DEBUG - 2016-08-02 19:36:21 --> Total execution time: 0.3298
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:36:21 --> Config Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:36:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:36:21 --> URI Class Initialized
DEBUG - 2016-08-02 19:36:21 --> Router Class Initialized
ERROR - 2016-08-02 19:36:21 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:37:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Router Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Output Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Security Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Input Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:37:12 --> Language Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Loader Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:37:12 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Session Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:37:12 --> Session routines successfully run
DEBUG - 2016-08-02 19:37:12 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Controller Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:37:12 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:37:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:37:12 --> Final output sent to browser
DEBUG - 2016-08-02 19:37:12 --> Total execution time: 0.3481
DEBUG - 2016-08-02 19:37:12 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:12 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:12 --> Router Class Initialized
ERROR - 2016-08-02 19:37:12 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:37:13 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:13 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:13 --> Router Class Initialized
ERROR - 2016-08-02 19:37:13 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:37:17 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:17 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Router Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Output Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Security Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Input Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:37:17 --> Language Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Loader Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:37:17 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Session Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:37:17 --> Session routines successfully run
DEBUG - 2016-08-02 19:37:17 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Controller Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:37:17 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:37:17 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:37:17 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:37:17 --> Final output sent to browser
DEBUG - 2016-08-02 19:37:17 --> Total execution time: 0.3487
DEBUG - 2016-08-02 19:37:51 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:51 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Router Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Output Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Security Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Input Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:37:51 --> Language Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Loader Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:37:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Session Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:37:51 --> Session routines successfully run
DEBUG - 2016-08-02 19:37:51 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Controller Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Model Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:37:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:37:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:37:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:37:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:37:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:37:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:37:52 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:37:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:37:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:37:52 --> Final output sent to browser
DEBUG - 2016-08-02 19:37:52 --> Total execution time: 0.3457
DEBUG - 2016-08-02 19:37:53 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:53 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:53 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:53 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:53 --> Router Class Initialized
ERROR - 2016-08-02 19:37:53 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:37:53 --> Config Class Initialized
DEBUG - 2016-08-02 19:37:53 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:37:53 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:37:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:37:53 --> URI Class Initialized
DEBUG - 2016-08-02 19:37:53 --> Router Class Initialized
ERROR - 2016-08-02 19:37:53 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:38:58 --> Config Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:38:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:38:58 --> URI Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Router Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Output Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Security Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Input Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:38:58 --> Language Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Loader Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:38:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Session Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:38:58 --> Session routines successfully run
DEBUG - 2016-08-02 19:38:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Controller Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:38:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:38:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:38:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:38:58 --> Final output sent to browser
DEBUG - 2016-08-02 19:38:58 --> Total execution time: 0.3550
DEBUG - 2016-08-02 19:38:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:38:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:38:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:38:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:38:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:38:59 --> Router Class Initialized
ERROR - 2016-08-02 19:38:59 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:38:59 --> Config Class Initialized
DEBUG - 2016-08-02 19:38:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:38:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:38:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:38:59 --> URI Class Initialized
DEBUG - 2016-08-02 19:38:59 --> Router Class Initialized
ERROR - 2016-08-02 19:38:59 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:39:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:39:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:39:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Router Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Output Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Security Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Input Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:39:32 --> Language Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Loader Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:39:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Session Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:39:32 --> Session routines successfully run
DEBUG - 2016-08-02 19:39:32 --> Model Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Model Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Controller Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Model Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:39:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:39:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:39:32 --> Final output sent to browser
DEBUG - 2016-08-02 19:39:32 --> Total execution time: 0.3445
DEBUG - 2016-08-02 19:39:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:39:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:39:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Router Class Initialized
ERROR - 2016-08-02 19:39:32 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:39:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:39:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:39:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:39:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:39:33 --> Router Class Initialized
ERROR - 2016-08-02 19:39:33 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:39:52 --> Config Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:39:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:39:52 --> URI Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Router Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Output Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Security Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Input Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:39:52 --> Language Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Loader Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:39:52 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Session Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:39:52 --> Session routines successfully run
DEBUG - 2016-08-02 19:39:52 --> Model Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Model Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Controller Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Model Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:39:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:39:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:39:52 --> Final output sent to browser
DEBUG - 2016-08-02 19:39:52 --> Total execution time: 0.3548
DEBUG - 2016-08-02 19:39:52 --> Config Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:39:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:39:52 --> URI Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Router Class Initialized
ERROR - 2016-08-02 19:39:52 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:39:52 --> Config Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:39:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:39:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:39:52 --> URI Class Initialized
DEBUG - 2016-08-02 19:39:53 --> Router Class Initialized
ERROR - 2016-08-02 19:39:53 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:40:04 --> Config Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Config Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:40:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:40:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:40:05 --> URI Class Initialized
DEBUG - 2016-08-02 19:40:05 --> URI Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Router Class Initialized
DEBUG - 2016-08-02 19:40:05 --> Router Class Initialized
ERROR - 2016-08-02 19:40:05 --> 404 Page Not Found --> angularjs
ERROR - 2016-08-02 19:40:05 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:43:03 --> Config Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:43:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:43:03 --> URI Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Router Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Output Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Security Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Input Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:43:03 --> Language Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Loader Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:43:03 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Session Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:43:03 --> Session routines successfully run
DEBUG - 2016-08-02 19:43:03 --> Model Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Model Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Controller Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Model Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:43:03 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:43:03 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:43:03 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:43:03 --> Final output sent to browser
DEBUG - 2016-08-02 19:43:03 --> Total execution time: 0.3587
DEBUG - 2016-08-02 19:43:04 --> Config Class Initialized
DEBUG - 2016-08-02 19:43:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:43:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:43:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:43:04 --> URI Class Initialized
DEBUG - 2016-08-02 19:43:04 --> Router Class Initialized
ERROR - 2016-08-02 19:43:04 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:43:04 --> Config Class Initialized
DEBUG - 2016-08-02 19:43:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:43:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:43:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:43:04 --> URI Class Initialized
DEBUG - 2016-08-02 19:43:04 --> Router Class Initialized
ERROR - 2016-08-02 19:43:04 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:53:55 --> Config Class Initialized
DEBUG - 2016-08-02 19:53:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:53:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:53:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:53:55 --> URI Class Initialized
DEBUG - 2016-08-02 19:53:55 --> Router Class Initialized
DEBUG - 2016-08-02 19:53:55 --> No URI present. Default controller set.
DEBUG - 2016-08-02 19:53:56 --> Output Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Security Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Input Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:53:56 --> Language Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Loader Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:53:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Session Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:53:56 --> Session routines successfully run
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Controller Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:53:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Config Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:53:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:53:56 --> URI Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Router Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Output Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Security Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Input Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:53:56 --> Language Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Loader Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:53:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Session Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:53:56 --> Session routines successfully run
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Controller Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:53:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:53:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:53:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:53:56 --> Final output sent to browser
DEBUG - 2016-08-02 19:53:56 --> Total execution time: 0.3101
DEBUG - 2016-08-02 19:53:58 --> Config Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:53:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:53:58 --> URI Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Router Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Output Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Security Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Input Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:53:58 --> Language Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Loader Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:53:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Session Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:53:58 --> Session routines successfully run
DEBUG - 2016-08-02 19:53:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Controller Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Model Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:53:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:53:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:53:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:53:58 --> Final output sent to browser
DEBUG - 2016-08-02 19:53:58 --> Total execution time: 0.3142
DEBUG - 2016-08-02 19:54:26 --> Config Class Initialized
DEBUG - 2016-08-02 19:54:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:54:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:54:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:54:27 --> URI Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Router Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Output Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Security Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Input Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:54:27 --> Language Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Loader Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:54:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Session Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:54:27 --> Session routines successfully run
DEBUG - 2016-08-02 19:54:27 --> Model Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Model Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Controller Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Model Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:54:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:54:27 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:54:27 --> Final output sent to browser
DEBUG - 2016-08-02 19:54:27 --> Total execution time: 0.3323
DEBUG - 2016-08-02 19:54:27 --> Config Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:54:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:54:27 --> URI Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Router Class Initialized
ERROR - 2016-08-02 19:54:27 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:54:27 --> Config Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:54:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:54:27 --> URI Class Initialized
DEBUG - 2016-08-02 19:54:27 --> Router Class Initialized
ERROR - 2016-08-02 19:54:27 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:55:04 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:04 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Router Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Output Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Security Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Input Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:55:04 --> Language Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Loader Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:55:04 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Session Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:55:04 --> Session routines successfully run
DEBUG - 2016-08-02 19:55:04 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Controller Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:55:04 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:55:04 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:55:04 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:55:04 --> Final output sent to browser
DEBUG - 2016-08-02 19:55:04 --> Total execution time: 0.4946
DEBUG - 2016-08-02 19:55:05 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:05 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:05 --> Router Class Initialized
ERROR - 2016-08-02 19:55:05 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:55:05 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:05 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:05 --> Router Class Initialized
ERROR - 2016-08-02 19:55:05 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:55:31 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:31 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Router Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Output Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Security Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Input Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:55:31 --> Language Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Loader Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:55:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Session Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:55:31 --> Session routines successfully run
DEBUG - 2016-08-02 19:55:31 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Controller Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:55:31 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:55:31 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:55:31 --> Final output sent to browser
DEBUG - 2016-08-02 19:55:31 --> Total execution time: 0.3206
DEBUG - 2016-08-02 19:55:31 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:32 --> Router Class Initialized
ERROR - 2016-08-02 19:55:32 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:55:32 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:32 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:32 --> Router Class Initialized
ERROR - 2016-08-02 19:55:32 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:55:45 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:45 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Router Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Output Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Security Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Input Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:55:45 --> Language Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Loader Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:55:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Session Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:55:45 --> Session routines successfully run
DEBUG - 2016-08-02 19:55:45 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Controller Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:55:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:55:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:55:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:55:45 --> Final output sent to browser
DEBUG - 2016-08-02 19:55:45 --> Total execution time: 0.3072
DEBUG - 2016-08-02 19:55:46 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:46 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:46 --> Router Class Initialized
ERROR - 2016-08-02 19:55:46 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:55:46 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:46 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:46 --> Router Class Initialized
ERROR - 2016-08-02 19:55:46 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:55:54 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:54 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Router Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Output Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Security Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Input Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:55:54 --> Language Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Loader Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:55:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Session Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:55:54 --> Session routines successfully run
DEBUG - 2016-08-02 19:55:54 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Controller Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Model Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:55:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:55:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:55:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:55:54 --> Final output sent to browser
DEBUG - 2016-08-02 19:55:54 --> Total execution time: 0.3169
DEBUG - 2016-08-02 19:55:55 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:55 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:55 --> Router Class Initialized
ERROR - 2016-08-02 19:55:55 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:55:55 --> Config Class Initialized
DEBUG - 2016-08-02 19:55:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:55:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:55:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:55:55 --> URI Class Initialized
DEBUG - 2016-08-02 19:55:55 --> Router Class Initialized
ERROR - 2016-08-02 19:55:55 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:57:53 --> Config Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:57:55 --> URI Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Router Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Output Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Security Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Input Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:57:55 --> Language Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Loader Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:57:55 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Session Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:57:55 --> Session routines successfully run
DEBUG - 2016-08-02 19:57:55 --> Model Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Model Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Controller Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Model Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:57:55 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:57:55 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:57:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:57:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:57:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:57:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:57:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:57:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:57:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:57:56 --> Final output sent to browser
DEBUG - 2016-08-02 19:57:56 --> Total execution time: 2.1455
DEBUG - 2016-08-02 19:57:57 --> Config Class Initialized
DEBUG - 2016-08-02 19:57:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:57:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:57:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:57:57 --> URI Class Initialized
DEBUG - 2016-08-02 19:57:57 --> Router Class Initialized
ERROR - 2016-08-02 19:57:57 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:57:57 --> Config Class Initialized
DEBUG - 2016-08-02 19:57:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:57:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:57:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:57:57 --> URI Class Initialized
DEBUG - 2016-08-02 19:57:57 --> Router Class Initialized
ERROR - 2016-08-02 19:57:57 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 19:58:06 --> Config Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:58:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:58:06 --> URI Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Router Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Output Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Security Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Input Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 19:58:06 --> Language Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Loader Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 19:58:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Session Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 19:58:06 --> Session routines successfully run
DEBUG - 2016-08-02 19:58:06 --> Model Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Model Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Controller Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Model Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 19:58:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 19:58:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 19:58:06 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 19:58:06 --> Final output sent to browser
DEBUG - 2016-08-02 19:58:06 --> Total execution time: 0.4852
DEBUG - 2016-08-02 19:58:07 --> Config Class Initialized
DEBUG - 2016-08-02 19:58:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:58:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:58:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:58:07 --> URI Class Initialized
DEBUG - 2016-08-02 19:58:07 --> Router Class Initialized
ERROR - 2016-08-02 19:58:07 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 19:58:07 --> Config Class Initialized
DEBUG - 2016-08-02 19:58:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 19:58:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 19:58:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 19:58:07 --> URI Class Initialized
DEBUG - 2016-08-02 19:58:07 --> Router Class Initialized
ERROR - 2016-08-02 19:58:07 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:00:08 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:08 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:08 --> Router Class Initialized
DEBUG - 2016-08-02 20:00:08 --> Output Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Security Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Input Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:00:09 --> Language Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Loader Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:00:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Session Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:00:09 --> Session routines successfully run
DEBUG - 2016-08-02 20:00:09 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Controller Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:00:09 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:00:09 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:00:09 --> Final output sent to browser
DEBUG - 2016-08-02 20:00:09 --> Total execution time: 0.6291
DEBUG - 2016-08-02 20:00:09 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:09 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Router Class Initialized
ERROR - 2016-08-02 20:00:09 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:00:09 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:09 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:09 --> Router Class Initialized
ERROR - 2016-08-02 20:00:09 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:00:23 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:23 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Router Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Output Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Security Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Input Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:00:23 --> Language Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Loader Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:00:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Session Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:00:23 --> Session routines successfully run
DEBUG - 2016-08-02 20:00:23 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Controller Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:00:23 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:00:23 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:00:23 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:00:23 --> Final output sent to browser
DEBUG - 2016-08-02 20:00:24 --> Total execution time: 0.4908
DEBUG - 2016-08-02 20:00:24 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:24 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:24 --> Router Class Initialized
ERROR - 2016-08-02 20:00:24 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:00:24 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:24 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:24 --> Router Class Initialized
ERROR - 2016-08-02 20:00:24 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:00:49 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:49 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Router Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Output Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Security Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Input Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:00:49 --> Language Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Loader Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:00:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Session Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:00:49 --> Session routines successfully run
DEBUG - 2016-08-02 20:00:49 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Controller Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Model Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:00:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:00:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:00:49 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:00:49 --> Final output sent to browser
DEBUG - 2016-08-02 20:00:49 --> Total execution time: 0.5076
DEBUG - 2016-08-02 20:00:50 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:50 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:50 --> Router Class Initialized
ERROR - 2016-08-02 20:00:50 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:00:50 --> Config Class Initialized
DEBUG - 2016-08-02 20:00:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:00:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:00:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:00:50 --> URI Class Initialized
DEBUG - 2016-08-02 20:00:50 --> Router Class Initialized
ERROR - 2016-08-02 20:00:50 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:01:00 --> Config Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:01:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:01:00 --> URI Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Router Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Output Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Security Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Input Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:01:00 --> Language Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Loader Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:01:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Session Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:01:00 --> Session routines successfully run
DEBUG - 2016-08-02 20:01:00 --> Model Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Model Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Controller Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Model Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:01:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:01:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:01:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:01:00 --> Final output sent to browser
DEBUG - 2016-08-02 20:01:00 --> Total execution time: 0.4956
DEBUG - 2016-08-02 20:01:01 --> Config Class Initialized
DEBUG - 2016-08-02 20:01:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:01:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:01:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:01:01 --> URI Class Initialized
DEBUG - 2016-08-02 20:01:01 --> Router Class Initialized
ERROR - 2016-08-02 20:01:01 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:01:01 --> Config Class Initialized
DEBUG - 2016-08-02 20:01:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:01:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:01:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:01:01 --> URI Class Initialized
DEBUG - 2016-08-02 20:01:01 --> Router Class Initialized
ERROR - 2016-08-02 20:01:01 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:06:31 --> Config Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:06:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:06:31 --> URI Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Router Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Output Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Security Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Input Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:06:31 --> Language Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Loader Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:06:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Session Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:06:31 --> Session routines successfully run
DEBUG - 2016-08-02 20:06:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Controller Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:06:31 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:06:31 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:06:31 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:06:31 --> Final output sent to browser
DEBUG - 2016-08-02 20:06:31 --> Total execution time: 0.5239
DEBUG - 2016-08-02 20:06:32 --> Config Class Initialized
DEBUG - 2016-08-02 20:06:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:06:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:06:32 --> Config Class Initialized
DEBUG - 2016-08-02 20:06:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:06:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:06:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:06:32 --> URI Class Initialized
DEBUG - 2016-08-02 20:06:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:06:32 --> Router Class Initialized
DEBUG - 2016-08-02 20:06:32 --> URI Class Initialized
ERROR - 2016-08-02 20:06:32 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:06:32 --> Router Class Initialized
ERROR - 2016-08-02 20:06:32 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:06:53 --> Config Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:06:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:06:54 --> URI Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Router Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Output Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Security Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Input Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:06:54 --> Language Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Loader Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:06:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Session Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:06:54 --> Session routines successfully run
DEBUG - 2016-08-02 20:06:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Controller Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:06:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:06:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:06:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:06:54 --> Final output sent to browser
DEBUG - 2016-08-02 20:06:54 --> Total execution time: 0.5719
DEBUG - 2016-08-02 20:06:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:06:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:06:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:06:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:06:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:06:55 --> Router Class Initialized
ERROR - 2016-08-02 20:06:55 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:06:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:06:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:06:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:06:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:06:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:06:55 --> Router Class Initialized
ERROR - 2016-08-02 20:06:55 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:08:45 --> Config Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:08:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:08:45 --> URI Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Router Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Output Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Security Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Input Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:08:45 --> Language Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Loader Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:08:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Session Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:08:45 --> Session routines successfully run
DEBUG - 2016-08-02 20:08:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Controller Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:08:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:08:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:08:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:08:45 --> Final output sent to browser
DEBUG - 2016-08-02 20:08:45 --> Total execution time: 0.3330
DEBUG - 2016-08-02 20:08:46 --> Config Class Initialized
DEBUG - 2016-08-02 20:08:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:08:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:08:46 --> URI Class Initialized
DEBUG - 2016-08-02 20:08:46 --> Router Class Initialized
ERROR - 2016-08-02 20:08:46 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:08:46 --> Config Class Initialized
DEBUG - 2016-08-02 20:08:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:08:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:08:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:08:46 --> URI Class Initialized
DEBUG - 2016-08-02 20:08:46 --> Router Class Initialized
ERROR - 2016-08-02 20:08:46 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:09:12 --> Config Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:09:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:09:12 --> URI Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Router Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Output Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Security Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Input Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:09:12 --> Language Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Loader Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:09:12 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Session Class Initialized
DEBUG - 2016-08-02 20:09:12 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:09:13 --> Session routines successfully run
DEBUG - 2016-08-02 20:09:13 --> Model Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Model Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Controller Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Model Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:09:13 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:09:13 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:09:13 --> Final output sent to browser
DEBUG - 2016-08-02 20:09:13 --> Total execution time: 0.3196
DEBUG - 2016-08-02 20:09:13 --> Config Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:09:13 --> URI Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Router Class Initialized
ERROR - 2016-08-02 20:09:13 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:09:13 --> Config Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:09:13 --> URI Class Initialized
DEBUG - 2016-08-02 20:09:13 --> Router Class Initialized
ERROR - 2016-08-02 20:09:13 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:09:45 --> Config Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:09:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:09:45 --> URI Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Router Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Output Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Security Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Input Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:09:45 --> Language Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Loader Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:09:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Session Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:09:45 --> Session routines successfully run
DEBUG - 2016-08-02 20:09:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Controller Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:09:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:09:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:09:45 --> Final output sent to browser
DEBUG - 2016-08-02 20:09:45 --> Total execution time: 0.3322
DEBUG - 2016-08-02 20:09:45 --> Config Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:09:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:09:45 --> URI Class Initialized
DEBUG - 2016-08-02 20:09:45 --> Router Class Initialized
ERROR - 2016-08-02 20:09:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:09:46 --> Config Class Initialized
DEBUG - 2016-08-02 20:09:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:09:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:09:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:09:46 --> URI Class Initialized
DEBUG - 2016-08-02 20:09:46 --> Router Class Initialized
ERROR - 2016-08-02 20:09:46 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:10:05 --> Config Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:10:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:10:05 --> URI Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Router Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Output Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Security Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Input Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:10:05 --> Language Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Loader Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:10:05 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Session Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:10:05 --> Session routines successfully run
DEBUG - 2016-08-02 20:10:05 --> Model Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Model Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Controller Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Model Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:10:05 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:10:05 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:10:05 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:10:05 --> Final output sent to browser
DEBUG - 2016-08-02 20:10:05 --> Total execution time: 0.3398
DEBUG - 2016-08-02 20:10:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:10:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:10:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:10:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:10:06 --> Router Class Initialized
ERROR - 2016-08-02 20:10:06 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:10:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:10:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:10:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:10:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:10:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:10:06 --> Router Class Initialized
ERROR - 2016-08-02 20:10:06 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:15:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:15:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:15:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Router Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Output Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Security Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Input Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:15:06 --> Language Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Loader Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:15:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Session Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:15:06 --> Session routines successfully run
DEBUG - 2016-08-02 20:15:06 --> Model Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Model Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Controller Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Model Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:15:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:15:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:15:06 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:15:06 --> Final output sent to browser
DEBUG - 2016-08-02 20:15:06 --> Total execution time: 0.3323
DEBUG - 2016-08-02 20:15:07 --> Config Class Initialized
DEBUG - 2016-08-02 20:15:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:15:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:15:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:15:07 --> URI Class Initialized
DEBUG - 2016-08-02 20:15:07 --> Router Class Initialized
ERROR - 2016-08-02 20:15:07 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:15:08 --> Config Class Initialized
DEBUG - 2016-08-02 20:15:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:15:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:15:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:15:08 --> URI Class Initialized
DEBUG - 2016-08-02 20:15:08 --> Router Class Initialized
ERROR - 2016-08-02 20:15:08 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:15:22 --> Config Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:15:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:15:22 --> URI Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Router Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Output Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Security Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Input Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:15:22 --> Language Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Loader Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:15:22 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Session Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:15:22 --> Session routines successfully run
DEBUG - 2016-08-02 20:15:22 --> Model Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Model Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Controller Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Model Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:15:22 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:15:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:15:22 --> Final output sent to browser
DEBUG - 2016-08-02 20:15:22 --> Total execution time: 0.3351
DEBUG - 2016-08-02 20:15:22 --> Config Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:15:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:15:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:15:23 --> URI Class Initialized
DEBUG - 2016-08-02 20:15:23 --> Router Class Initialized
ERROR - 2016-08-02 20:15:23 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:15:23 --> Config Class Initialized
DEBUG - 2016-08-02 20:15:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:15:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:15:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:15:23 --> URI Class Initialized
DEBUG - 2016-08-02 20:15:23 --> Router Class Initialized
ERROR - 2016-08-02 20:15:23 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:16:40 --> Config Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:16:40 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:16:40 --> URI Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Router Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Output Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Security Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Input Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:16:40 --> Language Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Loader Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:16:40 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Session Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:16:40 --> Session routines successfully run
DEBUG - 2016-08-02 20:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Controller Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Model Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:16:40 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:16:40 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:16:40 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:16:40 --> Final output sent to browser
DEBUG - 2016-08-02 20:16:41 --> Total execution time: 0.3368
DEBUG - 2016-08-02 20:16:41 --> Config Class Initialized
DEBUG - 2016-08-02 20:16:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:16:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:16:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:16:41 --> URI Class Initialized
DEBUG - 2016-08-02 20:16:41 --> Router Class Initialized
ERROR - 2016-08-02 20:16:41 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:16:41 --> Config Class Initialized
DEBUG - 2016-08-02 20:16:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:16:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:16:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:16:41 --> URI Class Initialized
DEBUG - 2016-08-02 20:16:41 --> Router Class Initialized
ERROR - 2016-08-02 20:16:41 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:16:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:16:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:16:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Router Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Output Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Security Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Input Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:16:55 --> Language Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Loader Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:16:55 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Session Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:16:55 --> Session routines successfully run
DEBUG - 2016-08-02 20:16:55 --> Model Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Model Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Controller Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Model Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:16:55 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:16:55 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:16:55 --> Final output sent to browser
DEBUG - 2016-08-02 20:16:55 --> Total execution time: 0.3292
DEBUG - 2016-08-02 20:16:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:16:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:16:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:16:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:16:56 --> Router Class Initialized
ERROR - 2016-08-02 20:16:56 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:16:56 --> Config Class Initialized
DEBUG - 2016-08-02 20:16:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:16:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:16:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:16:56 --> URI Class Initialized
DEBUG - 2016-08-02 20:16:56 --> Router Class Initialized
ERROR - 2016-08-02 20:16:56 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:17:21 --> Config Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:17:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:17:21 --> URI Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Router Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Output Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Security Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Input Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:17:21 --> Language Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Loader Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:17:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Session Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:17:21 --> Session routines successfully run
DEBUG - 2016-08-02 20:17:21 --> Model Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Model Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Controller Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Model Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:17:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:17:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:17:21 --> Final output sent to browser
DEBUG - 2016-08-02 20:17:21 --> Total execution time: 0.3285
DEBUG - 2016-08-02 20:17:21 --> Config Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:17:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:17:21 --> URI Class Initialized
DEBUG - 2016-08-02 20:17:21 --> Router Class Initialized
ERROR - 2016-08-02 20:17:21 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:17:22 --> Config Class Initialized
DEBUG - 2016-08-02 20:17:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:17:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:17:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:17:22 --> URI Class Initialized
DEBUG - 2016-08-02 20:17:22 --> Router Class Initialized
ERROR - 2016-08-02 20:17:22 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:18:46 --> Config Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:18:46 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:18:46 --> URI Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Router Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Output Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Security Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Input Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:18:46 --> Language Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Loader Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:18:46 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Session Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:18:46 --> Session routines successfully run
DEBUG - 2016-08-02 20:18:46 --> Model Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Model Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Controller Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Model Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:18:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:18:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:18:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:18:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:18:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:18:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:18:47 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:18:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:18:47 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:18:47 --> Final output sent to browser
DEBUG - 2016-08-02 20:18:47 --> Total execution time: 0.3461
DEBUG - 2016-08-02 20:18:47 --> Config Class Initialized
DEBUG - 2016-08-02 20:18:47 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:18:47 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:18:47 --> URI Class Initialized
DEBUG - 2016-08-02 20:18:47 --> Router Class Initialized
ERROR - 2016-08-02 20:18:47 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:18:47 --> Config Class Initialized
DEBUG - 2016-08-02 20:18:47 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:18:47 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:18:47 --> URI Class Initialized
DEBUG - 2016-08-02 20:18:47 --> Router Class Initialized
ERROR - 2016-08-02 20:18:47 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:19:18 --> Config Class Initialized
DEBUG - 2016-08-02 20:19:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:19:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:19:19 --> URI Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Router Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Output Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Security Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Input Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:19:19 --> Language Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Loader Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:19:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Session Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:19:19 --> Session routines successfully run
DEBUG - 2016-08-02 20:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Controller Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Model Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:19:19 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:19:19 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:19:19 --> Final output sent to browser
DEBUG - 2016-08-02 20:19:19 --> Total execution time: 0.3383
DEBUG - 2016-08-02 20:19:19 --> Config Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:19:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:19:19 --> URI Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Router Class Initialized
ERROR - 2016-08-02 20:19:19 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:19:19 --> Config Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:19:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:19:19 --> URI Class Initialized
DEBUG - 2016-08-02 20:19:19 --> Router Class Initialized
ERROR - 2016-08-02 20:19:19 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:19:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:19:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:19:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Router Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Output Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Security Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Input Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:19:36 --> Language Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Loader Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:19:36 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Session Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:19:36 --> Session routines successfully run
DEBUG - 2016-08-02 20:19:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Controller Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:19:36 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:19:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:19:36 --> Final output sent to browser
DEBUG - 2016-08-02 20:19:36 --> Total execution time: 0.3514
DEBUG - 2016-08-02 20:19:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:19:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:19:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:19:36 --> Router Class Initialized
ERROR - 2016-08-02 20:19:36 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:19:37 --> Config Class Initialized
DEBUG - 2016-08-02 20:19:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:19:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:19:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:19:37 --> URI Class Initialized
DEBUG - 2016-08-02 20:19:37 --> Router Class Initialized
ERROR - 2016-08-02 20:19:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:22:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Router Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Output Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Security Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Input Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:22:36 --> Language Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Loader Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:22:36 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Session Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:22:36 --> Session routines successfully run
DEBUG - 2016-08-02 20:22:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Controller Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:22:36 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:22:36 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:22:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:22:36 --> Final output sent to browser
DEBUG - 2016-08-02 20:22:36 --> Total execution time: 0.3485
DEBUG - 2016-08-02 20:22:37 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:37 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:37 --> Router Class Initialized
ERROR - 2016-08-02 20:22:37 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:22:37 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:37 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:37 --> Router Class Initialized
ERROR - 2016-08-02 20:22:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:22:47 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:47 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:47 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Router Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Output Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Security Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Input Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:22:47 --> Language Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Loader Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:22:47 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Session Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:22:47 --> Session routines successfully run
DEBUG - 2016-08-02 20:22:47 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Controller Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:22:47 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:22:47 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:22:47 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:22:47 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:22:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:22:47 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:22:47 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:22:47 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:22:48 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:22:48 --> Final output sent to browser
DEBUG - 2016-08-02 20:22:48 --> Total execution time: 0.3601
DEBUG - 2016-08-02 20:22:48 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:48 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:48 --> Router Class Initialized
ERROR - 2016-08-02 20:22:48 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:22:48 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:48 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:48 --> Router Class Initialized
ERROR - 2016-08-02 20:22:48 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:22:50 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:50 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Router Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Output Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Security Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Input Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:22:50 --> Language Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Loader Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:22:50 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Session Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:22:50 --> Session routines successfully run
DEBUG - 2016-08-02 20:22:50 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Controller Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Model Class Initialized
DEBUG - 2016-08-02 20:22:50 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:22:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:22:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:22:51 --> Final output sent to browser
DEBUG - 2016-08-02 20:22:51 --> Total execution time: 0.3278
DEBUG - 2016-08-02 20:22:51 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:51 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Router Class Initialized
ERROR - 2016-08-02 20:22:51 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:22:51 --> Config Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:22:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:22:51 --> URI Class Initialized
DEBUG - 2016-08-02 20:22:51 --> Router Class Initialized
ERROR - 2016-08-02 20:22:51 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:25:00 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:00 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Router Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Output Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Security Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Input Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:25:00 --> Language Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Loader Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:25:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Session Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:25:00 --> Session routines successfully run
DEBUG - 2016-08-02 20:25:00 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Controller Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:25:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:25:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:25:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:25:00 --> Final output sent to browser
DEBUG - 2016-08-02 20:25:00 --> Total execution time: 0.3598
DEBUG - 2016-08-02 20:25:01 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:01 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:01 --> Router Class Initialized
ERROR - 2016-08-02 20:25:01 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:25:01 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:01 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:01 --> Router Class Initialized
ERROR - 2016-08-02 20:25:01 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:25:27 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:27 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Router Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Output Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Security Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Input Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:25:27 --> Language Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Loader Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:25:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Session Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:25:27 --> Session routines successfully run
DEBUG - 2016-08-02 20:25:27 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Controller Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:25:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:25:27 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:25:27 --> Final output sent to browser
DEBUG - 2016-08-02 20:25:27 --> Total execution time: 0.3426
DEBUG - 2016-08-02 20:25:27 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:27 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:27 --> Router Class Initialized
ERROR - 2016-08-02 20:25:27 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:25:28 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:28 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:28 --> Router Class Initialized
ERROR - 2016-08-02 20:25:28 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:25:48 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:48 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Router Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Output Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Security Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Input Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:25:48 --> Language Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Loader Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:25:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Session Class Initialized
DEBUG - 2016-08-02 20:25:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:25:48 --> Session routines successfully run
DEBUG - 2016-08-02 20:25:49 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Controller Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Model Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:25:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:25:49 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:25:49 --> Final output sent to browser
DEBUG - 2016-08-02 20:25:49 --> Total execution time: 0.3628
DEBUG - 2016-08-02 20:25:49 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:49 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:49 --> Router Class Initialized
ERROR - 2016-08-02 20:25:49 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:25:50 --> Config Class Initialized
DEBUG - 2016-08-02 20:25:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:25:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:25:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:25:50 --> URI Class Initialized
DEBUG - 2016-08-02 20:25:50 --> Router Class Initialized
ERROR - 2016-08-02 20:25:50 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:26:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:26:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:26:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:26:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:26:06 --> Router Class Initialized
ERROR - 2016-08-02 20:26:06 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:26:07 --> Config Class Initialized
DEBUG - 2016-08-02 20:26:07 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:26:07 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:26:07 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:26:07 --> URI Class Initialized
DEBUG - 2016-08-02 20:26:07 --> Router Class Initialized
ERROR - 2016-08-02 20:26:07 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:27:49 --> Config Class Initialized
DEBUG - 2016-08-02 20:27:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:27:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:27:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:27:49 --> URI Class Initialized
DEBUG - 2016-08-02 20:27:49 --> Router Class Initialized
ERROR - 2016-08-02 20:27:49 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:27:50 --> Config Class Initialized
DEBUG - 2016-08-02 20:27:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:27:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:27:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:27:50 --> URI Class Initialized
DEBUG - 2016-08-02 20:27:50 --> Router Class Initialized
ERROR - 2016-08-02 20:27:50 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:27:51 --> Config Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:27:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:27:51 --> URI Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Router Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Output Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Security Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Input Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:27:51 --> Language Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Loader Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:27:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Session Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:27:51 --> Session routines successfully run
DEBUG - 2016-08-02 20:27:51 --> Model Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Model Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Controller Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Model Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:27:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:27:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:27:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:27:51 --> Final output sent to browser
DEBUG - 2016-08-02 20:27:51 --> Total execution time: 0.3621
DEBUG - 2016-08-02 20:27:52 --> Config Class Initialized
DEBUG - 2016-08-02 20:27:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:27:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:27:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:27:52 --> URI Class Initialized
DEBUG - 2016-08-02 20:27:52 --> Router Class Initialized
ERROR - 2016-08-02 20:27:52 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:27:52 --> Config Class Initialized
DEBUG - 2016-08-02 20:27:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:27:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:27:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:27:52 --> URI Class Initialized
DEBUG - 2016-08-02 20:27:52 --> Router Class Initialized
ERROR - 2016-08-02 20:27:52 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:28:48 --> Config Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:28:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:28:48 --> URI Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Router Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Output Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Security Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Input Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:28:48 --> Language Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Loader Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:28:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Session Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:28:48 --> Session routines successfully run
DEBUG - 2016-08-02 20:28:48 --> Model Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Model Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Controller Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Model Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:28:48 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:28:48 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:28:48 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:28:48 --> Final output sent to browser
DEBUG - 2016-08-02 20:28:48 --> Total execution time: 0.3618
DEBUG - 2016-08-02 20:28:49 --> Config Class Initialized
DEBUG - 2016-08-02 20:28:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:28:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:28:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:28:49 --> URI Class Initialized
DEBUG - 2016-08-02 20:28:49 --> Router Class Initialized
ERROR - 2016-08-02 20:28:49 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:28:49 --> Config Class Initialized
DEBUG - 2016-08-02 20:28:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:28:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:28:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:28:49 --> URI Class Initialized
DEBUG - 2016-08-02 20:28:49 --> Router Class Initialized
ERROR - 2016-08-02 20:28:49 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:29:41 --> Config Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:29:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:29:41 --> URI Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Router Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Output Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Security Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Input Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:29:41 --> Language Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Loader Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:29:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Session Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:29:41 --> Session routines successfully run
DEBUG - 2016-08-02 20:29:41 --> Model Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Model Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Controller Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Model Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:29:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:29:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:29:41 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:29:41 --> Final output sent to browser
DEBUG - 2016-08-02 20:29:41 --> Total execution time: 0.3580
DEBUG - 2016-08-02 20:29:42 --> Config Class Initialized
DEBUG - 2016-08-02 20:29:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:29:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:29:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:29:42 --> URI Class Initialized
DEBUG - 2016-08-02 20:29:42 --> Router Class Initialized
ERROR - 2016-08-02 20:29:42 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:29:42 --> Config Class Initialized
DEBUG - 2016-08-02 20:29:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:29:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:29:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:29:42 --> URI Class Initialized
DEBUG - 2016-08-02 20:29:42 --> Router Class Initialized
ERROR - 2016-08-02 20:29:42 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:30:05 --> Config Class Initialized
DEBUG - 2016-08-02 20:30:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:30:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:30:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:30:05 --> URI Class Initialized
DEBUG - 2016-08-02 20:30:05 --> Router Class Initialized
DEBUG - 2016-08-02 20:30:05 --> Output Class Initialized
DEBUG - 2016-08-02 20:30:05 --> Security Class Initialized
DEBUG - 2016-08-02 20:30:05 --> Input Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:30:06 --> Language Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Loader Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:30:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Session Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:30:06 --> Session routines successfully run
DEBUG - 2016-08-02 20:30:06 --> Model Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Model Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Controller Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Model Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:30:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:30:06 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:30:06 --> Final output sent to browser
DEBUG - 2016-08-02 20:30:06 --> Total execution time: 0.3419
DEBUG - 2016-08-02 20:30:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:30:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:30:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Router Class Initialized
ERROR - 2016-08-02 20:30:06 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:30:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:30:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:30:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:30:06 --> Router Class Initialized
ERROR - 2016-08-02 20:30:06 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:30:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:30:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:30:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Router Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Output Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Security Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Input Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:30:36 --> Language Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Loader Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:30:36 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Session Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:30:36 --> Session routines successfully run
DEBUG - 2016-08-02 20:30:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Controller Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:30:36 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:30:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:30:36 --> Final output sent to browser
DEBUG - 2016-08-02 20:30:36 --> Total execution time: 0.3604
DEBUG - 2016-08-02 20:30:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:30:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:30:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:30:36 --> Router Class Initialized
ERROR - 2016-08-02 20:30:36 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:30:37 --> Config Class Initialized
DEBUG - 2016-08-02 20:30:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:30:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:30:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:30:37 --> URI Class Initialized
DEBUG - 2016-08-02 20:30:37 --> Router Class Initialized
ERROR - 2016-08-02 20:30:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:32:05 --> Config Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:32:05 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:32:05 --> URI Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Router Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Output Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Security Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Input Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:32:05 --> Language Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Loader Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:32:05 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Session Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:32:05 --> Session routines successfully run
DEBUG - 2016-08-02 20:32:05 --> Model Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Model Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Controller Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Model Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:32:05 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:32:05 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:32:05 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:32:05 --> Final output sent to browser
DEBUG - 2016-08-02 20:32:06 --> Total execution time: 0.3618
DEBUG - 2016-08-02 20:32:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:32:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:32:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:32:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:32:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:32:06 --> Router Class Initialized
ERROR - 2016-08-02 20:32:06 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:32:06 --> Config Class Initialized
DEBUG - 2016-08-02 20:32:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:32:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:32:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:32:06 --> URI Class Initialized
DEBUG - 2016-08-02 20:32:06 --> Router Class Initialized
ERROR - 2016-08-02 20:32:06 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:33:32 --> Config Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:33:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:33:32 --> URI Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Router Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Output Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Security Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Input Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:33:32 --> Language Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Loader Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:33:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Session Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:33:32 --> Session routines successfully run
DEBUG - 2016-08-02 20:33:32 --> Model Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Model Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Controller Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Model Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:33:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:33:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:33:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:33:32 --> Final output sent to browser
DEBUG - 2016-08-02 20:33:32 --> Total execution time: 0.3703
DEBUG - 2016-08-02 20:33:33 --> Config Class Initialized
DEBUG - 2016-08-02 20:33:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:33:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:33:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:33:33 --> URI Class Initialized
DEBUG - 2016-08-02 20:33:33 --> Router Class Initialized
ERROR - 2016-08-02 20:33:33 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:33:33 --> Config Class Initialized
DEBUG - 2016-08-02 20:33:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:33:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:33:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:33:33 --> URI Class Initialized
DEBUG - 2016-08-02 20:33:33 --> Router Class Initialized
ERROR - 2016-08-02 20:33:33 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:34:31 --> Config Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:34:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:34:31 --> URI Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Router Class Initialized
DEBUG - 2016-08-02 20:34:31 --> No URI present. Default controller set.
DEBUG - 2016-08-02 20:34:31 --> Output Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Security Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Input Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:34:31 --> Language Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Loader Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:34:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Session Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:34:31 --> Session routines successfully run
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Controller Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:31 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:34:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Config Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:34:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:34:32 --> URI Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Router Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Output Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Security Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Input Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:34:32 --> Language Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Loader Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:34:32 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Session Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:34:32 --> Session routines successfully run
DEBUG - 2016-08-02 20:34:32 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Controller Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:34:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:34:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:34:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:34:32 --> Final output sent to browser
DEBUG - 2016-08-02 20:34:32 --> Total execution time: 0.3358
DEBUG - 2016-08-02 20:34:51 --> Config Class Initialized
DEBUG - 2016-08-02 20:34:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:34:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:34:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:34:52 --> URI Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Router Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Output Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Security Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Input Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:34:52 --> Language Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Loader Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:34:52 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Session Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:34:52 --> Session routines successfully run
DEBUG - 2016-08-02 20:34:52 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Controller Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Model Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:34:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:34:52 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:34:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:34:52 --> Final output sent to browser
DEBUG - 2016-08-02 20:34:52 --> Total execution time: 0.3502
DEBUG - 2016-08-02 20:35:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:35:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:35:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Router Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Output Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Security Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Input Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:35:36 --> Language Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Loader Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:35:36 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Session Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:35:36 --> Session routines successfully run
DEBUG - 2016-08-02 20:35:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Controller Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:35:36 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:35:36 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:35:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:35:36 --> Final output sent to browser
DEBUG - 2016-08-02 20:35:37 --> Total execution time: 0.3623
DEBUG - 2016-08-02 20:38:09 --> Config Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:38:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:38:09 --> URI Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Router Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Output Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Security Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Input Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:38:09 --> Language Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Loader Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:38:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Session Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:38:09 --> Session routines successfully run
DEBUG - 2016-08-02 20:38:09 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Controller Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:38:09 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:38:09 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:38:09 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:38:09 --> Final output sent to browser
DEBUG - 2016-08-02 20:38:09 --> Total execution time: 0.3718
DEBUG - 2016-08-02 20:38:28 --> Config Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:38:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:38:28 --> URI Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Router Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Output Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Security Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Input Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:38:28 --> Language Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Loader Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:38:28 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Session Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:38:28 --> Session routines successfully run
DEBUG - 2016-08-02 20:38:28 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Controller Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:38:28 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:38:28 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:38:28 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:38:28 --> Final output sent to browser
DEBUG - 2016-08-02 20:38:28 --> Total execution time: 0.3591
DEBUG - 2016-08-02 20:38:44 --> Config Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:38:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:38:44 --> URI Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Router Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Output Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Security Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Input Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:38:44 --> Language Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Loader Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:38:44 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Session Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:38:44 --> Session routines successfully run
DEBUG - 2016-08-02 20:38:44 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Controller Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Model Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:38:44 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:38:44 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:38:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:38:44 --> Final output sent to browser
DEBUG - 2016-08-02 20:38:44 --> Total execution time: 0.3569
DEBUG - 2016-08-02 20:39:10 --> Config Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:39:10 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:39:10 --> URI Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Router Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Output Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Security Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Input Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:39:10 --> Language Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Loader Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:39:10 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Session Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:39:10 --> Session routines successfully run
DEBUG - 2016-08-02 20:39:10 --> Model Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Model Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Controller Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Model Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:39:10 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:39:10 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:39:10 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:39:10 --> Final output sent to browser
DEBUG - 2016-08-02 20:39:10 --> Total execution time: 0.3560
DEBUG - 2016-08-02 20:41:13 --> Config Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:41:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:41:13 --> URI Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Router Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Output Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Security Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Input Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:41:13 --> Language Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Loader Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:41:13 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Session Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:41:13 --> Session routines successfully run
DEBUG - 2016-08-02 20:41:13 --> Model Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Model Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Controller Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Model Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:41:13 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:41:13 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:41:13 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:41:13 --> Final output sent to browser
DEBUG - 2016-08-02 20:41:13 --> Total execution time: 0.3762
DEBUG - 2016-08-02 20:41:45 --> Config Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:41:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:41:45 --> URI Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Router Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Output Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Security Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Input Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:41:45 --> Language Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Loader Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:41:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Session Class Initialized
DEBUG - 2016-08-02 20:41:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:41:45 --> Session routines successfully run
DEBUG - 2016-08-02 20:41:45 --> Model Class Initialized
DEBUG - 2016-08-02 20:41:46 --> Model Class Initialized
DEBUG - 2016-08-02 20:41:46 --> Controller Class Initialized
DEBUG - 2016-08-02 20:41:46 --> Model Class Initialized
DEBUG - 2016-08-02 20:41:46 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:41:46 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:41:46 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:41:46 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:41:46 --> Final output sent to browser
DEBUG - 2016-08-02 20:41:46 --> Total execution time: 0.3681
DEBUG - 2016-08-02 20:42:22 --> Config Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:42:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:42:22 --> URI Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Router Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Output Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Security Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Input Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:42:22 --> Language Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Loader Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:42:22 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Session Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:42:22 --> Session routines successfully run
DEBUG - 2016-08-02 20:42:22 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Controller Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:42:22 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:42:22 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:42:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:42:22 --> Final output sent to browser
DEBUG - 2016-08-02 20:42:22 --> Total execution time: 0.3625
DEBUG - 2016-08-02 20:42:37 --> Config Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:42:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:42:37 --> URI Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Router Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Output Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Security Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Input Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:42:37 --> Language Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Loader Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:42:37 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Session Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:42:37 --> Session routines successfully run
DEBUG - 2016-08-02 20:42:37 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Controller Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:42:37 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:42:37 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:42:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:42:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:42:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:42:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:42:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:42:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:42:38 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:42:38 --> Final output sent to browser
DEBUG - 2016-08-02 20:42:38 --> Total execution time: 0.3644
DEBUG - 2016-08-02 20:42:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:42:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:42:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Router Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Output Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Security Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Input Class Initialized
DEBUG - 2016-08-02 20:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:42:56 --> Language Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Loader Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:42:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Session Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:42:56 --> Session routines successfully run
DEBUG - 2016-08-02 20:42:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Controller Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:42:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:42:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:42:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:42:56 --> Final output sent to browser
DEBUG - 2016-08-02 20:42:56 --> Total execution time: 0.3624
DEBUG - 2016-08-02 20:43:54 --> Config Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:43:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:43:54 --> URI Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Router Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Output Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Security Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Input Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:43:54 --> Language Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Loader Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:43:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Session Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:43:54 --> Session routines successfully run
DEBUG - 2016-08-02 20:43:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Controller Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:43:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:43:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:43:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:43:54 --> Final output sent to browser
DEBUG - 2016-08-02 20:43:54 --> Total execution time: 0.3928
DEBUG - 2016-08-02 20:44:08 --> Config Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:44:08 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:44:08 --> URI Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Router Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Output Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Security Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Input Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:44:08 --> Language Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Loader Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:44:08 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Session Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:44:08 --> Session routines successfully run
DEBUG - 2016-08-02 20:44:08 --> Model Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Model Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Controller Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Model Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:44:08 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:44:08 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:44:08 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:44:08 --> Final output sent to browser
DEBUG - 2016-08-02 20:44:08 --> Total execution time: 0.3715
DEBUG - 2016-08-02 20:44:57 --> Config Class Initialized
DEBUG - 2016-08-02 20:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:44:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:44:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:44:57 --> URI Class Initialized
DEBUG - 2016-08-02 20:44:57 --> Router Class Initialized
ERROR - 2016-08-02 20:44:57 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:44:57 --> Config Class Initialized
DEBUG - 2016-08-02 20:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:44:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:44:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:44:57 --> URI Class Initialized
DEBUG - 2016-08-02 20:44:57 --> Router Class Initialized
ERROR - 2016-08-02 20:44:57 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:44:59 --> Config Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:44:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:44:59 --> URI Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Router Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Output Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Security Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Input Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:44:59 --> Language Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Loader Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:44:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Session Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:44:59 --> Session routines successfully run
DEBUG - 2016-08-02 20:44:59 --> Model Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Model Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Controller Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Model Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:44:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:44:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:44:59 --> Final output sent to browser
DEBUG - 2016-08-02 20:44:59 --> Total execution time: 0.3682
DEBUG - 2016-08-02 20:44:59 --> Config Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:44:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:44:59 --> URI Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Router Class Initialized
ERROR - 2016-08-02 20:44:59 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:44:59 --> Config Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:44:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:44:59 --> URI Class Initialized
DEBUG - 2016-08-02 20:44:59 --> Router Class Initialized
ERROR - 2016-08-02 20:44:59 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:45:20 --> Config Class Initialized
DEBUG - 2016-08-02 20:45:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:45:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:45:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:45:20 --> URI Class Initialized
DEBUG - 2016-08-02 20:45:20 --> Router Class Initialized
ERROR - 2016-08-02 20:45:20 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:45:20 --> Config Class Initialized
DEBUG - 2016-08-02 20:45:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:45:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:45:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:45:20 --> URI Class Initialized
DEBUG - 2016-08-02 20:45:20 --> Router Class Initialized
ERROR - 2016-08-02 20:45:20 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:45:23 --> Config Class Initialized
DEBUG - 2016-08-02 20:45:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:45:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:45:24 --> URI Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Router Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Output Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Security Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Input Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:45:24 --> Language Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Loader Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:45:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Session Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:45:24 --> Session routines successfully run
DEBUG - 2016-08-02 20:45:24 --> Model Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Model Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Controller Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Model Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:45:24 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:45:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:45:24 --> Final output sent to browser
DEBUG - 2016-08-02 20:45:24 --> Total execution time: 0.3816
DEBUG - 2016-08-02 20:45:24 --> Config Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:45:24 --> URI Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Router Class Initialized
ERROR - 2016-08-02 20:45:24 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:45:24 --> Config Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:45:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:45:24 --> URI Class Initialized
DEBUG - 2016-08-02 20:45:24 --> Router Class Initialized
ERROR - 2016-08-02 20:45:24 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:47:14 --> Config Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:47:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:47:14 --> URI Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Router Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Output Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Security Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Input Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:47:14 --> Language Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Loader Class Initialized
DEBUG - 2016-08-02 20:47:14 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:47:15 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Session Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:47:15 --> Session routines successfully run
DEBUG - 2016-08-02 20:47:15 --> Model Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Model Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Controller Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Model Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:47:15 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:47:15 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:47:15 --> Final output sent to browser
DEBUG - 2016-08-02 20:47:15 --> Total execution time: 0.3786
DEBUG - 2016-08-02 20:47:15 --> Config Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:47:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:47:15 --> URI Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Router Class Initialized
ERROR - 2016-08-02 20:47:15 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:47:15 --> Config Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:47:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:47:15 --> URI Class Initialized
DEBUG - 2016-08-02 20:47:15 --> Router Class Initialized
ERROR - 2016-08-02 20:47:15 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:47:51 --> Config Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:47:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:47:51 --> URI Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Router Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Output Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Security Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Input Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:47:51 --> Language Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Loader Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:47:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Session Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:47:51 --> Session routines successfully run
DEBUG - 2016-08-02 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Controller Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Model Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:47:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:47:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:47:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:47:51 --> Final output sent to browser
DEBUG - 2016-08-02 20:47:51 --> Total execution time: 0.3632
DEBUG - 2016-08-02 20:47:52 --> Config Class Initialized
DEBUG - 2016-08-02 20:47:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:47:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:47:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:47:52 --> URI Class Initialized
DEBUG - 2016-08-02 20:47:52 --> Router Class Initialized
ERROR - 2016-08-02 20:47:52 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:47:52 --> Config Class Initialized
DEBUG - 2016-08-02 20:47:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:47:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:47:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:47:52 --> URI Class Initialized
DEBUG - 2016-08-02 20:47:52 --> Router Class Initialized
ERROR - 2016-08-02 20:47:52 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:49:53 --> Config Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:49:53 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:49:53 --> URI Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Router Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Output Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Security Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Input Class Initialized
DEBUG - 2016-08-02 20:49:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:49:53 --> Language Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Loader Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:49:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Session Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:49:54 --> Session routines successfully run
DEBUG - 2016-08-02 20:49:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Controller Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Model Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:49:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:49:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:49:54 --> Final output sent to browser
DEBUG - 2016-08-02 20:49:54 --> Total execution time: 0.3676
DEBUG - 2016-08-02 20:49:54 --> Config Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:49:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:49:54 --> URI Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Router Class Initialized
ERROR - 2016-08-02 20:49:54 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:49:54 --> Config Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:49:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:49:54 --> URI Class Initialized
DEBUG - 2016-08-02 20:49:54 --> Router Class Initialized
ERROR - 2016-08-02 20:49:54 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:50:17 --> Config Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:50:17 --> URI Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Router Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Output Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Security Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Input Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:50:17 --> Language Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Loader Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:50:17 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Session Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:50:17 --> Session routines successfully run
DEBUG - 2016-08-02 20:50:17 --> Model Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Model Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Controller Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Model Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:50:17 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:50:17 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:50:17 --> Final output sent to browser
DEBUG - 2016-08-02 20:50:17 --> Total execution time: 0.3644
DEBUG - 2016-08-02 20:50:17 --> Config Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:50:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:50:17 --> URI Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Router Class Initialized
ERROR - 2016-08-02 20:50:17 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:50:17 --> Config Class Initialized
DEBUG - 2016-08-02 20:50:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:50:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:50:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:50:18 --> URI Class Initialized
DEBUG - 2016-08-02 20:50:18 --> Router Class Initialized
ERROR - 2016-08-02 20:50:18 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:52:42 --> Config Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:52:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:52:42 --> URI Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Router Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Output Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Security Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Input Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:52:42 --> Language Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Loader Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:52:42 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Session Class Initialized
DEBUG - 2016-08-02 20:52:42 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:52:42 --> Session routines successfully run
DEBUG - 2016-08-02 20:52:43 --> Model Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Model Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Controller Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Model Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:52:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:52:43 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:52:43 --> Final output sent to browser
DEBUG - 2016-08-02 20:52:43 --> Total execution time: 0.3811
DEBUG - 2016-08-02 20:52:43 --> Config Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:52:43 --> URI Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Router Class Initialized
ERROR - 2016-08-02 20:52:43 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:52:43 --> Config Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:52:43 --> URI Class Initialized
DEBUG - 2016-08-02 20:52:43 --> Router Class Initialized
ERROR - 2016-08-02 20:52:43 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:52:58 --> Config Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:52:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:52:58 --> URI Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Router Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Output Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Security Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Input Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:52:58 --> Language Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Loader Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:52:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Session Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:52:58 --> Session routines successfully run
DEBUG - 2016-08-02 20:52:58 --> Model Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Model Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Controller Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Model Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:52:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:52:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:52:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:52:58 --> Final output sent to browser
DEBUG - 2016-08-02 20:52:58 --> Total execution time: 0.3778
DEBUG - 2016-08-02 20:52:59 --> Config Class Initialized
DEBUG - 2016-08-02 20:52:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:52:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:52:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:52:59 --> URI Class Initialized
DEBUG - 2016-08-02 20:52:59 --> Router Class Initialized
ERROR - 2016-08-02 20:52:59 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:52:59 --> Config Class Initialized
DEBUG - 2016-08-02 20:52:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:52:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:52:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:52:59 --> URI Class Initialized
DEBUG - 2016-08-02 20:52:59 --> Router Class Initialized
ERROR - 2016-08-02 20:52:59 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:53:56 --> Config Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:53:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:53:56 --> URI Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Router Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Output Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Security Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Input Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:53:56 --> Language Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Loader Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:53:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Session Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:53:56 --> Session routines successfully run
DEBUG - 2016-08-02 20:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Controller Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:53:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:53:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:53:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:53:56 --> Final output sent to browser
DEBUG - 2016-08-02 20:53:56 --> Total execution time: 0.3654
DEBUG - 2016-08-02 20:53:58 --> Config Class Initialized
DEBUG - 2016-08-02 20:53:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:53:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:53:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:53:59 --> URI Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Router Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Output Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Security Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Input Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:53:59 --> Language Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Loader Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:53:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Session Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:53:59 --> Session routines successfully run
DEBUG - 2016-08-02 20:53:59 --> Model Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Model Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Controller Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Model Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:53:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:53:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:53:59 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:53:59 --> Final output sent to browser
DEBUG - 2016-08-02 20:53:59 --> Total execution time: 0.3931
DEBUG - 2016-08-02 20:55:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:55:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:55:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Router Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Output Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Security Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Input Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:55:55 --> Language Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Loader Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:55:55 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Session Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:55:55 --> Session routines successfully run
DEBUG - 2016-08-02 20:55:55 --> Model Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Model Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Controller Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Model Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:55:55 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:55:55 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:55:55 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:55:55 --> Final output sent to browser
DEBUG - 2016-08-02 20:55:55 --> Total execution time: 0.3815
DEBUG - 2016-08-02 20:56:12 --> Config Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:56:12 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:56:12 --> URI Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Router Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Output Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Security Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Input Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:56:12 --> Language Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Loader Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:56:12 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Session Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:56:12 --> Session routines successfully run
DEBUG - 2016-08-02 20:56:12 --> Model Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Model Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Controller Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Model Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:56:12 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:56:12 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:56:12 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:56:12 --> Final output sent to browser
DEBUG - 2016-08-02 20:56:12 --> Total execution time: 0.3729
DEBUG - 2016-08-02 20:56:13 --> Config Class Initialized
DEBUG - 2016-08-02 20:56:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:56:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:56:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:56:13 --> URI Class Initialized
DEBUG - 2016-08-02 20:56:13 --> Router Class Initialized
ERROR - 2016-08-02 20:56:13 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:56:13 --> Config Class Initialized
DEBUG - 2016-08-02 20:56:13 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:56:13 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:56:13 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:56:13 --> URI Class Initialized
DEBUG - 2016-08-02 20:56:13 --> Router Class Initialized
ERROR - 2016-08-02 20:56:13 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:57:41 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:41 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:41 --> Router Class Initialized
ERROR - 2016-08-02 20:57:41 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:57:41 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:41 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:41 --> Router Class Initialized
ERROR - 2016-08-02 20:57:41 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:57:43 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:43 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Router Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Output Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Security Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Input Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:57:43 --> Language Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Loader Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:57:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Session Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:57:43 --> Session routines successfully run
DEBUG - 2016-08-02 20:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Controller Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Model Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:57:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:57:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:57:43 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:57:43 --> Final output sent to browser
DEBUG - 2016-08-02 20:57:43 --> Total execution time: 0.3863
DEBUG - 2016-08-02 20:57:44 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:44 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:44 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:44 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:44 --> Router Class Initialized
ERROR - 2016-08-02 20:57:44 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:57:44 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:44 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:44 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:44 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:44 --> Router Class Initialized
ERROR - 2016-08-02 20:57:44 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:57:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:55 --> Router Class Initialized
ERROR - 2016-08-02 20:57:55 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:57:55 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:55 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:55 --> Router Class Initialized
ERROR - 2016-08-02 20:57:55 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:57:56 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:56 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Router Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Output Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Security Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Input Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:57:56 --> Language Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Loader Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:57:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Session Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:57:56 --> Session routines successfully run
DEBUG - 2016-08-02 20:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Controller Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Model Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:57:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:57:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:57:57 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:57:57 --> Final output sent to browser
DEBUG - 2016-08-02 20:57:57 --> Total execution time: 0.3813
DEBUG - 2016-08-02 20:57:57 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:57 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:57 --> Router Class Initialized
ERROR - 2016-08-02 20:57:57 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:57:57 --> Config Class Initialized
DEBUG - 2016-08-02 20:57:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:57:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:57:57 --> URI Class Initialized
DEBUG - 2016-08-02 20:57:57 --> Router Class Initialized
ERROR - 2016-08-02 20:57:57 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:58:42 --> Config Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:58:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:58:42 --> URI Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Router Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Output Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Security Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Input Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:58:42 --> Language Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Loader Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:58:42 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Session Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:58:42 --> Session routines successfully run
DEBUG - 2016-08-02 20:58:42 --> Model Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Model Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Controller Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Model Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:58:42 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:58:42 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:58:42 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:58:42 --> Final output sent to browser
DEBUG - 2016-08-02 20:58:42 --> Total execution time: 0.3950
DEBUG - 2016-08-02 20:58:43 --> Config Class Initialized
DEBUG - 2016-08-02 20:58:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:58:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:58:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:58:43 --> URI Class Initialized
DEBUG - 2016-08-02 20:58:43 --> Router Class Initialized
ERROR - 2016-08-02 20:58:43 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:58:43 --> Config Class Initialized
DEBUG - 2016-08-02 20:58:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:58:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:58:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:58:43 --> URI Class Initialized
DEBUG - 2016-08-02 20:58:43 --> Router Class Initialized
ERROR - 2016-08-02 20:58:43 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:59:34 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:34 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:34 --> Router Class Initialized
ERROR - 2016-08-02 20:59:34 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:59:34 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:34 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:34 --> Router Class Initialized
ERROR - 2016-08-02 20:59:34 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:59:35 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Router Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Output Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Security Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Input Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:59:36 --> Language Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Loader Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:59:36 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Session Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:59:36 --> Session routines successfully run
DEBUG - 2016-08-02 20:59:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Controller Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Model Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:59:36 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:59:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:59:36 --> Final output sent to browser
DEBUG - 2016-08-02 20:59:36 --> Total execution time: 0.3896
DEBUG - 2016-08-02 20:59:36 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:36 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:36 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:36 --> Router Class Initialized
ERROR - 2016-08-02 20:59:36 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:59:37 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:37 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:37 --> Router Class Initialized
ERROR - 2016-08-02 20:59:37 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 20:59:44 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:44 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:44 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Router Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Output Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Security Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Input Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 20:59:44 --> Language Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Loader Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Helper loaded: url_helper
DEBUG - 2016-08-02 20:59:44 --> Database Driver Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Session Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Helper loaded: string_helper
DEBUG - 2016-08-02 20:59:44 --> Session routines successfully run
DEBUG - 2016-08-02 20:59:44 --> Model Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Model Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Controller Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Model Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Helper loaded: form_helper
DEBUG - 2016-08-02 20:59:44 --> Form Validation Class Initialized
DEBUG - 2016-08-02 20:59:44 --> Pagination Class Initialized
DEBUG - 2016-08-02 20:59:44 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 20:59:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 20:59:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 20:59:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 20:59:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 20:59:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 20:59:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 20:59:45 --> Final output sent to browser
DEBUG - 2016-08-02 20:59:45 --> Total execution time: 0.3721
DEBUG - 2016-08-02 20:59:45 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:45 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:45 --> Router Class Initialized
ERROR - 2016-08-02 20:59:45 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 20:59:45 --> Config Class Initialized
DEBUG - 2016-08-02 20:59:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 20:59:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 20:59:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 20:59:45 --> URI Class Initialized
DEBUG - 2016-08-02 20:59:45 --> Router Class Initialized
ERROR - 2016-08-02 20:59:45 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:00:18 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:18 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Router Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Output Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Security Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Input Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:00:18 --> Language Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Loader Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:00:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Session Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:00:18 --> Session routines successfully run
DEBUG - 2016-08-02 21:00:18 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Controller Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:00:18 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:00:18 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:00:18 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:00:18 --> Final output sent to browser
DEBUG - 2016-08-02 21:00:18 --> Total execution time: 0.3944
DEBUG - 2016-08-02 21:00:19 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:19 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:19 --> Router Class Initialized
ERROR - 2016-08-02 21:00:19 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:00:19 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:19 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:19 --> Router Class Initialized
ERROR - 2016-08-02 21:00:19 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:00:24 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:24 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:24 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Router Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Output Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Security Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Input Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:00:24 --> Language Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Loader Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:00:24 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Session Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:00:24 --> Session routines successfully run
DEBUG - 2016-08-02 21:00:24 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:24 --> Controller Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:00:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:00:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:00:25 --> Final output sent to browser
DEBUG - 2016-08-02 21:00:25 --> Total execution time: 0.3912
DEBUG - 2016-08-02 21:00:25 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:25 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Router Class Initialized
ERROR - 2016-08-02 21:00:25 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:00:25 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:25 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:25 --> Router Class Initialized
ERROR - 2016-08-02 21:00:25 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:00:38 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:38 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Router Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Output Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Security Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Input Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:00:38 --> Language Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Loader Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:00:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Session Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:00:38 --> Session routines successfully run
DEBUG - 2016-08-02 21:00:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Controller Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:00:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:00:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:00:38 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:00:38 --> Final output sent to browser
DEBUG - 2016-08-02 21:00:38 --> Total execution time: 0.3851
DEBUG - 2016-08-02 21:00:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:39 --> Router Class Initialized
ERROR - 2016-08-02 21:00:39 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:00:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:00:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:00:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:00:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:00:39 --> Router Class Initialized
ERROR - 2016-08-02 21:00:39 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:01:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:01:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:01:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:01:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:01:39 --> Router Class Initialized
ERROR - 2016-08-02 21:01:39 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:01:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:01:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:01:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:01:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:01:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:01:39 --> Router Class Initialized
ERROR - 2016-08-02 21:01:39 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:01:41 --> Config Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:01:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:01:41 --> URI Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Router Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Output Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Security Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Input Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:01:41 --> Language Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Loader Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:01:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Session Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:01:41 --> Session routines successfully run
DEBUG - 2016-08-02 21:01:41 --> Model Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Model Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Controller Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Model Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:01:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:01:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:01:41 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:01:41 --> Final output sent to browser
DEBUG - 2016-08-02 21:01:41 --> Total execution time: 0.3986
DEBUG - 2016-08-02 21:01:42 --> Config Class Initialized
DEBUG - 2016-08-02 21:01:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:01:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:01:42 --> URI Class Initialized
DEBUG - 2016-08-02 21:01:42 --> Router Class Initialized
ERROR - 2016-08-02 21:01:42 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:01:42 --> Config Class Initialized
DEBUG - 2016-08-02 21:01:42 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:01:42 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:01:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:01:42 --> URI Class Initialized
DEBUG - 2016-08-02 21:01:42 --> Router Class Initialized
ERROR - 2016-08-02 21:01:42 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:03:14 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:14 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:14 --> Router Class Initialized
ERROR - 2016-08-02 21:03:14 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:03:15 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:15 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:15 --> Router Class Initialized
ERROR - 2016-08-02 21:03:15 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:03:16 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:16 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Router Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Output Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Security Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Input Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:03:16 --> Language Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Loader Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:03:16 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Session Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:03:16 --> Session routines successfully run
DEBUG - 2016-08-02 21:03:16 --> Model Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Model Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Controller Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Model Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:03:16 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:03:16 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:03:16 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:03:16 --> Final output sent to browser
DEBUG - 2016-08-02 21:03:16 --> Total execution time: 0.4320
DEBUG - 2016-08-02 21:03:17 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:17 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:17 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:17 --> Router Class Initialized
ERROR - 2016-08-02 21:03:17 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:03:17 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:17 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:17 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:17 --> Router Class Initialized
ERROR - 2016-08-02 21:03:17 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:03:31 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:31 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Router Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Output Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Security Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Input Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:03:31 --> Language Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Loader Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:03:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Session Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:03:31 --> Session routines successfully run
DEBUG - 2016-08-02 21:03:31 --> Model Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Model Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Controller Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Model Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:03:31 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:03:31 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:03:31 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:03:31 --> Final output sent to browser
DEBUG - 2016-08-02 21:03:31 --> Total execution time: 0.3939
DEBUG - 2016-08-02 21:03:32 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:32 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:32 --> Router Class Initialized
ERROR - 2016-08-02 21:03:32 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:03:33 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:33 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:33 --> Router Class Initialized
ERROR - 2016-08-02 21:03:33 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:03:38 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:38 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:38 --> Router Class Initialized
ERROR - 2016-08-02 21:03:38 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:03:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:03:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:03:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:03:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:03:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:03:39 --> Router Class Initialized
ERROR - 2016-08-02 21:03:39 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:04:15 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:15 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Router Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Output Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Security Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Input Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:04:15 --> Language Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Loader Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:04:15 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Session Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:04:15 --> Session routines successfully run
DEBUG - 2016-08-02 21:04:15 --> Model Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Model Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Controller Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Model Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:04:15 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:04:15 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:04:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:04:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:04:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:04:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:04:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:04:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:04:16 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:04:16 --> Final output sent to browser
DEBUG - 2016-08-02 21:04:16 --> Total execution time: 0.3930
DEBUG - 2016-08-02 21:04:16 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:16 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:16 --> Router Class Initialized
ERROR - 2016-08-02 21:04:16 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:04:16 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:16 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:16 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:16 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:16 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:16 --> Router Class Initialized
ERROR - 2016-08-02 21:04:16 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:04:34 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:34 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:34 --> Router Class Initialized
ERROR - 2016-08-02 21:04:34 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:04:35 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:35 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:35 --> Router Class Initialized
ERROR - 2016-08-02 21:04:35 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:04:37 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:38 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Router Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Output Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Security Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Input Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:04:38 --> Language Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Loader Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:04:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Session Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:04:38 --> Session routines successfully run
DEBUG - 2016-08-02 21:04:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Controller Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:04:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:04:38 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:04:38 --> Final output sent to browser
DEBUG - 2016-08-02 21:04:38 --> Total execution time: 0.4081
DEBUG - 2016-08-02 21:04:38 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:38 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Router Class Initialized
ERROR - 2016-08-02 21:04:38 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:04:38 --> Config Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:04:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:04:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:04:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:04:39 --> Router Class Initialized
ERROR - 2016-08-02 21:04:39 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:05:18 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:18 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:18 --> Router Class Initialized
ERROR - 2016-08-02 21:05:18 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:05:18 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:18 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:18 --> Router Class Initialized
ERROR - 2016-08-02 21:05:18 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:05:21 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:21 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Router Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Output Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Security Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Input Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:05:21 --> Language Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Loader Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:05:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Session Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:05:21 --> Session routines successfully run
DEBUG - 2016-08-02 21:05:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Controller Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:05:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:05:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:05:21 --> Final output sent to browser
DEBUG - 2016-08-02 21:05:21 --> Total execution time: 0.4002
DEBUG - 2016-08-02 21:05:21 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:21 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:21 --> Router Class Initialized
ERROR - 2016-08-02 21:05:21 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:05:22 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:22 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:22 --> Router Class Initialized
ERROR - 2016-08-02 21:05:22 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:05:35 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:35 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:35 --> Router Class Initialized
ERROR - 2016-08-02 21:05:35 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:05:35 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:35 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:35 --> Router Class Initialized
ERROR - 2016-08-02 21:05:35 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:05:38 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:38 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:38 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Router Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Output Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Security Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Input Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:05:38 --> Language Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Loader Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:05:38 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Session Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:05:38 --> Session routines successfully run
DEBUG - 2016-08-02 21:05:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Controller Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Model Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:05:38 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:05:38 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:05:38 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:05:38 --> Final output sent to browser
DEBUG - 2016-08-02 21:05:38 --> Total execution time: 0.3891
DEBUG - 2016-08-02 21:05:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:39 --> Router Class Initialized
ERROR - 2016-08-02 21:05:39 --> 404 Page Not Found --> js
DEBUG - 2016-08-02 21:05:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:05:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:05:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:05:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:05:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:05:40 --> Router Class Initialized
ERROR - 2016-08-02 21:05:40 --> 404 Page Not Found --> angularjs
DEBUG - 2016-08-02 21:07:15 --> Config Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:07:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:07:15 --> URI Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Router Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Output Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Security Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Input Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:07:15 --> Language Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Loader Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:07:15 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Session Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:07:15 --> Session routines successfully run
DEBUG - 2016-08-02 21:07:15 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Controller Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:07:15 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:07:15 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:07:15 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:07:15 --> Final output sent to browser
DEBUG - 2016-08-02 21:07:15 --> Total execution time: 0.4073
DEBUG - 2016-08-02 21:07:35 --> Config Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:07:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:07:35 --> URI Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Router Class Initialized
DEBUG - 2016-08-02 21:07:35 --> No URI present. Default controller set.
DEBUG - 2016-08-02 21:07:35 --> Output Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Security Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Input Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:07:35 --> Language Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Loader Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:07:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Session Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:07:35 --> Session routines successfully run
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Controller Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:07:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Config Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:07:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:07:35 --> URI Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Router Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Output Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Security Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Input Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:07:35 --> Language Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Loader Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:07:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Session Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:07:35 --> Session routines successfully run
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Controller Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:07:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:07:35 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:07:35 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:07:35 --> Final output sent to browser
DEBUG - 2016-08-02 21:07:35 --> Total execution time: 0.3747
DEBUG - 2016-08-02 21:07:37 --> Config Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:07:37 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:07:37 --> URI Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Router Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Output Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Security Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Input Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:07:37 --> Language Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Loader Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:07:37 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Session Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:07:37 --> Session routines successfully run
DEBUG - 2016-08-02 21:07:37 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Controller Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:07:37 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:07:37 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:07:37 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:07:37 --> Final output sent to browser
DEBUG - 2016-08-02 21:07:37 --> Total execution time: 0.3927
DEBUG - 2016-08-02 21:07:58 --> Config Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:07:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:07:58 --> URI Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Router Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Output Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Security Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Input Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:07:58 --> Language Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Loader Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:07:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Session Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:07:58 --> Session routines successfully run
DEBUG - 2016-08-02 21:07:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Controller Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:07:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:07:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:07:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:07:58 --> Final output sent to browser
DEBUG - 2016-08-02 21:07:58 --> Total execution time: 0.4156
DEBUG - 2016-08-02 21:08:17 --> Config Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:08:17 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:08:17 --> URI Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Router Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Output Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Security Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Input Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:08:17 --> Language Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Loader Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:08:17 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Session Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:08:17 --> Session routines successfully run
DEBUG - 2016-08-02 21:08:17 --> Model Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Model Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Controller Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Model Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:08:17 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:08:17 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:08:17 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:08:17 --> Final output sent to browser
DEBUG - 2016-08-02 21:08:17 --> Total execution time: 0.3931
DEBUG - 2016-08-02 21:09:34 --> Config Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:09:34 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:09:34 --> URI Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Router Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Output Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Security Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Input Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:09:34 --> Language Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Loader Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:09:34 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Session Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:09:34 --> Session routines successfully run
DEBUG - 2016-08-02 21:09:34 --> Model Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Model Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Controller Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Model Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:09:34 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:09:34 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:09:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:09:34 --> Final output sent to browser
DEBUG - 2016-08-02 21:09:34 --> Total execution time: 0.4035
DEBUG - 2016-08-02 21:11:06 --> Config Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:11:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:11:06 --> URI Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Router Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Output Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Security Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Input Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:11:06 --> Language Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Loader Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:11:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Session Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:11:06 --> Session routines successfully run
DEBUG - 2016-08-02 21:11:06 --> Model Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Model Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Controller Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Model Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:11:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:11:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:11:06 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:11:06 --> Final output sent to browser
DEBUG - 2016-08-02 21:11:06 --> Total execution time: 0.4072
DEBUG - 2016-08-02 21:11:49 --> Config Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:11:49 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:11:49 --> URI Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Router Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Output Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Security Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Input Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:11:49 --> Language Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Loader Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:11:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Session Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:11:49 --> Session routines successfully run
DEBUG - 2016-08-02 21:11:49 --> Model Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Model Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Controller Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Model Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:11:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:11:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:11:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:11:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:11:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:11:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:11:50 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:11:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:11:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:11:50 --> Final output sent to browser
DEBUG - 2016-08-02 21:11:50 --> Total execution time: 0.4102
DEBUG - 2016-08-02 21:12:43 --> Config Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:12:43 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:12:43 --> URI Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Router Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Output Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Security Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Input Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:12:43 --> Language Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Loader Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:12:43 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Session Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:12:43 --> Session routines successfully run
DEBUG - 2016-08-02 21:12:43 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Controller Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:12:43 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:12:43 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:12:43 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:12:43 --> Final output sent to browser
DEBUG - 2016-08-02 21:12:43 --> Total execution time: 0.4049
DEBUG - 2016-08-02 21:12:54 --> Config Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:12:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:12:54 --> URI Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Router Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Output Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Security Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Input Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:12:54 --> Language Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Loader Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:12:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Session Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:12:54 --> Session routines successfully run
DEBUG - 2016-08-02 21:12:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:55 --> Controller Class Initialized
DEBUG - 2016-08-02 21:12:55 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:55 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:12:55 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:12:55 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:12:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:12:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:12:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:12:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:12:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:12:55 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 21:12:55 --> Final output sent to browser
DEBUG - 2016-08-02 21:12:55 --> Total execution time: 0.5664
DEBUG - 2016-08-02 21:12:58 --> Config Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:12:58 --> URI Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Router Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Output Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Security Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Input Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:12:58 --> Language Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Loader Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:12:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Session Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:12:58 --> Session routines successfully run
DEBUG - 2016-08-02 21:12:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Controller Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:12:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:12:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:12:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:12:58 --> Final output sent to browser
DEBUG - 2016-08-02 21:12:58 --> Total execution time: 0.4501
DEBUG - 2016-08-02 21:13:25 --> Config Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:13:25 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:13:25 --> URI Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Router Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Output Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Security Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Input Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:13:25 --> Language Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Loader Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:13:25 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Session Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:13:25 --> Session routines successfully run
DEBUG - 2016-08-02 21:13:25 --> Model Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Model Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Controller Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Model Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:13:25 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:13:25 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:13:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:13:25 --> Final output sent to browser
DEBUG - 2016-08-02 21:13:25 --> Total execution time: 0.4161
DEBUG - 2016-08-02 21:15:00 --> Config Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:15:00 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:15:00 --> URI Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Router Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Output Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Security Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Input Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:15:00 --> Language Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Loader Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:15:00 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Session Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:15:00 --> Session routines successfully run
DEBUG - 2016-08-02 21:15:00 --> Model Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Model Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Controller Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Model Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:15:00 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:15:00 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:15:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:15:00 --> Final output sent to browser
DEBUG - 2016-08-02 21:15:00 --> Total execution time: 0.4216
DEBUG - 2016-08-02 21:16:14 --> Config Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:16:14 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:16:14 --> URI Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Router Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Output Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Security Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Input Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:16:14 --> Language Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Loader Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:16:14 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Session Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:16:14 --> Session routines successfully run
DEBUG - 2016-08-02 21:16:14 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Controller Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:16:14 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:16:14 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:16:14 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:16:15 --> Final output sent to browser
DEBUG - 2016-08-02 21:16:15 --> Total execution time: 0.4115
DEBUG - 2016-08-02 21:16:21 --> Config Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:16:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:16:21 --> URI Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Router Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Output Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Security Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Input Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:16:21 --> Language Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Loader Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:16:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Session Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:16:21 --> Session routines successfully run
DEBUG - 2016-08-02 21:16:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Controller Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:16:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:16:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:16:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:16:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:16:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:16:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:16:22 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:16:22 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:16:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:16:22 --> Final output sent to browser
DEBUG - 2016-08-02 21:16:22 --> Total execution time: 0.3928
DEBUG - 2016-08-02 21:16:23 --> Config Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:16:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:16:23 --> URI Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Router Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Output Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Security Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Input Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:16:23 --> Language Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Loader Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:16:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Session Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:16:23 --> Session routines successfully run
DEBUG - 2016-08-02 21:16:23 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Controller Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Model Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:16:23 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:16:23 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:16:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:16:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:16:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:16:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:16:23 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:16:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:16:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:16:24 --> Final output sent to browser
DEBUG - 2016-08-02 21:16:24 --> Total execution time: 0.3968
DEBUG - 2016-08-02 21:17:50 --> Config Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:17:50 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:17:50 --> URI Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Router Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Output Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Security Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Input Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:17:50 --> Language Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Loader Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:17:50 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Session Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:17:50 --> Session routines successfully run
DEBUG - 2016-08-02 21:17:50 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Controller Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:17:50 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:17:50 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:17:50 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:17:50 --> Final output sent to browser
DEBUG - 2016-08-02 21:17:50 --> Total execution time: 0.4254
DEBUG - 2016-08-02 21:17:56 --> Config Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:17:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:17:56 --> URI Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Router Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Output Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Security Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Input Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:17:56 --> Language Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Loader Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:17:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Session Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:17:56 --> Session routines successfully run
DEBUG - 2016-08-02 21:17:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Controller Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:17:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:17:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:17:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:17:56 --> Final output sent to browser
DEBUG - 2016-08-02 21:17:56 --> Total execution time: 0.3956
DEBUG - 2016-08-02 21:17:58 --> Config Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:17:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:17:58 --> URI Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Router Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Output Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Security Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Input Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:17:58 --> Language Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Loader Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:17:58 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Session Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:17:58 --> Session routines successfully run
DEBUG - 2016-08-02 21:17:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Controller Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Model Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:17:58 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:17:58 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:17:58 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:17:58 --> Final output sent to browser
DEBUG - 2016-08-02 21:17:58 --> Total execution time: 0.3989
DEBUG - 2016-08-02 21:19:29 --> Config Class Initialized
DEBUG - 2016-08-02 21:19:29 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:19:29 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:19:29 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:19:29 --> URI Class Initialized
DEBUG - 2016-08-02 21:19:29 --> Router Class Initialized
DEBUG - 2016-08-02 21:19:29 --> Output Class Initialized
DEBUG - 2016-08-02 21:19:29 --> Security Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Input Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:19:30 --> Language Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Loader Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:19:30 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Session Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:19:30 --> Session routines successfully run
DEBUG - 2016-08-02 21:19:30 --> Model Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Model Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Controller Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Model Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:19:30 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:19:30 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:19:30 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:19:30 --> Final output sent to browser
DEBUG - 2016-08-02 21:19:30 --> Total execution time: 0.4174
DEBUG - 2016-08-02 21:19:31 --> Config Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:19:31 --> URI Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Router Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Output Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Security Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Input Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:19:31 --> Language Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Loader Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:19:31 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Session Class Initialized
DEBUG - 2016-08-02 21:19:31 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:19:31 --> Session routines successfully run
DEBUG - 2016-08-02 21:19:32 --> Model Class Initialized
DEBUG - 2016-08-02 21:19:32 --> Model Class Initialized
DEBUG - 2016-08-02 21:19:32 --> Controller Class Initialized
DEBUG - 2016-08-02 21:19:32 --> Model Class Initialized
DEBUG - 2016-08-02 21:19:32 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:19:32 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:19:32 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:19:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:19:32 --> Final output sent to browser
DEBUG - 2016-08-02 21:19:32 --> Total execution time: 0.4002
DEBUG - 2016-08-02 21:21:19 --> Config Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:21:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:21:19 --> URI Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Router Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Output Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Security Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Input Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:21:19 --> Language Class Initialized
DEBUG - 2016-08-02 21:21:19 --> Loader Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:21:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Session Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:21:20 --> Session routines successfully run
DEBUG - 2016-08-02 21:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Controller Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:21:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:21:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:21:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:21:20 --> Final output sent to browser
DEBUG - 2016-08-02 21:21:20 --> Total execution time: 0.4016
DEBUG - 2016-08-02 21:21:21 --> Config Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:21:21 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:21:21 --> URI Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Router Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Output Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Security Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Input Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:21:21 --> Language Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Loader Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:21:21 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Session Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:21:21 --> Session routines successfully run
DEBUG - 2016-08-02 21:21:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Controller Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:21:21 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:21:21 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:21:21 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:21:21 --> Final output sent to browser
DEBUG - 2016-08-02 21:21:21 --> Total execution time: 0.4337
DEBUG - 2016-08-02 21:21:54 --> Config Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:21:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:21:54 --> URI Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Router Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Output Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Security Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Input Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:21:54 --> Language Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Loader Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:21:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Session Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:21:54 --> Session routines successfully run
DEBUG - 2016-08-02 21:21:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Controller Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:21:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:21:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:21:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:21:54 --> Final output sent to browser
DEBUG - 2016-08-02 21:21:54 --> Total execution time: 0.4135
DEBUG - 2016-08-02 21:21:56 --> Config Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:21:56 --> URI Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Router Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Output Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Security Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Input Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:21:56 --> Language Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Loader Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:21:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Session Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:21:56 --> Session routines successfully run
DEBUG - 2016-08-02 21:21:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Controller Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:21:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:21:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:21:56 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:21:56 --> Final output sent to browser
DEBUG - 2016-08-02 21:21:56 --> Total execution time: 0.4147
DEBUG - 2016-08-02 21:22:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:22:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:22:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Router Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Output Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Security Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Input Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:22:39 --> Language Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Loader Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:22:39 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Session Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:22:39 --> Session routines successfully run
DEBUG - 2016-08-02 21:22:39 --> Model Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Model Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Controller Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Model Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:22:39 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:22:39 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:22:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:22:39 --> Final output sent to browser
DEBUG - 2016-08-02 21:22:39 --> Total execution time: 0.4249
DEBUG - 2016-08-02 21:23:34 --> Config Class Initialized
DEBUG - 2016-08-02 21:23:34 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:23:35 --> URI Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Router Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Output Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Security Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Input Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:23:35 --> Language Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Loader Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:23:35 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Session Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:23:35 --> Session routines successfully run
DEBUG - 2016-08-02 21:23:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Controller Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Model Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:23:35 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:23:35 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:23:35 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:23:35 --> Final output sent to browser
DEBUG - 2016-08-02 21:23:35 --> Total execution time: 0.4240
DEBUG - 2016-08-02 21:23:57 --> Config Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:23:57 --> URI Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Router Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Output Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Security Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Input Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:23:57 --> Language Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Loader Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:23:57 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Session Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:23:57 --> Session routines successfully run
DEBUG - 2016-08-02 21:23:57 --> Model Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Model Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Controller Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Model Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:23:57 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:23:57 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:23:57 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:23:57 --> Final output sent to browser
DEBUG - 2016-08-02 21:23:57 --> Total execution time: 0.4355
DEBUG - 2016-08-02 21:35:51 --> Config Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:35:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:35:51 --> URI Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Router Class Initialized
DEBUG - 2016-08-02 21:35:51 --> No URI present. Default controller set.
DEBUG - 2016-08-02 21:35:51 --> Output Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Security Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Input Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:35:51 --> Language Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Loader Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:35:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Session Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:35:51 --> Session routines successfully run
DEBUG - 2016-08-02 21:35:51 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Controller Class Initialized
DEBUG - 2016-08-02 21:35:51 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:35:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Config Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:35:52 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:35:52 --> URI Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Router Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Output Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Security Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Input Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:35:52 --> Language Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Loader Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:35:52 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Session Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:35:52 --> Session routines successfully run
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Controller Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Model Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:35:52 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:35:52 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:35:52 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:35:52 --> Final output sent to browser
DEBUG - 2016-08-02 21:35:52 --> Total execution time: 0.4107
DEBUG - 2016-08-02 21:36:55 --> Config Class Initialized
DEBUG - 2016-08-02 21:36:55 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:36:55 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:36:55 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:36:55 --> URI Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Router Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Output Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Security Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Input Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:36:56 --> Language Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Loader Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:36:56 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Session Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:36:56 --> Session routines successfully run
DEBUG - 2016-08-02 21:36:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Controller Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:36:56 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:36:56 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:36:56 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:36:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:36:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:36:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:36:56 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:36:56 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 21:36:56 --> Final output sent to browser
DEBUG - 2016-08-02 21:36:56 --> Total execution time: 0.4249
DEBUG - 2016-08-02 21:36:58 --> Config Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:36:58 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:36:58 --> URI Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Router Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Output Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Security Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Input Class Initialized
DEBUG - 2016-08-02 21:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:36:59 --> Language Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Loader Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:36:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Session Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:36:59 --> Session routines successfully run
DEBUG - 2016-08-02 21:36:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Controller Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:36:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:36:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:36:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:36:59 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:36:59 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:36:59 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:36:59 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:36:59 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2016-08-02 21:36:59 --> Final output sent to browser
DEBUG - 2016-08-02 21:36:59 --> Total execution time: 0.4920
DEBUG - 2016-08-02 21:37:23 --> Config Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:37:23 --> URI Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Router Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Output Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Security Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Input Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:37:23 --> Language Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Loader Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:37:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:37:23 --> Session Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:37:24 --> Session routines successfully run
DEBUG - 2016-08-02 21:37:24 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Controller Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:37:24 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:37:24 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:37:24 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:37:24 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:37:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:37:24 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:37:24 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:37:24 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2016-08-02 21:37:24 --> Final output sent to browser
DEBUG - 2016-08-02 21:37:24 --> Total execution time: 0.5623
DEBUG - 2016-08-02 21:37:27 --> Config Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:37:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:37:27 --> URI Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Router Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Output Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Security Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Input Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:37:27 --> Language Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Loader Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:37:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Session Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:37:27 --> Session routines successfully run
DEBUG - 2016-08-02 21:37:27 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:27 --> Controller Class Initialized
DEBUG - 2016-08-02 21:37:28 --> Model Class Initialized
DEBUG - 2016-08-02 21:37:28 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:37:28 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:37:28 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:37:28 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:37:28 --> Final output sent to browser
DEBUG - 2016-08-02 21:37:28 --> Total execution time: 0.4520
DEBUG - 2016-08-02 21:38:48 --> Config Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:38:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:38:48 --> URI Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Router Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Output Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Security Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Input Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:38:48 --> Language Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Loader Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:38:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Session Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:38:48 --> Session routines successfully run
DEBUG - 2016-08-02 21:38:48 --> Model Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Model Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Controller Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Model Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:38:48 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:38:48 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:38:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:38:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:38:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:38:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:38:48 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:38:48 --> File loaded: application/views/director/directorListView.php
DEBUG - 2016-08-02 21:38:48 --> Final output sent to browser
DEBUG - 2016-08-02 21:38:48 --> Total execution time: 0.4237
DEBUG - 2016-08-02 21:38:51 --> Config Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:38:51 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:38:51 --> URI Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Router Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Output Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Security Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Input Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:38:51 --> Language Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Loader Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:38:51 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Session Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:38:51 --> Session routines successfully run
DEBUG - 2016-08-02 21:38:51 --> Model Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Model Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Controller Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Model Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:38:51 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:38:51 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:38:51 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:38:51 --> Final output sent to browser
DEBUG - 2016-08-02 21:38:51 --> Total execution time: 0.4383
DEBUG - 2016-08-02 21:52:03 --> Config Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:52:03 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:52:03 --> URI Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Router Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Output Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Security Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Input Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:52:03 --> Language Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Loader Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:52:03 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Session Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:52:03 --> Session routines successfully run
DEBUG - 2016-08-02 21:52:03 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:03 --> Controller Class Initialized
DEBUG - 2016-08-02 21:52:04 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:04 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:52:04 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:52:04 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:52:04 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:52:04 --> Final output sent to browser
DEBUG - 2016-08-02 21:52:04 --> Total execution time: 0.5958
DEBUG - 2016-08-02 21:52:20 --> Config Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:52:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:52:20 --> URI Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Router Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Output Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Security Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Input Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:52:20 --> Language Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Loader Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:52:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Session Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:52:20 --> Session routines successfully run
DEBUG - 2016-08-02 21:52:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Controller Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:52:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:52:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:52:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:52:20 --> Final output sent to browser
DEBUG - 2016-08-02 21:52:20 --> Total execution time: 0.4374
DEBUG - 2016-08-02 21:52:28 --> Config Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:52:28 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:52:28 --> URI Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Router Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Output Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Security Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Input Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:52:28 --> Language Class Initialized
DEBUG - 2016-08-02 21:52:28 --> Loader Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:52:29 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Session Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:52:29 --> Session routines successfully run
DEBUG - 2016-08-02 21:52:29 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Controller Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Model Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:52:29 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:52:29 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:52:29 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:52:29 --> Final output sent to browser
DEBUG - 2016-08-02 21:52:29 --> Total execution time: 0.4295
DEBUG - 2016-08-02 21:53:19 --> Config Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:53:19 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:53:19 --> URI Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Router Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Output Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Security Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Input Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:53:19 --> Language Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Loader Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:53:19 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Session Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:53:19 --> Session routines successfully run
DEBUG - 2016-08-02 21:53:19 --> Model Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Model Class Initialized
DEBUG - 2016-08-02 21:53:19 --> Controller Class Initialized
DEBUG - 2016-08-02 21:53:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:53:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:53:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:53:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:53:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:53:20 --> Final output sent to browser
DEBUG - 2016-08-02 21:53:20 --> Total execution time: 0.4436
DEBUG - 2016-08-02 21:53:48 --> Config Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:53:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:53:48 --> URI Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Router Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Output Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Security Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Input Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:53:48 --> Language Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Loader Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:53:48 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Session Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:53:48 --> Session routines successfully run
DEBUG - 2016-08-02 21:53:48 --> Model Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Model Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Controller Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Model Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:53:48 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:53:48 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:53:48 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:53:48 --> Final output sent to browser
DEBUG - 2016-08-02 21:53:48 --> Total execution time: 0.4268
DEBUG - 2016-08-02 21:54:27 --> Config Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:54:27 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:54:27 --> URI Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Router Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Output Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Security Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Input Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:54:27 --> Language Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Loader Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:54:27 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Session Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:54:27 --> Session routines successfully run
DEBUG - 2016-08-02 21:54:27 --> Model Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Model Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Controller Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Model Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:54:27 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:54:27 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:54:27 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:54:27 --> Final output sent to browser
DEBUG - 2016-08-02 21:54:27 --> Total execution time: 0.4342
DEBUG - 2016-08-02 21:54:45 --> Config Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:54:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:54:45 --> URI Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Router Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Output Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Security Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Input Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:54:45 --> Language Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Loader Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:54:45 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Session Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:54:45 --> Session routines successfully run
DEBUG - 2016-08-02 21:54:45 --> Model Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Model Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Controller Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Model Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:54:45 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:54:45 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:54:45 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:54:45 --> Final output sent to browser
DEBUG - 2016-08-02 21:54:45 --> Total execution time: 0.4417
DEBUG - 2016-08-02 21:55:59 --> Config Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:55:59 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:55:59 --> URI Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Router Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Output Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Security Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Input Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:55:59 --> Language Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Loader Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:55:59 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Session Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:55:59 --> Session routines successfully run
DEBUG - 2016-08-02 21:55:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Controller Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Model Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:55:59 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:55:59 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:55:59 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:56:00 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:56:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:56:00 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:56:00 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:56:00 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:56:00 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:56:00 --> Final output sent to browser
DEBUG - 2016-08-02 21:56:00 --> Total execution time: 0.4353
DEBUG - 2016-08-02 21:56:20 --> Config Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:56:20 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:56:20 --> URI Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Router Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Output Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Security Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Input Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:56:20 --> Language Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Loader Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:56:20 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Session Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:56:20 --> Session routines successfully run
DEBUG - 2016-08-02 21:56:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Controller Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Model Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:56:20 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:56:20 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:56:20 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:56:20 --> Final output sent to browser
DEBUG - 2016-08-02 21:56:20 --> Total execution time: 0.4454
DEBUG - 2016-08-02 21:56:33 --> Config Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:56:33 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:56:33 --> URI Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Router Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Output Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Security Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Input Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:56:33 --> Language Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Loader Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:56:33 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Session Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:56:33 --> Session routines successfully run
DEBUG - 2016-08-02 21:56:33 --> Model Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Model Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Controller Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Model Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:56:33 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:56:33 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:56:33 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:56:33 --> Final output sent to browser
DEBUG - 2016-08-02 21:56:33 --> Total execution time: 0.4286
DEBUG - 2016-08-02 21:57:01 --> Config Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:57:01 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:57:01 --> URI Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Router Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Output Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Security Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Input Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:57:01 --> Language Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Loader Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:57:01 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Session Class Initialized
DEBUG - 2016-08-02 21:57:01 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:57:02 --> Session routines successfully run
DEBUG - 2016-08-02 21:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 21:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 21:57:02 --> Controller Class Initialized
DEBUG - 2016-08-02 21:57:02 --> Model Class Initialized
DEBUG - 2016-08-02 21:57:02 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:57:02 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:57:02 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:57:02 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:57:02 --> Final output sent to browser
DEBUG - 2016-08-02 21:57:02 --> Total execution time: 0.4386
DEBUG - 2016-08-02 21:57:39 --> Config Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:57:39 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:57:39 --> URI Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Router Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Output Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Security Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Input Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:57:39 --> Language Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Loader Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:57:39 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Session Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:57:39 --> Session routines successfully run
DEBUG - 2016-08-02 21:57:39 --> Model Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Model Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Controller Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Model Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:57:39 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:57:39 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:57:39 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:57:39 --> Final output sent to browser
DEBUG - 2016-08-02 21:57:39 --> Total execution time: 0.4353
DEBUG - 2016-08-02 21:58:04 --> Config Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:58:04 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:58:04 --> URI Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Router Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Output Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Security Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Input Class Initialized
DEBUG - 2016-08-02 21:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:58:04 --> Language Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Loader Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:58:05 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Session Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:58:05 --> Session routines successfully run
DEBUG - 2016-08-02 21:58:05 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Controller Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:58:05 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:58:05 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:58:05 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:58:05 --> Final output sent to browser
DEBUG - 2016-08-02 21:58:05 --> Total execution time: 0.4381
DEBUG - 2016-08-02 21:58:22 --> Config Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:58:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:58:22 --> URI Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Router Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Output Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Security Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Input Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:58:22 --> Language Class Initialized
DEBUG - 2016-08-02 21:58:22 --> Loader Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:58:23 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Session Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:58:23 --> Session routines successfully run
DEBUG - 2016-08-02 21:58:23 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Controller Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:58:23 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:58:23 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:58:23 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:58:23 --> Final output sent to browser
DEBUG - 2016-08-02 21:58:23 --> Total execution time: 0.4415
DEBUG - 2016-08-02 21:58:54 --> Config Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:58:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:58:54 --> URI Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Router Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Output Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Security Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Input Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:58:54 --> Language Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Loader Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:58:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Session Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:58:54 --> Session routines successfully run
DEBUG - 2016-08-02 21:58:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Controller Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Model Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:58:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:58:54 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:58:54 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:58:54 --> Final output sent to browser
DEBUG - 2016-08-02 21:58:54 --> Total execution time: 0.4456
DEBUG - 2016-08-02 21:59:48 --> Config Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Hooks Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Utf8 Class Initialized
DEBUG - 2016-08-02 21:59:48 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 21:59:48 --> URI Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Router Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Output Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Security Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Input Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 21:59:48 --> Language Class Initialized
DEBUG - 2016-08-02 21:59:48 --> Loader Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Helper loaded: url_helper
DEBUG - 2016-08-02 21:59:49 --> Database Driver Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Session Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Helper loaded: string_helper
DEBUG - 2016-08-02 21:59:49 --> Session routines successfully run
DEBUG - 2016-08-02 21:59:49 --> Model Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Model Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Controller Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Model Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Helper loaded: form_helper
DEBUG - 2016-08-02 21:59:49 --> Form Validation Class Initialized
DEBUG - 2016-08-02 21:59:49 --> Pagination Class Initialized
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 21:59:49 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 21:59:49 --> Final output sent to browser
DEBUG - 2016-08-02 21:59:49 --> Total execution time: 0.4378
DEBUG - 2016-08-02 22:00:09 --> Config Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:00:09 --> URI Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Router Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Output Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Security Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Input Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:00:09 --> Language Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Loader Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:00:09 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Session Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:00:09 --> Session routines successfully run
DEBUG - 2016-08-02 22:00:09 --> Model Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Model Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Controller Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Model Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:00:09 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:00:09 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:00:09 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:00:09 --> Final output sent to browser
DEBUG - 2016-08-02 22:00:09 --> Total execution time: 0.4374
DEBUG - 2016-08-02 22:00:41 --> Config Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:00:41 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:00:41 --> URI Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Router Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Output Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Security Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Input Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:00:41 --> Language Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Loader Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:00:41 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Session Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:00:41 --> Session routines successfully run
DEBUG - 2016-08-02 22:00:41 --> Model Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Model Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Controller Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Model Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:00:41 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:00:41 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:00:41 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:00:41 --> Final output sent to browser
DEBUG - 2016-08-02 22:00:41 --> Total execution time: 0.4431
DEBUG - 2016-08-02 22:01:54 --> Config Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:01:54 --> URI Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Router Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Output Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Security Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Input Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:01:54 --> Language Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Loader Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:01:54 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Session Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:01:54 --> Session routines successfully run
DEBUG - 2016-08-02 22:01:54 --> Model Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Model Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Controller Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Model Class Initialized
DEBUG - 2016-08-02 22:01:54 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:01:54 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:01:55 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:01:55 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:01:55 --> Final output sent to browser
DEBUG - 2016-08-02 22:01:55 --> Total execution time: 0.4285
DEBUG - 2016-08-02 22:02:32 --> Config Class Initialized
DEBUG - 2016-08-02 22:02:32 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:02:32 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:02:32 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:02:32 --> URI Class Initialized
DEBUG - 2016-08-02 22:02:32 --> Router Class Initialized
DEBUG - 2016-08-02 22:02:32 --> Output Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Security Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Input Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:02:33 --> Language Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Loader Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:02:33 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Session Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:02:33 --> Session routines successfully run
DEBUG - 2016-08-02 22:02:33 --> Model Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Model Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Controller Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Model Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:02:33 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:02:33 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:02:33 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:02:33 --> Final output sent to browser
DEBUG - 2016-08-02 22:02:33 --> Total execution time: 0.4499
DEBUG - 2016-08-02 22:03:05 --> Config Class Initialized
DEBUG - 2016-08-02 22:03:05 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:03:06 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:03:06 --> URI Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Router Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Output Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Security Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Input Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:03:06 --> Language Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Loader Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:03:06 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Session Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:03:06 --> Session routines successfully run
DEBUG - 2016-08-02 22:03:06 --> Model Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Model Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Controller Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Model Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:03:06 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:03:06 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:03:06 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:03:06 --> Final output sent to browser
DEBUG - 2016-08-02 22:03:06 --> Total execution time: 0.4471
DEBUG - 2016-08-02 22:03:26 --> Config Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:03:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:03:26 --> URI Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Router Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Output Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Security Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Input Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:03:26 --> Language Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Loader Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:03:26 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Session Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:03:26 --> Session routines successfully run
DEBUG - 2016-08-02 22:03:26 --> Model Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Model Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Controller Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Model Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:03:26 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:03:26 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:03:26 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:03:26 --> Final output sent to browser
DEBUG - 2016-08-02 22:03:26 --> Total execution time: 0.4415
DEBUG - 2016-08-02 22:05:18 --> Config Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Hooks Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Utf8 Class Initialized
DEBUG - 2016-08-02 22:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-08-02 22:05:18 --> URI Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Router Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Output Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Security Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Input Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-08-02 22:05:18 --> Language Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Loader Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Helper loaded: url_helper
DEBUG - 2016-08-02 22:05:18 --> Database Driver Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Session Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Helper loaded: string_helper
DEBUG - 2016-08-02 22:05:18 --> Session routines successfully run
DEBUG - 2016-08-02 22:05:18 --> Model Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Model Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Controller Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Model Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Helper loaded: form_helper
DEBUG - 2016-08-02 22:05:18 --> Form Validation Class Initialized
DEBUG - 2016-08-02 22:05:18 --> Pagination Class Initialized
DEBUG - 2016-08-02 22:05:18 --> File loaded: application/views/header.php
DEBUG - 2016-08-02 22:05:18 --> File loaded: application/views/navbar.php
DEBUG - 2016-08-02 22:05:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-08-02 22:05:18 --> File loaded: application/views/sidebar.php
DEBUG - 2016-08-02 22:05:19 --> File loaded: application/views/common/exporttable.php
DEBUG - 2016-08-02 22:05:19 --> File loaded: application/views/footer.php
DEBUG - 2016-08-02 22:05:19 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-08-02 22:05:19 --> Final output sent to browser
DEBUG - 2016-08-02 22:05:19 --> Total execution time: 0.4679
