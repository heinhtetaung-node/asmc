<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-02-12 16:55:16 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:16 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Router Class Initialized
DEBUG - 2016-02-12 16:55:16 --> No URI present. Default controller set.
DEBUG - 2016-02-12 16:55:16 --> Output Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Security Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Input Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:55:16 --> Language Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Loader Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:55:16 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Session Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:55:16 --> A session cookie was not found.
DEBUG - 2016-02-12 16:55:16 --> Session routines successfully run
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Controller Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:16 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:55:16 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:55:16 --> File loaded: application/views/loginView.php
DEBUG - 2016-02-12 16:55:16 --> Final output sent to browser
DEBUG - 2016-02-12 16:55:16 --> Total execution time: 0.0604
DEBUG - 2016-02-12 16:55:17 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:17 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:17 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:17 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:17 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:17 --> Router Class Initialized
ERROR - 2016-02-12 16:55:17 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:55:22 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:22 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Router Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Output Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Security Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Input Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:55:22 --> Language Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Loader Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:55:22 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Session Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:55:22 --> Session routines successfully run
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Controller Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:55:22 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-12 16:55:22 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:22 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Router Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Output Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Security Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Input Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:55:22 --> Language Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Loader Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:55:22 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Session Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:55:22 --> Session routines successfully run
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Controller Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:55:22 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:55:22 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:55:22 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:55:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:55:22 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:55:22 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:55:22 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-02-12 16:55:22 --> Final output sent to browser
DEBUG - 2016-02-12 16:55:22 --> Total execution time: 0.0432
DEBUG - 2016-02-12 16:55:22 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:22 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:22 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:22 --> Router Class Initialized
ERROR - 2016-02-12 16:55:22 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:55:38 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:38 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Router Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Output Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Security Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Input Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:55:38 --> Language Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Loader Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:55:38 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Session Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:55:38 --> Session routines successfully run
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Controller Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:55:38 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:55:38 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:55:38 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:55:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:55:38 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:55:38 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:55:38 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-02-12 16:55:38 --> Final output sent to browser
DEBUG - 2016-02-12 16:55:38 --> Total execution time: 0.2604
DEBUG - 2016-02-12 16:55:38 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:38 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:38 --> Router Class Initialized
ERROR - 2016-02-12 16:55:38 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:55:54 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:54 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Router Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Output Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Security Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Input Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:55:54 --> Language Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Loader Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:55:54 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Session Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:55:54 --> Session routines successfully run
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Controller Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:55:54 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:55:54 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:55:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:55:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:55:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:55:54 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:55:54 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-12 16:55:54 --> Final output sent to browser
DEBUG - 2016-02-12 16:55:54 --> Total execution time: 0.1121
DEBUG - 2016-02-12 16:55:54 --> Config Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:55:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:55:54 --> URI Class Initialized
DEBUG - 2016-02-12 16:55:54 --> Router Class Initialized
ERROR - 2016-02-12 16:55:54 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:56:50 --> Config Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:56:50 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:56:50 --> URI Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Router Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Output Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Security Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Input Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:56:50 --> Language Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Loader Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:56:50 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Session Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:56:50 --> Session routines successfully run
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Controller Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:56:50 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:56:50 --> Pagination Class Initialized
ERROR - 2016-02-12 16:56:50 --> Severity: Notice  --> Trying to get property of non-object /Applications/MAMP/htdocs/asmc/crm/application/models/invoice_model.php 484
DEBUG - 2016-02-12 16:56:50 --> DB Transaction Failure
ERROR - 2016-02-12 16:56:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'order by number asc' at line 1
DEBUG - 2016-02-12 16:56:50 --> Language file loaded: language/english/db_lang.php
ERROR - 2016-02-12 16:56:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/core/Common.php 442
DEBUG - 2016-02-12 16:56:52 --> Config Class Initialized
DEBUG - 2016-02-12 16:56:52 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:56:52 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:56:52 --> URI Class Initialized
DEBUG - 2016-02-12 16:56:52 --> Router Class Initialized
ERROR - 2016-02-12 16:56:52 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:56:54 --> Config Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:56:54 --> URI Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Router Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Output Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Security Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Input Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:56:54 --> Language Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Loader Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:56:54 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Session Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:56:54 --> Session routines successfully run
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Controller Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:56:54 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:56:54 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:56:54 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:56:54 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:56:54 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:56:54 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:56:54 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:56:54 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-02-12 16:56:54 --> Final output sent to browser
DEBUG - 2016-02-12 16:56:54 --> Total execution time: 0.0467
DEBUG - 2016-02-12 16:56:55 --> Config Class Initialized
DEBUG - 2016-02-12 16:56:55 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:56:55 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:56:55 --> URI Class Initialized
DEBUG - 2016-02-12 16:56:55 --> Router Class Initialized
ERROR - 2016-02-12 16:56:55 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:56:56 --> Config Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:56:56 --> URI Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Router Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Output Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Security Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Input Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:56:56 --> Language Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Loader Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:56:56 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Session Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:56:56 --> Session routines successfully run
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Controller Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Model Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:56:56 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:56:56 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:56:56 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:56:56 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:56:56 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:56:56 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:56:56 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-12 16:56:56 --> Final output sent to browser
DEBUG - 2016-02-12 16:56:56 --> Total execution time: 0.0535
DEBUG - 2016-02-12 16:56:56 --> Config Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:56:56 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:56:56 --> URI Class Initialized
DEBUG - 2016-02-12 16:56:56 --> Router Class Initialized
ERROR - 2016-02-12 16:56:56 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:57:12 --> Config Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:57:12 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:57:12 --> URI Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Router Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Output Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Security Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Input Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:57:12 --> Language Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Loader Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:57:12 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Session Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:57:12 --> Session routines successfully run
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Controller Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:57:12 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> Model Class Initialized
DEBUG - 2016-02-12 16:57:12 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:57:12 --> File loaded: application/views/form/index.php
DEBUG - 2016-02-12 16:57:12 --> Final output sent to browser
DEBUG - 2016-02-12 16:57:12 --> Total execution time: 0.0508
DEBUG - 2016-02-12 16:57:13 --> Config Class Initialized
DEBUG - 2016-02-12 16:57:13 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:57:13 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:57:13 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:57:13 --> URI Class Initialized
DEBUG - 2016-02-12 16:57:13 --> Router Class Initialized
ERROR - 2016-02-12 16:57:13 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:58:26 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:26 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Router Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Output Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Security Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Input Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:58:26 --> Language Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Loader Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:58:26 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Session Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:58:26 --> Session routines successfully run
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Controller Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:58:26 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:26 --> File loaded: application/views/form/email.php
DEBUG - 2016-02-12 16:58:26 --> Email Class Initialized
DEBUG - 2016-02-12 16:58:26 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:58:26 --> File loaded: application/views/form/index.php
DEBUG - 2016-02-12 16:58:26 --> Final output sent to browser
DEBUG - 2016-02-12 16:58:26 --> Total execution time: 0.0676
DEBUG - 2016-02-12 16:58:26 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:26 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:26 --> Router Class Initialized
ERROR - 2016-02-12 16:58:26 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:58:32 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:32 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Router Class Initialized
DEBUG - 2016-02-12 16:58:32 --> No URI present. Default controller set.
DEBUG - 2016-02-12 16:58:32 --> Output Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Security Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Input Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:58:32 --> Language Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Loader Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:58:32 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Session Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:58:32 --> Session routines successfully run
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Controller Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:58:32 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:32 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Router Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Output Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Security Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Input Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:58:32 --> Language Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Loader Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:58:32 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Session Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:58:32 --> Session routines successfully run
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Controller Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:58:32 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:58:32 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:58:32 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:58:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:58:32 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:58:32 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:58:32 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2016-02-12 16:58:32 --> Final output sent to browser
DEBUG - 2016-02-12 16:58:32 --> Total execution time: 0.0381
DEBUG - 2016-02-12 16:58:32 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:32 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:32 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:32 --> Router Class Initialized
ERROR - 2016-02-12 16:58:32 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:58:36 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:36 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Router Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Output Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Security Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Input Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:58:36 --> Language Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Loader Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:58:36 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Session Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:58:36 --> Session routines successfully run
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Controller Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:58:36 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:36 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:58:36 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:58:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:58:36 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:58:36 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:58:36 --> File loaded: application/views/form/list.php
DEBUG - 2016-02-12 16:58:36 --> Final output sent to browser
DEBUG - 2016-02-12 16:58:36 --> Total execution time: 0.0538
DEBUG - 2016-02-12 16:58:36 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:36 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:36 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:36 --> Router Class Initialized
ERROR - 2016-02-12 16:58:36 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:58:43 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:43 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Router Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Output Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Security Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Input Class Initialized
DEBUG - 2016-02-12 16:58:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:58:43 --> Language Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Loader Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:58:44 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Session Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:58:44 --> Session routines successfully run
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Controller Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Model Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:58:44 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:58:44 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:58:44 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:58:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:58:44 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:58:44 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:58:44 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2016-02-12 16:58:44 --> Final output sent to browser
DEBUG - 2016-02-12 16:58:44 --> Total execution time: 0.0668
DEBUG - 2016-02-12 16:58:44 --> Config Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:58:44 --> URI Class Initialized
DEBUG - 2016-02-12 16:58:44 --> Router Class Initialized
ERROR - 2016-02-12 16:58:44 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 16:59:28 --> Config Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:59:28 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:59:28 --> URI Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Router Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Output Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Security Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Input Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:59:28 --> Language Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Loader Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:59:28 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Session Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:59:28 --> Session routines successfully run
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Controller Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:59:28 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:59:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-12 16:59:28 --> Helper loaded: pdf_helper
DEBUG - 2016-02-12 16:59:29 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-12 16:59:31 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-12 16:59:34 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-12 16:59:35 --> Config Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:59:35 --> URI Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Router Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Output Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Security Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Input Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 16:59:35 --> Language Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Loader Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Helper loaded: url_helper
DEBUG - 2016-02-12 16:59:35 --> Database Driver Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Session Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Helper loaded: string_helper
DEBUG - 2016-02-12 16:59:35 --> Session routines successfully run
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Controller Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Model Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Helper loaded: form_helper
DEBUG - 2016-02-12 16:59:35 --> Form Validation Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Pagination Class Initialized
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 16:59:35 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-12 16:59:35 --> Final output sent to browser
DEBUG - 2016-02-12 16:59:35 --> Total execution time: 0.0605
DEBUG - 2016-02-12 16:59:35 --> Config Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Hooks Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Utf8 Class Initialized
DEBUG - 2016-02-12 16:59:35 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 16:59:35 --> URI Class Initialized
DEBUG - 2016-02-12 16:59:35 --> Router Class Initialized
ERROR - 2016-02-12 16:59:35 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:01:55 --> Config Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:01:55 --> URI Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Router Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Output Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Security Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Input Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:01:55 --> Language Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Loader Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:01:55 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Session Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:01:55 --> Session routines successfully run
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Controller Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:01:55 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:01:55 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:01:55 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:01:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:01:55 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:01:55 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:01:55 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-12 17:01:55 --> Final output sent to browser
DEBUG - 2016-02-12 17:01:55 --> Total execution time: 0.0853
DEBUG - 2016-02-12 17:01:55 --> Config Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:01:55 --> URI Class Initialized
DEBUG - 2016-02-12 17:01:55 --> Router Class Initialized
ERROR - 2016-02-12 17:01:55 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:01:59 --> Config Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:01:59 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:01:59 --> URI Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Router Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Output Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Security Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Input Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:01:59 --> Language Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Loader Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:01:59 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Session Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:01:59 --> Session routines successfully run
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Controller Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Model Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:01:59 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:01:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-12 17:01:59 --> Helper loaded: pdf_helper
DEBUG - 2016-02-12 17:01:59 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-12 17:02:02 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-12 17:02:04 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-12 17:02:05 --> Config Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:02:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:02:05 --> URI Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Router Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Output Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Security Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Input Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:02:05 --> Language Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Loader Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:02:05 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Session Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:02:05 --> Session routines successfully run
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Controller Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:02:05 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:02:05 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:02:05 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-12 17:02:05 --> Final output sent to browser
DEBUG - 2016-02-12 17:02:05 --> Total execution time: 0.0585
DEBUG - 2016-02-12 17:02:06 --> Config Class Initialized
DEBUG - 2016-02-12 17:02:06 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:02:06 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:02:06 --> URI Class Initialized
DEBUG - 2016-02-12 17:02:06 --> Router Class Initialized
ERROR - 2016-02-12 17:02:06 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:05:11 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:11 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:11 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Router Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Output Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Security Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Input Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:05:11 --> Language Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Loader Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:05:11 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Session Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:05:11 --> Session routines successfully run
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Controller Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:05:11 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:05:11 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:05:11 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:05:12 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:05:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:05:12 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:05:12 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:05:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2016-02-12 17:05:12 --> Final output sent to browser
DEBUG - 2016-02-12 17:05:12 --> Total execution time: 0.0650
DEBUG - 2016-02-12 17:05:12 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:12 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:12 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:12 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:12 --> Router Class Initialized
ERROR - 2016-02-12 17:05:12 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:05:14 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:14 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:14 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Router Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Output Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Security Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Input Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:05:14 --> Language Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Loader Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:05:14 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Session Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:05:14 --> Session routines successfully run
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Controller Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:05:14 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:05:14 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:05:14 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:05:14 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:05:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:05:14 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:05:14 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:05:14 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-12 17:05:14 --> Final output sent to browser
DEBUG - 2016-02-12 17:05:14 --> Total execution time: 0.0628
DEBUG - 2016-02-12 17:05:15 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:15 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:15 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:15 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:15 --> Router Class Initialized
ERROR - 2016-02-12 17:05:15 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:05:18 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:18 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:18 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Router Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Output Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Security Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Input Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:05:18 --> Language Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Loader Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:05:18 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Session Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:05:18 --> Session routines successfully run
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Controller Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:05:18 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:05:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-12 17:05:18 --> Helper loaded: pdf_helper
DEBUG - 2016-02-12 17:05:19 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-12 17:05:21 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-12 17:05:23 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-12 17:05:25 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:25 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Router Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Output Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Security Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Input Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:05:25 --> Language Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Loader Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:05:25 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Session Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:05:25 --> Session routines successfully run
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Controller Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Model Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:05:25 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:05:25 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:05:25 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-12 17:05:25 --> Final output sent to browser
DEBUG - 2016-02-12 17:05:25 --> Total execution time: 0.0611
DEBUG - 2016-02-12 17:05:26 --> Config Class Initialized
DEBUG - 2016-02-12 17:05:26 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:05:26 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:05:26 --> URI Class Initialized
DEBUG - 2016-02-12 17:05:26 --> Router Class Initialized
ERROR - 2016-02-12 17:05:26 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:08:05 --> Config Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:08:05 --> URI Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Router Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Output Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Security Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Input Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:08:05 --> Language Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Loader Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:08:05 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Session Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:08:05 --> Session routines successfully run
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Controller Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:08:05 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:08:05 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:08:05 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:08:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:08:05 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:08:05 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:08:05 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2016-02-12 17:08:05 --> Final output sent to browser
DEBUG - 2016-02-12 17:08:05 --> Total execution time: 0.0767
DEBUG - 2016-02-12 17:08:05 --> Config Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:08:05 --> URI Class Initialized
DEBUG - 2016-02-12 17:08:05 --> Router Class Initialized
ERROR - 2016-02-12 17:08:05 --> 404 Page Not Found --> js
DEBUG - 2016-02-12 17:08:09 --> Config Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:08:09 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:08:09 --> URI Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Router Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Output Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Security Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Input Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:08:09 --> Language Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Loader Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:08:09 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Session Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:08:09 --> Session routines successfully run
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Controller Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:08:09 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:08:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2016-02-12 17:08:09 --> Helper loaded: pdf_helper
DEBUG - 2016-02-12 17:08:09 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2016-02-12 17:08:12 --> File loaded: application/views/invoice/pdf/agreementPDF.php
DEBUG - 2016-02-12 17:08:14 --> File loaded: application/views/invoice/pdf/riskPDF.php
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/invoice/pdf/payoutPDF.php
DEBUG - 2016-02-12 17:08:15 --> Config Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:08:15 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:08:15 --> URI Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Router Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Output Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Security Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Input Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-02-12 17:08:15 --> Language Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Loader Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Helper loaded: url_helper
DEBUG - 2016-02-12 17:08:15 --> Database Driver Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Session Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Helper loaded: string_helper
DEBUG - 2016-02-12 17:08:15 --> Session routines successfully run
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Controller Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Model Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Helper loaded: form_helper
DEBUG - 2016-02-12 17:08:15 --> Form Validation Class Initialized
DEBUG - 2016-02-12 17:08:15 --> Pagination Class Initialized
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/header.php
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/navbar.php
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/sidebar.php
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/footer.php
DEBUG - 2016-02-12 17:08:15 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2016-02-12 17:08:15 --> Final output sent to browser
DEBUG - 2016-02-12 17:08:15 --> Total execution time: 0.0556
DEBUG - 2016-02-12 17:08:16 --> Config Class Initialized
DEBUG - 2016-02-12 17:08:16 --> Hooks Class Initialized
DEBUG - 2016-02-12 17:08:16 --> Utf8 Class Initialized
DEBUG - 2016-02-12 17:08:16 --> UTF-8 Support Enabled
DEBUG - 2016-02-12 17:08:16 --> URI Class Initialized
DEBUG - 2016-02-12 17:08:16 --> Router Class Initialized
ERROR - 2016-02-12 17:08:16 --> 404 Page Not Found --> js
