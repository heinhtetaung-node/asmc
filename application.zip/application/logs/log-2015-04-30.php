<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-30 09:57:31 --> Config Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Hooks Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Utf8 Class Initialized
DEBUG - 2015-04-30 09:57:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 09:57:31 --> URI Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Router Class Initialized
DEBUG - 2015-04-30 09:57:31 --> No URI present. Default controller set.
DEBUG - 2015-04-30 09:57:31 --> Output Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Security Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Input Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 09:57:31 --> Language Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Loader Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Helper loaded: url_helper
DEBUG - 2015-04-30 09:57:31 --> Database Driver Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Session Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Helper loaded: string_helper
DEBUG - 2015-04-30 09:57:31 --> A session cookie was not found.
DEBUG - 2015-04-30 09:57:31 --> Session routines successfully run
DEBUG - 2015-04-30 09:57:31 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Controller Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:31 --> Helper loaded: form_helper
DEBUG - 2015-04-30 09:57:31 --> Form Validation Class Initialized
DEBUG - 2015-04-30 09:57:31 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-30 09:57:31 --> Final output sent to browser
DEBUG - 2015-04-30 09:57:31 --> Total execution time: 0.0609
DEBUG - 2015-04-30 09:57:37 --> Config Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Hooks Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Utf8 Class Initialized
DEBUG - 2015-04-30 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 09:57:37 --> URI Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Router Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Output Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Security Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Input Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 09:57:37 --> Language Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Loader Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Helper loaded: url_helper
DEBUG - 2015-04-30 09:57:37 --> Database Driver Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Session Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Helper loaded: string_helper
DEBUG - 2015-04-30 09:57:37 --> Session routines successfully run
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Controller Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Helper loaded: form_helper
DEBUG - 2015-04-30 09:57:37 --> Form Validation Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 09:57:37 --> Config Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Hooks Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Utf8 Class Initialized
DEBUG - 2015-04-30 09:57:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 09:57:37 --> URI Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Router Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Output Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Security Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Input Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 09:57:37 --> Language Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Loader Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Helper loaded: url_helper
DEBUG - 2015-04-30 09:57:37 --> Database Driver Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Session Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Helper loaded: string_helper
DEBUG - 2015-04-30 09:57:37 --> Session routines successfully run
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Controller Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Helper loaded: form_helper
DEBUG - 2015-04-30 09:57:37 --> Form Validation Class Initialized
DEBUG - 2015-04-30 09:57:37 --> Pagination Class Initialized
DEBUG - 2015-04-30 09:57:37 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 09:57:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 09:57:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 09:57:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 09:57:37 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 09:57:37 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-30 09:57:37 --> Final output sent to browser
DEBUG - 2015-04-30 09:57:37 --> Total execution time: 0.0472
DEBUG - 2015-04-30 09:57:44 --> Config Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Hooks Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Utf8 Class Initialized
DEBUG - 2015-04-30 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 09:57:44 --> URI Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Router Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Output Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Security Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Input Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 09:57:44 --> Language Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Loader Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Helper loaded: url_helper
DEBUG - 2015-04-30 09:57:44 --> Database Driver Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Session Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Helper loaded: string_helper
DEBUG - 2015-04-30 09:57:44 --> Session routines successfully run
DEBUG - 2015-04-30 09:57:44 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Controller Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Model Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Helper loaded: form_helper
DEBUG - 2015-04-30 09:57:44 --> Form Validation Class Initialized
DEBUG - 2015-04-30 09:57:44 --> Pagination Class Initialized
DEBUG - 2015-04-30 09:57:44 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 09:57:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 09:57:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 09:57:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 09:57:44 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 09:57:44 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-30 09:57:44 --> Final output sent to browser
DEBUG - 2015-04-30 09:57:44 --> Total execution time: 0.0459
DEBUG - 2015-04-30 09:58:19 --> Config Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Hooks Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Utf8 Class Initialized
DEBUG - 2015-04-30 09:58:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 09:58:19 --> URI Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Router Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Output Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Security Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Input Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 09:58:19 --> Language Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Loader Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Helper loaded: url_helper
DEBUG - 2015-04-30 09:58:19 --> Database Driver Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Session Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Helper loaded: string_helper
DEBUG - 2015-04-30 09:58:19 --> Session routines successfully run
DEBUG - 2015-04-30 09:58:19 --> Model Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Model Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Controller Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Model Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Helper loaded: form_helper
DEBUG - 2015-04-30 09:58:19 --> Form Validation Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Pagination Class Initialized
DEBUG - 2015-04-30 09:58:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 09:58:19 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 09:58:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 09:58:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 09:58:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 09:58:19 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 09:58:19 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-30 09:58:19 --> Final output sent to browser
DEBUG - 2015-04-30 09:58:19 --> Total execution time: 0.0618
DEBUG - 2015-04-30 09:59:03 --> Config Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Hooks Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Utf8 Class Initialized
DEBUG - 2015-04-30 09:59:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 09:59:03 --> URI Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Router Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Output Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Security Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Input Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 09:59:03 --> Language Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Loader Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Helper loaded: url_helper
DEBUG - 2015-04-30 09:59:03 --> Database Driver Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Session Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Helper loaded: string_helper
DEBUG - 2015-04-30 09:59:03 --> Session routines successfully run
DEBUG - 2015-04-30 09:59:03 --> Model Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Model Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Controller Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Model Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Helper loaded: form_helper
DEBUG - 2015-04-30 09:59:03 --> Form Validation Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Pagination Class Initialized
DEBUG - 2015-04-30 09:59:03 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 09:59:03 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 09:59:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 09:59:03 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 09:59:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 09:59:03 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 09:59:03 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-30 09:59:03 --> Final output sent to browser
DEBUG - 2015-04-30 09:59:03 --> Total execution time: 0.0478
DEBUG - 2015-04-30 10:00:57 --> Config Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:00:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:00:57 --> URI Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Router Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Output Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Security Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Input Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:00:57 --> Language Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Loader Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:00:57 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Session Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:00:57 --> Session routines successfully run
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Controller Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:00:57 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:00:57 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:00:57 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:00:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:00:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:00:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:00:57 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:00:57 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-30 10:00:57 --> Final output sent to browser
DEBUG - 2015-04-30 10:00:57 --> Total execution time: 0.1001
DEBUG - 2015-04-30 10:00:58 --> Config Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:00:58 --> URI Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Router Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Output Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Security Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Input Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:00:58 --> Language Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Loader Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:00:58 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Session Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:00:58 --> Session routines successfully run
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Controller Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Model Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:00:58 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:00:58 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:00:58 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:00:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:00:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:00:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:00:58 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:00:58 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-04-30 10:00:58 --> Final output sent to browser
DEBUG - 2015-04-30 10:00:58 --> Total execution time: 0.0583
DEBUG - 2015-04-30 10:04:01 --> Config Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:04:01 --> URI Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Router Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Output Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Security Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Input Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:04:01 --> Language Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Loader Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:04:01 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Session Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:04:01 --> Session routines successfully run
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Controller Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:04:01 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:04:01 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:04:01 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:04:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:04:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:04:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:04:01 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:04:01 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-04-30 10:04:01 --> Final output sent to browser
DEBUG - 2015-04-30 10:04:01 --> Total execution time: 0.0449
DEBUG - 2015-04-30 10:04:54 --> Config Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:04:54 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:04:54 --> URI Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Router Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Output Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Security Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Input Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:04:54 --> Language Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Loader Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:04:54 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Session Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:04:54 --> Session routines successfully run
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Controller Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:04:54 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:04:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 10:04:54 --> Helper loaded: pdf_helper
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-04-30 10:04:55 --> Config Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:04:55 --> URI Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Router Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Output Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Security Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Input Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:04:55 --> Language Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Loader Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:04:55 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Session Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:04:55 --> Session routines successfully run
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Controller Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Model Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:04:55 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:04:55 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:04:55 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 10:04:55 --> Final output sent to browser
DEBUG - 2015-04-30 10:04:55 --> Total execution time: 0.0553
DEBUG - 2015-04-30 10:05:33 --> Config Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:05:33 --> URI Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Router Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Output Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Security Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Input Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:05:33 --> Language Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Loader Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:05:33 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Session Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:05:33 --> Session routines successfully run
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Controller Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Model Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:05:33 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:05:33 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:05:33 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:05:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:05:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:05:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:05:33 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:05:33 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 10:05:33 --> Final output sent to browser
DEBUG - 2015-04-30 10:05:33 --> Total execution time: 0.0577
DEBUG - 2015-04-30 10:12:30 --> Config Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:12:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:12:30 --> URI Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Router Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Output Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Security Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Input Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:12:30 --> Language Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Loader Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:12:30 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Session Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:12:30 --> Session routines successfully run
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Controller Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:12:30 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:12:30 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:12:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:12:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:12:30 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:12:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:12:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:12:30 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-30 10:12:30 --> Final output sent to browser
DEBUG - 2015-04-30 10:12:30 --> Total execution time: 0.0915
DEBUG - 2015-04-30 10:12:36 --> Config Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:12:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:12:36 --> URI Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Router Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Output Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Security Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Input Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:12:36 --> Language Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Loader Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:12:36 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Session Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:12:36 --> Session routines successfully run
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Controller Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:12:36 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:12:36 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-04-30 10:12:36 --> Severity: Notice  --> Undefined index: cheque_no3 /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 385
ERROR - 2015-04-30 10:12:36 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-30 10:12:36 --> Helper loaded: pdf_helper
ERROR - 2015-04-30 10:12:37 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/tcpdf.php 7624
DEBUG - 2015-04-30 10:21:26 --> Config Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:21:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:21:26 --> URI Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Router Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Output Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Security Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Input Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:21:26 --> Language Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Loader Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:21:26 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Session Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:21:26 --> Session routines successfully run
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Controller Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:21:26 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:21:26 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-04-30 10:21:26 --> Severity: Notice  --> Undefined index: cheque_no3 /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 385
ERROR - 2015-04-30 10:21:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-30 10:21:26 --> Helper loaded: pdf_helper
ERROR - 2015-04-30 10:21:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/tcpdf.php 7624
DEBUG - 2015-04-30 10:21:29 --> Config Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:21:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:21:29 --> URI Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Router Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Output Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Security Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Input Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:21:29 --> Language Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Loader Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:21:29 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Session Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:21:29 --> Session routines successfully run
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Controller Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:21:29 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:21:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-04-30 10:21:29 --> Severity: Notice  --> Undefined index: cheque_no3 /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 385
ERROR - 2015-04-30 10:21:29 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/system/libraries/Session.php 675
DEBUG - 2015-04-30 10:21:29 --> Helper loaded: pdf_helper
ERROR - 2015-04-30 10:21:30 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /Applications/MAMP/htdocs/asmc/crm/system/core/Exceptions.php:185) /Applications/MAMP/htdocs/asmc/crm/application/helpers/tcpdf/tcpdf.php 7624
DEBUG - 2015-04-30 10:21:32 --> Config Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:21:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:21:32 --> URI Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Router Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Output Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Security Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Input Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:21:32 --> Language Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Loader Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:21:32 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Session Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:21:32 --> Session routines successfully run
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Controller Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:21:32 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:21:32 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:21:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:21:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:21:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:21:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:21:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:21:32 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-30 10:21:32 --> Final output sent to browser
DEBUG - 2015-04-30 10:21:32 --> Total execution time: 0.0604
DEBUG - 2015-04-30 10:21:36 --> Config Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:21:36 --> URI Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Router Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Output Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Security Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Input Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:21:36 --> Language Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Loader Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:21:36 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Session Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:21:36 --> Session routines successfully run
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Controller Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:21:36 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:21:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 10:21:36 --> Helper loaded: pdf_helper
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-04-30 10:21:37 --> Config Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Hooks Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Utf8 Class Initialized
DEBUG - 2015-04-30 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 10:21:37 --> URI Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Router Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Output Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Security Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Input Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 10:21:37 --> Language Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Loader Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Helper loaded: url_helper
DEBUG - 2015-04-30 10:21:37 --> Database Driver Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Session Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Helper loaded: string_helper
DEBUG - 2015-04-30 10:21:37 --> Session routines successfully run
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Controller Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Model Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Helper loaded: form_helper
DEBUG - 2015-04-30 10:21:37 --> Form Validation Class Initialized
DEBUG - 2015-04-30 10:21:37 --> Pagination Class Initialized
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 10:21:37 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 10:21:37 --> Final output sent to browser
DEBUG - 2015-04-30 10:21:37 --> Total execution time: 0.0555
DEBUG - 2015-04-30 11:48:32 --> Config Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:48:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:48:32 --> URI Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Router Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Output Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Security Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Input Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:48:32 --> Language Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Loader Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:48:32 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Session Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:48:32 --> Session routines successfully run
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Controller Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:48:32 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:48:32 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:48:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:48:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:48:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:48:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:48:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:48:32 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-30 11:48:32 --> Final output sent to browser
DEBUG - 2015-04-30 11:48:32 --> Total execution time: 0.0925
DEBUG - 2015-04-30 11:48:36 --> Config Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:48:36 --> URI Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Router Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Output Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Security Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Input Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:48:36 --> Language Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Loader Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:48:36 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Session Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:48:36 --> Session routines successfully run
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Controller Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:48:36 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: pdf_helper
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-04-30 11:48:36 --> Config Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:48:36 --> URI Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Router Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Output Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Security Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Input Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:48:36 --> Language Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Loader Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:48:36 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Session Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:48:36 --> Session routines successfully run
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Controller Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:48:36 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:48:36 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:48:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 11:48:36 --> Final output sent to browser
DEBUG - 2015-04-30 11:48:36 --> Total execution time: 0.0621
DEBUG - 2015-04-30 11:48:53 --> Config Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:48:53 --> URI Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Router Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Output Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Security Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Input Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:48:53 --> Language Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Loader Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:48:53 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Session Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:48:53 --> Session routines successfully run
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Controller Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:48:53 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:48:53 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:48:53 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:48:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:48:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:48:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:48:53 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:48:53 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-30 11:48:53 --> Final output sent to browser
DEBUG - 2015-04-30 11:48:53 --> Total execution time: 0.0700
DEBUG - 2015-04-30 11:49:01 --> Config Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:49:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:49:01 --> URI Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Router Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Output Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Security Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Input Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:49:01 --> Language Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Loader Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:49:01 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Session Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:49:01 --> Session routines successfully run
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Controller Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:49:01 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:49:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 11:49:01 --> Helper loaded: pdf_helper
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-04-30 11:49:02 --> Config Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:49:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:49:02 --> URI Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Router Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Output Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Security Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Input Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:49:02 --> Language Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Loader Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:49:02 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Session Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:49:02 --> Session routines successfully run
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Controller Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:49:02 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:49:02 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:49:02 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 11:49:02 --> Final output sent to browser
DEBUG - 2015-04-30 11:49:02 --> Total execution time: 0.0531
DEBUG - 2015-04-30 11:49:19 --> Config Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:49:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:49:19 --> URI Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Router Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Output Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Security Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Input Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:49:19 --> Language Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Loader Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:49:19 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Session Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:49:19 --> Session routines successfully run
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Controller Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:49:19 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:49:19 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:49:19 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:49:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:49:19 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:49:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:49:19 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:49:19 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-30 11:49:19 --> Final output sent to browser
DEBUG - 2015-04-30 11:49:19 --> Total execution time: 0.0732
DEBUG - 2015-04-30 11:49:24 --> Config Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:49:24 --> URI Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Router Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Output Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Security Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Input Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:49:24 --> Language Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Loader Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:49:24 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Session Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:49:24 --> Session routines successfully run
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Controller Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:49:24 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:49:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-30 11:49:24 --> Helper loaded: pdf_helper
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/invoice/pdf/receiptPDF.php
DEBUG - 2015-04-30 11:49:25 --> Config Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:49:25 --> URI Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Router Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Output Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Security Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Input Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:49:25 --> Language Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Loader Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:49:25 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Session Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:49:25 --> Session routines successfully run
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Controller Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Model Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:49:25 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:49:25 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:49:25 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 11:49:25 --> Final output sent to browser
DEBUG - 2015-04-30 11:49:25 --> Total execution time: 0.0550
DEBUG - 2015-04-30 11:50:08 --> Config Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:50:08 --> URI Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Router Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Output Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Security Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Input Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:50:08 --> Language Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Loader Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:50:08 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Session Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:50:08 --> Session routines successfully run
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Controller Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:50:08 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:50:08 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:50:08 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:50:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:50:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:50:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:50:08 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:50:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-30 11:50:08 --> Final output sent to browser
DEBUG - 2015-04-30 11:50:08 --> Total execution time: 0.0636
DEBUG - 2015-04-30 11:50:20 --> Config Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:50:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:50:20 --> URI Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Router Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Output Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Security Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Input Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:50:20 --> Language Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Loader Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:50:20 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Session Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:50:20 --> Session routines successfully run
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Controller Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Model Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:50:20 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:50:20 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:50:20 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:50:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:50:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:50:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:50:20 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:50:20 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-30 11:50:20 --> Final output sent to browser
DEBUG - 2015-04-30 11:50:20 --> Total execution time: 0.0653
DEBUG - 2015-04-30 11:52:26 --> Config Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Hooks Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Utf8 Class Initialized
DEBUG - 2015-04-30 11:52:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-30 11:52:26 --> URI Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Router Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Output Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Security Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Input Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-30 11:52:26 --> Language Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Loader Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Helper loaded: url_helper
DEBUG - 2015-04-30 11:52:26 --> Database Driver Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Session Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Helper loaded: string_helper
DEBUG - 2015-04-30 11:52:26 --> Session routines successfully run
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Controller Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Model Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Helper loaded: form_helper
DEBUG - 2015-04-30 11:52:26 --> Form Validation Class Initialized
DEBUG - 2015-04-30 11:52:26 --> Pagination Class Initialized
DEBUG - 2015-04-30 11:52:26 --> File loaded: application/views/header.php
DEBUG - 2015-04-30 11:52:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-30 11:52:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-30 11:52:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-30 11:52:26 --> File loaded: application/views/footer.php
DEBUG - 2015-04-30 11:52:26 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-30 11:52:26 --> Final output sent to browser
DEBUG - 2015-04-30 11:52:26 --> Total execution time: 0.0858
