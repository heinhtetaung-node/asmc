<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-05-14 11:23:58 --> Config Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:23:58 --> URI Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Router Class Initialized
DEBUG - 2015-05-14 11:23:58 --> No URI present. Default controller set.
DEBUG - 2015-05-14 11:23:58 --> Output Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Security Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Input Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:23:58 --> Language Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Loader Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:23:58 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Session Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:23:58 --> A session cookie was not found.
DEBUG - 2015-05-14 11:23:58 --> Session routines successfully run
DEBUG - 2015-05-14 11:23:58 --> Model Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Model Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Controller Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Model Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Model Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Model Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Model Class Initialized
DEBUG - 2015-05-14 11:23:58 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:23:58 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:23:58 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-14 11:23:58 --> Final output sent to browser
DEBUG - 2015-05-14 11:23:58 --> Total execution time: 0.0623
DEBUG - 2015-05-14 11:24:05 --> Config Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:24:05 --> URI Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Router Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Output Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Security Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Input Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:24:05 --> Language Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Loader Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:24:05 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Session Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:24:05 --> Session routines successfully run
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Controller Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:24:05 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-14 11:24:05 --> Config Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:24:05 --> URI Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Router Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Output Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Security Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Input Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:24:05 --> Language Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Loader Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:24:05 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Session Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:24:05 --> Session routines successfully run
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Controller Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:24:05 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:24:05 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:24:05 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:24:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:24:05 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:24:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:24:05 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:24:05 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-14 11:24:05 --> Final output sent to browser
DEBUG - 2015-05-14 11:24:05 --> Total execution time: 0.0458
DEBUG - 2015-05-14 11:24:08 --> Config Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:24:08 --> URI Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Router Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Output Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Security Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Input Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:24:08 --> Language Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Loader Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:24:08 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Session Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:24:08 --> Session routines successfully run
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Controller Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:24:08 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:24:08 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:24:08 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:24:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:24:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:24:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:24:08 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:24:08 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-14 11:24:08 --> Final output sent to browser
DEBUG - 2015-05-14 11:24:08 --> Total execution time: 0.0937
DEBUG - 2015-05-14 11:24:10 --> Config Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:24:10 --> URI Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Router Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Output Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Security Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Input Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:24:10 --> Language Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Loader Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:24:10 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Session Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:24:10 --> Session routines successfully run
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Controller Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Model Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:24:10 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:24:10 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:24:10 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:24:10 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:24:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:24:10 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:24:10 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:24:10 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 11:24:10 --> Final output sent to browser
DEBUG - 2015-05-14 11:24:10 --> Total execution time: 0.0779
DEBUG - 2015-05-14 11:29:35 --> Config Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:29:35 --> URI Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Router Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Output Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Security Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Input Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:29:35 --> Language Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Loader Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:29:35 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Session Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:29:35 --> Session routines successfully run
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Controller Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:29:35 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Config Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:29:35 --> URI Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Router Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Output Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Security Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Input Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:29:35 --> Language Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Loader Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:29:35 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Session Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:29:35 --> Session routines successfully run
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Controller Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:29:35 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:29:35 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:29:35 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:29:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:29:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:29:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:29:36 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:29:36 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-14 11:29:36 --> Final output sent to browser
DEBUG - 2015-05-14 11:29:36 --> Total execution time: 0.0666
DEBUG - 2015-05-14 11:32:06 --> Config Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:32:06 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:32:06 --> URI Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Router Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Output Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Security Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Input Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:32:06 --> Language Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Loader Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:32:06 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Session Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:32:06 --> Session routines successfully run
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Controller Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:32:06 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:32:06 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:32:07 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:32:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:32:07 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:32:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:32:07 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:32:07 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-14 11:32:07 --> Final output sent to browser
DEBUG - 2015-05-14 11:32:07 --> Total execution time: 0.1102
DEBUG - 2015-05-14 11:32:18 --> Config Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:32:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:32:18 --> URI Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Router Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Output Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Security Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Input Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:32:18 --> Language Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Loader Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:32:18 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Session Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:32:18 --> Session routines successfully run
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Controller Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:32:18 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:32:18 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:32:18 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:32:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:32:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:32:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:32:18 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:32:18 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 11:32:18 --> Final output sent to browser
DEBUG - 2015-05-14 11:32:18 --> Total execution time: 0.0711
DEBUG - 2015-05-14 11:32:40 --> Config Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:32:40 --> URI Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Router Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Output Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Security Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Input Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:32:40 --> Language Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Loader Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:32:40 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Session Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:32:40 --> Session routines successfully run
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Controller Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:32:40 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:32:40 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:32:40 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:32:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:32:40 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:32:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:32:40 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:32:40 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-14 11:32:40 --> Final output sent to browser
DEBUG - 2015-05-14 11:32:40 --> Total execution time: 0.0621
DEBUG - 2015-05-14 11:32:42 --> Config Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:32:42 --> URI Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Router Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Output Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Security Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Input Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:32:42 --> Language Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Loader Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:32:42 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Session Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:32:42 --> Session routines successfully run
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Controller Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:32:42 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:32:42 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:32:42 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:32:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:32:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:32:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:32:42 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:32:42 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-14 11:32:42 --> Final output sent to browser
DEBUG - 2015-05-14 11:32:42 --> Total execution time: 0.0738
DEBUG - 2015-05-14 11:32:46 --> Config Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:32:46 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:32:46 --> URI Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Router Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Output Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Security Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Input Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:32:46 --> Language Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Loader Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:32:46 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Session Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:32:46 --> Session routines successfully run
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Controller Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Model Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:32:46 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:32:46 --> Helper loaded: pdf_helper
DEBUG - 2015-05-14 11:32:46 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2015-05-14 11:32:46 --> Final output sent to browser
DEBUG - 2015-05-14 11:32:46 --> Total execution time: 0.5585
DEBUG - 2015-05-14 11:34:35 --> Config Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:34:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:34:35 --> URI Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Router Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Output Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Security Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Input Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:34:35 --> Language Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Loader Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:34:35 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Session Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:34:35 --> Session routines successfully run
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Controller Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Model Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:34:35 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:34:35 --> Helper loaded: pdf_helper
DEBUG - 2015-05-14 11:34:35 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2015-05-14 11:34:35 --> Final output sent to browser
DEBUG - 2015-05-14 11:34:35 --> Total execution time: 0.5160
DEBUG - 2015-05-14 11:41:37 --> Config Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:41:37 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:41:37 --> URI Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Router Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Output Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Security Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Input Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:41:37 --> Language Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Loader Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:41:37 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Session Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:41:37 --> Session routines successfully run
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Controller Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:41:37 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:41:37 --> Helper loaded: pdf_helper
DEBUG - 2015-05-14 11:41:37 --> File loaded: application/views/invoice/pdf/payoutreceiptPDF.php
DEBUG - 2015-05-14 11:41:37 --> Final output sent to browser
DEBUG - 2015-05-14 11:41:37 --> Total execution time: 0.5876
DEBUG - 2015-05-14 11:41:39 --> Config Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:41:39 --> URI Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Router Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Output Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Security Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Input Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:41:39 --> Language Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Loader Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:41:39 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Session Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:41:39 --> Session routines successfully run
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Controller Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:41:39 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:41:39 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:41:39 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:41:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:41:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:41:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:41:39 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:41:39 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-14 11:41:39 --> Final output sent to browser
DEBUG - 2015-05-14 11:41:39 --> Total execution time: 0.0739
DEBUG - 2015-05-14 11:41:43 --> Config Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Hooks Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Utf8 Class Initialized
DEBUG - 2015-05-14 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 11:41:43 --> URI Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Router Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Output Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Security Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Input Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 11:41:43 --> Language Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Loader Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Helper loaded: url_helper
DEBUG - 2015-05-14 11:41:43 --> Database Driver Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Session Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Helper loaded: string_helper
DEBUG - 2015-05-14 11:41:43 --> Session routines successfully run
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Controller Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Model Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Helper loaded: form_helper
DEBUG - 2015-05-14 11:41:43 --> Form Validation Class Initialized
DEBUG - 2015-05-14 11:41:43 --> Pagination Class Initialized
DEBUG - 2015-05-14 11:41:43 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 11:41:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 11:41:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 11:41:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 11:41:43 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 11:41:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 11:41:43 --> Final output sent to browser
DEBUG - 2015-05-14 11:41:43 --> Total execution time: 0.0583
DEBUG - 2015-05-14 12:00:55 --> Config Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:00:55 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:00:55 --> URI Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Router Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Output Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Security Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Input Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:00:55 --> Language Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Loader Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:00:55 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Session Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:00:55 --> Session routines successfully run
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Controller Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Model Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:00:55 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:00:55 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:00:55 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:00:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:00:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:00:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:00:55 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:00:55 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:00:55 --> Final output sent to browser
DEBUG - 2015-05-14 12:00:55 --> Total execution time: 0.0845
DEBUG - 2015-05-14 12:01:04 --> Config Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:01:04 --> URI Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Router Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Output Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Security Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Input Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:01:04 --> Language Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Loader Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:01:04 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Session Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:01:04 --> Session routines successfully run
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Controller Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:01:04 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:01:04 --> Pagination Class Initialized
ERROR - 2015-05-14 12:01:04 --> Severity: Notice  --> Undefined index: uploads /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 326
DEBUG - 2015-05-14 12:01:04 --> Final output sent to browser
DEBUG - 2015-05-14 12:01:04 --> Total execution time: 0.0449
DEBUG - 2015-05-14 12:01:29 --> Config Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:01:29 --> URI Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Router Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Output Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Security Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Input Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:01:29 --> Language Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Loader Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:01:29 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Session Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:01:29 --> Session routines successfully run
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Controller Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:01:29 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:01:29 --> Pagination Class Initialized
ERROR - 2015-05-14 12:01:29 --> Severity: Notice  --> Array to string conversion /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 327
DEBUG - 2015-05-14 12:01:29 --> Final output sent to browser
DEBUG - 2015-05-14 12:01:29 --> Total execution time: 0.0446
DEBUG - 2015-05-14 12:01:35 --> Config Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:01:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:01:35 --> URI Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Router Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Output Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Security Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Input Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:01:35 --> Language Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Loader Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:01:35 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Session Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:01:35 --> Session routines successfully run
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Controller Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:01:35 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:01:35 --> Final output sent to browser
DEBUG - 2015-05-14 12:01:35 --> Total execution time: 0.0438
DEBUG - 2015-05-14 12:05:03 --> Config Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:05:03 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:05:03 --> URI Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Router Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Output Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Security Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Input Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:05:03 --> Language Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Loader Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:05:03 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Session Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:05:03 --> Session routines successfully run
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Controller Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:05:03 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:05:03 --> Pagination Class Initialized
ERROR - 2015-05-14 12:05:03 --> Severity: Warning  --> move_uploaded_file(/Applications/MAMP/htdocs/asmc/crm/pdf/receipts/manual/Screen Shot 2015-05-13 at 12.30.30 pm.png): failed to open stream: No such file or directory /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 333
ERROR - 2015-05-14 12:05:03 --> Severity: Warning  --> move_uploaded_file(): Unable to move '/Applications/MAMP/tmp/php/phpV8XzHG' to '/Applications/MAMP/htdocs/asmc/crm/pdf/receipts/manual/Screen Shot 2015-05-13 at 12.30.30 pm.png' /Applications/MAMP/htdocs/asmc/crm/application/controllers/invoice.php 333
DEBUG - 2015-05-14 12:05:03 --> Final output sent to browser
DEBUG - 2015-05-14 12:05:03 --> Total execution time: 0.0533
DEBUG - 2015-05-14 12:05:21 --> Config Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:05:21 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:05:21 --> URI Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Router Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Output Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Security Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Input Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:05:21 --> Language Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Loader Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:05:21 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Session Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:05:21 --> Session routines successfully run
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Controller Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Model Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:05:21 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:05:21 --> Final output sent to browser
DEBUG - 2015-05-14 12:05:21 --> Total execution time: 0.0480
DEBUG - 2015-05-14 12:07:35 --> Config Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:07:35 --> URI Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Router Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Output Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Security Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Input Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:07:35 --> Language Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Loader Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:07:35 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Session Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:07:35 --> Session routines successfully run
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Controller Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:07:35 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:07:35 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:07:35 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:07:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:07:35 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:07:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:07:35 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:07:35 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:07:35 --> Final output sent to browser
DEBUG - 2015-05-14 12:07:35 --> Total execution time: 0.0836
DEBUG - 2015-05-14 12:07:44 --> Config Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:07:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:07:44 --> URI Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Router Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Output Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Security Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Input Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:07:44 --> Language Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Loader Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:07:44 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Session Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:07:44 --> Session routines successfully run
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Controller Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Model Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:07:44 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:07:44 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:07:44 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:07:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:07:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:07:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:07:44 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:07:44 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:07:44 --> Final output sent to browser
DEBUG - 2015-05-14 12:07:44 --> Total execution time: 0.0592
DEBUG - 2015-05-14 12:10:28 --> Config Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:10:28 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:10:28 --> URI Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Router Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Output Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Security Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Input Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:10:28 --> Language Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Loader Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:10:28 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Session Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:10:28 --> Session routines successfully run
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Controller Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Model Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:10:28 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:10:28 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:10:28 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:10:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:10:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:10:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:10:28 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:10:28 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:10:28 --> Final output sent to browser
DEBUG - 2015-05-14 12:10:28 --> Total execution time: 0.0567
DEBUG - 2015-05-14 12:13:52 --> Config Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:13:52 --> URI Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Router Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Output Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Security Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Input Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:13:52 --> Language Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Loader Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:13:52 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Session Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:13:52 --> Session routines successfully run
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Controller Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:13:52 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Config Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:13:52 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:13:52 --> URI Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Router Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Output Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Security Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Input Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:13:53 --> Language Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Loader Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:13:53 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Session Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:13:53 --> Session routines successfully run
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Controller Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Model Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:13:53 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:13:53 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:13:53 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:13:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:13:53 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:13:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:13:53 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:13:53 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:13:53 --> Final output sent to browser
DEBUG - 2015-05-14 12:13:53 --> Total execution time: 0.0584
DEBUG - 2015-05-14 12:15:02 --> Config Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:15:02 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:15:02 --> URI Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Router Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Output Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Security Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Input Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:15:02 --> Language Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Loader Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:15:02 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Session Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:15:02 --> Session routines successfully run
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Controller Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:15:02 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:15:02 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:15:02 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:15:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:15:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:15:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:15:02 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:15:02 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-14 12:15:02 --> Final output sent to browser
DEBUG - 2015-05-14 12:15:02 --> Total execution time: 0.0604
DEBUG - 2015-05-14 12:15:04 --> Config Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:15:04 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:15:04 --> URI Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Router Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Output Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Security Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Input Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:15:04 --> Language Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Loader Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:15:04 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Session Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:15:04 --> Session routines successfully run
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Controller Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Model Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:15:04 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:15:04 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:15:04 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:15:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:15:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:15:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:15:04 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:15:04 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:15:04 --> Final output sent to browser
DEBUG - 2015-05-14 12:15:04 --> Total execution time: 0.0630
DEBUG - 2015-05-14 12:16:39 --> Config Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:16:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:16:39 --> URI Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Router Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Output Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Security Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Input Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:16:39 --> Language Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Loader Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:16:39 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Session Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:16:39 --> Session routines successfully run
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Controller Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Model Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:16:39 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:16:39 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:16:39 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:16:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:16:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:16:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:16:39 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:16:39 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:16:39 --> Final output sent to browser
DEBUG - 2015-05-14 12:16:39 --> Total execution time: 0.0764
DEBUG - 2015-05-14 12:21:24 --> Config Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:21:24 --> URI Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Router Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Output Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Security Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Input Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:21:24 --> Language Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Loader Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:21:24 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Session Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:21:24 --> Session routines successfully run
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Controller Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:21:24 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:21:24 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:21:24 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:21:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:21:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:21:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:21:24 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:21:24 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:21:24 --> Final output sent to browser
DEBUG - 2015-05-14 12:21:24 --> Total execution time: 0.0830
DEBUG - 2015-05-14 12:21:27 --> Config Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:21:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:21:27 --> URI Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Router Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Output Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Security Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Input Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:21:27 --> Language Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Loader Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:21:27 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Session Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:21:27 --> Session routines successfully run
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Controller Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:21:27 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Config Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:21:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:21:27 --> URI Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Router Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Output Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Security Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Input Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:21:27 --> Language Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Loader Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:21:27 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Session Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:21:27 --> Session routines successfully run
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Controller Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:21:27 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:21:27 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:21:27 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:21:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:21:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:21:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:21:27 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:21:27 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:21:27 --> Final output sent to browser
DEBUG - 2015-05-14 12:21:27 --> Total execution time: 0.0583
DEBUG - 2015-05-14 12:21:52 --> Config Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:21:52 --> URI Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Router Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Output Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Security Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Input Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:21:52 --> Language Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Loader Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:21:52 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Session Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:21:52 --> Session routines successfully run
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Controller Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:21:52 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Config Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:21:52 --> URI Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Router Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Output Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Security Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Input Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:21:52 --> Language Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Loader Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:21:52 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Session Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:21:52 --> Session routines successfully run
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Controller Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Model Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:21:52 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:21:52 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:21:52 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:21:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:21:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:21:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:21:52 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:21:52 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:21:52 --> Final output sent to browser
DEBUG - 2015-05-14 12:21:52 --> Total execution time: 0.0572
DEBUG - 2015-05-14 12:22:48 --> Config Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:22:48 --> URI Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Router Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Output Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Security Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Input Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:22:48 --> Language Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Loader Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:22:48 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Session Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:22:48 --> Session routines successfully run
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Controller Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:22:48 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Config Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:22:48 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:22:48 --> URI Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Router Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Output Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Security Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Input Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:22:48 --> Language Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Loader Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:22:48 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Session Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:22:48 --> Session routines successfully run
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Controller Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Model Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:22:48 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:22:48 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:22:48 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:22:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:22:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:22:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:22:48 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:22:48 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:22:48 --> Final output sent to browser
DEBUG - 2015-05-14 12:22:48 --> Total execution time: 0.0580
DEBUG - 2015-05-14 12:24:38 --> Config Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:24:38 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:24:38 --> URI Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Router Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Output Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Security Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Input Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:24:38 --> Language Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Loader Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:24:38 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Session Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:24:38 --> Session routines successfully run
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Controller Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:24:38 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:24:38 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:24:38 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:24:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:24:38 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:24:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:24:38 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:24:38 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:24:38 --> Final output sent to browser
DEBUG - 2015-05-14 12:24:38 --> Total execution time: 0.0637
DEBUG - 2015-05-14 12:24:43 --> Config Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:24:43 --> URI Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Router Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Output Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Security Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Input Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:24:43 --> Language Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Loader Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:24:43 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Session Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:24:43 --> Session routines successfully run
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Controller Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:24:43 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Config Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:24:43 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:24:43 --> URI Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Router Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Output Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Security Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Input Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:24:43 --> Language Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Loader Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:24:43 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Session Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:24:43 --> Session routines successfully run
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Controller Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Model Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:24:43 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:24:43 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:24:43 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:24:43 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:24:43 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:24:43 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:24:43 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:24:43 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:24:43 --> Final output sent to browser
DEBUG - 2015-05-14 12:24:43 --> Total execution time: 0.0598
DEBUG - 2015-05-14 12:25:29 --> Config Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:25:29 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:25:29 --> URI Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Router Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Output Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Security Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Input Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:25:29 --> Language Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Loader Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:25:29 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Session Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:25:29 --> Session routines successfully run
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Controller Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:25:29 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:25:29 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:25:29 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:25:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:25:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:25:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:25:29 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:25:29 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:25:29 --> Final output sent to browser
DEBUG - 2015-05-14 12:25:29 --> Total execution time: 0.0642
DEBUG - 2015-05-14 12:25:37 --> Config Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:25:37 --> URI Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Router Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Output Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Security Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Input Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:25:37 --> Language Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Loader Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:25:37 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Session Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:25:37 --> Session routines successfully run
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Controller Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:25:37 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:25:37 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:25:37 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:25:37 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:25:37 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-14 12:25:37 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:25:37 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:25:37 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-14 12:25:37 --> Final output sent to browser
DEBUG - 2015-05-14 12:25:37 --> Total execution time: 0.0635
DEBUG - 2015-05-14 12:25:49 --> Config Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:25:49 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:25:49 --> URI Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Router Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Output Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Security Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Input Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:25:49 --> Language Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Loader Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:25:49 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Session Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:25:49 --> Session routines successfully run
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Controller Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:25:49 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Config Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:25:49 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:25:49 --> URI Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Router Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Output Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Security Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Input Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:25:49 --> Language Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Loader Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:25:49 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Session Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:25:49 --> Session routines successfully run
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Controller Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Model Class Initialized
DEBUG - 2015-05-14 12:25:49 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:25:49 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:25:49 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-14 12:25:49 --> Final output sent to browser
DEBUG - 2015-05-14 12:25:49 --> Total execution time: 0.0318
DEBUG - 2015-05-14 12:26:06 --> Config Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:26:06 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:26:06 --> URI Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Router Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Output Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Security Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Input Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:26:06 --> Language Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Loader Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:26:06 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Session Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:26:06 --> Session routines successfully run
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Controller Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:26:06 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-14 12:26:06 --> Config Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:26:06 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:26:06 --> URI Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Router Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Output Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Security Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Input Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:26:06 --> Language Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Loader Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:26:06 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Session Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:26:06 --> Session routines successfully run
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Controller Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:26:06 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:26:06 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:26:06 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:26:06 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:26:06 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-14 12:26:06 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:26:06 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:26:06 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-05-14 12:26:06 --> Final output sent to browser
DEBUG - 2015-05-14 12:26:06 --> Total execution time: 0.0404
DEBUG - 2015-05-14 12:26:07 --> Config Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:26:07 --> URI Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Router Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Output Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Security Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Input Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:26:07 --> Language Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Loader Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:26:07 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Session Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:26:07 --> Session routines successfully run
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Controller Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:26:07 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:26:07 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:26:07 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:26:07 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:26:07 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-14 12:26:07 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:26:07 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:26:07 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-14 12:26:07 --> Final output sent to browser
DEBUG - 2015-05-14 12:26:07 --> Total execution time: 0.0468
DEBUG - 2015-05-14 12:26:09 --> Config Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:26:09 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:26:09 --> URI Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Router Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Output Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Security Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Input Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:26:09 --> Language Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Loader Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:26:09 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Session Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:26:09 --> Session routines successfully run
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Controller Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:26:09 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:26:09 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:26:09 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:26:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:26:09 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-14 12:26:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:26:09 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:26:09 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-14 12:26:09 --> Final output sent to browser
DEBUG - 2015-05-14 12:26:09 --> Total execution time: 0.0598
DEBUG - 2015-05-14 12:26:51 --> Config Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Hooks Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Utf8 Class Initialized
DEBUG - 2015-05-14 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2015-05-14 12:26:51 --> URI Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Router Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Output Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Security Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Input Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-14 12:26:51 --> Language Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Loader Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Helper loaded: url_helper
DEBUG - 2015-05-14 12:26:51 --> Database Driver Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Session Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Helper loaded: string_helper
DEBUG - 2015-05-14 12:26:51 --> Session routines successfully run
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Controller Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Model Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Helper loaded: form_helper
DEBUG - 2015-05-14 12:26:51 --> Form Validation Class Initialized
DEBUG - 2015-05-14 12:26:51 --> Pagination Class Initialized
DEBUG - 2015-05-14 12:26:51 --> File loaded: application/views/header.php
DEBUG - 2015-05-14 12:26:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-14 12:26:51 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-05-14 12:26:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-14 12:26:51 --> File loaded: application/views/footer.php
DEBUG - 2015-05-14 12:26:51 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-14 12:26:51 --> Final output sent to browser
DEBUG - 2015-05-14 12:26:51 --> Total execution time: 0.0552
