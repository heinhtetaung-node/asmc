<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-05-11 10:38:34 --> Config Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:38:34 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:38:34 --> URI Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Router Class Initialized
DEBUG - 2015-05-11 10:38:34 --> No URI present. Default controller set.
DEBUG - 2015-05-11 10:38:34 --> Output Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Security Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Input Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:38:34 --> Language Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Loader Class Initialized
DEBUG - 2015-05-11 10:38:34 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:38:35 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Session Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:38:35 --> A session cookie was not found.
DEBUG - 2015-05-11 10:38:35 --> Session routines successfully run
DEBUG - 2015-05-11 10:38:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Controller Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:35 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:38:35 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:38:35 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 10:38:35 --> Final output sent to browser
DEBUG - 2015-05-11 10:38:35 --> Total execution time: 0.1172
DEBUG - 2015-05-11 10:38:44 --> Config Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:38:44 --> URI Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Router Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Output Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Security Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Input Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:38:44 --> Language Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Loader Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:38:44 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Session Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:38:44 --> Session routines successfully run
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Controller Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:38:44 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:38:44 --> Config Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:38:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:38:44 --> URI Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Router Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Output Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Security Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Input Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:38:44 --> Language Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Loader Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:38:44 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Session Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:38:44 --> Session routines successfully run
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Controller Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:38:44 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:38:44 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:38:44 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:38:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:38:44 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-05-11 10:38:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:38:44 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:38:44 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-05-11 10:38:44 --> Final output sent to browser
DEBUG - 2015-05-11 10:38:44 --> Total execution time: 0.0494
DEBUG - 2015-05-11 10:38:45 --> Config Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:38:45 --> URI Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Router Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Output Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Security Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Input Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:38:45 --> Language Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Loader Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:38:45 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Session Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:38:45 --> Session routines successfully run
DEBUG - 2015-05-11 10:38:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Controller Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:38:46 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:38:46 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:38:46 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:38:46 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:38:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:38:46 --> File loaded: application/views/sidebar_manager.php
DEBUG - 2015-05-11 10:38:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:38:46 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:38:46 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:38:46 --> Final output sent to browser
DEBUG - 2015-05-11 10:38:46 --> Total execution time: 0.0838
DEBUG - 2015-05-11 10:39:02 --> Config Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:39:02 --> URI Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Router Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Output Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Security Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Input Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:39:02 --> Language Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Loader Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:39:02 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Session Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:39:02 --> Session routines successfully run
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Controller Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:39:02 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Config Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:39:02 --> URI Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Router Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Output Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Security Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Input Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:39:02 --> Language Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Loader Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:39:02 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Session Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:39:02 --> Session routines successfully run
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Controller Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:02 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:39:02 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:39:02 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 10:39:02 --> Final output sent to browser
DEBUG - 2015-05-11 10:39:02 --> Total execution time: 0.0348
DEBUG - 2015-05-11 10:39:08 --> Config Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:39:08 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:39:08 --> URI Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Router Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Output Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Security Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Input Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:39:08 --> Language Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Loader Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:39:08 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Session Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:39:08 --> Session routines successfully run
DEBUG - 2015-05-11 10:39:08 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Controller Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:39:08 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:39:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:39:09 --> Config Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:39:09 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:39:09 --> URI Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Router Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Output Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Security Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Input Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:39:09 --> Language Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Loader Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:39:09 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Session Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:39:09 --> Session routines successfully run
DEBUG - 2015-05-11 10:39:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Controller Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:09 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:39:09 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:39:09 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:39:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:39:09 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:39:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:39:09 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:39:09 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-05-11 10:39:09 --> Final output sent to browser
DEBUG - 2015-05-11 10:39:09 --> Total execution time: 0.0399
DEBUG - 2015-05-11 10:39:11 --> Config Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:39:11 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:39:11 --> URI Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Router Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Output Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Security Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Input Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:39:11 --> Language Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Loader Class Initialized
DEBUG - 2015-05-11 10:39:11 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:39:11 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Session Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:39:12 --> Session routines successfully run
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Controller Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:39:12 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:39:12 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:39:12 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:39:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:39:12 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:39:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:39:12 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:39:12 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 10:39:12 --> Final output sent to browser
DEBUG - 2015-05-11 10:39:12 --> Total execution time: 0.0623
DEBUG - 2015-05-11 10:39:22 --> Config Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:39:22 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:39:22 --> URI Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Router Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Output Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Security Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Input Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:39:22 --> Language Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Loader Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:39:22 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Session Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:39:22 --> Session routines successfully run
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Controller Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Model Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:39:22 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:39:22 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:39:22 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:39:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:39:22 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:39:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:39:22 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:39:22 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:39:22 --> Final output sent to browser
DEBUG - 2015-05-11 10:39:22 --> Total execution time: 0.0662
DEBUG - 2015-05-11 10:40:57 --> Config Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:40:57 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:40:57 --> URI Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Router Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Output Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Security Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Input Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:40:57 --> Language Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Loader Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:40:57 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Session Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:40:57 --> Session routines successfully run
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Controller Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Model Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:40:57 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:40:57 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:40:57 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:40:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:40:57 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:40:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:40:57 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:40:57 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:40:57 --> Final output sent to browser
DEBUG - 2015-05-11 10:40:57 --> Total execution time: 0.0777
DEBUG - 2015-05-11 10:41:40 --> Config Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:41:40 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:41:40 --> URI Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Router Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Output Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Security Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Input Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:41:40 --> Language Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Loader Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:41:40 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Session Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:41:40 --> Session routines successfully run
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Controller Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:41:40 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:41:40 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:41:40 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:41:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:41:40 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:41:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:41:40 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:41:40 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:41:40 --> Final output sent to browser
DEBUG - 2015-05-11 10:41:40 --> Total execution time: 0.0875
DEBUG - 2015-05-11 10:41:53 --> Config Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:41:53 --> URI Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Router Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Output Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Security Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Input Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:41:53 --> Language Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Loader Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:41:53 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Session Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:41:53 --> Session routines successfully run
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Controller Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:41:53 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:41:53 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:41:53 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:41:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:41:53 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:41:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:41:53 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:41:53 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 10:41:53 --> Final output sent to browser
DEBUG - 2015-05-11 10:41:53 --> Total execution time: 0.0654
DEBUG - 2015-05-11 10:41:58 --> Config Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:41:58 --> URI Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Router Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Output Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Security Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Input Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:41:58 --> Language Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Loader Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:41:58 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Session Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:41:58 --> Session routines successfully run
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Controller Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Model Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:41:58 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:41:58 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:41:58 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:41:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:41:58 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:41:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:41:58 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:41:58 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:41:58 --> Final output sent to browser
DEBUG - 2015-05-11 10:41:58 --> Total execution time: 0.0592
DEBUG - 2015-05-11 10:42:27 --> Config Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:42:27 --> URI Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Router Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Output Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Security Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Input Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:42:27 --> Language Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Loader Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:42:27 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Session Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:42:27 --> Session routines successfully run
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Controller Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:42:27 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:42:27 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:42:27 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:42:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:42:27 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:42:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:42:27 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:42:27 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:42:27 --> Final output sent to browser
DEBUG - 2015-05-11 10:42:27 --> Total execution time: 0.0596
DEBUG - 2015-05-11 10:42:35 --> Config Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:42:35 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:42:35 --> URI Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Router Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Output Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Security Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Input Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:42:35 --> Language Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Loader Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:42:35 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Session Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:42:35 --> Session routines successfully run
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Controller Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Model Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:42:35 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:42:35 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:42:35 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:42:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:42:35 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:42:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:42:35 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:42:35 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:42:35 --> Final output sent to browser
DEBUG - 2015-05-11 10:42:35 --> Total execution time: 0.0493
DEBUG - 2015-05-11 10:45:27 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:27 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:27 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:27 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:27 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:27 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:27 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:45:27 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:45:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:45:27 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:45:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:45:27 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:45:27 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 10:45:27 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:27 --> Total execution time: 0.1696
DEBUG - 2015-05-11 10:45:30 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:30 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:30 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:30 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:30 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:30 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:30 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:30 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:45:30 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:45:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:45:30 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:45:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:45:30 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:45:30 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:45:30 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:30 --> Total execution time: 0.1018
DEBUG - 2015-05-11 10:45:33 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:33 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:33 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:33 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:33 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:33 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:33 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:33 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:33 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:33 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:33 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:33 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:33 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 10:45:33 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:33 --> Total execution time: 0.0366
DEBUG - 2015-05-11 10:45:38 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:38 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:38 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:38 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:38 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:38 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:38 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:38 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:45:38 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 10:45:38 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:38 --> Total execution time: 0.0385
DEBUG - 2015-05-11 10:45:44 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:44 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:44 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:44 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:44 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:44 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:45:44 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:44 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:44 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:44 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:44 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:44 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:44 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:45:44 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:45:44 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:45:44 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:45:44 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:45:44 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:45:44 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-11 10:45:44 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:44 --> Total execution time: 0.0425
DEBUG - 2015-05-11 10:45:46 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:46 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:46 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:46 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:46 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:46 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:46 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:46 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:45:46 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:45:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:45:46 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:45:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:45:46 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:45:46 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 10:45:46 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:46 --> Total execution time: 0.0644
DEBUG - 2015-05-11 10:45:49 --> Config Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:45:49 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:45:49 --> URI Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Router Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Output Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Security Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Input Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:45:49 --> Language Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Loader Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:45:49 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Session Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:45:49 --> Session routines successfully run
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Controller Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Model Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:45:49 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:45:49 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:45:49 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:45:49 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:45:49 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:45:49 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:45:49 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:45:49 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:45:49 --> Final output sent to browser
DEBUG - 2015-05-11 10:45:49 --> Total execution time: 0.0598
DEBUG - 2015-05-11 10:46:09 --> Config Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:46:09 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:46:09 --> URI Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Router Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Output Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Security Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Input Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:46:09 --> Language Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Loader Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:46:09 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Session Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:46:09 --> Session routines successfully run
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Controller Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:46:09 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:46:09 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:46:09 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:46:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:46:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:46:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:46:09 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:46:09 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-11 10:46:09 --> Final output sent to browser
DEBUG - 2015-05-11 10:46:09 --> Total execution time: 0.0701
DEBUG - 2015-05-11 10:46:18 --> Config Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:46:18 --> URI Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Router Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Output Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Security Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Input Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:46:18 --> Language Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Loader Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:46:18 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Session Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:46:18 --> Session routines successfully run
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Controller Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:46:18 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:46:18 --> Config Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:46:18 --> URI Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Router Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Output Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Security Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Input Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:46:18 --> Language Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Loader Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:46:18 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Session Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:46:18 --> Session routines successfully run
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Controller Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Model Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:46:18 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:46:18 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:46:18 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:46:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:46:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:46:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:46:18 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:46:18 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:46:18 --> Final output sent to browser
DEBUG - 2015-05-11 10:46:18 --> Total execution time: 0.0600
DEBUG - 2015-05-11 10:48:12 --> Config Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:48:12 --> URI Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Router Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Output Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Security Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Input Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:48:12 --> Language Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Loader Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:48:12 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Session Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:48:12 --> Session routines successfully run
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Controller Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:48:12 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:48:12 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:48:12 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:48:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:48:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:48:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:48:12 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:48:12 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-11 10:48:12 --> Final output sent to browser
DEBUG - 2015-05-11 10:48:12 --> Total execution time: 0.0807
DEBUG - 2015-05-11 10:48:15 --> Config Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:48:15 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:48:15 --> URI Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Router Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Output Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Security Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Input Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:48:15 --> Language Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Loader Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:48:15 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Session Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:48:15 --> Session routines successfully run
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Controller Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:48:15 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:48:15 --> Config Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:48:15 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:48:15 --> URI Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Router Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Output Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Security Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Input Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:48:15 --> Language Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Loader Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:48:15 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Session Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:48:15 --> Session routines successfully run
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Controller Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Model Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:48:15 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:48:15 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:48:15 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:48:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:48:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:48:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:48:15 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:48:15 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:48:15 --> Final output sent to browser
DEBUG - 2015-05-11 10:48:15 --> Total execution time: 0.0534
DEBUG - 2015-05-11 10:55:01 --> Config Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:55:01 --> URI Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Router Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Output Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Security Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Input Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:55:01 --> Language Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Loader Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:55:01 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Session Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:55:01 --> Session routines successfully run
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Controller Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:55:01 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:55:01 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:55:01 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:55:01 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:55:01 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:55:01 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:55:01 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:55:01 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-11 10:55:01 --> Final output sent to browser
DEBUG - 2015-05-11 10:55:01 --> Total execution time: 0.0980
DEBUG - 2015-05-11 10:55:04 --> Config Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:55:04 --> URI Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Router Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Output Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Security Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Input Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:55:04 --> Language Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Loader Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:55:04 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Session Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:55:04 --> Session routines successfully run
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Controller Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:55:04 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:55:04 --> Config Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:55:04 --> URI Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Router Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Output Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Security Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Input Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:55:04 --> Language Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Loader Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:55:04 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Session Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:55:04 --> Session routines successfully run
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Controller Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Model Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:55:04 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:55:04 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:55:04 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:55:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:55:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:55:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:55:04 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:55:04 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:55:04 --> Final output sent to browser
DEBUG - 2015-05-11 10:55:04 --> Total execution time: 0.0541
DEBUG - 2015-05-11 10:56:39 --> Config Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:56:39 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:56:39 --> URI Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Router Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Output Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Security Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Input Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:56:39 --> Language Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Loader Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:56:39 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Session Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:56:39 --> Session routines successfully run
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Controller Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:56:39 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:56:39 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:56:39 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:56:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:56:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:56:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:56:39 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:56:39 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-11 10:56:39 --> Final output sent to browser
DEBUG - 2015-05-11 10:56:39 --> Total execution time: 0.0912
DEBUG - 2015-05-11 10:56:41 --> Config Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:56:41 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:56:41 --> URI Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Router Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Output Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Security Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Input Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:56:41 --> Language Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Loader Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:56:41 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Session Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:56:41 --> Session routines successfully run
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Controller Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Model Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:56:41 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:56:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:58:20 --> Config Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:58:20 --> URI Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Router Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Output Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Security Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Input Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:58:20 --> Language Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Loader Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:58:20 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Session Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:58:20 --> Session routines successfully run
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Controller Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:58:20 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:58:20 --> Config Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:58:20 --> URI Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Router Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Output Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Security Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Input Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:58:20 --> Language Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Loader Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:58:20 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Session Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:58:20 --> Session routines successfully run
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Controller Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Model Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:58:20 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:58:20 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:58:20 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:58:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:58:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 10:58:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:58:20 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:58:20 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 10:58:20 --> Final output sent to browser
DEBUG - 2015-05-11 10:58:20 --> Total execution time: 0.0571
DEBUG - 2015-05-11 10:59:45 --> Config Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:59:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:59:45 --> URI Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Router Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Output Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Security Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Input Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:59:45 --> Language Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Loader Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:59:45 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Session Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:59:45 --> Session routines successfully run
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Controller Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:59:45 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Config Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:59:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:59:45 --> URI Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Router Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Output Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Security Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Input Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:59:45 --> Language Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Loader Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:59:45 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Session Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:59:45 --> Session routines successfully run
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Controller Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:45 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:59:45 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:59:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 10:59:45 --> Final output sent to browser
DEBUG - 2015-05-11 10:59:45 --> Total execution time: 0.0362
DEBUG - 2015-05-11 10:59:51 --> Config Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:59:51 --> URI Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Router Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Output Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Security Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Input Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:59:51 --> Language Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Loader Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:59:51 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Session Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:59:51 --> Session routines successfully run
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Controller Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:59:51 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 10:59:51 --> Config Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:59:51 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:59:51 --> URI Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Router Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Output Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Security Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Input Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:59:51 --> Language Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Loader Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:59:51 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Session Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:59:51 --> Session routines successfully run
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Controller Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:51 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:59:51 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:59:51 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:59:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:59:51 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:59:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:59:51 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:59:51 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-05-11 10:59:51 --> Final output sent to browser
DEBUG - 2015-05-11 10:59:51 --> Total execution time: 0.0472
DEBUG - 2015-05-11 10:59:53 --> Config Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:59:53 --> URI Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Router Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Output Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Security Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Input Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:59:53 --> Language Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Loader Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Session Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:59:53 --> Session routines successfully run
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Controller Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:59:53 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:59:53 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 10:59:54 --> Final output sent to browser
DEBUG - 2015-05-11 10:59:54 --> Total execution time: 0.0465
DEBUG - 2015-05-11 10:59:54 --> Config Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Hooks Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Utf8 Class Initialized
DEBUG - 2015-05-11 10:59:54 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 10:59:54 --> URI Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Router Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Output Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Security Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Input Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 10:59:54 --> Language Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Loader Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Helper loaded: url_helper
DEBUG - 2015-05-11 10:59:54 --> Database Driver Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Session Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Helper loaded: string_helper
DEBUG - 2015-05-11 10:59:54 --> Session routines successfully run
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Controller Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Model Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Helper loaded: form_helper
DEBUG - 2015-05-11 10:59:54 --> Form Validation Class Initialized
DEBUG - 2015-05-11 10:59:54 --> Pagination Class Initialized
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 10:59:54 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-05-11 10:59:54 --> Final output sent to browser
DEBUG - 2015-05-11 10:59:54 --> Total execution time: 0.0560
DEBUG - 2015-05-11 11:00:18 --> Config Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:00:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:00:18 --> URI Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Router Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Output Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Security Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Input Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:00:18 --> Language Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Loader Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:00:18 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Session Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:00:18 --> Session routines successfully run
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Controller Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:00:18 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Config Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:00:18 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:00:18 --> URI Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Router Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Output Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Security Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Input Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:00:18 --> Language Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Loader Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:00:18 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Session Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:00:18 --> Session routines successfully run
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Controller Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:18 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:00:18 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:00:18 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 11:00:18 --> Final output sent to browser
DEBUG - 2015-05-11 11:00:18 --> Total execution time: 0.0347
DEBUG - 2015-05-11 11:00:24 --> Config Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:00:24 --> URI Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Router Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Output Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Security Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Input Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:00:24 --> Language Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Loader Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:00:24 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Session Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:00:24 --> Session routines successfully run
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Controller Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:00:24 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 11:00:24 --> Config Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:00:24 --> URI Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Router Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Output Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Security Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Input Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:00:24 --> Language Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Loader Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:00:24 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Session Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:00:24 --> Session routines successfully run
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Controller Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:00:24 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:00:24 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:00:24 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:00:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:00:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:00:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:00:24 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:00:24 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-11 11:00:24 --> Final output sent to browser
DEBUG - 2015-05-11 11:00:24 --> Total execution time: 0.0422
DEBUG - 2015-05-11 11:00:26 --> Config Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:00:26 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:00:26 --> URI Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Router Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Output Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Security Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Input Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:00:26 --> Language Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Loader Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:00:26 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Session Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:00:26 --> Session routines successfully run
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Controller Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:00:26 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:00:26 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:00:26 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:00:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:00:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:00:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:00:26 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:00:26 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 11:00:26 --> Final output sent to browser
DEBUG - 2015-05-11 11:00:26 --> Total execution time: 0.0618
DEBUG - 2015-05-11 11:00:29 --> Config Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:00:29 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:00:29 --> URI Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Router Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Output Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Security Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Input Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:00:29 --> Language Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Loader Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:00:29 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Session Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:00:29 --> Session routines successfully run
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Controller Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Model Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:00:29 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:00:29 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:00:29 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:00:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:00:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:00:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:00:29 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:00:29 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 11:00:29 --> Final output sent to browser
DEBUG - 2015-05-11 11:00:29 --> Total execution time: 0.0604
DEBUG - 2015-05-11 11:01:04 --> Config Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:01:04 --> URI Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Router Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Output Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Security Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Input Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:01:04 --> Language Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Loader Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:01:04 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Session Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:01:04 --> Session routines successfully run
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Controller Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:01:04 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:01:04 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:01:04 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:01:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:01:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:01:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:01:04 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:01:04 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-05-11 11:01:04 --> Final output sent to browser
DEBUG - 2015-05-11 11:01:04 --> Total execution time: 0.0852
DEBUG - 2015-05-11 11:01:07 --> Config Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:01:07 --> URI Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Router Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Output Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Security Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Input Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:01:07 --> Language Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Loader Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:01:07 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Session Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:01:07 --> Session routines successfully run
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Controller Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:01:07 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 11:01:07 --> Config Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:01:07 --> URI Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Router Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Output Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Security Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Input Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:01:07 --> Language Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Loader Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:01:07 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Session Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:01:07 --> Session routines successfully run
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Controller Class Initialized
DEBUG - 2015-05-11 11:01:07 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:08 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:08 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:08 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:08 --> Model Class Initialized
DEBUG - 2015-05-11 11:01:08 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:01:08 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:01:08 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:01:08 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:01:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:01:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:01:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:01:08 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:01:08 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 11:01:08 --> Final output sent to browser
DEBUG - 2015-05-11 11:01:08 --> Total execution time: 0.0518
DEBUG - 2015-05-11 11:02:33 --> Config Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:02:33 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:02:33 --> URI Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Router Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Output Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Security Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Input Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:02:33 --> Language Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Loader Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:02:33 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Session Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:02:33 --> Session routines successfully run
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Controller Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:02:33 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:02:33 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:02:33 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:02:33 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:02:33 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:02:33 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:02:33 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:02:33 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 11:02:33 --> Final output sent to browser
DEBUG - 2015-05-11 11:02:33 --> Total execution time: 0.0855
DEBUG - 2015-05-11 11:02:45 --> Config Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:02:45 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:02:45 --> URI Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Router Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Output Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Security Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Input Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:02:45 --> Language Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Loader Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:02:45 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Session Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:02:45 --> Session routines successfully run
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Controller Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Model Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:02:45 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:02:45 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:02:45 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 11:02:45 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 11:02:45 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 11:02:45 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 11:02:45 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 11:02:45 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 11:02:45 --> Final output sent to browser
DEBUG - 2015-05-11 11:02:45 --> Total execution time: 0.0857
DEBUG - 2015-05-11 11:05:54 --> Config Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:05:54 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:05:54 --> URI Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Router Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Output Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Security Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Input Class Initialized
DEBUG - 2015-05-11 11:05:54 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:05:54 --> Language Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Config Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:06:10 --> URI Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Router Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Output Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Security Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Input Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:06:10 --> Language Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Loader Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:06:10 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Session Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:06:10 --> Session routines successfully run
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Controller Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:06:10 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:06:10 --> Final output sent to browser
DEBUG - 2015-05-11 11:06:10 --> Total execution time: 0.0483
DEBUG - 2015-05-11 11:06:53 --> Config Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:06:53 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:06:53 --> URI Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Router Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Output Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Security Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Input Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:06:53 --> Language Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Loader Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:06:53 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Session Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:06:53 --> Session routines successfully run
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Controller Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:06:53 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:06:53 --> Final output sent to browser
DEBUG - 2015-05-11 11:06:53 --> Total execution time: 0.0426
DEBUG - 2015-05-11 11:06:59 --> Config Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Hooks Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Utf8 Class Initialized
DEBUG - 2015-05-11 11:06:59 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 11:06:59 --> URI Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Router Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Output Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Security Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Input Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 11:06:59 --> Language Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Loader Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Helper loaded: url_helper
DEBUG - 2015-05-11 11:06:59 --> Database Driver Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Session Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Helper loaded: string_helper
DEBUG - 2015-05-11 11:06:59 --> Session routines successfully run
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Controller Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Model Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Helper loaded: form_helper
DEBUG - 2015-05-11 11:06:59 --> Form Validation Class Initialized
DEBUG - 2015-05-11 11:06:59 --> Pagination Class Initialized
DEBUG - 2015-05-11 11:07:00 --> Final output sent to browser
DEBUG - 2015-05-11 11:07:00 --> Total execution time: 0.4249
DEBUG - 2015-05-11 13:06:16 --> Config Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Hooks Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Utf8 Class Initialized
DEBUG - 2015-05-11 13:06:16 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 13:06:16 --> URI Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Router Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Output Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Security Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Input Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 13:06:16 --> Language Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Loader Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Helper loaded: url_helper
DEBUG - 2015-05-11 13:06:16 --> Database Driver Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Session Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Helper loaded: string_helper
DEBUG - 2015-05-11 13:06:16 --> A session cookie was not found.
DEBUG - 2015-05-11 13:06:16 --> Session routines successfully run
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Controller Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Config Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Hooks Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Utf8 Class Initialized
DEBUG - 2015-05-11 13:06:16 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 13:06:16 --> URI Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Router Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Output Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Security Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Input Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 13:06:16 --> Language Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Loader Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Helper loaded: url_helper
DEBUG - 2015-05-11 13:06:16 --> Database Driver Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Session Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Helper loaded: string_helper
DEBUG - 2015-05-11 13:06:16 --> Session routines successfully run
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Controller Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:16 --> Helper loaded: form_helper
DEBUG - 2015-05-11 13:06:16 --> Form Validation Class Initialized
DEBUG - 2015-05-11 13:06:16 --> File loaded: application/views/loginView.php
DEBUG - 2015-05-11 13:06:16 --> Final output sent to browser
DEBUG - 2015-05-11 13:06:16 --> Total execution time: 0.0374
DEBUG - 2015-05-11 13:06:25 --> Config Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Hooks Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Utf8 Class Initialized
DEBUG - 2015-05-11 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 13:06:25 --> URI Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Router Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Output Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Security Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Input Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 13:06:25 --> Language Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Loader Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Helper loaded: url_helper
DEBUG - 2015-05-11 13:06:25 --> Database Driver Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Session Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Helper loaded: string_helper
DEBUG - 2015-05-11 13:06:25 --> Session routines successfully run
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Controller Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Helper loaded: form_helper
DEBUG - 2015-05-11 13:06:25 --> Form Validation Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-05-11 13:06:25 --> Config Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Hooks Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Utf8 Class Initialized
DEBUG - 2015-05-11 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 13:06:25 --> URI Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Router Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Output Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Security Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Input Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 13:06:25 --> Language Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Loader Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Helper loaded: url_helper
DEBUG - 2015-05-11 13:06:25 --> Database Driver Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Session Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Helper loaded: string_helper
DEBUG - 2015-05-11 13:06:25 --> Session routines successfully run
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Controller Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Helper loaded: form_helper
DEBUG - 2015-05-11 13:06:25 --> Form Validation Class Initialized
DEBUG - 2015-05-11 13:06:25 --> Pagination Class Initialized
DEBUG - 2015-05-11 13:06:25 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 13:06:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 13:06:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 13:06:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 13:06:25 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 13:06:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-05-11 13:06:25 --> Final output sent to browser
DEBUG - 2015-05-11 13:06:25 --> Total execution time: 0.0438
DEBUG - 2015-05-11 13:06:27 --> Config Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Hooks Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Utf8 Class Initialized
DEBUG - 2015-05-11 13:06:27 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 13:06:27 --> URI Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Router Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Output Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Security Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Input Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 13:06:27 --> Language Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Loader Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Helper loaded: url_helper
DEBUG - 2015-05-11 13:06:27 --> Database Driver Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Session Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Helper loaded: string_helper
DEBUG - 2015-05-11 13:06:27 --> Session routines successfully run
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Controller Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Helper loaded: form_helper
DEBUG - 2015-05-11 13:06:27 --> Form Validation Class Initialized
DEBUG - 2015-05-11 13:06:27 --> Pagination Class Initialized
DEBUG - 2015-05-11 13:06:27 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 13:06:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 13:06:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 13:06:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 13:06:27 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 13:06:27 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-05-11 13:06:27 --> Final output sent to browser
DEBUG - 2015-05-11 13:06:27 --> Total execution time: 0.0767
DEBUG - 2015-05-11 13:06:29 --> Config Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Hooks Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Utf8 Class Initialized
DEBUG - 2015-05-11 13:06:29 --> UTF-8 Support Enabled
DEBUG - 2015-05-11 13:06:29 --> URI Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Router Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Output Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Security Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Input Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-05-11 13:06:29 --> Language Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Loader Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Helper loaded: url_helper
DEBUG - 2015-05-11 13:06:29 --> Database Driver Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Session Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Helper loaded: string_helper
DEBUG - 2015-05-11 13:06:29 --> Session routines successfully run
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Controller Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Model Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Helper loaded: form_helper
DEBUG - 2015-05-11 13:06:29 --> Form Validation Class Initialized
DEBUG - 2015-05-11 13:06:29 --> Pagination Class Initialized
DEBUG - 2015-05-11 13:06:29 --> File loaded: application/views/header.php
DEBUG - 2015-05-11 13:06:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-05-11 13:06:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-05-11 13:06:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-05-11 13:06:29 --> File loaded: application/views/footer.php
DEBUG - 2015-05-11 13:06:29 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-05-11 13:06:29 --> Final output sent to browser
DEBUG - 2015-05-11 13:06:29 --> Total execution time: 0.0674
