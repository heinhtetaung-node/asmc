<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-07-29 12:19:50 --> Config Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Hooks Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Utf8 Class Initialized
DEBUG - 2016-07-29 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2016-07-29 12:19:50 --> URI Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Router Class Initialized
DEBUG - 2016-07-29 12:19:50 --> No URI present. Default controller set.
DEBUG - 2016-07-29 12:19:50 --> Output Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Security Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Input Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-29 12:19:50 --> Language Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Loader Class Initialized
DEBUG - 2016-07-29 12:19:50 --> Helper loaded: url_helper
DEBUG - 2016-07-29 12:19:50 --> Database Driver Class Initialized
ERROR - 2016-07-29 12:19:50 --> Severity: Warning  --> mysqli_connect(): (HY000/1045): Access denied for user 'sgdatacr_admin'@'localhost' (using password: YES) D:\xampp\htdocs\asmc\system\database\drivers\mysqli\mysqli_driver.php 76
ERROR - 2016-07-29 12:19:50 --> Unable to connect to the database
DEBUG - 2016-07-29 12:19:50 --> Language file loaded: language/english/db_lang.php
DEBUG - 2016-07-29 12:35:09 --> Config Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Hooks Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Utf8 Class Initialized
DEBUG - 2016-07-29 12:35:09 --> UTF-8 Support Enabled
DEBUG - 2016-07-29 12:35:09 --> URI Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Router Class Initialized
DEBUG - 2016-07-29 12:35:09 --> No URI present. Default controller set.
DEBUG - 2016-07-29 12:35:09 --> Output Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Security Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Input Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-29 12:35:09 --> Language Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Loader Class Initialized
DEBUG - 2016-07-29 12:35:09 --> Helper loaded: url_helper
DEBUG - 2016-07-29 12:35:09 --> Database Driver Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Session Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Helper loaded: string_helper
DEBUG - 2016-07-29 12:35:10 --> A session cookie was not found.
DEBUG - 2016-07-29 12:35:10 --> Session routines successfully run
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Controller Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Model Class Initialized
DEBUG - 2016-07-29 12:35:10 --> Helper loaded: form_helper
DEBUG - 2016-07-29 12:35:10 --> Form Validation Class Initialized
DEBUG - 2016-07-29 12:35:10 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-29 12:35:10 --> Final output sent to browser
DEBUG - 2016-07-29 12:35:10 --> Total execution time: 0.3590
DEBUG - 2016-07-29 12:56:21 --> Config Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Hooks Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Utf8 Class Initialized
DEBUG - 2016-07-29 12:56:22 --> UTF-8 Support Enabled
DEBUG - 2016-07-29 12:56:22 --> URI Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Router Class Initialized
DEBUG - 2016-07-29 12:56:22 --> No URI present. Default controller set.
DEBUG - 2016-07-29 12:56:22 --> Output Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Security Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Input Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-07-29 12:56:22 --> Language Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Loader Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Helper loaded: url_helper
DEBUG - 2016-07-29 12:56:22 --> Database Driver Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Session Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Helper loaded: string_helper
DEBUG - 2016-07-29 12:56:22 --> Session routines successfully run
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Controller Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Model Class Initialized
DEBUG - 2016-07-29 12:56:22 --> Helper loaded: form_helper
DEBUG - 2016-07-29 12:56:22 --> Form Validation Class Initialized
DEBUG - 2016-07-29 12:56:22 --> File loaded: application/views/loginView.php
DEBUG - 2016-07-29 12:56:22 --> Final output sent to browser
DEBUG - 2016-07-29 12:56:22 --> Total execution time: 0.1019
