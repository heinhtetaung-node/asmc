<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2015-04-01 11:26:31 --> Config Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:26:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:26:31 --> URI Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Router Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Output Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Security Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Input Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:26:31 --> Language Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Loader Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:26:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Session Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:26:31 --> Session routines successfully run
DEBUG - 2015-04-01 11:26:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:31 --> Controller Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Config Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:26:43 --> URI Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Router Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Output Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Security Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Input Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:26:43 --> Language Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Loader Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:26:43 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Session Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:26:43 --> Session routines successfully run
DEBUG - 2015-04-01 11:26:43 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:43 --> Controller Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Config Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:26:46 --> URI Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Router Class Initialized
DEBUG - 2015-04-01 11:26:46 --> No URI present. Default controller set.
DEBUG - 2015-04-01 11:26:46 --> Output Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Security Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Input Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:26:46 --> Language Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Loader Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:26:46 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Session Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:26:46 --> Session routines successfully run
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Controller Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:26:46 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Config Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:26:46 --> URI Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Router Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Output Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Security Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Input Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:26:46 --> Language Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Loader Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:26:46 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Session Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:26:46 --> Session routines successfully run
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:26:46 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:20 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:20 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:20 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:20 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:20 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:20 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:20 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 11:27:20 --> Final output sent to browser
DEBUG - 2015-04-01 11:27:20 --> Total execution time: 0.0328
DEBUG - 2015-04-01 11:27:27 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:27 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:27 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:27 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:27 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:27:27 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 11:27:27 --> Final output sent to browser
DEBUG - 2015-04-01 11:27:27 --> Total execution time: 0.0338
DEBUG - 2015-04-01 11:27:31 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:31 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:31 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:31 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:31 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:27:31 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 11:27:31 --> Final output sent to browser
DEBUG - 2015-04-01 11:27:31 --> Total execution time: 0.0406
DEBUG - 2015-04-01 11:27:36 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:36 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:36 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:36 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:27:36 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:36 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:36 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:36 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:36 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:27:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:27:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:27:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:27:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:27:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:27:36 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-01 11:27:36 --> Final output sent to browser
DEBUG - 2015-04-01 11:27:36 --> Total execution time: 0.0420
DEBUG - 2015-04-01 11:27:42 --> Config Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:27:42 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:27:42 --> URI Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Router Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Output Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Security Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Input Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:27:42 --> Language Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Loader Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:27:42 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Session Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:27:42 --> Session routines successfully run
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Controller Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Model Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:27:42 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:27:42 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:27:42 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:27:42 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:27:42 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:27:42 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:27:42 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:27:42 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-04-01 11:27:42 --> Final output sent to browser
DEBUG - 2015-04-01 11:27:42 --> Total execution time: 0.0584
DEBUG - 2015-04-01 11:28:36 --> Config Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:28:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:28:36 --> URI Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Router Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Output Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Security Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Input Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:28:36 --> Language Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Loader Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:28:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Session Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:28:36 --> Session routines successfully run
DEBUG - 2015-04-01 11:28:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Controller Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Model Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:28:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:28:36 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:28:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:28:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:28:36 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:28:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:28:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:28:36 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-01 11:28:36 --> Final output sent to browser
DEBUG - 2015-04-01 11:28:36 --> Total execution time: 0.0496
DEBUG - 2015-04-01 11:28:51 --> Config Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:28:51 --> URI Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Router Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Output Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Security Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Input Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:28:51 --> Language Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Loader Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:28:51 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Session Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:28:51 --> Session routines successfully run
DEBUG - 2015-04-01 11:28:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Controller Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Model Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:28:51 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:28:51 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:28:51 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:28:51 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:28:51 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:28:51 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:28:51 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:28:51 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:28:51 --> Final output sent to browser
DEBUG - 2015-04-01 11:28:51 --> Total execution time: 0.0533
DEBUG - 2015-04-01 11:29:14 --> Config Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:29:14 --> URI Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Router Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Output Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Security Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Input Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:29:14 --> Language Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Loader Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:29:14 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Session Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:29:14 --> Session routines successfully run
DEBUG - 2015-04-01 11:29:14 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Controller Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:29:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:29:14 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:29:14 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:29:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:29:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:29:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:29:14 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:29:14 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-01 11:29:14 --> Final output sent to browser
DEBUG - 2015-04-01 11:29:14 --> Total execution time: 0.0565
DEBUG - 2015-04-01 11:29:22 --> Config Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:29:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:29:22 --> URI Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Router Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Output Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Security Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Input Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:29:22 --> Language Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Loader Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:29:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Session Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:29:22 --> Session routines successfully run
DEBUG - 2015-04-01 11:29:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Controller Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:29:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:29:22 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:29:22 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:29:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:29:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:29:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:29:22 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:29:22 --> File loaded: application/views/manager/managerListView.php
DEBUG - 2015-04-01 11:29:22 --> Final output sent to browser
DEBUG - 2015-04-01 11:29:22 --> Total execution time: 0.0491
DEBUG - 2015-04-01 11:29:25 --> Config Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:29:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:29:25 --> URI Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Router Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Output Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Security Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Input Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:29:25 --> Language Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Loader Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:29:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Session Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:29:25 --> Session routines successfully run
DEBUG - 2015-04-01 11:29:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Controller Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:29:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:29:25 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:29:25 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:29:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:29:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:29:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:29:25 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:29:25 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-01 11:29:25 --> Final output sent to browser
DEBUG - 2015-04-01 11:29:25 --> Total execution time: 0.0547
DEBUG - 2015-04-01 11:29:29 --> Config Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:29:29 --> URI Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Router Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Output Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Security Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Input Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:29:29 --> Language Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Loader Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:29:29 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Session Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:29:29 --> Session routines successfully run
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Controller Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:29:29 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:29:29 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:29:29 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:29:29 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:29:29 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:29:29 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:29:29 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:29:29 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 11:29:29 --> Final output sent to browser
DEBUG - 2015-04-01 11:29:29 --> Total execution time: 0.0747
DEBUG - 2015-04-01 11:29:32 --> Config Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:29:32 --> URI Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Router Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Output Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Security Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Input Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:29:32 --> Language Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Loader Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:29:32 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Session Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:29:32 --> Session routines successfully run
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Controller Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Model Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:29:32 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:29:32 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:29:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:29:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:29:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:29:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:29:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:29:32 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:29:32 --> Final output sent to browser
DEBUG - 2015-04-01 11:29:32 --> Total execution time: 0.0637
DEBUG - 2015-04-01 11:33:27 --> Config Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:33:27 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:33:27 --> URI Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Router Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Output Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Security Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Input Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:33:27 --> Language Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Loader Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:33:27 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Session Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:33:27 --> Session routines successfully run
DEBUG - 2015-04-01 11:33:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Controller Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Model Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:33:27 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:33:27 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:33:27 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:33:27 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:33:27 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:33:27 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:33:27 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:33:27 --> File loaded: application/views/customer/customerListView.php
DEBUG - 2015-04-01 11:33:27 --> Final output sent to browser
DEBUG - 2015-04-01 11:33:27 --> Total execution time: 0.0630
DEBUG - 2015-04-01 11:33:39 --> Config Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:33:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:33:39 --> URI Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Router Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Output Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Security Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Input Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:33:39 --> Language Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Loader Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:33:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Session Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:33:39 --> Session routines successfully run
DEBUG - 2015-04-01 11:33:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Controller Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:33:39 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:33:39 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:33:39 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:33:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:33:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:33:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:33:39 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:33:39 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:33:39 --> Final output sent to browser
DEBUG - 2015-04-01 11:33:39 --> Total execution time: 0.0451
DEBUG - 2015-04-01 11:35:09 --> Config Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:35:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:35:09 --> URI Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Router Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Output Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Security Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Input Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:35:09 --> Language Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Loader Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:35:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Session Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:35:09 --> Session routines successfully run
DEBUG - 2015-04-01 11:35:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Controller Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:35:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:35:09 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:35:09 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:35:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:35:10 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:35:10 --> File loaded: application/views/sidebar.php
ERROR - 2015-04-01 11:35:10 --> Severity: Notice  --> Undefined variable: customer_project /Applications/MAMP/htdocs/asmc/crm/application/views/customer/addCustomerView.php 44
DEBUG - 2015-04-01 11:35:10 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:35:10 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:35:10 --> Final output sent to browser
DEBUG - 2015-04-01 11:35:10 --> Total execution time: 0.0597
DEBUG - 2015-04-01 11:36:39 --> Config Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:36:39 --> URI Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Router Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Output Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Security Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Input Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:36:39 --> Language Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Loader Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:36:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Session Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:36:39 --> Session routines successfully run
DEBUG - 2015-04-01 11:36:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Controller Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:36:39 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:36:39 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:36:39 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:36:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:36:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:36:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:36:39 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:36:39 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:36:39 --> Final output sent to browser
DEBUG - 2015-04-01 11:36:39 --> Total execution time: 0.0502
DEBUG - 2015-04-01 11:37:39 --> Config Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:37:39 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:37:39 --> URI Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Router Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Output Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Security Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Input Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:37:39 --> Language Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Loader Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:37:39 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Session Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:37:39 --> Session routines successfully run
DEBUG - 2015-04-01 11:37:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Controller Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:37:39 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:37:39 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:37:39 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:37:39 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:37:39 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:37:39 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:37:39 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:37:39 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:37:39 --> Final output sent to browser
DEBUG - 2015-04-01 11:37:39 --> Total execution time: 0.0486
DEBUG - 2015-04-01 11:37:47 --> Config Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:37:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:37:47 --> URI Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Router Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Output Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Security Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Input Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:37:47 --> Language Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Loader Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:37:47 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Session Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:37:47 --> Session routines successfully run
DEBUG - 2015-04-01 11:37:47 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Controller Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Model Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:37:47 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:37:47 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:37:47 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:37:47 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:37:47 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:37:47 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:37:47 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:37:47 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:37:47 --> Final output sent to browser
DEBUG - 2015-04-01 11:37:47 --> Total execution time: 0.0474
DEBUG - 2015-04-01 11:38:15 --> Config Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:38:15 --> URI Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Router Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Output Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Security Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Input Class Initialized
DEBUG - 2015-04-01 11:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:38:15 --> Language Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Loader Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:38:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Session Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:38:16 --> Session routines successfully run
DEBUG - 2015-04-01 11:38:16 --> Model Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Model Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Controller Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Model Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:38:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:38:16 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:38:16 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:38:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:38:16 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:38:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:38:16 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:38:16 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:38:16 --> Final output sent to browser
DEBUG - 2015-04-01 11:38:16 --> Total execution time: 0.0411
DEBUG - 2015-04-01 11:38:20 --> Config Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:38:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:38:20 --> URI Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Router Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Output Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Security Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Input Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:38:20 --> Language Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Loader Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:38:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Session Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:38:20 --> Session routines successfully run
DEBUG - 2015-04-01 11:38:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Controller Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Model Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:38:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:38:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:38:20 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:38:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:38:20 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:38:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:38:20 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:38:20 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 11:38:20 --> Final output sent to browser
DEBUG - 2015-04-01 11:38:20 --> Total execution time: 0.0475
DEBUG - 2015-04-01 11:43:11 --> Config Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:43:11 --> URI Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Router Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Output Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Security Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Input Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:43:11 --> Language Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Loader Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:43:11 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Session Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:43:11 --> Session routines successfully run
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Controller Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:43:11 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:43:11 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:43:11 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:43:11 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:43:11 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:43:11 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:43:11 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:43:11 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 11:43:11 --> Final output sent to browser
DEBUG - 2015-04-01 11:43:11 --> Total execution time: 0.0834
DEBUG - 2015-04-01 11:43:13 --> Config Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:43:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:43:13 --> URI Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Router Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Output Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Security Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Input Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:43:13 --> Language Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Loader Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:43:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Session Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:43:13 --> Session routines successfully run
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Controller Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:43:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:43:13 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:43:13 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:43:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:43:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:43:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:43:13 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:43:13 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:43:13 --> Final output sent to browser
DEBUG - 2015-04-01 11:43:13 --> Total execution time: 0.0680
DEBUG - 2015-04-01 11:44:15 --> Config Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:44:15 --> URI Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Router Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Output Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Security Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Input Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:44:15 --> Language Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Loader Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:44:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Session Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:44:15 --> Session routines successfully run
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Controller Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Model Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:44:15 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:44:15 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:44:15 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:44:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:44:15 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:44:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:44:15 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:44:15 --> File loaded: application/views/invoice/addInvoiceView.php
DEBUG - 2015-04-01 11:44:15 --> Final output sent to browser
DEBUG - 2015-04-01 11:44:15 --> Total execution time: 0.0560
DEBUG - 2015-04-01 11:46:00 --> Config Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:46:00 --> URI Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Router Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Output Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Security Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Input Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:46:00 --> Language Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Loader Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:46:00 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Session Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:46:00 --> Session routines successfully run
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Controller Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:46:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:46:00 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:46:00 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:46:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:46:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:46:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:46:00 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:46:00 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 11:46:00 --> Final output sent to browser
DEBUG - 2015-04-01 11:46:00 --> Total execution time: 0.0725
DEBUG - 2015-04-01 11:46:02 --> Config Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:46:02 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:46:02 --> URI Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Router Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Output Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Security Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Input Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:46:02 --> Language Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Loader Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:46:02 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Session Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:46:02 --> Session routines successfully run
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Controller Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:46:02 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:46:02 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:46:02 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:46:02 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:46:02 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:46:02 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:46:02 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:46:02 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:46:02 --> Final output sent to browser
DEBUG - 2015-04-01 11:46:02 --> Total execution time: 0.0630
DEBUG - 2015-04-01 11:46:09 --> Config Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:46:09 --> URI Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Router Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Output Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Security Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Input Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:46:09 --> Language Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Loader Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:46:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Session Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:46:09 --> Session routines successfully run
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Controller Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Model Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:46:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:46:09 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:46:09 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:46:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:46:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:46:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:46:09 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:46:09 --> File loaded: application/views/invoice/editInvoiceView.php
DEBUG - 2015-04-01 11:46:09 --> Final output sent to browser
DEBUG - 2015-04-01 11:46:09 --> Total execution time: 0.0632
DEBUG - 2015-04-01 11:48:31 --> Config Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:48:31 --> URI Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Router Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Output Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Security Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Input Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:48:31 --> Language Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Loader Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:48:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Session Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:48:31 --> Session routines successfully run
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Controller Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:48:31 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Config Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:48:31 --> URI Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Router Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Output Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Security Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Input Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:48:31 --> Language Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Loader Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:48:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Session Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:48:31 --> Session routines successfully run
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Controller Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:31 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:48:31 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:48:31 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 11:48:31 --> Final output sent to browser
DEBUG - 2015-04-01 11:48:31 --> Total execution time: 0.0362
DEBUG - 2015-04-01 11:48:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:48:53 --> URI Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Router Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Output Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Security Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Input Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:48:53 --> Language Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Loader Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:48:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Session Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:48:53 --> Session routines successfully run
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Controller Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:48:53 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:48:53 --> Config Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:48:53 --> URI Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Router Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Output Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Security Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Input Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:48:53 --> Language Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Loader Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:48:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Session Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:48:53 --> Session routines successfully run
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Controller Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:48:53 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:48:53 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:48:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:48:53 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:48:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:48:53 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:48:53 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-01 11:48:53 --> Final output sent to browser
DEBUG - 2015-04-01 11:48:53 --> Total execution time: 0.0414
DEBUG - 2015-04-01 11:48:57 --> Config Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:48:57 --> URI Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Router Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Output Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Security Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Input Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:48:57 --> Language Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Loader Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:48:57 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Session Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:48:57 --> Session routines successfully run
DEBUG - 2015-04-01 11:48:57 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Controller Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:48:57 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:48:57 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:48:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:48:57 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:48:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:48:57 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:48:57 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-04-01 11:48:57 --> Final output sent to browser
DEBUG - 2015-04-01 11:48:57 --> Total execution time: 0.0486
DEBUG - 2015-04-01 11:48:58 --> Config Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:48:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:48:58 --> URI Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Router Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Output Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Security Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Input Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:48:58 --> Language Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Loader Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:48:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Session Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:48:58 --> Session routines successfully run
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Controller Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Model Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:48:58 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:48:58 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:48:58 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:48:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:48:58 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:48:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:48:58 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:48:58 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 11:48:58 --> Final output sent to browser
DEBUG - 2015-04-01 11:48:58 --> Total execution time: 0.0526
DEBUG - 2015-04-01 11:49:00 --> Config Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:49:00 --> URI Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Router Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Output Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Security Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Input Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:49:00 --> Language Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Loader Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:49:00 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Session Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:49:00 --> Session routines successfully run
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Controller Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:49:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:49:00 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:49:00 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:49:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:49:00 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:49:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:49:00 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:49:00 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:49:00 --> Final output sent to browser
DEBUG - 2015-04-01 11:49:00 --> Total execution time: 0.0589
DEBUG - 2015-04-01 11:49:46 --> Config Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:49:46 --> URI Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Router Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Output Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Security Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Input Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:49:46 --> Language Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Loader Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:49:46 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Session Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:49:46 --> Session routines successfully run
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Controller Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Model Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:49:46 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:49:46 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:49:46 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:49:46 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:49:46 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:49:46 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:49:46 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:49:46 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:49:46 --> Final output sent to browser
DEBUG - 2015-04-01 11:49:46 --> Total execution time: 0.0659
DEBUG - 2015-04-01 11:50:08 --> Config Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:50:08 --> URI Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Router Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Output Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Security Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Input Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:50:08 --> Language Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Loader Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:50:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Session Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:50:08 --> Session routines successfully run
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Controller Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:50:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:50:08 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:50:08 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:50:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:50:08 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:50:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:50:08 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:50:08 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:50:08 --> Final output sent to browser
DEBUG - 2015-04-01 11:50:08 --> Total execution time: 0.0575
DEBUG - 2015-04-01 11:50:35 --> Config Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:50:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:50:35 --> URI Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Router Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Output Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Security Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Input Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:50:35 --> Language Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Loader Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:50:35 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Session Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:50:35 --> Session routines successfully run
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Controller Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:50:35 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:50:35 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:50:35 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:50:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:50:35 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:50:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:50:35 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:50:35 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:50:35 --> Final output sent to browser
DEBUG - 2015-04-01 11:50:35 --> Total execution time: 0.0627
DEBUG - 2015-04-01 11:51:35 --> Config Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:51:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:51:35 --> URI Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Router Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Output Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Security Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Input Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:51:35 --> Language Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Loader Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:51:35 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Session Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:51:35 --> Session routines successfully run
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Controller Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:51:35 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:51:35 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:51:35 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:51:35 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:51:35 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:51:35 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:51:35 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:51:35 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:51:35 --> Final output sent to browser
DEBUG - 2015-04-01 11:51:35 --> Total execution time: 0.0610
DEBUG - 2015-04-01 11:51:40 --> Config Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:51:40 --> URI Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Router Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Output Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Security Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Input Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:51:40 --> Language Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Loader Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:51:40 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Session Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:51:40 --> Session routines successfully run
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Controller Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:51:40 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:51:40 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:51:40 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:51:40 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:51:40 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 11:51:40 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:51:40 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:51:40 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 11:51:40 --> Final output sent to browser
DEBUG - 2015-04-01 11:51:40 --> Total execution time: 0.0532
DEBUG - 2015-04-01 11:51:45 --> Config Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:51:45 --> URI Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Router Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Output Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Security Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Input Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:51:45 --> Language Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Loader Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:51:45 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Session Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:51:45 --> Session routines successfully run
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Controller Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:51:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Config Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:51:45 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:51:45 --> URI Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Router Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Output Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Security Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Input Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:51:45 --> Language Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Loader Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:51:45 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Session Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:51:45 --> Session routines successfully run
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Controller Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Model Class Initialized
DEBUG - 2015-04-01 11:51:45 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:51:45 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:51:45 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 11:51:45 --> Final output sent to browser
DEBUG - 2015-04-01 11:51:45 --> Total execution time: 0.0343
DEBUG - 2015-04-01 11:52:03 --> Config Class Initialized
DEBUG - 2015-04-01 11:52:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:52:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:52:03 --> URI Class Initialized
DEBUG - 2015-04-01 11:52:03 --> Router Class Initialized
DEBUG - 2015-04-01 11:52:03 --> Output Class Initialized
DEBUG - 2015-04-01 11:52:03 --> Security Class Initialized
DEBUG - 2015-04-01 11:52:03 --> Input Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Loader Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:52:04 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Session Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:52:04 --> Session routines successfully run
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Controller Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:52:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 11:52:04 --> Config Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:52:04 --> URI Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Router Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Output Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Security Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Input Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:52:04 --> Language Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Loader Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:52:04 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Session Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:52:04 --> Session routines successfully run
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Controller Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:52:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:52:04 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:52:04 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:52:04 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:52:04 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:52:04 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:52:04 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:52:04 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-01 11:52:04 --> Final output sent to browser
DEBUG - 2015-04-01 11:52:04 --> Total execution time: 0.0422
DEBUG - 2015-04-01 11:52:22 --> Config Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:52:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:52:22 --> URI Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Router Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Output Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Security Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Input Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:52:22 --> Language Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Loader Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:52:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Session Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:52:22 --> Session routines successfully run
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Controller Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:52:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:52:22 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:52:22 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:52:22 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:52:22 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:52:22 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:52:22 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:52:22 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 11:52:22 --> Final output sent to browser
DEBUG - 2015-04-01 11:52:22 --> Total execution time: 0.0588
DEBUG - 2015-04-01 11:52:25 --> Config Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:52:25 --> URI Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Router Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Output Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Security Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Input Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:52:25 --> Language Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Loader Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:52:25 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Session Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:52:25 --> Session routines successfully run
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Controller Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:52:25 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:52:25 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:52:25 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:52:25 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:52:25 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:52:25 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:52:25 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:52:25 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 11:52:25 --> Final output sent to browser
DEBUG - 2015-04-01 11:52:25 --> Total execution time: 0.0533
DEBUG - 2015-04-01 11:52:28 --> Config Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:52:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:52:28 --> URI Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Router Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Output Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Security Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Input Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:52:28 --> Language Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Loader Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:52:28 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Session Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:52:28 --> Session routines successfully run
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Controller Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Model Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:52:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:52:28 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:52:28 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:52:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:52:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:52:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:52:28 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:52:28 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:52:28 --> Final output sent to browser
DEBUG - 2015-04-01 11:52:28 --> Total execution time: 0.0644
DEBUG - 2015-04-01 11:53:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:53:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:53:48 --> URI Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Router Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Output Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Security Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Input Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:53:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Loader Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:53:48 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Session Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:53:48 --> Session routines successfully run
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Controller Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:53:48 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:53:48 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:53:48 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:53:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:53:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:53:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:53:48 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:53:48 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:53:48 --> Final output sent to browser
DEBUG - 2015-04-01 11:53:48 --> Total execution time: 0.0532
DEBUG - 2015-04-01 11:54:18 --> Config Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:54:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:54:18 --> URI Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Router Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Output Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Security Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Input Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:54:18 --> Language Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Loader Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:54:18 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Session Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:54:18 --> Session routines successfully run
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Controller Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:54:18 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:54:18 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:54:18 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:54:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:54:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:54:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:54:18 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:54:18 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 11:54:18 --> Final output sent to browser
DEBUG - 2015-04-01 11:54:18 --> Total execution time: 0.0568
DEBUG - 2015-04-01 11:54:21 --> Config Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:54:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:54:21 --> URI Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Router Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Output Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Security Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Input Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:54:21 --> Language Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Loader Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:54:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Session Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:54:21 --> Session routines successfully run
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Controller Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:54:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:54:21 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:54:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:54:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:54:21 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:54:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:54:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:54:21 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 11:54:21 --> Final output sent to browser
DEBUG - 2015-04-01 11:54:21 --> Total execution time: 0.0572
DEBUG - 2015-04-01 11:54:48 --> Config Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:54:48 --> URI Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Router Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Output Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Security Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Input Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:54:48 --> Language Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Loader Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:54:48 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Session Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:54:48 --> Session routines successfully run
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Controller Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Model Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:54:48 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:54:48 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:54:48 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:54:48 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:54:48 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:54:48 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:54:48 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:54:48 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 11:54:48 --> Final output sent to browser
DEBUG - 2015-04-01 11:54:48 --> Total execution time: 0.0458
DEBUG - 2015-04-01 11:55:13 --> Config Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Hooks Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Utf8 Class Initialized
DEBUG - 2015-04-01 11:55:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 11:55:13 --> URI Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Router Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Output Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Security Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Input Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 11:55:13 --> Language Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Loader Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 11:55:13 --> Database Driver Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Session Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Helper loaded: string_helper
DEBUG - 2015-04-01 11:55:13 --> Session routines successfully run
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Controller Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Model Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Helper loaded: form_helper
DEBUG - 2015-04-01 11:55:13 --> Form Validation Class Initialized
DEBUG - 2015-04-01 11:55:13 --> Pagination Class Initialized
DEBUG - 2015-04-01 11:55:13 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 11:55:13 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 11:55:13 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 11:55:13 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 11:55:13 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 11:55:13 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 11:55:13 --> Final output sent to browser
DEBUG - 2015-04-01 11:55:13 --> Total execution time: 0.0509
DEBUG - 2015-04-01 22:13:22 --> Config Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:13:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:13:22 --> URI Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Router Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Output Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Security Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Input Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:13:22 --> Language Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Loader Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:13:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Session Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:13:22 --> A session cookie was not found.
DEBUG - 2015-04-01 22:13:22 --> Session routines successfully run
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Controller Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Config Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:13:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:13:22 --> URI Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Router Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Output Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Security Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Input Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:13:22 --> Language Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Loader Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:13:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Session Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:13:22 --> Session routines successfully run
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Controller Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:13:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:13:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:13:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:13:22 --> Final output sent to browser
DEBUG - 2015-04-01 22:13:22 --> Total execution time: 0.0490
DEBUG - 2015-04-01 22:14:38 --> Config Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:14:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:14:38 --> URI Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Router Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Output Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Security Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Input Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:14:38 --> Language Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Loader Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:14:38 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Session Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:14:38 --> Session routines successfully run
DEBUG - 2015-04-01 22:14:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Controller Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:14:38 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:14:38 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:14:38 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:14:38 --> Final output sent to browser
DEBUG - 2015-04-01 22:14:38 --> Total execution time: 0.0702
DEBUG - 2015-04-01 22:14:52 --> Config Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:14:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:14:52 --> URI Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Router Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Output Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Security Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Input Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:14:52 --> Language Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Loader Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:14:52 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Session Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:14:52 --> Session routines successfully run
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Controller Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:14:52 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:14:52 --> Config Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:14:52 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:14:52 --> URI Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Router Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Output Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Security Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Input Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:14:52 --> Language Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Loader Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:14:52 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Session Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:14:52 --> Session routines successfully run
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Controller Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:14:52 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:14:52 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:14:52 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:14:52 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:14:52 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:14:52 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:14:52 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:14:52 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-01 22:14:52 --> Final output sent to browser
DEBUG - 2015-04-01 22:14:52 --> Total execution time: 0.0527
DEBUG - 2015-04-01 22:14:55 --> Config Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:14:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:14:55 --> URI Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Router Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Output Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Security Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Input Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:14:55 --> Language Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Loader Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:14:55 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Session Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:14:55 --> Session routines successfully run
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Controller Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:14:55 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:14:55 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:14:55 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:14:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:14:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:14:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:14:55 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:14:55 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:14:55 --> Final output sent to browser
DEBUG - 2015-04-01 22:14:55 --> Total execution time: 0.0583
DEBUG - 2015-04-01 22:15:00 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:00 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:00 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:00 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:00 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:00 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:15:00 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:15:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:15:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:15:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:15:00 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:15:00 --> File loaded: application/views/commission/managerCommView.php
DEBUG - 2015-04-01 22:15:00 --> Final output sent to browser
DEBUG - 2015-04-01 22:15:00 --> Total execution time: 0.0752
DEBUG - 2015-04-01 22:15:21 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:21 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:21 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:21 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:21 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:21 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:21 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:21 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:15:21 --> Final output sent to browser
DEBUG - 2015-04-01 22:15:21 --> Total execution time: 0.0331
DEBUG - 2015-04-01 22:15:34 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:34 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:34 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:34 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:34 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:34 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:15:34 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:34 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:34 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:34 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:34 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:34 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:34 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:34 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:15:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:15:34 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:15:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:15:34 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:15:34 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-01 22:15:34 --> Final output sent to browser
DEBUG - 2015-04-01 22:15:34 --> Total execution time: 0.0468
DEBUG - 2015-04-01 22:15:36 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:36 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:36 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:36 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:36 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:15:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:15:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:15:36 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:15:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:15:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:15:36 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:15:36 --> Final output sent to browser
DEBUG - 2015-04-01 22:15:36 --> Total execution time: 0.0592
DEBUG - 2015-04-01 22:15:38 --> Config Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:15:38 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:15:38 --> URI Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Router Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Output Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Security Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Input Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:15:38 --> Language Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Loader Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:15:38 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Session Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:15:38 --> Session routines successfully run
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Controller Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Model Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:15:38 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:15:38 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:15:38 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:15:38 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:15:38 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:15:38 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:15:38 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:15:38 --> File loaded: application/views/commission/salesCommView.php
DEBUG - 2015-04-01 22:15:38 --> Final output sent to browser
DEBUG - 2015-04-01 22:15:38 --> Total execution time: 0.0654
DEBUG - 2015-04-01 22:16:14 --> Config Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:16:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:16:14 --> URI Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Router Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Output Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Security Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Input Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:16:14 --> Language Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Loader Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:16:14 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Session Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:16:14 --> Session routines successfully run
DEBUG - 2015-04-01 22:16:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Controller Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:16:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:16:14 --> Config Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:16:15 --> URI Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Router Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Output Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Security Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Input Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:16:15 --> Language Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Loader Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:16:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Session Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:16:15 --> Session routines successfully run
DEBUG - 2015-04-01 22:16:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Controller Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:16:15 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:16:15 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:16:15 --> Final output sent to browser
DEBUG - 2015-04-01 22:16:15 --> Total execution time: 0.0357
DEBUG - 2015-04-01 22:16:30 --> Config Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:16:30 --> URI Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Router Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Output Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Security Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Input Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:16:30 --> Language Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Loader Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:16:30 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Session Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:16:30 --> Session routines successfully run
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Controller Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:16:30 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:16:30 --> Config Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:16:30 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:16:30 --> URI Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Router Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Output Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Security Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Input Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:16:30 --> Language Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Loader Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:16:30 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Session Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:16:30 --> Session routines successfully run
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Controller Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Model Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:16:30 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:16:30 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:16:30 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:16:30 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:16:30 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:16:30 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:16:30 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:16:30 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-01 22:16:30 --> Final output sent to browser
DEBUG - 2015-04-01 22:16:30 --> Total execution time: 0.0414
DEBUG - 2015-04-01 22:17:19 --> Config Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:17:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:17:19 --> URI Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Router Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Output Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Security Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Input Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:17:19 --> Language Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Loader Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:17:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Session Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:17:19 --> Session routines successfully run
DEBUG - 2015-04-01 22:17:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Controller Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:17:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:17:19 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:17:19 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:17:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:17:19 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:17:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:17:19 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:17:19 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-01 22:17:19 --> Final output sent to browser
DEBUG - 2015-04-01 22:17:19 --> Total execution time: 0.0511
DEBUG - 2015-04-01 22:17:36 --> Config Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:17:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:17:36 --> URI Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Router Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Output Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Security Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Input Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:17:36 --> Language Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Loader Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:17:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Session Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:17:36 --> Session routines successfully run
DEBUG - 2015-04-01 22:17:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Controller Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:17:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:17:36 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:17:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:17:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:17:36 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:17:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:17:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:17:36 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-01 22:17:36 --> Final output sent to browser
DEBUG - 2015-04-01 22:17:36 --> Total execution time: 0.0431
DEBUG - 2015-04-01 22:17:53 --> Config Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:17:53 --> URI Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Router Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Output Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Security Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Input Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:17:53 --> Language Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Loader Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:17:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Session Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:17:53 --> Session routines successfully run
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Controller Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:17:53 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:17:53 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:17:53 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:17:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:17:53 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:17:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:17:53 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:17:53 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 22:17:53 --> Final output sent to browser
DEBUG - 2015-04-01 22:17:53 --> Total execution time: 0.0639
DEBUG - 2015-04-01 22:17:58 --> Config Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:17:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:17:58 --> URI Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Router Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Output Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Security Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Input Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:17:58 --> Language Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Loader Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:17:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Session Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:17:58 --> Session routines successfully run
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Controller Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:17:58 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:17:58 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:17:58 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:17:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:17:58 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:17:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:17:58 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:17:58 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 22:17:58 --> Final output sent to browser
DEBUG - 2015-04-01 22:17:58 --> Total execution time: 0.0581
DEBUG - 2015-04-01 22:18:14 --> Config Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:18:14 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:18:14 --> URI Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Router Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Output Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Security Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Input Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:18:14 --> Language Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Loader Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:18:14 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Session Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:18:14 --> Session routines successfully run
DEBUG - 2015-04-01 22:18:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Controller Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:18:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:18:14 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:18:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:18:14 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:18:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:18:14 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:18:14 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-04-01 22:18:14 --> Final output sent to browser
DEBUG - 2015-04-01 22:18:14 --> Total execution time: 0.0549
DEBUG - 2015-04-01 22:18:15 --> Config Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:18:15 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:18:15 --> URI Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Router Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Output Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Security Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Input Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:18:15 --> Language Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Loader Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:18:15 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Session Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:18:15 --> Session routines successfully run
DEBUG - 2015-04-01 22:18:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Controller Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:15 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:18:15 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:18:15 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:18:15 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:18:15 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:18:15 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:18:15 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:18:15 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-04-01 22:18:15 --> Final output sent to browser
DEBUG - 2015-04-01 22:18:15 --> Total execution time: 0.0438
DEBUG - 2015-04-01 22:18:17 --> Config Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:18:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:18:17 --> URI Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Router Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Output Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Security Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Input Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:18:17 --> Language Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Loader Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:18:17 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Session Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:18:17 --> Session routines successfully run
DEBUG - 2015-04-01 22:18:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Controller Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:17 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:18:17 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:18:17 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:18:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:18:17 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:18:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:18:17 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:18:17 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-01 22:18:17 --> Final output sent to browser
DEBUG - 2015-04-01 22:18:17 --> Total execution time: 0.0503
DEBUG - 2015-04-01 22:18:18 --> Config Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:18:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:18:18 --> URI Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Router Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Output Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Security Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Input Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:18:18 --> Language Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Loader Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:18:18 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Session Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:18:18 --> Session routines successfully run
DEBUG - 2015-04-01 22:18:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Controller Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:18:18 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:18:18 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:18:18 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:18:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:18:18 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:18:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:18:18 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:18:18 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-01 22:18:18 --> Final output sent to browser
DEBUG - 2015-04-01 22:18:18 --> Total execution time: 0.0431
DEBUG - 2015-04-01 22:18:22 --> Config Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:18:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:18:22 --> URI Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Router Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Output Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Security Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Input Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:18:22 --> Language Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Loader Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:18:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Session Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:18:22 --> Session routines successfully run
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Controller Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:18:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Config Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:18:22 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:18:22 --> URI Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Router Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Output Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Security Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Input Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:18:22 --> Language Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Loader Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:18:22 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Session Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:18:22 --> Session routines successfully run
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Controller Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Model Class Initialized
DEBUG - 2015-04-01 22:18:22 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:18:22 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:18:22 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:18:22 --> Final output sent to browser
DEBUG - 2015-04-01 22:18:22 --> Total execution time: 0.0326
DEBUG - 2015-04-01 22:19:09 --> Config Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:19:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:19:09 --> URI Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Router Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Output Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Security Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Input Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:19:09 --> Language Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Loader Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:19:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Session Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:19:09 --> Session routines successfully run
DEBUG - 2015-04-01 22:19:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Controller Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:19:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:19:09 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:19:09 --> Final output sent to browser
DEBUG - 2015-04-01 22:19:09 --> Total execution time: 0.0419
DEBUG - 2015-04-01 22:19:12 --> Config Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:19:12 --> URI Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Router Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Output Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Security Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Input Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:19:12 --> Language Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Loader Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:19:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Session Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:19:12 --> Session routines successfully run
DEBUG - 2015-04-01 22:19:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Controller Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:19:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:19:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:19:12 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:19:12 --> Final output sent to browser
DEBUG - 2015-04-01 22:19:12 --> Total execution time: 0.0362
DEBUG - 2015-04-01 22:21:44 --> Config Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:21:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:21:44 --> URI Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Router Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Output Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Security Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Input Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:21:44 --> Language Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Loader Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:21:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Session Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:21:44 --> Session routines successfully run
DEBUG - 2015-04-01 22:21:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Controller Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:21:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:21:44 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:21:44 --> Final output sent to browser
DEBUG - 2015-04-01 22:21:44 --> Total execution time: 0.0351
DEBUG - 2015-04-01 22:21:47 --> Config Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:21:47 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:21:47 --> URI Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Router Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Output Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Security Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Input Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:21:47 --> Language Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Loader Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:21:47 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Session Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:21:47 --> Session routines successfully run
DEBUG - 2015-04-01 22:21:47 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Controller Class Initialized
DEBUG - 2015-04-01 22:21:47 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:48 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:48 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:48 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:48 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:21:48 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:21:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:21:48 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:21:48 --> Final output sent to browser
DEBUG - 2015-04-01 22:21:48 --> Total execution time: 0.0364
DEBUG - 2015-04-01 22:21:50 --> Config Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:21:50 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:21:50 --> URI Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Router Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Output Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Security Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Input Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:21:50 --> Language Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Loader Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:21:50 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Session Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:21:50 --> Session routines successfully run
DEBUG - 2015-04-01 22:21:50 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Controller Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Model Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:21:50 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:21:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:21:50 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:21:50 --> Final output sent to browser
DEBUG - 2015-04-01 22:21:50 --> Total execution time: 0.0409
DEBUG - 2015-04-01 22:22:33 --> Config Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:22:33 --> URI Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Router Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Output Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Security Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Input Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:22:33 --> Language Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Loader Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:22:33 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Session Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:22:33 --> Session routines successfully run
DEBUG - 2015-04-01 22:22:33 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Controller Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:33 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:22:33 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:22:33 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:22:33 --> Final output sent to browser
DEBUG - 2015-04-01 22:22:33 --> Total execution time: 0.0355
DEBUG - 2015-04-01 22:22:34 --> Config Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:22:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:22:34 --> URI Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Router Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Output Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Security Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Input Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:22:34 --> Language Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Loader Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:22:34 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Session Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:22:34 --> Session routines successfully run
DEBUG - 2015-04-01 22:22:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Controller Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:22:34 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:22:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:22:34 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:22:34 --> Final output sent to browser
DEBUG - 2015-04-01 22:22:34 --> Total execution time: 0.0441
DEBUG - 2015-04-01 22:22:36 --> Config Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:22:36 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:22:36 --> URI Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Router Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Output Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Security Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Input Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:22:36 --> Language Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Loader Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:22:36 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Session Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:22:36 --> Session routines successfully run
DEBUG - 2015-04-01 22:22:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Controller Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Model Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:22:36 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:22:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:22:36 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:22:36 --> Final output sent to browser
DEBUG - 2015-04-01 22:22:36 --> Total execution time: 0.0346
DEBUG - 2015-04-01 22:23:01 --> Config Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:23:01 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:23:01 --> URI Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Router Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Output Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Security Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Input Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:23:01 --> Language Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Loader Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:23:01 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Session Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:23:01 --> Session routines successfully run
DEBUG - 2015-04-01 22:23:01 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Controller Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:23:01 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:23:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:23:01 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:23:01 --> Final output sent to browser
DEBUG - 2015-04-01 22:23:01 --> Total execution time: 0.0385
DEBUG - 2015-04-01 22:23:19 --> Config Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:23:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:23:19 --> URI Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Router Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Output Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Security Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Input Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:23:19 --> Language Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Loader Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:23:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Session Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:23:19 --> Session routines successfully run
DEBUG - 2015-04-01 22:23:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Controller Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:23:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:23:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:23:19 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:23:19 --> Final output sent to browser
DEBUG - 2015-04-01 22:23:19 --> Total execution time: 0.0348
DEBUG - 2015-04-01 22:23:31 --> Config Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:23:31 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:23:31 --> URI Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Router Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Output Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Security Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Input Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:23:31 --> Language Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Loader Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:23:31 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Session Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:23:31 --> Session routines successfully run
DEBUG - 2015-04-01 22:23:31 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Controller Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:31 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:23:31 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:23:31 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:23:31 --> Final output sent to browser
DEBUG - 2015-04-01 22:23:31 --> Total execution time: 0.0416
DEBUG - 2015-04-01 22:23:41 --> Config Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:23:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:23:41 --> URI Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Router Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Output Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Security Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Input Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:23:41 --> Language Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Loader Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:23:41 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Session Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:23:41 --> Session routines successfully run
DEBUG - 2015-04-01 22:23:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Controller Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:23:41 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:23:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:23:41 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:23:41 --> Final output sent to browser
DEBUG - 2015-04-01 22:23:41 --> Total execution time: 0.0341
DEBUG - 2015-04-01 22:24:08 --> Config Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:24:08 --> URI Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Router Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Output Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Security Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Input Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:24:08 --> Language Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Loader Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:24:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Session Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:24:08 --> Session routines successfully run
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Controller Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:24:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:24:08 --> Config Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:24:08 --> URI Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Router Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Output Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Security Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Input Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:24:08 --> Language Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Loader Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:24:08 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Session Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:24:08 --> Session routines successfully run
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Controller Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Model Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:24:08 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:24:08 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:24:08 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:24:08 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:24:08 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:24:08 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:24:08 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:24:08 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-01 22:24:08 --> Final output sent to browser
DEBUG - 2015-04-01 22:24:08 --> Total execution time: 0.0507
DEBUG - 2015-04-01 22:27:13 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:13 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:13 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:13 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:13 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:14 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:14 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:14 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:14 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:14 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:14 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:14 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:14 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:14 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:14 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-01 22:27:14 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:14 --> Total execution time: 0.0395
DEBUG - 2015-04-01 22:27:17 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:17 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:17 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:17 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:17 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:17 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:17 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:17 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:17 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:17 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:17 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:17 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:17 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:17 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 22:27:17 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:17 --> Total execution time: 0.0609
DEBUG - 2015-04-01 22:27:18 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:18 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:18 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:18 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:18 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:18 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:18 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:18 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:18 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:18 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:18 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:18 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:18 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:18 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 22:27:18 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:18 --> Total execution time: 0.0613
DEBUG - 2015-04-01 22:27:24 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:24 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:24 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:24 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:24 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:24 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:24 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:24 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:24 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:24 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:24 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:24 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:24 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:24 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:27:24 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:24 --> Total execution time: 0.0542
DEBUG - 2015-04-01 22:27:26 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:26 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:26 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:26 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:26 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:26 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:26 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:26 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:26 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:26 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:26 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:26 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:26 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:26 --> File loaded: application/views/commission/managerCommView.php
DEBUG - 2015-04-01 22:27:26 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:26 --> Total execution time: 0.0560
DEBUG - 2015-04-01 22:27:32 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:32 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:32 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:32 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:32 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:32 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:32 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:32 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:32 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:32 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:32 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:32 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:32 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:27:32 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:32 --> Total execution time: 0.0527
DEBUG - 2015-04-01 22:27:34 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:34 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:34 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:34 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:34 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:34 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:34 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:34 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:27:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:34 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:34 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 22:27:34 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:34 --> Total execution time: 0.0564
DEBUG - 2015-04-01 22:27:44 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:44 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:44 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:44 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:44 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:44 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:44 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:44 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:44 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:44 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:44 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:44 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:27:44 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:44 --> Total execution time: 0.0321
DEBUG - 2015-04-01 22:27:53 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:53 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:53 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:53 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:53 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:27:53 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:53 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:53 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:53 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:53 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:53 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:53 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:53 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:53 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:53 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:27:53 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:53 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:53 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-01 22:27:53 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:53 --> Total execution time: 0.0413
DEBUG - 2015-04-01 22:27:58 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:58 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:58 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:58 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:58 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:58 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:58 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:58 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:27:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:58 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:58 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 22:27:58 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:58 --> Total execution time: 0.0618
DEBUG - 2015-04-01 22:27:59 --> Config Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:27:59 --> URI Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Router Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Output Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Security Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Input Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:27:59 --> Language Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Loader Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:27:59 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Session Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:27:59 --> Session routines successfully run
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Controller Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Model Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:27:59 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:27:59 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:27:59 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:27:59 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:27:59 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:27:59 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:27:59 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:27:59 --> File loaded: application/views/invoice/invoiceView.php
DEBUG - 2015-04-01 22:27:59 --> Final output sent to browser
DEBUG - 2015-04-01 22:27:59 --> Total execution time: 0.0614
DEBUG - 2015-04-01 22:28:03 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:03 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:03 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:03 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:03 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:03 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:03 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:03 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:28:03 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:03 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:03 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:28:03 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:03 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:03 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:28:03 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:03 --> Total execution time: 0.0550
DEBUG - 2015-04-01 22:28:05 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:05 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:05 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:05 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:05 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:05 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:05 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:28:05 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:05 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:05 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:28:05 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:05 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:05 --> File loaded: application/views/commission/salesCommView.php
DEBUG - 2015-04-01 22:28:05 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:05 --> Total execution time: 0.0500
DEBUG - 2015-04-01 22:28:16 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:16 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:16 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:16 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:16 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:16 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:16 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:16 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:28:16 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:16 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:16 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:28:16 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:16 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:16 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 22:28:16 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:16 --> Total execution time: 0.0555
DEBUG - 2015-04-01 22:28:19 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:19 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:19 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:19 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:19 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:19 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:19 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:28:19 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:19 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:19 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-04-01 22:28:19 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:19 --> Total execution time: 0.0554
DEBUG - 2015-04-01 22:28:20 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:20 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:20 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:20 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:20 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:20 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:20 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:20 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:20 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:20 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:20 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:20 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:28:20 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:20 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:20 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-04-01 22:28:20 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:20 --> Total execution time: 0.0475
DEBUG - 2015-04-01 22:28:21 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:21 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:21 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:21 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:21 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:21 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:21 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:21 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:21 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:21 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:21 --> File loaded: application/views/sidebar_agent.php
DEBUG - 2015-04-01 22:28:21 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:21 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:21 --> File loaded: application/views/message/inboxView.php
DEBUG - 2015-04-01 22:28:21 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:21 --> Total execution time: 0.0440
DEBUG - 2015-04-01 22:28:23 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:23 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:23 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:23 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:23 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:23 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:23 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:23 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:23 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:23 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:23 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:23 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:23 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:28:23 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:23 --> Total execution time: 0.0297
DEBUG - 2015-04-01 22:28:35 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:35 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:35 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:35 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:35 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:35 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:28:35 --> Config Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:28:35 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:28:35 --> URI Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Router Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Output Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Security Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Input Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:28:35 --> Language Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Loader Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:28:35 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Session Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:28:35 --> Session routines successfully run
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Controller Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Model Class Initialized
DEBUG - 2015-04-01 22:28:35 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:28:35 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:28:36 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:28:36 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:28:36 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:28:36 --> File loaded: application/views/sidebar_customer.php
DEBUG - 2015-04-01 22:28:36 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:28:36 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:28:36 --> File loaded: application/views/customer/profileView.php
DEBUG - 2015-04-01 22:28:36 --> Final output sent to browser
DEBUG - 2015-04-01 22:28:36 --> Total execution time: 0.0382
DEBUG - 2015-04-01 22:32:04 --> Config Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:32:04 --> URI Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Router Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Output Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Security Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Input Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:32:04 --> Language Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Loader Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:32:04 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Session Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:32:04 --> Session routines successfully run
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Controller Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:32:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Config Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:32:04 --> URI Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Router Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Output Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Security Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Input Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:32:04 --> Language Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Loader Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:32:04 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Session Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:32:04 --> Session routines successfully run
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Controller Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:04 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:32:04 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:32:04 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:32:04 --> Final output sent to browser
DEBUG - 2015-04-01 22:32:04 --> Total execution time: 0.0409
DEBUG - 2015-04-01 22:32:09 --> Config Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:32:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:32:09 --> URI Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Router Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Output Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Security Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Input Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:32:09 --> Language Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Loader Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:32:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Session Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:32:09 --> Session routines successfully run
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Controller Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:32:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:32:09 --> Config Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:32:09 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:32:09 --> URI Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Router Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Output Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Security Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Input Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:32:09 --> Language Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Loader Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:32:09 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Session Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:32:09 --> Session routines successfully run
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Controller Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:32:09 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:32:09 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:32:09 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:32:09 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:32:09 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:32:09 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:32:09 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:32:09 --> File loaded: application/views/agent/agentListView.php
DEBUG - 2015-04-01 22:32:09 --> Final output sent to browser
DEBUG - 2015-04-01 22:32:09 --> Total execution time: 0.0414
DEBUG - 2015-04-01 22:32:12 --> Config Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:32:12 --> URI Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Router Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Output Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Security Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Input Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:32:12 --> Language Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Loader Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:32:12 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Session Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:32:12 --> Session routines successfully run
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Controller Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:32:12 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:32:12 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:32:12 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:32:12 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:32:12 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:32:12 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:32:12 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:32:12 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:32:12 --> Final output sent to browser
DEBUG - 2015-04-01 22:32:12 --> Total execution time: 0.0647
DEBUG - 2015-04-01 22:32:28 --> Config Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:32:28 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:32:28 --> URI Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Router Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Output Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Security Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Input Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:32:28 --> Language Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Loader Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:32:28 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Session Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:32:28 --> Session routines successfully run
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Controller Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Model Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:32:28 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:32:28 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:32:28 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:32:28 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:32:28 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:32:28 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:32:28 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:32:28 --> File loaded: application/views/commission/managerCommView.php
DEBUG - 2015-04-01 22:32:28 --> Final output sent to browser
DEBUG - 2015-04-01 22:32:28 --> Total execution time: 0.0489
DEBUG - 2015-04-01 22:50:55 --> Config Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:50:55 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:50:55 --> URI Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Router Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Output Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Security Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Input Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:50:55 --> Language Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Loader Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:50:55 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Session Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:50:55 --> Session routines successfully run
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Controller Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:50:55 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:50:55 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:50:55 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:50:55 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:50:55 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:50:55 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:50:55 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:50:55 --> File loaded: application/views/invoice/invoiceListView.php
DEBUG - 2015-04-01 22:50:55 --> Final output sent to browser
DEBUG - 2015-04-01 22:50:55 --> Total execution time: 0.0645
DEBUG - 2015-04-01 22:50:57 --> Config Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:50:57 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:50:57 --> URI Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Router Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Output Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Security Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Input Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:50:57 --> Language Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Loader Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:50:57 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Session Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:50:57 --> Session routines successfully run
DEBUG - 2015-04-01 22:50:57 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Controller Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:57 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:50:57 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:50:57 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:50:57 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:50:57 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:50:57 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:50:57 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:50:57 --> File loaded: application/views/message/sentView.php
DEBUG - 2015-04-01 22:50:57 --> Final output sent to browser
DEBUG - 2015-04-01 22:50:57 --> Total execution time: 0.0508
DEBUG - 2015-04-01 22:50:58 --> Config Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:50:58 --> URI Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Router Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Output Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Security Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Input Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:50:58 --> Language Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Loader Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:50:58 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Session Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:50:58 --> Session routines successfully run
DEBUG - 2015-04-01 22:50:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Controller Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Model Class Initialized
DEBUG - 2015-04-01 22:50:58 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:50:58 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:50:58 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:50:58 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:50:58 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:50:58 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:50:58 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:50:58 --> File loaded: application/views/message/compose2View.php
DEBUG - 2015-04-01 22:50:58 --> Final output sent to browser
DEBUG - 2015-04-01 22:50:58 --> Total execution time: 0.0452
DEBUG - 2015-04-01 22:51:00 --> Config Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:51:00 --> URI Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Router Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Output Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Security Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Input Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:51:00 --> Language Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Loader Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:51:00 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Session Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:51:00 --> Session routines successfully run
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Controller Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:51:00 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:51:00 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:51:00 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:51:00 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:51:00 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:51:00 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:51:00 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:51:00 --> File loaded: application/views/commission/commissionListView.php
DEBUG - 2015-04-01 22:51:00 --> Final output sent to browser
DEBUG - 2015-04-01 22:51:00 --> Total execution time: 0.0538
DEBUG - 2015-04-01 22:51:19 --> Config Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:51:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:51:19 --> URI Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Router Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Output Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Security Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Input Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:51:19 --> Language Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Loader Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:51:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Session Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:51:19 --> Session routines successfully run
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Controller Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:51:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Config Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:51:19 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:51:19 --> URI Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Router Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Output Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Security Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Input Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:51:19 --> Language Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Loader Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:51:19 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Session Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:51:19 --> Session routines successfully run
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Controller Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:19 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:51:19 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:51:19 --> File loaded: application/views/loginView.php
DEBUG - 2015-04-01 22:51:19 --> Final output sent to browser
DEBUG - 2015-04-01 22:51:19 --> Total execution time: 0.0311
DEBUG - 2015-04-01 22:51:34 --> Config Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:51:34 --> URI Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Router Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Output Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Security Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Input Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:51:34 --> Language Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Loader Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:51:34 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Session Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:51:34 --> Session routines successfully run
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Controller Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:51:34 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-04-01 22:51:34 --> Config Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:51:34 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:51:34 --> URI Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Router Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Output Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Security Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Input Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:51:34 --> Language Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Loader Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:51:34 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Session Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:51:34 --> Session routines successfully run
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Controller Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:51:34 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:51:34 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:51:34 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:51:34 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:51:34 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:51:34 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:51:34 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:51:34 --> File loaded: application/views/admin/adminListView.php
DEBUG - 2015-04-01 22:51:34 --> Final output sent to browser
DEBUG - 2015-04-01 22:51:34 --> Total execution time: 0.0444
DEBUG - 2015-04-01 22:51:41 --> Config Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Hooks Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Utf8 Class Initialized
DEBUG - 2015-04-01 22:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-04-01 22:51:41 --> URI Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Router Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Output Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Security Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Input Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Global POST and COOKIE data sanitized
DEBUG - 2015-04-01 22:51:41 --> Language Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Loader Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Helper loaded: url_helper
DEBUG - 2015-04-01 22:51:41 --> Database Driver Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Session Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Helper loaded: string_helper
DEBUG - 2015-04-01 22:51:41 --> Session routines successfully run
DEBUG - 2015-04-01 22:51:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Controller Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Model Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Helper loaded: form_helper
DEBUG - 2015-04-01 22:51:41 --> Form Validation Class Initialized
DEBUG - 2015-04-01 22:51:41 --> Pagination Class Initialized
DEBUG - 2015-04-01 22:51:41 --> File loaded: application/views/header.php
DEBUG - 2015-04-01 22:51:41 --> File loaded: application/views/navbar.php
DEBUG - 2015-04-01 22:51:41 --> File loaded: application/views/sidebar_admin.php
DEBUG - 2015-04-01 22:51:41 --> File loaded: application/views/sidebar.php
DEBUG - 2015-04-01 22:51:41 --> File loaded: application/views/footer.php
DEBUG - 2015-04-01 22:51:41 --> File loaded: application/views/customer/addCustomerView.php
DEBUG - 2015-04-01 22:51:41 --> Final output sent to browser
DEBUG - 2015-04-01 22:51:41 --> Total execution time: 0.0551
